/**
 * Safety Guard: Injection Blocker for Quizzes, Timed Assessments, and LTI launches.
 *
 * HARD RULE 2 (NON-NEGOTIABLE):
 * The panel must NOT inject or run on quiz-taking pages, timed assessments,
 * or LTI/New Quizzes launches (match URL patterns and known DOM markers;
 * make the list configurable; default to not running when unsure).
 * There is NO OVERRIDE.
 */
/**
 * Default blocked URL patterns representing quiz-taking, timed assessments,
 * and New Quizzes / LTI launches.
 */
export const DEFAULT_BLOCKED_URL_PATTERNS = [
    // Classic Canvas quiz taking
    /\/courses\/\d+\/quizzes\/\d+\/take(\/.*)?$/i,
    /\/courses\/\d+\/quizzes\/\d+\/take\/questions/i,
    /\/courses\/\d+\/quizzes\/\d+\/submissions/i,
    // Canvas assignments with quiz / assessment submissions in progress
    /\/courses\/\d+\/assignments\/\d+\/take/i,
    // LTI / New Quizzes launches & embeds
    /\/external_tools\/.*quiz.*/i,
    /\/external_tools\/.*assessment.*/i,
    /canvas\.quiz-lti-iad-prod\.instructure\.com/i,
    /launch_type=assessment/i,
    /launch_type=quiz/i,
    // Remote proctoring & lockdown browser indicators
    /proctorio/i,
    /honorlock/i,
    /respondus/i,
];
/**
 * Known DOM markers that unequivocally indicate active quiz-taking or timed exam environment.
 */
export const DEFAULT_BLOCKED_DOM_SELECTORS = [
    // Quiz forms
    '#submit_quiz_form',
    'form.take_quiz_form',
    'form#take_quiz_form',
    'div.quiz-submission',
    // Active timers
    '#quiz_timer',
    '#timer_running',
    '.quiz-timer',
    '.quiz-submission-timer',
    '[data-testid="timer-display"]',
    '[aria-label*="time remaining" i]',
    '[aria-label*="quiz timer" i]',
    // Active question forms & quiz questions
    '#questions.quiz-questions',
    'div.display_question.question',
    'div[data-testid="question-content"]',
    // LTI / New Quizzes embed containers
    'iframe#tool_content[src*="quiz"]',
    'iframe[data-testid="lti-frame"][src*="assessment"]',
    'iframe[src*="new_quizzes"]',
];
/**
 * Standard allowlisted Canvas top-level views where GRADIENT is permitted to inject.
 * When in doubt outside of these recognized views, default is FAIL-CLOSED.
 */
export const ALLOWED_CANVAS_PATH_PATTERNS = [
    /\/courses\/\d+\/?$/i,
    /\/courses\/\d+\/grades\/?$/i,
    /\/courses\/\d+\/assignments\/?$/i,
    /\/courses\/\d+\/assignments\/\d+\/?$/i,
    /\/courses\/\d+\/modules\/?$/i,
    /\/courses\/\d+\/pages\/?.*$/i,
    /\/courses\/\d+\/announcements\/?.*$/i,
    /\/courses\/\d+\/syllabus\/?$/i,
    /\/courses\/\d+\/files\/?.*$/i,
];
export class SafetyGuard {
    config;
    constructor(customConfig) {
        this.config = {
            blockedUrlPatterns: customConfig?.blockedUrlPatterns ?? DEFAULT_BLOCKED_URL_PATTERNS,
            blockedDomSelectors: customConfig?.blockedDomSelectors ?? DEFAULT_BLOCKED_DOM_SELECTORS,
            failClosedOnUnknownCourseUrl: customConfig?.failClosedOnUnknownCourseUrl ?? true,
        };
    }
    /**
     * Evaluate whether a URL matches any blocked quiz or assessment patterns.
     */
    matchesBlockedUrl(url) {
        for (const pattern of this.config.blockedUrlPatterns) {
            if (pattern.test(url)) {
                return { blocked: true, matchedPattern: pattern.source };
            }
        }
        return { blocked: false };
    }
    /**
     * Evaluate whether the DOM contains active assessment or quiz markers.
     */
    matchesBlockedDom(root) {
        if (!root)
            return { blocked: false };
        for (const selector of this.config.blockedDomSelectors) {
            try {
                const elem = root.querySelector(selector);
                if (elem) {
                    return { blocked: true, matchedSelector: selector };
                }
            }
            catch {
                // In case an older browser does not support complex pseudo-selectors, continue checking
                continue;
            }
        }
        return { blocked: false };
    }
    /**
     * Comprehensive injection check.
     * Default to NOT running when unsure (Fail-Closed).
     * NO OVERRIDE EXISTS.
     */
    canInject(url, domRoot) {
        // 1. Check blocked URL patterns
        const urlCheck = this.matchesBlockedUrl(url);
        if (urlCheck.blocked) {
            return {
                allowed: false,
                blocked: true,
                reason: `Blocked by URL safety rule: matches assessment pattern '${urlCheck.matchedPattern}'`,
            };
        }
        // 2. Check DOM markers
        if (domRoot) {
            const domCheck = this.matchesBlockedDom(domRoot);
            if (domCheck.blocked) {
                return {
                    allowed: false,
                    blocked: true,
                    reason: `Blocked by DOM safety marker: detected assessment element '${domCheck.matchedSelector}'`,
                };
            }
        }
        // 3. Fail-closed check: verify URL is within recognized safe Canvas course spaces
        if (this.config.failClosedOnUnknownCourseUrl) {
            const isRecognizedSafePath = ALLOWED_CANVAS_PATH_PATTERNS.some((pat) => pat.test(url));
            if (!isRecognizedSafePath) {
                return {
                    allowed: false,
                    blocked: true,
                    reason: `Blocked by fail-closed policy: URL '${url}' is not an explicitly allowlisted safe Canvas course path`,
                };
            }
        }
        return {
            allowed: true,
            blocked: false,
            reason: 'Safe to inject: URL is allowlisted and no quiz/assessment markers were detected',
        };
    }
}
export const defaultSafetyGuard = new SafetyGuard();
