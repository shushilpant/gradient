// extension/background.ts
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "GRADIENT_TOGGLE" });
  } catch {
    await chrome.runtime.openOptionsPage();
  }
});
