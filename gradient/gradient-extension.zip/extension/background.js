// extension/assistantTransport.ts
function validateBackendUrl(value) {
  let url;
  try {
    url = new URL(value);
  } catch {
    throw new Error("Enter a local backend URL, for example http://127.0.0.1:8765.");
  }
  if (url.protocol !== "http:" || !["127.0.0.1", "localhost"].includes(url.hostname) || url.username || url.password || url.search || url.hash || !["", "/"].includes(url.pathname)) {
    throw new Error("The AI backend must be an HTTP service on localhost.");
  }
  return url.origin;
}
function validateAssistantPath(path, method) {
  const get = method === "GET" && (/^\/api\/v1\/assistant\/health$/.test(path) || /^\/api\/v1\/assistant\/jobs\/[a-zA-Z0-9_-]{1,80}$/.test(path));
  const post = method === "POST" && /^\/api\/v1\/assistant\/(models\/pull|generate|browser\/plan|materials\/extract|jobs)$/.test(path);
  if (!get && !post) throw new Error("This local assistant operation is not supported.");
}
async function localAssistantFetch(backendUrl, path, method, body) {
  const origin = validateBackendUrl(backendUrl);
  validateAssistantPath(path, method);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 24e3);
  try {
    const response = await fetch(origin + path, {
      method,
      headers: { "Content-Type": "application/json", "X-Gradient-Client": "gradient-extension" },
      body: body === void 0 ? void 0 : JSON.stringify(body),
      credentials: "omit",
      redirect: "error",
      cache: "no-store",
      signal: controller.signal
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) {
      const detail = data?.detail;
      throw new Error(typeof detail === "string" ? detail : `The local assistant returned HTTP ${response.status}.`);
    }
    return data;
  } catch (error) {
    if (error instanceof Error && error.name === "AbortError") throw new Error("The local assistant took too long to respond. Check that the service is running.");
    if (error instanceof TypeError) throw new Error("Cannot reach the local AI service. Start it on 127.0.0.1:8765, then check the connection.");
    throw error;
  } finally {
    clearTimeout(timeout);
  }
}

// extension/deadlineCalendar.ts
var STORAGE_KEY = "gradient_deadline_tracking_v1";
var ALARM_PREFIX = "gradient-deadline:";
var HOUR = 60 * 60 * 1e3;
var emptyStore = () => ({ accounts: {}, delivered: {} });
var emptyState = () => ({ enabled: false, excludedIds: [], deadlines: [], updatedAt: "" });
var scope = (origin, userId) => `${origin}|${userId}`;
function reminderName(deadline, leadHours) {
  return `${ALARM_PREFIX}${encodeURIComponent(deadline.id)}:${Date.parse(deadline.dueAt)}:${leadHours}`;
}
function planDeadlineReminders(state, now = Date.now()) {
  if (!state.enabled) return [];
  const excluded = new Set(state.excludedIds);
  const reminders = /* @__PURE__ */ new Map();
  for (const deadline of state.deadlines) {
    if (excluded.has(deadline.id)) continue;
    const due = Date.parse(deadline.dueAt);
    if (!Number.isFinite(due)) continue;
    for (const leadHours of [24, 1]) {
      const when = due - leadHours * HOUR;
      if (when > now) {
        const name = reminderName(deadline, leadHours);
        reminders.set(name, { name, when, leadHours, deadline });
      }
    }
  }
  return [...reminders.values()].sort((a, b) => a.when - b.when);
}
async function readStore() {
  let stored;
  if (typeof chrome !== "undefined" && chrome.storage?.local) stored = (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY];
  else if (typeof localStorage !== "undefined") {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) try {
      stored = JSON.parse(raw);
    } catch {
    }
  }
  if (!stored || typeof stored !== "object") return emptyStore();
  const value = stored;
  return { accounts: value.accounts && typeof value.accounts === "object" ? value.accounts : {}, delivered: value.delivered && typeof value.delivered === "object" ? value.delivered : {} };
}
async function writeStore(store) {
  if (typeof chrome !== "undefined" && chrome.storage?.local) await chrome.storage.local.set({ [STORAGE_KEY]: store });
  else if (typeof localStorage !== "undefined") localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
}
function isDeadlineMessage(message) {
  return !!message && typeof message === "object" && ["GRADIENT_GET_TRACKING", "GRADIENT_TRACK_DEADLINES", "GRADIENT_SYNC_DEADLINES"].includes(String(message.type));
}
var queue = Promise.resolve();
function serialized(task) {
  const pending = queue.then(task, task);
  queue = pending.catch(() => {
  });
  return pending;
}
function validateMessage(message, sender) {
  if (typeof message.origin !== "string" || typeof message.userId !== "string" || !/^[\w-]{1,100}$/.test(message.userId)) throw new Error("Invalid Canvas reminder account.");
  const origin = new URL(message.origin).origin;
  if (origin !== message.origin || !sender.tab?.url || new URL(sender.tab.url).origin !== origin) throw new Error("Deadline reminders must come from your signed-in Canvas tab.");
  return { origin, userId: message.userId };
}
function validateDeadlines(raw, origin, userId) {
  if (!Array.isArray(raw) || raw.length > 5e3) throw new Error("Canvas returned too many deadlines to track.");
  const result = /* @__PURE__ */ new Map();
  for (const value of raw) {
    if (!value || typeof value !== "object") throw new Error("Invalid assignment deadline.");
    const deadline = value;
    if (["id", "origin", "userId", "courseId", "assignmentId", "title", "courseName", "courseCode", "dueAt", "url"].some((key) => typeof value[key] !== "string")) throw new Error("Invalid assignment deadline.");
    if (deadline.origin !== origin || deadline.userId !== userId || deadline.id !== `${scope(origin, userId)}|${deadline.courseId}|${deadline.assignmentId}` || !Number.isFinite(Date.parse(deadline.dueAt))) throw new Error("Invalid assignment deadline.");
    const url = new URL(deadline.url);
    if (url.origin !== origin || url.pathname !== `/courses/${encodeURIComponent(deadline.courseId)}/assignments/${encodeURIComponent(deadline.assignmentId)}`) throw new Error("Deadline links must point to the current Canvas account.");
    result.set(deadline.id, { ...deadline, title: deadline.title.slice(0, 1e3), courseName: deadline.courseName.slice(0, 1e3), courseCode: deadline.courseCode.slice(0, 200), dueAt: new Date(deadline.dueAt).toISOString() });
  }
  return [...result.values()];
}
async function scheduleDeadlineReminders(states) {
  if (typeof chrome === "undefined" || !chrome.alarms) return;
  const store = await readStore();
  const planned = (states ?? Object.values(store.accounts)).flatMap((state) => planDeadlineReminders(state));
  const desired = new Map(planned.filter((item) => !store.delivered[item.name]).map((item) => [item.name, item]));
  const existing = await chrome.alarms.getAll();
  for (const alarm of existing) if (alarm.name.startsWith(ALARM_PREFIX) && !desired.has(alarm.name)) await chrome.alarms.clear(alarm.name);
  const names = new Set(existing.map((alarm) => alarm.name));
  for (const reminder of desired.values()) if (!names.has(reminder.name)) await chrome.alarms.create(reminder.name, { when: reminder.when });
}
function handleDeadlineMessage(message, sender) {
  return serialized(async () => {
    try {
      const { origin, userId } = validateMessage(message, sender);
      const store = await readStore(), key = scope(origin, userId);
      const previous = store.accounts[key] ?? emptyState();
      if (message.type === "GRADIENT_GET_TRACKING") return { ok: true, state: previous };
      if (!["GRADIENT_TRACK_DEADLINES", "GRADIENT_SYNC_DEADLINES"].includes(String(message.type))) throw new Error("Unknown deadline request.");
      if (message.type === "GRADIENT_SYNC_DEADLINES" && !previous.enabled) return { ok: true, state: previous };
      const deadlines = validateDeadlines(message.deadlines, origin, userId);
      if (message.type === "GRADIENT_TRACK_DEADLINES" && typeof message.enabled !== "boolean") throw new Error("Choose whether to enable deadline reminders.");
      const excludedIds = message.excludedIds === void 0 ? previous.excludedIds : message.excludedIds;
      if (!Array.isArray(excludedIds) || excludedIds.some((id) => typeof id !== "string") || excludedIds.length > 5e3) throw new Error("Invalid reminder selection.");
      const state = {
        enabled: message.type === "GRADIENT_TRACK_DEADLINES" ? message.enabled : previous.enabled,
        excludedIds,
        deadlines,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      store.accounts[key] = state;
      store.delivered = Object.fromEntries(Object.entries(store.delivered).filter(([, timestamp]) => Number(timestamp) > Date.now() - 90 * 24 * HOUR));
      await writeStore(store);
      await scheduleDeadlineReminders();
      return { ok: true, state };
    } catch (error) {
      return { ok: false, error: error instanceof Error ? error.message : "Could not save deadline reminders." };
    }
  });
}
function initializeDeadlineReminders() {
  return serialized(() => scheduleDeadlineReminders());
}
function deliverDeadlineAlarm(alarm) {
  if (!alarm.name.startsWith(ALARM_PREFIX)) return Promise.resolve();
  return serialized(async () => {
    const store = await readStore();
    if (store.delivered[alarm.name]) return;
    for (const state of Object.values(store.accounts)) {
      if (!state.enabled) continue;
      for (const deadline of state.deadlines) {
        if (state.excludedIds.includes(deadline.id) || Date.parse(deadline.dueAt) <= Date.now()) continue;
        for (const leadHours of [24, 1]) if (alarm.name === reminderName(deadline, leadHours)) {
          await chrome.notifications.create(alarm.name, {
            type: "basic",
            iconUrl: chrome.runtime.getURL("extension/icons/icon128.png"),
            title: `${deadline.courseCode}: assignment due soon`,
            message: `${deadline.title}
Due ${new Date(deadline.dueAt).toLocaleString()}. Click to open in Canvas.`,
            priority: 1
          });
          store.delivered[alarm.name] = Date.now();
          await writeStore(store);
          return;
        }
      }
    }
  });
}
async function openDeadlineNotification(notificationId) {
  if (!notificationId.startsWith(ALARM_PREFIX)) return;
  const store = await readStore();
  for (const state of Object.values(store.accounts)) for (const deadline of state.deadlines) {
    if ([24, 1].some((hours) => notificationId === reminderName(deadline, hours))) {
      await chrome.tabs.create({ url: deadline.url });
      await chrome.notifications.clear(notificationId);
      return;
    }
  }
}

// extension/background.ts
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "GRADIENT_TOGGLE" });
  } catch {
    await chrome.runtime.openOptionsPage();
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return false;
  if (isDeadlineMessage(message)) {
    void handleDeadlineMessage(message, sender).then(sendResponse);
    return true;
  }
  if (message?.type === "GRADIENT_ASSISTANT_REQUEST") {
    void (async () => {
      if (typeof message.backendUrl !== "string" || typeof message.path !== "string" || !["GET", "POST"].includes(message.method)) throw new Error("Invalid local assistant request.");
      return localAssistantFetch(message.backendUrl, message.path, message.method, message.body);
    })().then((data) => sendResponse({ ok: true, data }), (error) => sendResponse({ ok: false, error: error instanceof Error ? error.message : "The local assistant request failed." }));
    return true;
  }
  if (message?.type === "GRADIENT_CAPTURE_CONTEXT") {
    void (async () => {
      if (!sender.tab?.id || sender.tab.windowId === void 0) throw new Error("Inspect the page from its Canvas tab.");
      const [active] = await chrome.tabs.query({ active: true, windowId: sender.tab.windowId });
      if (active?.id !== sender.tab.id) throw new Error("Keep the Canvas tab active while inspecting it.");
      try {
        const screenshot = await chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: "jpeg", quality: 55 });
        return { screenshot };
      } catch {
        return { warning: "Screenshot unavailable. Click the GRADIENT toolbar icon to grant active-tab access, then inspect again." };
      }
    })().then((data) => sendResponse({ ok: true, data }), (error) => sendResponse({ ok: false, error: error instanceof Error ? error.message : "Page capture failed." }));
    return true;
  }
  return false;
});
chrome.alarms.onAlarm.addListener((alarm) => {
  void deliverDeadlineAlarm(alarm).catch(console.error);
});
chrome.notifications.onClicked.addListener((id) => {
  void openDeadlineNotification(id).catch(console.error);
});
chrome.runtime.onStartup.addListener(() => {
  void initializeDeadlineReminders().catch(console.error);
});
chrome.runtime.onInstalled.addListener(() => {
  void initializeDeadlineReminders().catch(console.error);
});
