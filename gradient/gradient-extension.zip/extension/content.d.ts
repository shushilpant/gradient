/**
 * GRADIENT MV3 Content Script
 *
 * Injects a Shadow-DOM side panel into Canvas LMS pages.
 * Enforces Hard Rules:
 *  - Rule 1: Read-Only CanvasClient
 *  - Rule 2: Absolute quiz/assessment injection blocker (SafetyGuard)
 */
export declare function initializeGradient(): {
    status: 'injected' | 'blocked';
    reason: string;
};
