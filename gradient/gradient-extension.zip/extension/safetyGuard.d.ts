/**
 * Safety Guard: Injection Blocker for Quizzes, Timed Assessments, and LTI launches.
 *
 * HARD RULE 2 (NON-NEGOTIABLE):
 * The panel must NOT inject or run on quiz-taking pages, timed assessments,
 * or LTI/New Quizzes launches (match URL patterns and known DOM markers;
 * make the list configurable; default to not running when unsure).
 * There is NO OVERRIDE.
 */
export interface SafetyGuardConfig {
    blockedUrlPatterns: RegExp[];
    blockedDomSelectors: string[];
    failClosedOnUnknownCourseUrl: boolean;
}
/**
 * Default blocked URL patterns representing quiz-taking, timed assessments,
 * and New Quizzes / LTI launches.
 */
export declare const DEFAULT_BLOCKED_URL_PATTERNS: RegExp[];
/**
 * Known DOM markers that unequivocally indicate active quiz-taking or timed exam environment.
 */
export declare const DEFAULT_BLOCKED_DOM_SELECTORS: string[];
/**
 * Standard allowlisted Canvas top-level views where GRADIENT is permitted to inject.
 * When in doubt outside of these recognized views, default is FAIL-CLOSED.
 */
export declare const ALLOWED_CANVAS_PATH_PATTERNS: RegExp[];
export interface InjectionCheckResult {
    allowed: boolean;
    blocked: boolean;
    reason: string;
}
export declare class SafetyGuard {
    private config;
    constructor(customConfig?: Partial<SafetyGuardConfig>);
    /**
     * Evaluate whether a URL matches any blocked quiz or assessment patterns.
     */
    matchesBlockedUrl(url: string): {
        blocked: boolean;
        matchedPattern?: string;
    };
    /**
     * Evaluate whether the DOM contains active assessment or quiz markers.
     */
    matchesBlockedDom(root?: {
        querySelector(selector: string): unknown | null;
    } | null): {
        blocked: boolean;
        matchedSelector?: string;
    };
    /**
     * Comprehensive injection check.
     * Default to NOT running when unsure (Fail-Closed).
     * NO OVERRIDE EXISTS.
     */
    canInject(url: string, domRoot?: {
        querySelector(selector: string): unknown | null;
    } | null): InjectionCheckResult;
}
export declare const defaultSafetyGuard: SafetyGuard;
