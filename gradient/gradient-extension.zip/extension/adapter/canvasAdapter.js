import { CourseSchema, AssignmentGroupSchema, AssignmentSchema, SubmissionSchema, DEFAULT_GRADING_SCHEME, DEFAULT_GRADE_POINT_SCALE, } from '../../core/schema.js';
/**
 * Canvas LMS Adapter
 * Maps raw Canvas REST API payloads into Zod-validated neutral internal schema.
 */
export class CanvasAdapter {
    lmsName = 'Canvas LMS';
    parseCourse(raw, creditHours) {
        const data = raw;
        // Normalise grading scheme if provided by Canvas
        let gradingScheme = DEFAULT_GRADING_SCHEME.map((item) => ({ ...item }));
        const rawScheme = data.grading_standard ?? data.grading_scheme;
        if (Array.isArray(rawScheme) && rawScheme.length > 0) {
            gradingScheme = rawScheme.map((entry) => {
                // Canvas grading schemes can be [letter, fraction] or { name, value }
                let letter = 'F';
                let minPct = 0;
                if (Array.isArray(entry) && entry.length >= 2) {
                    letter = String(entry[0]);
                    const val = Number(entry[1]);
                    minPct = val <= 1.0 ? Math.round(val * 100) : val;
                }
                else if (typeof entry === 'object' && entry !== null) {
                    letter = String(entry.name ?? 'F');
                    const val = Number(entry.value ?? 0);
                    minPct = val <= 1.0 ? Math.round(val * 100) : val;
                }
                return { letter, minPct };
            });
        }
        const courseData = {
            id: String(data.id),
            name: data.name,
            creditHours,
            applyGroupWeights: Boolean(data.apply_assignment_group_weights),
            gradingScheme,
            gradePointScale: DEFAULT_GRADE_POINT_SCALE,
        };
        return CourseSchema.parse(courseData);
    }
    parseAssignmentGroups(rawList) {
        return rawList.map((item) => {
            const g = item;
            const rules = {
                dropLowest: g.rules?.drop_lowest ?? 0,
                dropHighest: g.rules?.drop_highest ?? 0,
                neverDrop: (g.rules?.never_drop ?? []).map((id) => String(id)),
            };
            const groupData = {
                id: String(g.id),
                name: g.name,
                weight: Number(g.group_weight ?? 0),
                rules,
            };
            return AssignmentGroupSchema.parse(groupData);
        });
    }
    parseAssignments(rawList) {
        return rawList.map((item) => {
            const a = item;
            let rubric;
            if (Array.isArray(a.rubric) && a.rubric.length > 0) {
                rubric = a.rubric.map((r) => ({
                    id: String(r.id),
                    description: r.description ?? '',
                    points: Number(r.points ?? 0),
                    ratings: (r.ratings ?? []).map((rat) => ({
                        id: rat.id ? String(rat.id) : undefined,
                        description: rat.description ?? '',
                        points: Number(rat.points ?? 0),
                    })),
                }));
            }
            const assignmentData = {
                id: String(a.id),
                groupId: String(a.assignment_group_id),
                name: a.name,
                pointsPossible: Number(a.points_possible ?? 0),
                dueAt: a.due_at ?? null,
                submissionTypes: a.submission_types ?? [],
                omitFromFinalGrade: Boolean(a.omit_from_final_grade),
                hasRubric: Boolean(rubric && rubric.length > 0),
                rubric,
            };
            return AssignmentSchema.parse(assignmentData);
        });
    }
    parseSubmissions(rawList) {
        return rawList.map((item) => {
            const s = item;
            // In Canvas, posted_at is null if grades are hidden under the posting policy
            const posted = s.posted_at !== null && s.posted_at !== undefined;
            let workflowState = 'graded';
            if (s.workflow_state === 'unsubmitted') {
                workflowState = 'unsubmitted';
            }
            else if (s.workflow_state === 'submitted') {
                workflowState = 'submitted';
            }
            else if (s.workflow_state === 'pending_review') {
                workflowState = 'pending_review';
            }
            const submissionData = {
                assignmentId: String(s.assignment_id),
                score: typeof s.score === 'number' ? s.score : null,
                excused: Boolean(s.excused),
                missing: Boolean(s.missing),
                late: Boolean(s.late),
                posted,
                workflowState,
            };
            return SubmissionSchema.parse(submissionData);
        });
    }
}
