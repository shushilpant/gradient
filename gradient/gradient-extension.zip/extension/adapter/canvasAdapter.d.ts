import { type LMSAdapter, type Course, type AssignmentGroup, type Assignment, type Submission } from '../../core/schema.js';
/**
 * Canvas LMS Adapter
 * Maps raw Canvas REST API payloads into Zod-validated neutral internal schema.
 */
export declare class CanvasAdapter implements LMSAdapter {
    readonly lmsName = "Canvas LMS";
    parseCourse(raw: unknown, creditHours: number): Course;
    parseAssignmentGroups(rawList: unknown[]): AssignmentGroup[];
    parseAssignments(rawList: unknown[]): Assignment[];
    parseSubmissions(rawList: unknown[]): Submission[];
}
