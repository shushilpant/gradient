/**
 * Canvas Read-Only Client
 *
 * HARD RULE 1 (NON-NEGOTIABLE):
 * READ-ONLY toward Canvas. All Canvas requests go through this single fetch wrapper
 * that throws on any method except GET. The extension never submits, posts, edits,
 * or answers anything in Canvas.
 */
export declare class CanvasReadOnlyViolationError extends Error {
    constructor(attemptedMethod: string);
}
export type SafeFetchOptions = Omit<RequestInit, 'method' | 'body'> & {
    method?: 'GET' | 'get';
};
/**
 * Verified single fetch wrapper for all Canvas LMS communications.
 * Enforces GET-only at the type level AND runtime level.
 */
export declare function safeCanvasFetch(input: string | URL, init?: RequestInit): Promise<Response>;
/**
 * Canvas REST API Client.
 * All operations are strictly GET requests using safeCanvasFetch.
 */
export declare class CanvasClient {
    private baseUrl;
    constructor(baseUrl?: string);
    /**
     * Helper to perform a typed safe GET request.
     */
    get<T>(endpoint: string, params?: Record<string, string | number | boolean>): Promise<T>;
    /**
     * Fetch all paginated pages from a Canvas API endpoint (using Link headers).
     * Capped to maxPages to prevent runaway pagination.
     */
    getAllPages<T>(endpoint: string, params?: Record<string, string | number | boolean>, maxPages?: number): Promise<T[]>;
    private extractNextPageUrl;
    fetchCourse(courseId: string | number): Promise<unknown>;
    fetchAssignmentGroups(courseId: string | number): Promise<unknown[]>;
    fetchAssignments(courseId: string | number): Promise<unknown[]>;
    fetchSubmissions(courseId: string | number): Promise<unknown[]>;
}
