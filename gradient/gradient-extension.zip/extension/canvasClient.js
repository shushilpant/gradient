/**
 * Canvas Read-Only Client
 *
 * HARD RULE 1 (NON-NEGOTIABLE):
 * READ-ONLY toward Canvas. All Canvas requests go through this single fetch wrapper
 * that throws on any method except GET. The extension never submits, posts, edits,
 * or answers anything in Canvas.
 */
export class CanvasReadOnlyViolationError extends Error {
    constructor(attemptedMethod) {
        super(`[SECURITY VIOLATION] Canvas mutation rejected: Method '${attemptedMethod}' is strictly forbidden. ` +
            `GRADIENT is strictly read-only and never modifies Canvas LMS state.`);
        this.name = 'CanvasReadOnlyViolationError';
    }
}
/**
 * Verified single fetch wrapper for all Canvas LMS communications.
 * Enforces GET-only at the type level AND runtime level.
 */
export async function safeCanvasFetch(input, init) {
    const method = (init?.method ?? 'GET').toUpperCase();
    if (method !== 'GET') {
        throw new CanvasReadOnlyViolationError(method);
    }
    if (init?.body !== undefined && init.body !== null) {
        throw new CanvasReadOnlyViolationError('GET_WITH_BODY');
    }
    // Ensure same-origin credentials and JSON accept header are set
    const headers = new Headers(init?.headers);
    if (!headers.has('Accept')) {
        headers.set('Accept', 'application/json');
    }
    const safeInit = {
        ...init,
        method: 'GET',
        credentials: 'include', // Uses student's active Canvas session
        headers,
    };
    return fetch(input, safeInit);
}
/**
 * Canvas REST API Client.
 * All operations are strictly GET requests using safeCanvasFetch.
 */
export class CanvasClient {
    baseUrl;
    constructor(baseUrl = '') {
        // Normalise base URL without trailing slash
        this.baseUrl = baseUrl.replace(/\/+$/, '');
    }
    /**
     * Helper to perform a typed safe GET request.
     */
    async get(endpoint, params) {
        const url = new URL(endpoint.startsWith('http') ? endpoint : `${this.baseUrl}${endpoint.startsWith('/') ? '' : '/'}${endpoint}`, typeof window !== 'undefined' ? window.location.origin : 'https://canvas.instructure.com');
        if (params) {
            for (const [key, value] of Object.entries(params)) {
                url.searchParams.append(key, String(value));
            }
        }
        const response = await safeCanvasFetch(url.toString());
        if (!response.ok) {
            throw new Error(`Canvas API error: HTTP ${response.status} ${response.statusText} for ${url.pathname}`);
        }
        return (await response.json());
    }
    /**
     * Fetch all paginated pages from a Canvas API endpoint (using Link headers).
     * Capped to maxPages to prevent runaway pagination.
     */
    async getAllPages(endpoint, params, maxPages = 10) {
        const results = [];
        let currentUrl = endpoint;
        let pageCount = 0;
        while (currentUrl && pageCount < maxPages) {
            const targetUrl = new URL(currentUrl.startsWith('http') ? currentUrl : `${this.baseUrl}${currentUrl.startsWith('/') ? '' : '/'}${currentUrl}`, typeof window !== 'undefined' ? window.location.origin : 'https://canvas.instructure.com');
            if (pageCount === 0 && params) {
                for (const [key, value] of Object.entries(params)) {
                    targetUrl.searchParams.append(key, String(value));
                }
            }
            const response = await safeCanvasFetch(targetUrl.toString());
            if (!response.ok) {
                throw new Error(`Canvas API error: HTTP ${response.status} on page ${pageCount + 1}`);
            }
            const items = (await response.json());
            if (Array.isArray(items)) {
                results.push(...items);
            }
            else {
                results.push(items);
                break;
            }
            // Parse Canvas RFC 5988 Link header for rel="next"
            const linkHeader = response.headers.get('Link');
            currentUrl = this.extractNextPageUrl(linkHeader);
            pageCount++;
        }
        return results;
    }
    extractNextPageUrl(linkHeader) {
        if (!linkHeader)
            return null;
        const links = linkHeader.split(',');
        for (const link of links) {
            const match = link.match(/<([^>]+)>;\s*rel="([^"]+)"/);
            if (match && match[2] === 'next') {
                return match[1] ?? null;
            }
        }
        return null;
    }
    // --- Verified Canvas Endpoints ---
    async fetchCourse(courseId) {
        return this.get(`/api/v1/courses/${courseId}`, {
            include: 'grading_scheme,total_scores',
        });
    }
    async fetchAssignmentGroups(courseId) {
        return this.getAllPages(`/api/v1/courses/${courseId}/assignment_groups`, {
            include: 'assignments,rules',
            per_page: 50,
        });
    }
    async fetchAssignments(courseId) {
        return this.getAllPages(`/api/v1/courses/${courseId}/assignments`, {
            include: 'rubric,submission',
            per_page: 50,
        });
    }
    async fetchSubmissions(courseId) {
        return this.getAllPages(`/api/v1/courses/${courseId}/students/submissions`, {
            student_ids: 'self',
            include: 'rubric_assessment',
            per_page: 50,
        });
    }
}
