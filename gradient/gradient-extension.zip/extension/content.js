"use strict";
(() => {
  // node_modules/preact/dist/preact.mjs
  var n;
  var t;
  var r;
  var i;
  var u;
  var f;
  var e;
  var o;
  var l;
  var c;
  var a;
  var s;
  var h = Symbol.for("pv");
  var p = {};
  var v = [];
  var y = /^m(i|n|o|s|text|space)$/;
  var w = Array.isArray;
  var d = v.slice;
  var _ = Object.assign;
  function g(n2) {
    n2 && n2.parentNode && n2.remove();
  }
  function k(n2, t3, r3) {
    var i3, u4, f4, e3 = {}, o4 = arguments.length;
    for (f4 in t3) "key" == f4 ? i3 = t3[f4] : "ref" == f4 && "function" != typeof n2 ? u4 = t3[f4] : e3[f4] = t3[f4];
    return o4 > 2 && (e3.children = o4 > 3 ? d.call(arguments, 2) : r3), m(n2, e3, i3, u4, null);
  }
  function m(r3, i3, u4, f4, e3) {
    var o4 = { type: r3, props: i3, key: u4, ref: f4, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: h, __v: e3 || ++t, __i: -1, __u: 0 };
    return !e3 && n.vnode && n.vnode(o4), o4;
  }
  function M(n2) {
    return n2.children;
  }
  function x(n2, t3) {
    this.props = n2, this.context = t3, this.__g = 0;
  }
  function S(n2, t3) {
    if (null == t3) return n2.__ && S(n2.__, n2.__i + 1);
    for (var r3; t3 < n2.__k.length; t3++) if ((r3 = n2.__k[t3]) && r3.__e) return r3.__e;
    return "function" != typeof n2.type || n2.props.__P ? null : S(n2);
  }
  function C(n2) {
    if ((n2 = n2.__) && n2.__c && !n2.props.__P) return n2.__e = null, n2.__k.some(function(t3) {
      return t3 && (n2.__e = t3.__e);
    }), C(n2);
  }
  function j(t3) {
    (8 & t3.__g || (t3.__g |= 8, i.push(t3), f++)) && u == n.debounceRendering || ((u = n.debounceRendering) || queueMicrotask)(L);
  }
  function L() {
    var t3, r3, o4, l3, c3, a4, s3, p3, v3;
    try {
      for (r3 = 1; i.length; ) i.length > r3 && i.sort(e), t3 = i.shift(), r3 = i.length, 8 & t3.__g && (l3 = void 0, c3 = void 0, a4 = (c3 = (o4 = t3).__v).__e, s3 = [], p3 = [], (v3 = o4.__P) && ((l3 = _({ constructor: h }, c3)).__v = c3.__v + 1, n.vnode && n.vnode(l3), V(v3, l3, c3, o4.__n, v3.namespaceURI, 32 & c3.__u ? [a4] : null, s3, a4 || S(c3), 32 & c3.__u, p3), l3.__v = c3.__v, l3.__.__k[l3.__i] = l3, D(s3, l3, p3), c3.__ = c3.__e = null, l3.__e != a4 && C(l3)));
    } finally {
      (f = i.length) && (u || queueMicrotask)(L);
    }
  }
  function H(n2, t3, r3, i3, u4, f4, e3, o4, l3, c3, a4) {
    var s3, h3, y3, w3, d3, _3, g3 = i3.__k || v, k3 = t3.length;
    for (l3 = I(r3, t3, g3, l3, k3), s3 = 0; s3 < k3; s3++) null != (y3 = r3.__k[s3]) && (h3 = ~y3.__i && g3[y3.__i] || p, y3.__i = s3, _3 = V(n2, y3, h3, u4, f4, e3, o4, l3, c3, a4), w3 = y3.__e, (h3.ref != y3.ref || 8 & h3.__u) && (h3.ref && F(h3.ref, null, y3, h3), y3.ref && a4.push(y3.ref, y3.__c || w3, y3)), d3 = d3 || w3, 4 & y3.__u ? (l3 = q(y3, l3, n2, !h3.__v), h3.__e && (h3.__e = null)) : "function" == typeof y3.type && void 0 !== _3 ? l3 = _3 : w3 && (l3 = w3.nextSibling), y3.__u &= -21);
    return r3.__e = d3, l3;
  }
  function I(n2, t3, r3, i3, u4) {
    var f4, e3, o4, l3, c3, a4, s3, p3, v3, y3 = r3.length, d3 = y3, _3 = 0, g3 = 0, k3 = n2.__k = Array(u4);
    for (f4 = 0; f4 < u4; f4++) null != (e3 = t3[f4]) && "boolean" != typeof e3 && "function" != typeof e3 ? ("object" != typeof e3 || e3.constructor === String ? e3 = k3[f4] = m(null, e3) : w(e3) ? e3 = k3[f4] = m(M, { children: e3 }) : e3.constructor === h && e3.__b ? e3 = k3[f4] = m(e3.type, e3.props, e3.key, e3.ref, e3.__v) : k3[f4] = e3, l3 = f4 + _3, e3.__ = n2, e3.__b = n2.__b + 1, o4 = null, ~(c3 = e3.__i = O(e3, r3, l3, d3)) && (d3--, (o4 = r3[c3]) && (o4.__u |= 2)), o4 && o4.__v ? (e3.__u |= 16, c3 == l3 - 1 ? _3-- : c3 == l3 + 1 ? _3++ : c3 != l3 && (c3 > l3 ? _3-- : _3++, g3 = 1)) : (~c3 || (u4 > y3 ? _3-- : u4 < y3 && _3++), "function" != typeof e3.type && (e3.__u |= 4))) : k3[f4] = null;
    if (g3) {
      for (a4 = [], s3 = [], f4 = 0; f4 < u4; f4++) if ((e3 = k3[f4]) && 16 & e3.__u) {
        for (_3 = 0, p3 = a4.length; _3 < p3; ) a4[v3 = _3 + p3 >> 1] < e3.__i ? _3 = v3 + 1 : p3 = v3;
        a4[_3] = e3.__i, s3[f4] = _3 + 1;
      }
      for (_3 = a4.length; f4--; ) s3[f4] && (s3[f4] == _3 ? _3-- : k3[f4].__u |= 4);
    }
    if (d3) for (f4 = 0; f4 < y3; f4++) !(o4 = r3[f4]) || 2 & o4.__u || (o4.__e == i3 && (i3 = S(o4)), G(o4, o4));
    return i3;
  }
  function q(n2, t3, r3, i3) {
    var u4, f4, e3, o4;
    if ("function" == typeof n2.type) {
      if (n2.props.__P) return t3;
      if (u4 = n2.__k) for (f4 = 0; f4 < u4.length; f4++) u4[f4] && (u4[f4].__ = n2, t3 = q(u4[f4], t3, r3, false));
      return t3;
    }
    for (t3 && !t3.parentNode && (t3 = S(n2)) && !t3.parentNode && (t3 = null), e3 = n2.__e, o4 = t3; o4 && 8 == o4.nodeType; ) o4 = o4.nextSibling;
    for (e3 != o4 && (!i3 && r3.moveBefore && e3.parentNode ? r3.moveBefore(e3, t3) : r3.insertBefore(e3, t3 || null)), t3 = e3; (t3 = t3 && t3.nextSibling) && 8 == t3.nodeType && !t3.data.startsWith("$s"); ) ;
    return t3;
  }
  function O(n2, t3, r3, i3) {
    var u4, f4 = n2.key, e3 = n2.type, o4 = t3[r3], l3 = o4 && !(2 & o4.__u);
    if (null === o4 && null == f4 || l3 && f4 == o4.key && e3 == o4.type) return r3;
    if (i3 > (l3 ? 1 : 0)) {
      for (u4 = r3 - 1; u4 >= 0; u4--) if ((o4 = t3[u4]) && !(2 & o4.__u) && f4 == o4.key && e3 == o4.type) return u4;
      for (u4 = r3 + 1; u4 < t3.length; u4++) if ((o4 = t3[u4]) && !(2 & o4.__u) && f4 == o4.key && e3 == o4.type) return u4;
    }
    return -1;
  }
  function P(n2, t3, r3) {
    null == r3 && (r3 = ""), "-" == t3[0] ? n2.setProperty(t3, r3) : n2[t3] = r3;
  }
  function T(n2, t3, r3, i3, u4) {
    var f4, e3;
    if ("style" == t3) if ("string" == typeof r3) n2.style.cssText = r3;
    else {
      if ("string" == typeof i3 && (n2.style.cssText = i3 = ""), i3) for (t3 in i3) r3 && t3 in r3 || P(n2.style, t3);
      if (r3) for (t3 in r3) i3 && r3[t3] == i3[t3] || P(n2.style, t3, r3[t3]);
    }
    else if ("o" == t3[0] && "n" == t3[1]) (n2.__e || (n2.__e = {}))[t3] = r3, r3 && i3 || (e3 = a[t3] || (a[t3] = N(t3)), (n2.__a || (n2.__a = {}))[t3] = c, f4 = t3 != (t3 = t3.replace(l, "$1")), (t3 = t3.slice(2))[0] < "a" && (t3 = t3.toLowerCase()), r3 ? n2.addEventListener(t3, e3, f4) : n2.removeEventListener(t3, e3, f4));
    else {
      if ("http://www.w3.org/2000/svg" == u4) t3 = t3.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
      else if ("width" != t3 && "height" != t3 && "href" != t3 && "list" != t3 && "form" != t3 && "tabIndex" != t3 && "download" != t3 && "rowSpan" != t3 && "colSpan" != t3 && "role" != t3 && "popover" != t3 && t3 in n2) try {
        return void (n2[t3] = null == r3 ? "" : r3);
      } catch (n3) {
      }
      if ("function" == typeof r3) return;
      null == r3 || false === r3 && "-" != t3[4] ? n2.removeAttribute(t3) : n2.setAttribute(t3, "popover" == t3 && 1 == r3 ? "" : r3);
    }
  }
  function N(t3) {
    return function(r3) {
      var i3 = this.__e;
      if (i3) {
        if (i3 = i3[t3], null == r3[o]) r3[o] = c++;
        else if (r3[o] < this.__a[t3]) return;
        return i3(n.event ? n.event(r3) : r3);
      }
    };
  }
  function V(t3, r3, i3, u4, f4, e3, o4, l3, c3, a4) {
    var s3, p3, y3, d3, k3, b2, m3, $, C3, j2, L2, I2, q2, A2, O2, P2, T3, N2, V2 = r3.type;
    if (r3.constructor !== h) return null;
    128 & i3.__u && (c3 = 32 & i3.__u, s3 = i3.__c.__z) && (r3.__u |= c3, p3 = e3 = [], 8 == s3.nodeType ? l3 = z(s3, e3) : e3.push(s3), l3 = e3[0] || l3), (s3 = n.__b) && s3(r3);
    n: if ("function" == typeof V2) {
      y3 = o4.length;
      try {
        if ($ = r3.props, C3 = (s3 = V2.prototype) && s3.render, j2 = (s3 = V2.contextType) && u4[s3.__c], L2 = s3 ? j2 ? j2.props.value : s3.__ : u4, (d3 = i3.__c) ? (r3.__c = d3, 2 & d3.__g && (d3.__g |= 1)) : (C3 ? r3.__c = d3 = new V2($, L2) : (r3.__c = d3 = new x($, L2), d3.constructor = V2, d3.render = J), j2 && j2.sub(d3), d3.state || (d3.state = {}), d3.__n = u4, d3.__g |= 8, d3.__h = [], d3.__k = []), C3 && (d3.__s || (d3.__s = d3.state), V2.getDerivedStateFromProps && (d3.__s == d3.state && (d3.__s = _({}, d3.__s)), _(d3.__s, V2.getDerivedStateFromProps($, d3.__s)))), k3 = d3.props, b2 = d3.state, d3.__v = r3, i3.__c) {
          if ($ !== k3 && C3 && !V2.getDerivedStateFromProps && d3.componentWillReceiveProps && d3.componentWillReceiveProps($, L2), r3.__v == i3.__v && !(8 & d3.__g) || !(4 & d3.__g) && d3.shouldComponentUpdate && false === d3.shouldComponentUpdate($, d3.__s, L2)) {
            r3.__v != i3.__v && (d3.props = $, d3.state = d3.__s, d3.__g &= -9), r3.__e = i3.__e, r3.__k = i3.__k, r3.__k.some(function(n2) {
              n2 && (n2.__ = r3);
            }), v.push.apply(d3.__h, d3.__k), d3.__k = [], d3.__h.length && o4.push(d3), l3 = S(i3);
            break n;
          }
          d3.componentWillUpdate && d3.componentWillUpdate($, d3.__s, L2), C3 && d3.componentDidUpdate && d3.__h.push(function() {
            d3.componentDidUpdate(k3, b2, m3);
          });
        } else C3 && !V2.getDerivedStateFromProps && d3.componentWillMount && d3.componentWillMount(), C3 && d3.componentDidMount && d3.__h.push(d3.componentDidMount);
        if (d3.context = L2, d3.props = $, d3.__P = t3, d3.__g &= -5, I2 = n.__r, q2 = 0, C3) d3.state = d3.__s, d3.__g &= -9, I2 && I2(r3), s3 = d3.render(d3.props, d3.state, d3.context), v.push.apply(d3.__h, d3.__k), d3.__k = [];
        else do {
          d3.__g &= -9, I2 && I2(r3), s3 = d3.render(d3.props, d3.state, d3.context), d3.state = d3.__s;
        } while (8 & d3.__g && ++q2 < 25);
        d3.state = d3.__s, d3.getChildContext && (u4 = _({}, u4, d3.getChildContext())), C3 && i3.__c && d3.getSnapshotBeforeUpdate && (m3 = d3.getSnapshotBeforeUpdate(k3, b2)), A2 = s3 && s3.type === M && null == s3.key ? s3.props.children : s3, $.__P && (s3 = l3, f4 = (t3 = $.__P).namespaceURI, c3 = e3 = null, i3.props && i3.props.__P != t3 && (i3.__k.some(function(n2) {
          n2 && G(n2, n2);
        }), i3.__k = null), l3 = i3.__k ? S(i3, 0) : null), l3 = H(t3, w(A2) ? A2 : [A2], r3, i3, u4, f4, e3, o4, l3, c3, a4), $.__P && (r3.__e = null, l3 = s3), r3.__u &= -161, p3 && p3.some(g), d3.__h.length && o4.push(d3), 1 & d3.__g && (d3.__g &= -4);
      } catch (t4) {
        if (o4.length = y3, r3.__v = null, c3 || e3) if (t4.then) {
          if (O2 = 0, r3.__u |= 128 | c3, e3) {
            for (~(T3 = e3.indexOf(l3 || void 0)) || (T3 = e3.length); (N2 = e3[T3 - 1]) && 8 == N2.nodeType; ) T3--;
            for (; T3 < e3.length; T3++) if (N2 = e3[T3]) {
              if (e3[T3] = null, 8 == N2.nodeType) {
                if (N2.data.startsWith("$s")) O2++ || (P2 = N2);
                else if (O2 && N2.data.startsWith("/$s") && !--O2) break;
              } else if (!O2) break;
            }
          }
          if (!P2) {
            for (; l3 && 8 == l3.nodeType && l3.nextSibling; ) l3 = l3.nextSibling;
            P2 = l3;
          }
          (s3 = z(P2 = r3.__c.__z || (r3.__c.__z = P2))) ? (r3.__e = P2, l3 = s3) : r3.__e = l3, l3 = l3 && l3.nextSibling;
        } else e3 && e3.some(g);
        else r3.__e = i3.__e;
        r3.__k || (r3.__k = i3.__k || []), t4.then || B(r3), n.__e(t4, r3, i3);
      }
    } else l3 = r3.__e = E(i3.__e, r3, i3, u4, f4, e3, o4, c3, a4, t3);
    return (s3 = n.diffed) && s3(r3), l3;
  }
  function z(n2, t3) {
    if (n2 && 8 == n2.nodeType && n2.data.startsWith("$s")) for (var r3 = 1; n2 = n2.nextSibling; ) {
      if (8 == n2.nodeType) {
        if (n2.data.startsWith("$s")) r3++;
        else if (n2.data.startsWith("/$s") && !--r3) return n2;
      }
      t3 && t3.push(n2);
    }
  }
  function B(n2) {
    n2 && (n2.__c && (n2.__c.__g |= 4), n2.__k && n2.__k.some(B));
  }
  function D(t3, r3, i3) {
    for (var u4 = 0; u4 < i3.length; ) F(i3[u4++], i3[u4++], i3[u4++]);
    n.__c && n.__c(r3, t3), t3.some(function(r4) {
      try {
        t3 = r4.__h, r4.__h = [], t3.some(function(n2) {
          n2.call(r4);
        });
      } catch (t4) {
        n.__e(t4, r4.__v);
      }
    });
  }
  function E(t3, r3, i3, u4, f4, e3, o4, l3, c3, a4) {
    var s3, h3, v3, _3, k3, b2, m3, $, M2, x2 = i3.props || p, C3 = r3.props, j2 = r3.type;
    if ("svg" == j2 ? f4 = "http://www.w3.org/2000/svg" : "math" == j2 ? f4 = "http://www.w3.org/1998/Math/MathML" : f4 || (f4 = "http://www.w3.org/1999/xhtml"), e3) {
      for (s3 = 0; s3 < e3.length; s3++) if ((k3 = e3[s3]) && (j2 ? k3.localName == j2 : 3 == k3.nodeType)) {
        t3 = k3, e3[s3] = null;
        break;
      }
    }
    if (!t3) {
      if ($ = a4.ownerDocument || document, !j2) return $.createTextNode(C3);
      t3 = $.createElementNS(f4, j2, C3.is && C3), l3 && (n.__m && n.__m(r3, e3), l3 = false), e3 = null;
    }
    if (j2) {
      if (a4 = "template" == j2 && t3.content || t3, e3 = "textarea" == j2 && null != C3.defaultValue ? null : e3 && d.call(a4.childNodes), !l3 && e3) for (x2 = {}, s3 = 0; s3 < t3.attributes.length; s3++) x2[(k3 = t3.attributes[s3]).name] = k3.value;
      for (s3 in x2) k3 = x2[s3], "dangerouslySetInnerHTML" == s3 ? v3 = k3 : "children" == s3 || s3 in C3 || "value" == s3 && "defaultValue" in C3 || "checked" == s3 && "defaultChecked" in C3 || T(t3, s3, null, k3, f4);
      for (s3 in M2 = 1 & i3.__u, C3) k3 = C3[s3], "children" == s3 ? _3 = k3 : "dangerouslySetInnerHTML" == s3 ? h3 = k3 : "value" == s3 ? b2 = k3 : "checked" == s3 ? m3 = k3 : l3 && "function" != typeof k3 || !(x2[s3] !== k3 || M2 && null != k3) || T(t3, s3, k3, x2[s3], f4);
      h3 ? (l3 || v3 && (h3.__html == v3.__html || h3.__html == t3.innerHTML) || (t3.innerHTML = h3.__html), r3.__k = []) : (v3 && (t3.textContent = ""), ("foreignObject" == j2 || "http://www.w3.org/1998/Math/MathML" == f4 && y.test(j2)) && (f4 = "http://www.w3.org/1999/xhtml"), H(a4, w(_3) ? _3 : [_3], r3, i3, u4, f4, e3, o4, e3 ? e3[0] : i3.__k && S(i3, 0), l3, c3), e3 && e3.some(g)), l3 && "textarea" != j2 || (s3 = "value", "progress" == j2 && null == b2 ? t3.removeAttribute(s3) : null == b2 || b2 === t3[s3] && ("progress" != j2 || b2) || T(t3, s3, b2, x2[s3], f4), s3 = "checked", null != m3 && m3 != t3[s3] && T(t3, s3, m3, x2[s3], f4));
    } else x2 === C3 || l3 && t3.data == C3 || (t3.data = C3);
    return t3;
  }
  function F(t3, r3, i3, u4) {
    try {
      "function" == typeof t3 ? r3 ? r3.__x = t3(r3) || 1 : u4 && (u4 = u4.__c || u4.__e) && (r3 = u4.__x) && (u4.__x = null, "function" == typeof r3 ? r3() : t3(null)) : t3.current = r3;
    } catch (t4) {
      n.__e(t4, i3);
    }
  }
  function G(t3, r3, i3) {
    var u4, f4, e3, o4;
    if (n.unmount && n.unmount(t3), !(u4 = t3.ref) || u4.current && u4.current != t3.__e || F(u4, null, r3, t3), u4 = t3.__c) {
      if (u4.componentWillUnmount) try {
        u4.componentWillUnmount();
      } catch (t4) {
        n.__e(t4, r3);
      }
      u4.__P = u4.__n = null;
    }
    if (u4 = t3.__k) for (o4 = 0; o4 < u4.length; o4++) u4[o4] && G(u4[o4], r3, "function" != typeof t3.type || i3 && !t3.props.__P);
    !i3 && (u4 = t3.__c) && (u4 = u4.__z) && (f4 = z(u4, e3 = [])) && (u4 == t3.__e && e3.some(g), g(f4), g(u4)), (u4 = t3.__e) && (i3 || g(u4), u4.__e && (u4.__e = null)), t3.__e = t3.__c = t3.__ = null;
  }
  function J(n2, t3, r3) {
    return this.constructor(n2, r3);
  }
  function K(t3, r3) {
    var i3, u4, f4, e3;
    n.__ && n.__(t3, r3), 9 == r3.nodeType && (r3 = r3.documentElement), u4 = (i3 = t3 && 32 & t3.__u) ? null : r3.__k, r3.__k = m(M, { children: [t3] }), f4 = [], e3 = [], V(r3, r3.__k, u4 || p, p, r3.namespaceURI, u4 ? null : r3.firstChild ? d.call(r3.childNodes) : null, f4, u4 ? u4.__e : r3.firstChild, i3, e3), D(f4, r3.__k, e3), r3.__k.props.children = null;
  }
  n = { __e: function(n2, t3, r3, i3) {
    for (var u4, e3, o4; t3 = t3.__; ) if ((u4 = t3.__c) && !(1 & u4.__g)) {
      u4.__g |= 4;
      try {
        if ((o4 = (e3 = u4.constructor) && e3.getDerivedStateFromError) && u4.setState(e3.getDerivedStateFromError(n2)), u4.componentDidCatch && (u4.componentDidCatch(n2, i3 || {}), o4 = 1), o4 && 8 & u4.__g) return void (u4.__g |= 2);
      } catch (t4) {
        n2 = t4;
      }
    }
    throw f = 0, n2;
  } }, t = 0, r = function(n2) {
    return null != n2 && n2.constructor === h;
  }, x.prototype.setState = function(n2, t3) {
    var r3 = this.__s;
    r3 && r3 != this.state || (r3 = this.__s = _({}, this.state)), "function" == typeof n2 && (n2 = n2(_({}, r3), this.props)), n2 && (_(r3, n2), this.__v && (t3 && this.__k.push(t3), j(this)));
  }, x.prototype.forceUpdate = function(n2) {
    this.__v && (this.__g |= 4, n2 && this.__h.push(n2), j(this));
  }, x.prototype.render = M, i = [], f = 0, e = function(n2, t3) {
    return n2.__v.__b - t3.__v.__b;
  }, o = Symbol(), l = /(PointerCapture)$|Capture$/i, c = 0, a = {}, s = 0;

  // extension/safetyGuard.ts
  var DEFAULT_BLOCKED_URL_PATTERNS = [
    // Classic Canvas quiz taking
    /\/courses\/\d+\/quizzes\/\d+\/take(\/.*)?$/i,
    /\/courses\/\d+\/quizzes\/\d+\/take\/questions/i,
    /\/courses\/\d+\/quizzes\/\d+\/submissions/i,
    // Assignment take / in-progress assessment submission
    /\/courses\/\d+\/assignments\/\d+\/take/i,
    // LTI / New Quizzes launches & embed containers
    /\/external_tools\/.*quiz.*/i,
    /\/external_tools\/.*assessment.*/i,
    /canvas\.quiz-lti-iad-prod\.instructure\.com/i,
    /launch_type=assessment/i,
    /launch_type=quiz/i,
    // Remote proctoring & lockdown browser indicators
    /proctorio/i,
    /honorlock/i,
    /respondus/i
  ];
  var DEFAULT_BLOCKED_DOM_SELECTORS = [
    // Active quiz submission forms
    "#submit_quiz_form",
    "form.take_quiz_form",
    "form#take_quiz_form",
    "div.quiz-submission",
    // Active timers & countdown clocks
    "#quiz_timer",
    "#timer_running",
    ".quiz-timer",
    ".quiz-submission-timer",
    '[data-testid="timer-display"]',
    '[aria-label*="time remaining" i]',
    '[aria-label*="quiz timer" i]',
    // Active question containers
    "#questions.quiz-questions",
    "div.display_question.question",
    'div[data-testid="question-content"]',
    // LTI / New Quizzes embed containers
    'iframe#tool_content[src*="quiz"]',
    'iframe[data-testid="lti-frame"][src*="assessment"]',
    'iframe[src*="new_quizzes"]'
  ];
  var DEFAULT_ALLOWED_PATH_PATTERNS = [
    /^https?:\/\/[^/?#]+\/(?:[?#].*)?$/i,
    /\/(?:dashboard|courses)\/?(?:[?#].*)?$/i,
    /\/courses\/\d+\/?$/i,
    /\/courses\/\d+\/grades\/?$/i,
    /\/courses\/\d+\/assignments\/?$/i,
    /\/courses\/\d+\/assignments\/\d+\/?$/i,
    /\/courses\/\d+\/assignments\/syllabus\/?$/i,
    /\/courses\/\d+\/discussion_topics(?:\/\d+)?\/?$/i,
    /\/courses\/\d+\/quizzes\/?$/i,
    /\/courses\/\d+\/quizzes\/\d+\/?$/i,
    // Near-miss: Quiz landing/overview page is SAFE
    /\/courses\/\d+\/quizzes\/\d+\/edit\/?$/i,
    // Near-miss: Quiz edit page is SAFE
    /\/courses\/\d+\/modules\/?.*$/i,
    /\/courses\/\d+\/pages\/?.*$/i,
    /\/courses\/\d+\/announcements\/?.*$/i,
    /\/courses\/\d+\/syllabus\/?$/i,
    /\/courses\/\d+\/files\/?.*$/i,
    /\/courses\/\d+\/calendar_events\/?.*$/i,
    /\/calendar\/?.*$/i
  ];
  var SafetyGuard = class {
    config;
    constructor(customConfig) {
      this.config = {
        blockedUrlPatterns: customConfig?.blockedUrlPatterns ?? DEFAULT_BLOCKED_URL_PATTERNS,
        blockedDomSelectors: customConfig?.blockedDomSelectors ?? DEFAULT_BLOCKED_DOM_SELECTORS,
        allowedPathPatterns: customConfig?.allowedPathPatterns ?? DEFAULT_ALLOWED_PATH_PATTERNS,
        defaultDenyWhenUnsure: customConfig?.defaultDenyWhenUnsure ?? true
      };
    }
    evaluate(url, dom) {
      if (!url || typeof url !== "string") {
        return { allowed: false, blocked: true, reason: "Invalid or missing URL (default deny)" };
      }
      for (const pattern of this.config.blockedUrlPatterns) {
        if (pattern.test(url)) {
          return {
            allowed: false,
            blocked: true,
            reason: `Blocked by URL safety rule: matches assessment pattern '${pattern.source}'`
          };
        }
      }
      if (dom) {
        for (const selector of this.config.blockedDomSelectors) {
          try {
            const elem = dom.querySelector(selector);
            if (elem) {
              return {
                allowed: false,
                blocked: true,
                reason: `Blocked by DOM safety marker: detected active assessment element '${selector}'`
              };
            }
          } catch {
            continue;
          }
        }
      }
      if (this.config.defaultDenyWhenUnsure) {
        const isRecognizedSafe = this.config.allowedPathPatterns.some((pattern) => pattern.test(url));
        if (!isRecognizedSafe) {
          return {
            allowed: false,
            blocked: true,
            reason: `Blocked by fail-closed policy: URL '${url}' is outside recognized safe Canvas course views`
          };
        }
      }
      return {
        allowed: true,
        blocked: false,
        reason: "Safe to inject: allowlisted Canvas course page with zero assessment markers"
      };
    }
    canInject(url, dom) {
      return this.evaluate(url, dom);
    }
  };
  var defaultSafetyGuard = new SafetyGuard();
  function shouldRunOnPage(url, dom, config) {
    const guard = config ? new SafetyGuard(config) : defaultSafetyGuard;
    return guard.evaluate(url, dom).allowed;
  }

  // node_modules/zod/lib/index.mjs
  var util;
  (function(util2) {
    util2.assertEqual = (val) => val;
    function assertIs(_arg) {
    }
    util2.assertIs = assertIs;
    function assertNever(_x) {
      throw new Error();
    }
    util2.assertNever = assertNever;
    util2.arrayToEnum = (items) => {
      const obj = {};
      for (const item of items) {
        obj[item] = item;
      }
      return obj;
    };
    util2.getValidEnumValues = (obj) => {
      const validKeys = util2.objectKeys(obj).filter((k3) => typeof obj[obj[k3]] !== "number");
      const filtered = {};
      for (const k3 of validKeys) {
        filtered[k3] = obj[k3];
      }
      return util2.objectValues(filtered);
    };
    util2.objectValues = (obj) => {
      return util2.objectKeys(obj).map(function(e3) {
        return obj[e3];
      });
    };
    util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
      const keys = [];
      for (const key in object) {
        if (Object.prototype.hasOwnProperty.call(object, key)) {
          keys.push(key);
        }
      }
      return keys;
    };
    util2.find = (arr, checker) => {
      for (const item of arr) {
        if (checker(item))
          return item;
      }
      return void 0;
    };
    util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && isFinite(val) && Math.floor(val) === val;
    function joinValues(array, separator = " | ") {
      return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
    }
    util2.joinValues = joinValues;
    util2.jsonStringifyReplacer = (_3, value) => {
      if (typeof value === "bigint") {
        return value.toString();
      }
      return value;
    };
  })(util || (util = {}));
  var objectUtil;
  (function(objectUtil2) {
    objectUtil2.mergeShapes = (first, second) => {
      return {
        ...first,
        ...second
        // second overwrites first
      };
    };
  })(objectUtil || (objectUtil = {}));
  var ZodParsedType = util.arrayToEnum([
    "string",
    "nan",
    "number",
    "integer",
    "float",
    "boolean",
    "date",
    "bigint",
    "symbol",
    "function",
    "undefined",
    "null",
    "array",
    "object",
    "unknown",
    "promise",
    "void",
    "never",
    "map",
    "set"
  ]);
  var getParsedType = (data) => {
    const t3 = typeof data;
    switch (t3) {
      case "undefined":
        return ZodParsedType.undefined;
      case "string":
        return ZodParsedType.string;
      case "number":
        return isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
      case "boolean":
        return ZodParsedType.boolean;
      case "function":
        return ZodParsedType.function;
      case "bigint":
        return ZodParsedType.bigint;
      case "symbol":
        return ZodParsedType.symbol;
      case "object":
        if (Array.isArray(data)) {
          return ZodParsedType.array;
        }
        if (data === null) {
          return ZodParsedType.null;
        }
        if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
          return ZodParsedType.promise;
        }
        if (typeof Map !== "undefined" && data instanceof Map) {
          return ZodParsedType.map;
        }
        if (typeof Set !== "undefined" && data instanceof Set) {
          return ZodParsedType.set;
        }
        if (typeof Date !== "undefined" && data instanceof Date) {
          return ZodParsedType.date;
        }
        return ZodParsedType.object;
      default:
        return ZodParsedType.unknown;
    }
  };
  var ZodIssueCode = util.arrayToEnum([
    "invalid_type",
    "invalid_literal",
    "custom",
    "invalid_union",
    "invalid_union_discriminator",
    "invalid_enum_value",
    "unrecognized_keys",
    "invalid_arguments",
    "invalid_return_type",
    "invalid_date",
    "invalid_string",
    "too_small",
    "too_big",
    "invalid_intersection_types",
    "not_multiple_of",
    "not_finite"
  ]);
  var quotelessJson = (obj) => {
    const json = JSON.stringify(obj, null, 2);
    return json.replace(/"([^"]+)":/g, "$1:");
  };
  var ZodError = class _ZodError extends Error {
    constructor(issues) {
      super();
      this.issues = [];
      this.addIssue = (sub) => {
        this.issues = [...this.issues, sub];
      };
      this.addIssues = (subs = []) => {
        this.issues = [...this.issues, ...subs];
      };
      const actualProto = new.target.prototype;
      if (Object.setPrototypeOf) {
        Object.setPrototypeOf(this, actualProto);
      } else {
        this.__proto__ = actualProto;
      }
      this.name = "ZodError";
      this.issues = issues;
    }
    get errors() {
      return this.issues;
    }
    format(_mapper) {
      const mapper = _mapper || function(issue) {
        return issue.message;
      };
      const fieldErrors = { _errors: [] };
      const processError = (error) => {
        for (const issue of error.issues) {
          if (issue.code === "invalid_union") {
            issue.unionErrors.map(processError);
          } else if (issue.code === "invalid_return_type") {
            processError(issue.returnTypeError);
          } else if (issue.code === "invalid_arguments") {
            processError(issue.argumentsError);
          } else if (issue.path.length === 0) {
            fieldErrors._errors.push(mapper(issue));
          } else {
            let curr = fieldErrors;
            let i3 = 0;
            while (i3 < issue.path.length) {
              const el = issue.path[i3];
              const terminal = i3 === issue.path.length - 1;
              if (!terminal) {
                curr[el] = curr[el] || { _errors: [] };
              } else {
                curr[el] = curr[el] || { _errors: [] };
                curr[el]._errors.push(mapper(issue));
              }
              curr = curr[el];
              i3++;
            }
          }
        }
      };
      processError(this);
      return fieldErrors;
    }
    static assert(value) {
      if (!(value instanceof _ZodError)) {
        throw new Error(`Not a ZodError: ${value}`);
      }
    }
    toString() {
      return this.message;
    }
    get message() {
      return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
    }
    get isEmpty() {
      return this.issues.length === 0;
    }
    flatten(mapper = (issue) => issue.message) {
      const fieldErrors = {};
      const formErrors = [];
      for (const sub of this.issues) {
        if (sub.path.length > 0) {
          fieldErrors[sub.path[0]] = fieldErrors[sub.path[0]] || [];
          fieldErrors[sub.path[0]].push(mapper(sub));
        } else {
          formErrors.push(mapper(sub));
        }
      }
      return { formErrors, fieldErrors };
    }
    get formErrors() {
      return this.flatten();
    }
  };
  ZodError.create = (issues) => {
    const error = new ZodError(issues);
    return error;
  };
  var errorMap = (issue, _ctx) => {
    let message2;
    switch (issue.code) {
      case ZodIssueCode.invalid_type:
        if (issue.received === ZodParsedType.undefined) {
          message2 = "Required";
        } else {
          message2 = `Expected ${issue.expected}, received ${issue.received}`;
        }
        break;
      case ZodIssueCode.invalid_literal:
        message2 = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
        break;
      case ZodIssueCode.unrecognized_keys:
        message2 = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
        break;
      case ZodIssueCode.invalid_union:
        message2 = `Invalid input`;
        break;
      case ZodIssueCode.invalid_union_discriminator:
        message2 = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
        break;
      case ZodIssueCode.invalid_enum_value:
        message2 = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
        break;
      case ZodIssueCode.invalid_arguments:
        message2 = `Invalid function arguments`;
        break;
      case ZodIssueCode.invalid_return_type:
        message2 = `Invalid function return type`;
        break;
      case ZodIssueCode.invalid_date:
        message2 = `Invalid date`;
        break;
      case ZodIssueCode.invalid_string:
        if (typeof issue.validation === "object") {
          if ("includes" in issue.validation) {
            message2 = `Invalid input: must include "${issue.validation.includes}"`;
            if (typeof issue.validation.position === "number") {
              message2 = `${message2} at one or more positions greater than or equal to ${issue.validation.position}`;
            }
          } else if ("startsWith" in issue.validation) {
            message2 = `Invalid input: must start with "${issue.validation.startsWith}"`;
          } else if ("endsWith" in issue.validation) {
            message2 = `Invalid input: must end with "${issue.validation.endsWith}"`;
          } else {
            util.assertNever(issue.validation);
          }
        } else if (issue.validation !== "regex") {
          message2 = `Invalid ${issue.validation}`;
        } else {
          message2 = "Invalid";
        }
        break;
      case ZodIssueCode.too_small:
        if (issue.type === "array")
          message2 = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
        else if (issue.type === "string")
          message2 = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
        else if (issue.type === "number")
          message2 = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "date")
          message2 = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
        else
          message2 = "Invalid input";
        break;
      case ZodIssueCode.too_big:
        if (issue.type === "array")
          message2 = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
        else if (issue.type === "string")
          message2 = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
        else if (issue.type === "number")
          message2 = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "bigint")
          message2 = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "date")
          message2 = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
        else
          message2 = "Invalid input";
        break;
      case ZodIssueCode.custom:
        message2 = `Invalid input`;
        break;
      case ZodIssueCode.invalid_intersection_types:
        message2 = `Intersection results could not be merged`;
        break;
      case ZodIssueCode.not_multiple_of:
        message2 = `Number must be a multiple of ${issue.multipleOf}`;
        break;
      case ZodIssueCode.not_finite:
        message2 = "Number must be finite";
        break;
      default:
        message2 = _ctx.defaultError;
        util.assertNever(issue);
    }
    return { message: message2 };
  };
  var overrideErrorMap = errorMap;
  function setErrorMap(map) {
    overrideErrorMap = map;
  }
  function getErrorMap() {
    return overrideErrorMap;
  }
  var makeIssue = (params) => {
    const { data, path, errorMaps, issueData } = params;
    const fullPath = [...path, ...issueData.path || []];
    const fullIssue = {
      ...issueData,
      path: fullPath
    };
    if (issueData.message !== void 0) {
      return {
        ...issueData,
        path: fullPath,
        message: issueData.message
      };
    }
    let errorMessage2 = "";
    const maps = errorMaps.filter((m3) => !!m3).slice().reverse();
    for (const map of maps) {
      errorMessage2 = map(fullIssue, { data, defaultError: errorMessage2 }).message;
    }
    return {
      ...issueData,
      path: fullPath,
      message: errorMessage2
    };
  };
  var EMPTY_PATH = [];
  function addIssueToContext(ctx, issueData) {
    const overrideMap = getErrorMap();
    const issue = makeIssue({
      issueData,
      data: ctx.data,
      path: ctx.path,
      errorMaps: [
        ctx.common.contextualErrorMap,
        ctx.schemaErrorMap,
        overrideMap,
        overrideMap === errorMap ? void 0 : errorMap
        // then global default map
      ].filter((x2) => !!x2)
    });
    ctx.common.issues.push(issue);
  }
  var ParseStatus = class _ParseStatus {
    constructor() {
      this.value = "valid";
    }
    dirty() {
      if (this.value === "valid")
        this.value = "dirty";
    }
    abort() {
      if (this.value !== "aborted")
        this.value = "aborted";
    }
    static mergeArray(status, results) {
      const arrayValue = [];
      for (const s3 of results) {
        if (s3.status === "aborted")
          return INVALID;
        if (s3.status === "dirty")
          status.dirty();
        arrayValue.push(s3.value);
      }
      return { status: status.value, value: arrayValue };
    }
    static async mergeObjectAsync(status, pairs) {
      const syncPairs = [];
      for (const pair of pairs) {
        const key = await pair.key;
        const value = await pair.value;
        syncPairs.push({
          key,
          value
        });
      }
      return _ParseStatus.mergeObjectSync(status, syncPairs);
    }
    static mergeObjectSync(status, pairs) {
      const finalObject = {};
      for (const pair of pairs) {
        const { key, value } = pair;
        if (key.status === "aborted")
          return INVALID;
        if (value.status === "aborted")
          return INVALID;
        if (key.status === "dirty")
          status.dirty();
        if (value.status === "dirty")
          status.dirty();
        if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
          finalObject[key.value] = value.value;
        }
      }
      return { status: status.value, value: finalObject };
    }
  };
  var INVALID = Object.freeze({
    status: "aborted"
  });
  var DIRTY = (value) => ({ status: "dirty", value });
  var OK = (value) => ({ status: "valid", value });
  var isAborted = (x2) => x2.status === "aborted";
  var isDirty = (x2) => x2.status === "dirty";
  var isValid = (x2) => x2.status === "valid";
  var isAsync = (x2) => typeof Promise !== "undefined" && x2 instanceof Promise;
  function __classPrivateFieldGet(receiver, state, kind, f4) {
    if (kind === "a" && !f4) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f4 : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f4 : kind === "a" ? f4.call(receiver) : f4 ? f4.value : state.get(receiver);
  }
  function __classPrivateFieldSet(receiver, state, value, kind, f4) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f4) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f4 : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return kind === "a" ? f4.call(receiver, value) : f4 ? f4.value = value : state.set(receiver, value), value;
  }
  var errorUtil;
  (function(errorUtil2) {
    errorUtil2.errToObj = (message2) => typeof message2 === "string" ? { message: message2 } : message2 || {};
    errorUtil2.toString = (message2) => typeof message2 === "string" ? message2 : message2 === null || message2 === void 0 ? void 0 : message2.message;
  })(errorUtil || (errorUtil = {}));
  var _ZodEnum_cache;
  var _ZodNativeEnum_cache;
  var ParseInputLazyPath = class {
    constructor(parent, value, path, key) {
      this._cachedPath = [];
      this.parent = parent;
      this.data = value;
      this._path = path;
      this._key = key;
    }
    get path() {
      if (!this._cachedPath.length) {
        if (this._key instanceof Array) {
          this._cachedPath.push(...this._path, ...this._key);
        } else {
          this._cachedPath.push(...this._path, this._key);
        }
      }
      return this._cachedPath;
    }
  };
  var handleResult = (ctx, result) => {
    if (isValid(result)) {
      return { success: true, data: result.value };
    } else {
      if (!ctx.common.issues.length) {
        throw new Error("Validation failed but no issues detected.");
      }
      return {
        success: false,
        get error() {
          if (this._error)
            return this._error;
          const error = new ZodError(ctx.common.issues);
          this._error = error;
          return this._error;
        }
      };
    }
  };
  function processCreateParams(params) {
    if (!params)
      return {};
    const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
    if (errorMap2 && (invalid_type_error || required_error)) {
      throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
    }
    if (errorMap2)
      return { errorMap: errorMap2, description };
    const customMap = (iss, ctx) => {
      var _a, _b;
      const { message: message2 } = params;
      if (iss.code === "invalid_enum_value") {
        return { message: message2 !== null && message2 !== void 0 ? message2 : ctx.defaultError };
      }
      if (typeof ctx.data === "undefined") {
        return { message: (_a = message2 !== null && message2 !== void 0 ? message2 : required_error) !== null && _a !== void 0 ? _a : ctx.defaultError };
      }
      if (iss.code !== "invalid_type")
        return { message: ctx.defaultError };
      return { message: (_b = message2 !== null && message2 !== void 0 ? message2 : invalid_type_error) !== null && _b !== void 0 ? _b : ctx.defaultError };
    };
    return { errorMap: customMap, description };
  }
  var ZodType = class {
    constructor(def) {
      this.spa = this.safeParseAsync;
      this._def = def;
      this.parse = this.parse.bind(this);
      this.safeParse = this.safeParse.bind(this);
      this.parseAsync = this.parseAsync.bind(this);
      this.safeParseAsync = this.safeParseAsync.bind(this);
      this.spa = this.spa.bind(this);
      this.refine = this.refine.bind(this);
      this.refinement = this.refinement.bind(this);
      this.superRefine = this.superRefine.bind(this);
      this.optional = this.optional.bind(this);
      this.nullable = this.nullable.bind(this);
      this.nullish = this.nullish.bind(this);
      this.array = this.array.bind(this);
      this.promise = this.promise.bind(this);
      this.or = this.or.bind(this);
      this.and = this.and.bind(this);
      this.transform = this.transform.bind(this);
      this.brand = this.brand.bind(this);
      this.default = this.default.bind(this);
      this.catch = this.catch.bind(this);
      this.describe = this.describe.bind(this);
      this.pipe = this.pipe.bind(this);
      this.readonly = this.readonly.bind(this);
      this.isNullable = this.isNullable.bind(this);
      this.isOptional = this.isOptional.bind(this);
    }
    get description() {
      return this._def.description;
    }
    _getType(input) {
      return getParsedType(input.data);
    }
    _getOrReturnCtx(input, ctx) {
      return ctx || {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      };
    }
    _processInputParams(input) {
      return {
        status: new ParseStatus(),
        ctx: {
          common: input.parent.common,
          data: input.data,
          parsedType: getParsedType(input.data),
          schemaErrorMap: this._def.errorMap,
          path: input.path,
          parent: input.parent
        }
      };
    }
    _parseSync(input) {
      const result = this._parse(input);
      if (isAsync(result)) {
        throw new Error("Synchronous parse encountered promise.");
      }
      return result;
    }
    _parseAsync(input) {
      const result = this._parse(input);
      return Promise.resolve(result);
    }
    parse(data, params) {
      const result = this.safeParse(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    safeParse(data, params) {
      var _a;
      const ctx = {
        common: {
          issues: [],
          async: (_a = params === null || params === void 0 ? void 0 : params.async) !== null && _a !== void 0 ? _a : false,
          contextualErrorMap: params === null || params === void 0 ? void 0 : params.errorMap
        },
        path: (params === null || params === void 0 ? void 0 : params.path) || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const result = this._parseSync({ data, path: ctx.path, parent: ctx });
      return handleResult(ctx, result);
    }
    async parseAsync(data, params) {
      const result = await this.safeParseAsync(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    async safeParseAsync(data, params) {
      const ctx = {
        common: {
          issues: [],
          contextualErrorMap: params === null || params === void 0 ? void 0 : params.errorMap,
          async: true
        },
        path: (params === null || params === void 0 ? void 0 : params.path) || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
      const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
      return handleResult(ctx, result);
    }
    refine(check, message2) {
      const getIssueProperties = (val) => {
        if (typeof message2 === "string" || typeof message2 === "undefined") {
          return { message: message2 };
        } else if (typeof message2 === "function") {
          return message2(val);
        } else {
          return message2;
        }
      };
      return this._refinement((val, ctx) => {
        const result = check(val);
        const setError = () => ctx.addIssue({
          code: ZodIssueCode.custom,
          ...getIssueProperties(val)
        });
        if (typeof Promise !== "undefined" && result instanceof Promise) {
          return result.then((data) => {
            if (!data) {
              setError();
              return false;
            } else {
              return true;
            }
          });
        }
        if (!result) {
          setError();
          return false;
        } else {
          return true;
        }
      });
    }
    refinement(check, refinementData) {
      return this._refinement((val, ctx) => {
        if (!check(val)) {
          ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
          return false;
        } else {
          return true;
        }
      });
    }
    _refinement(refinement) {
      return new ZodEffects({
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "refinement", refinement }
      });
    }
    superRefine(refinement) {
      return this._refinement(refinement);
    }
    optional() {
      return ZodOptional.create(this, this._def);
    }
    nullable() {
      return ZodNullable.create(this, this._def);
    }
    nullish() {
      return this.nullable().optional();
    }
    array() {
      return ZodArray.create(this, this._def);
    }
    promise() {
      return ZodPromise.create(this, this._def);
    }
    or(option) {
      return ZodUnion.create([this, option], this._def);
    }
    and(incoming) {
      return ZodIntersection.create(this, incoming, this._def);
    }
    transform(transform) {
      return new ZodEffects({
        ...processCreateParams(this._def),
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "transform", transform }
      });
    }
    default(def) {
      const defaultValueFunc = typeof def === "function" ? def : () => def;
      return new ZodDefault({
        ...processCreateParams(this._def),
        innerType: this,
        defaultValue: defaultValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodDefault
      });
    }
    brand() {
      return new ZodBranded({
        typeName: ZodFirstPartyTypeKind.ZodBranded,
        type: this,
        ...processCreateParams(this._def)
      });
    }
    catch(def) {
      const catchValueFunc = typeof def === "function" ? def : () => def;
      return new ZodCatch({
        ...processCreateParams(this._def),
        innerType: this,
        catchValue: catchValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodCatch
      });
    }
    describe(description) {
      const This = this.constructor;
      return new This({
        ...this._def,
        description
      });
    }
    pipe(target) {
      return ZodPipeline.create(this, target);
    }
    readonly() {
      return ZodReadonly.create(this);
    }
    isOptional() {
      return this.safeParse(void 0).success;
    }
    isNullable() {
      return this.safeParse(null).success;
    }
  };
  var cuidRegex = /^c[^\s-]{8,}$/i;
  var cuid2Regex = /^[0-9a-z]+$/;
  var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/;
  var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
  var nanoidRegex = /^[a-z0-9_-]{21}$/i;
  var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
  var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
  var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
  var emojiRegex;
  var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
  var ipv6Regex = /^(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))$/;
  var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
  var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
  var dateRegex = new RegExp(`^${dateRegexSource}$`);
  function timeRegexSource(args) {
    let regex = `([01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d`;
    if (args.precision) {
      regex = `${regex}\\.\\d{${args.precision}}`;
    } else if (args.precision == null) {
      regex = `${regex}(\\.\\d+)?`;
    }
    return regex;
  }
  function timeRegex(args) {
    return new RegExp(`^${timeRegexSource(args)}$`);
  }
  function datetimeRegex(args) {
    let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
    const opts = [];
    opts.push(args.local ? `Z?` : `Z`);
    if (args.offset)
      opts.push(`([+-]\\d{2}:?\\d{2})`);
    regex = `${regex}(${opts.join("|")})`;
    return new RegExp(`^${regex}$`);
  }
  function isValidIP(ip, version) {
    if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
      return true;
    }
    return false;
  }
  var ZodString = class _ZodString extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = String(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.string) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.string,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.length < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.length > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "length") {
          const tooBig = input.data.length > check.value;
          const tooSmall = input.data.length < check.value;
          if (tooBig || tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            if (tooBig) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            } else if (tooSmall) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            }
            status.dirty();
          }
        } else if (check.kind === "email") {
          if (!emailRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "email",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "emoji") {
          if (!emojiRegex) {
            emojiRegex = new RegExp(_emojiRegex, "u");
          }
          if (!emojiRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "emoji",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "uuid") {
          if (!uuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "uuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "nanoid") {
          if (!nanoidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "nanoid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid") {
          if (!cuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid2") {
          if (!cuid2Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid2",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ulid") {
          if (!ulidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ulid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "url") {
          try {
            new URL(input.data);
          } catch (_a) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "regex") {
          check.regex.lastIndex = 0;
          const testResult = check.regex.test(input.data);
          if (!testResult) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "regex",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "trim") {
          input.data = input.data.trim();
        } else if (check.kind === "includes") {
          if (!input.data.includes(check.value, check.position)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { includes: check.value, position: check.position },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "toLowerCase") {
          input.data = input.data.toLowerCase();
        } else if (check.kind === "toUpperCase") {
          input.data = input.data.toUpperCase();
        } else if (check.kind === "startsWith") {
          if (!input.data.startsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { startsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "endsWith") {
          if (!input.data.endsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { endsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "datetime") {
          const regex = datetimeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "datetime",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "date") {
          const regex = dateRegex;
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "date",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "time") {
          const regex = timeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "time",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "duration") {
          if (!durationRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "duration",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ip") {
          if (!isValidIP(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ip",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64") {
          if (!base64Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _regex(regex, validation, message2) {
      return this.refinement((data) => regex.test(data), {
        validation,
        code: ZodIssueCode.invalid_string,
        ...errorUtil.errToObj(message2)
      });
    }
    _addCheck(check) {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    email(message2) {
      return this._addCheck({ kind: "email", ...errorUtil.errToObj(message2) });
    }
    url(message2) {
      return this._addCheck({ kind: "url", ...errorUtil.errToObj(message2) });
    }
    emoji(message2) {
      return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message2) });
    }
    uuid(message2) {
      return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message2) });
    }
    nanoid(message2) {
      return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message2) });
    }
    cuid(message2) {
      return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message2) });
    }
    cuid2(message2) {
      return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message2) });
    }
    ulid(message2) {
      return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message2) });
    }
    base64(message2) {
      return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message2) });
    }
    ip(options) {
      return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
    }
    datetime(options) {
      var _a, _b;
      if (typeof options === "string") {
        return this._addCheck({
          kind: "datetime",
          precision: null,
          offset: false,
          local: false,
          message: options
        });
      }
      return this._addCheck({
        kind: "datetime",
        precision: typeof (options === null || options === void 0 ? void 0 : options.precision) === "undefined" ? null : options === null || options === void 0 ? void 0 : options.precision,
        offset: (_a = options === null || options === void 0 ? void 0 : options.offset) !== null && _a !== void 0 ? _a : false,
        local: (_b = options === null || options === void 0 ? void 0 : options.local) !== null && _b !== void 0 ? _b : false,
        ...errorUtil.errToObj(options === null || options === void 0 ? void 0 : options.message)
      });
    }
    date(message2) {
      return this._addCheck({ kind: "date", message: message2 });
    }
    time(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "time",
          precision: null,
          message: options
        });
      }
      return this._addCheck({
        kind: "time",
        precision: typeof (options === null || options === void 0 ? void 0 : options.precision) === "undefined" ? null : options === null || options === void 0 ? void 0 : options.precision,
        ...errorUtil.errToObj(options === null || options === void 0 ? void 0 : options.message)
      });
    }
    duration(message2) {
      return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message2) });
    }
    regex(regex, message2) {
      return this._addCheck({
        kind: "regex",
        regex,
        ...errorUtil.errToObj(message2)
      });
    }
    includes(value, options) {
      return this._addCheck({
        kind: "includes",
        value,
        position: options === null || options === void 0 ? void 0 : options.position,
        ...errorUtil.errToObj(options === null || options === void 0 ? void 0 : options.message)
      });
    }
    startsWith(value, message2) {
      return this._addCheck({
        kind: "startsWith",
        value,
        ...errorUtil.errToObj(message2)
      });
    }
    endsWith(value, message2) {
      return this._addCheck({
        kind: "endsWith",
        value,
        ...errorUtil.errToObj(message2)
      });
    }
    min(minLength, message2) {
      return this._addCheck({
        kind: "min",
        value: minLength,
        ...errorUtil.errToObj(message2)
      });
    }
    max(maxLength, message2) {
      return this._addCheck({
        kind: "max",
        value: maxLength,
        ...errorUtil.errToObj(message2)
      });
    }
    length(len, message2) {
      return this._addCheck({
        kind: "length",
        value: len,
        ...errorUtil.errToObj(message2)
      });
    }
    /**
     * @deprecated Use z.string().min(1) instead.
     * @see {@link ZodString.min}
     */
    nonempty(message2) {
      return this.min(1, errorUtil.errToObj(message2));
    }
    trim() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "trim" }]
      });
    }
    toLowerCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toLowerCase" }]
      });
    }
    toUpperCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toUpperCase" }]
      });
    }
    get isDatetime() {
      return !!this._def.checks.find((ch) => ch.kind === "datetime");
    }
    get isDate() {
      return !!this._def.checks.find((ch) => ch.kind === "date");
    }
    get isTime() {
      return !!this._def.checks.find((ch) => ch.kind === "time");
    }
    get isDuration() {
      return !!this._def.checks.find((ch) => ch.kind === "duration");
    }
    get isEmail() {
      return !!this._def.checks.find((ch) => ch.kind === "email");
    }
    get isURL() {
      return !!this._def.checks.find((ch) => ch.kind === "url");
    }
    get isEmoji() {
      return !!this._def.checks.find((ch) => ch.kind === "emoji");
    }
    get isUUID() {
      return !!this._def.checks.find((ch) => ch.kind === "uuid");
    }
    get isNANOID() {
      return !!this._def.checks.find((ch) => ch.kind === "nanoid");
    }
    get isCUID() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid");
    }
    get isCUID2() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid2");
    }
    get isULID() {
      return !!this._def.checks.find((ch) => ch.kind === "ulid");
    }
    get isIP() {
      return !!this._def.checks.find((ch) => ch.kind === "ip");
    }
    get isBase64() {
      return !!this._def.checks.find((ch) => ch.kind === "base64");
    }
    get minLength() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxLength() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodString.create = (params) => {
    var _a;
    return new ZodString({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodString,
      coerce: (_a = params === null || params === void 0 ? void 0 : params.coerce) !== null && _a !== void 0 ? _a : false,
      ...processCreateParams(params)
    });
  };
  function floatSafeRemainder(val, step) {
    const valDecCount = (val.toString().split(".")[1] || "").length;
    const stepDecCount = (step.toString().split(".")[1] || "").length;
    const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
    const valInt = parseInt(val.toFixed(decCount).replace(".", ""));
    const stepInt = parseInt(step.toFixed(decCount).replace(".", ""));
    return valInt % stepInt / Math.pow(10, decCount);
  }
  var ZodNumber = class _ZodNumber extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
      this.step = this.multipleOf;
    }
    _parse(input) {
      if (this._def.coerce) {
        input.data = Number(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.number) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.number,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "int") {
          if (!util.isInteger(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: "integer",
              received: "float",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (floatSafeRemainder(input.data, check.value) !== 0) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "finite") {
          if (!Number.isFinite(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_finite,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    gte(value, message2) {
      return this.setLimit("min", value, true, errorUtil.toString(message2));
    }
    gt(value, message2) {
      return this.setLimit("min", value, false, errorUtil.toString(message2));
    }
    lte(value, message2) {
      return this.setLimit("max", value, true, errorUtil.toString(message2));
    }
    lt(value, message2) {
      return this.setLimit("max", value, false, errorUtil.toString(message2));
    }
    setLimit(kind, value, inclusive, message2) {
      return new _ZodNumber({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message2)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodNumber({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    int(message2) {
      return this._addCheck({
        kind: "int",
        message: errorUtil.toString(message2)
      });
    }
    positive(message2) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    negative(message2) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    nonpositive(message2) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    nonnegative(message2) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    multipleOf(value, message2) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message2)
      });
    }
    finite(message2) {
      return this._addCheck({
        kind: "finite",
        message: errorUtil.toString(message2)
      });
    }
    safe(message2) {
      return this._addCheck({
        kind: "min",
        inclusive: true,
        value: Number.MIN_SAFE_INTEGER,
        message: errorUtil.toString(message2)
      })._addCheck({
        kind: "max",
        inclusive: true,
        value: Number.MAX_SAFE_INTEGER,
        message: errorUtil.toString(message2)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
    get isInt() {
      return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
    }
    get isFinite() {
      let max = null, min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
          return true;
        } else if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        } else if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return Number.isFinite(min) && Number.isFinite(max);
    }
  };
  ZodNumber.create = (params) => {
    return new ZodNumber({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodNumber,
      coerce: (params === null || params === void 0 ? void 0 : params.coerce) || false,
      ...processCreateParams(params)
    });
  };
  var ZodBigInt = class _ZodBigInt extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
    }
    _parse(input) {
      if (this._def.coerce) {
        input.data = BigInt(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.bigint) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.bigint,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              type: "bigint",
              minimum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              type: "bigint",
              maximum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (input.data % check.value !== BigInt(0)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    gte(value, message2) {
      return this.setLimit("min", value, true, errorUtil.toString(message2));
    }
    gt(value, message2) {
      return this.setLimit("min", value, false, errorUtil.toString(message2));
    }
    lte(value, message2) {
      return this.setLimit("max", value, true, errorUtil.toString(message2));
    }
    lt(value, message2) {
      return this.setLimit("max", value, false, errorUtil.toString(message2));
    }
    setLimit(kind, value, inclusive, message2) {
      return new _ZodBigInt({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message2)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodBigInt({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    positive(message2) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    negative(message2) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    nonpositive(message2) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    nonnegative(message2) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    multipleOf(value, message2) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message2)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodBigInt.create = (params) => {
    var _a;
    return new ZodBigInt({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodBigInt,
      coerce: (_a = params === null || params === void 0 ? void 0 : params.coerce) !== null && _a !== void 0 ? _a : false,
      ...processCreateParams(params)
    });
  };
  var ZodBoolean = class extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = Boolean(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.boolean) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.boolean,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodBoolean.create = (params) => {
    return new ZodBoolean({
      typeName: ZodFirstPartyTypeKind.ZodBoolean,
      coerce: (params === null || params === void 0 ? void 0 : params.coerce) || false,
      ...processCreateParams(params)
    });
  };
  var ZodDate = class _ZodDate extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = new Date(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.date) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.date,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      if (isNaN(input.data.getTime())) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_date
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.getTime() < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              message: check.message,
              inclusive: true,
              exact: false,
              minimum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.getTime() > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              message: check.message,
              inclusive: true,
              exact: false,
              maximum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return {
        status: status.value,
        value: new Date(input.data.getTime())
      };
    }
    _addCheck(check) {
      return new _ZodDate({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    min(minDate, message2) {
      return this._addCheck({
        kind: "min",
        value: minDate.getTime(),
        message: errorUtil.toString(message2)
      });
    }
    max(maxDate, message2) {
      return this._addCheck({
        kind: "max",
        value: maxDate.getTime(),
        message: errorUtil.toString(message2)
      });
    }
    get minDate() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min != null ? new Date(min) : null;
    }
    get maxDate() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max != null ? new Date(max) : null;
    }
  };
  ZodDate.create = (params) => {
    return new ZodDate({
      checks: [],
      coerce: (params === null || params === void 0 ? void 0 : params.coerce) || false,
      typeName: ZodFirstPartyTypeKind.ZodDate,
      ...processCreateParams(params)
    });
  };
  var ZodSymbol = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.symbol) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.symbol,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodSymbol.create = (params) => {
    return new ZodSymbol({
      typeName: ZodFirstPartyTypeKind.ZodSymbol,
      ...processCreateParams(params)
    });
  };
  var ZodUndefined = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.undefined,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodUndefined.create = (params) => {
    return new ZodUndefined({
      typeName: ZodFirstPartyTypeKind.ZodUndefined,
      ...processCreateParams(params)
    });
  };
  var ZodNull = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.null) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.null,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodNull.create = (params) => {
    return new ZodNull({
      typeName: ZodFirstPartyTypeKind.ZodNull,
      ...processCreateParams(params)
    });
  };
  var ZodAny = class extends ZodType {
    constructor() {
      super(...arguments);
      this._any = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodAny.create = (params) => {
    return new ZodAny({
      typeName: ZodFirstPartyTypeKind.ZodAny,
      ...processCreateParams(params)
    });
  };
  var ZodUnknown = class extends ZodType {
    constructor() {
      super(...arguments);
      this._unknown = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodUnknown.create = (params) => {
    return new ZodUnknown({
      typeName: ZodFirstPartyTypeKind.ZodUnknown,
      ...processCreateParams(params)
    });
  };
  var ZodNever = class extends ZodType {
    _parse(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.never,
        received: ctx.parsedType
      });
      return INVALID;
    }
  };
  ZodNever.create = (params) => {
    return new ZodNever({
      typeName: ZodFirstPartyTypeKind.ZodNever,
      ...processCreateParams(params)
    });
  };
  var ZodVoid = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.void,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodVoid.create = (params) => {
    return new ZodVoid({
      typeName: ZodFirstPartyTypeKind.ZodVoid,
      ...processCreateParams(params)
    });
  };
  var ZodArray = class _ZodArray extends ZodType {
    _parse(input) {
      const { ctx, status } = this._processInputParams(input);
      const def = this._def;
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (def.exactLength !== null) {
        const tooBig = ctx.data.length > def.exactLength.value;
        const tooSmall = ctx.data.length < def.exactLength.value;
        if (tooBig || tooSmall) {
          addIssueToContext(ctx, {
            code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
            minimum: tooSmall ? def.exactLength.value : void 0,
            maximum: tooBig ? def.exactLength.value : void 0,
            type: "array",
            inclusive: true,
            exact: true,
            message: def.exactLength.message
          });
          status.dirty();
        }
      }
      if (def.minLength !== null) {
        if (ctx.data.length < def.minLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.minLength.message
          });
          status.dirty();
        }
      }
      if (def.maxLength !== null) {
        if (ctx.data.length > def.maxLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.maxLength.message
          });
          status.dirty();
        }
      }
      if (ctx.common.async) {
        return Promise.all([...ctx.data].map((item, i3) => {
          return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i3));
        })).then((result2) => {
          return ParseStatus.mergeArray(status, result2);
        });
      }
      const result = [...ctx.data].map((item, i3) => {
        return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i3));
      });
      return ParseStatus.mergeArray(status, result);
    }
    get element() {
      return this._def.type;
    }
    min(minLength, message2) {
      return new _ZodArray({
        ...this._def,
        minLength: { value: minLength, message: errorUtil.toString(message2) }
      });
    }
    max(maxLength, message2) {
      return new _ZodArray({
        ...this._def,
        maxLength: { value: maxLength, message: errorUtil.toString(message2) }
      });
    }
    length(len, message2) {
      return new _ZodArray({
        ...this._def,
        exactLength: { value: len, message: errorUtil.toString(message2) }
      });
    }
    nonempty(message2) {
      return this.min(1, message2);
    }
  };
  ZodArray.create = (schema, params) => {
    return new ZodArray({
      type: schema,
      minLength: null,
      maxLength: null,
      exactLength: null,
      typeName: ZodFirstPartyTypeKind.ZodArray,
      ...processCreateParams(params)
    });
  };
  function deepPartialify(schema) {
    if (schema instanceof ZodObject) {
      const newShape = {};
      for (const key in schema.shape) {
        const fieldSchema = schema.shape[key];
        newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
      }
      return new ZodObject({
        ...schema._def,
        shape: () => newShape
      });
    } else if (schema instanceof ZodArray) {
      return new ZodArray({
        ...schema._def,
        type: deepPartialify(schema.element)
      });
    } else if (schema instanceof ZodOptional) {
      return ZodOptional.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodNullable) {
      return ZodNullable.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodTuple) {
      return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
    } else {
      return schema;
    }
  }
  var ZodObject = class _ZodObject extends ZodType {
    constructor() {
      super(...arguments);
      this._cached = null;
      this.nonstrict = this.passthrough;
      this.augment = this.extend;
    }
    _getCached() {
      if (this._cached !== null)
        return this._cached;
      const shape = this._def.shape();
      const keys = util.objectKeys(shape);
      return this._cached = { shape, keys };
    }
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.object) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const { status, ctx } = this._processInputParams(input);
      const { shape, keys: shapeKeys } = this._getCached();
      const extraKeys = [];
      if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
        for (const key in ctx.data) {
          if (!shapeKeys.includes(key)) {
            extraKeys.push(key);
          }
        }
      }
      const pairs = [];
      for (const key of shapeKeys) {
        const keyValidator = shape[key];
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (this._def.catchall instanceof ZodNever) {
        const unknownKeys = this._def.unknownKeys;
        if (unknownKeys === "passthrough") {
          for (const key of extraKeys) {
            pairs.push({
              key: { status: "valid", value: key },
              value: { status: "valid", value: ctx.data[key] }
            });
          }
        } else if (unknownKeys === "strict") {
          if (extraKeys.length > 0) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.unrecognized_keys,
              keys: extraKeys
            });
            status.dirty();
          }
        } else if (unknownKeys === "strip") ;
        else {
          throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
        }
      } else {
        const catchall = this._def.catchall;
        for (const key of extraKeys) {
          const value = ctx.data[key];
          pairs.push({
            key: { status: "valid", value: key },
            value: catchall._parse(
              new ParseInputLazyPath(ctx, value, ctx.path, key)
              //, ctx.child(key), value, getParsedType(value)
            ),
            alwaysSet: key in ctx.data
          });
        }
      }
      if (ctx.common.async) {
        return Promise.resolve().then(async () => {
          const syncPairs = [];
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            syncPairs.push({
              key,
              value,
              alwaysSet: pair.alwaysSet
            });
          }
          return syncPairs;
        }).then((syncPairs) => {
          return ParseStatus.mergeObjectSync(status, syncPairs);
        });
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get shape() {
      return this._def.shape();
    }
    strict(message2) {
      errorUtil.errToObj;
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strict",
        ...message2 !== void 0 ? {
          errorMap: (issue, ctx) => {
            var _a, _b, _c, _d;
            const defaultError = (_c = (_b = (_a = this._def).errorMap) === null || _b === void 0 ? void 0 : _b.call(_a, issue, ctx).message) !== null && _c !== void 0 ? _c : ctx.defaultError;
            if (issue.code === "unrecognized_keys")
              return {
                message: (_d = errorUtil.errToObj(message2).message) !== null && _d !== void 0 ? _d : defaultError
              };
            return {
              message: defaultError
            };
          }
        } : {}
      });
    }
    strip() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strip"
      });
    }
    passthrough() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "passthrough"
      });
    }
    // const AugmentFactory =
    //   <Def extends ZodObjectDef>(def: Def) =>
    //   <Augmentation extends ZodRawShape>(
    //     augmentation: Augmentation
    //   ): ZodObject<
    //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
    //     Def["unknownKeys"],
    //     Def["catchall"]
    //   > => {
    //     return new ZodObject({
    //       ...def,
    //       shape: () => ({
    //         ...def.shape(),
    //         ...augmentation,
    //       }),
    //     }) as any;
    //   };
    extend(augmentation) {
      return new _ZodObject({
        ...this._def,
        shape: () => ({
          ...this._def.shape(),
          ...augmentation
        })
      });
    }
    /**
     * Prior to zod@1.0.12 there was a bug in the
     * inferred type of merged objects. Please
     * upgrade if you are experiencing issues.
     */
    merge(merging) {
      const merged = new _ZodObject({
        unknownKeys: merging._def.unknownKeys,
        catchall: merging._def.catchall,
        shape: () => ({
          ...this._def.shape(),
          ...merging._def.shape()
        }),
        typeName: ZodFirstPartyTypeKind.ZodObject
      });
      return merged;
    }
    // merge<
    //   Incoming extends AnyZodObject,
    //   Augmentation extends Incoming["shape"],
    //   NewOutput extends {
    //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
    //       ? Augmentation[k]["_output"]
    //       : k extends keyof Output
    //       ? Output[k]
    //       : never;
    //   },
    //   NewInput extends {
    //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
    //       ? Augmentation[k]["_input"]
    //       : k extends keyof Input
    //       ? Input[k]
    //       : never;
    //   }
    // >(
    //   merging: Incoming
    // ): ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"],
    //   NewOutput,
    //   NewInput
    // > {
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    setKey(key, schema) {
      return this.augment({ [key]: schema });
    }
    // merge<Incoming extends AnyZodObject>(
    //   merging: Incoming
    // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
    // ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"]
    // > {
    //   // const mergedShape = objectUtil.mergeShapes(
    //   //   this._def.shape(),
    //   //   merging._def.shape()
    //   // );
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    catchall(index) {
      return new _ZodObject({
        ...this._def,
        catchall: index
      });
    }
    pick(mask) {
      const shape = {};
      util.objectKeys(mask).forEach((key) => {
        if (mask[key] && this.shape[key]) {
          shape[key] = this.shape[key];
        }
      });
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    omit(mask) {
      const shape = {};
      util.objectKeys(this.shape).forEach((key) => {
        if (!mask[key]) {
          shape[key] = this.shape[key];
        }
      });
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    /**
     * @deprecated
     */
    deepPartial() {
      return deepPartialify(this);
    }
    partial(mask) {
      const newShape = {};
      util.objectKeys(this.shape).forEach((key) => {
        const fieldSchema = this.shape[key];
        if (mask && !mask[key]) {
          newShape[key] = fieldSchema;
        } else {
          newShape[key] = fieldSchema.optional();
        }
      });
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    required(mask) {
      const newShape = {};
      util.objectKeys(this.shape).forEach((key) => {
        if (mask && !mask[key]) {
          newShape[key] = this.shape[key];
        } else {
          const fieldSchema = this.shape[key];
          let newField = fieldSchema;
          while (newField instanceof ZodOptional) {
            newField = newField._def.innerType;
          }
          newShape[key] = newField;
        }
      });
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    keyof() {
      return createZodEnum(util.objectKeys(this.shape));
    }
  };
  ZodObject.create = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.strictCreate = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strict",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.lazycreate = (shape, params) => {
    return new ZodObject({
      shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  var ZodUnion = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const options = this._def.options;
      function handleResults(results) {
        for (const result of results) {
          if (result.result.status === "valid") {
            return result.result;
          }
        }
        for (const result of results) {
          if (result.result.status === "dirty") {
            ctx.common.issues.push(...result.ctx.common.issues);
            return result.result;
          }
        }
        const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return Promise.all(options.map(async (option) => {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          return {
            result: await option._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: childCtx
            }),
            ctx: childCtx
          };
        })).then(handleResults);
      } else {
        let dirty = void 0;
        const issues = [];
        for (const option of options) {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          const result = option._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          });
          if (result.status === "valid") {
            return result;
          } else if (result.status === "dirty" && !dirty) {
            dirty = { result, ctx: childCtx };
          }
          if (childCtx.common.issues.length) {
            issues.push(childCtx.common.issues);
          }
        }
        if (dirty) {
          ctx.common.issues.push(...dirty.ctx.common.issues);
          return dirty.result;
        }
        const unionErrors = issues.map((issues2) => new ZodError(issues2));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
    }
    get options() {
      return this._def.options;
    }
  };
  ZodUnion.create = (types, params) => {
    return new ZodUnion({
      options: types,
      typeName: ZodFirstPartyTypeKind.ZodUnion,
      ...processCreateParams(params)
    });
  };
  var getDiscriminator = (type) => {
    if (type instanceof ZodLazy) {
      return getDiscriminator(type.schema);
    } else if (type instanceof ZodEffects) {
      return getDiscriminator(type.innerType());
    } else if (type instanceof ZodLiteral) {
      return [type.value];
    } else if (type instanceof ZodEnum) {
      return type.options;
    } else if (type instanceof ZodNativeEnum) {
      return util.objectValues(type.enum);
    } else if (type instanceof ZodDefault) {
      return getDiscriminator(type._def.innerType);
    } else if (type instanceof ZodUndefined) {
      return [void 0];
    } else if (type instanceof ZodNull) {
      return [null];
    } else if (type instanceof ZodOptional) {
      return [void 0, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodNullable) {
      return [null, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodBranded) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodReadonly) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodCatch) {
      return getDiscriminator(type._def.innerType);
    } else {
      return [];
    }
  };
  var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const discriminator = this.discriminator;
      const discriminatorValue = ctx.data[discriminator];
      const option = this.optionsMap.get(discriminatorValue);
      if (!option) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union_discriminator,
          options: Array.from(this.optionsMap.keys()),
          path: [discriminator]
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return option._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      } else {
        return option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      }
    }
    get discriminator() {
      return this._def.discriminator;
    }
    get options() {
      return this._def.options;
    }
    get optionsMap() {
      return this._def.optionsMap;
    }
    /**
     * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
     * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
     * have a different value for each object in the union.
     * @param discriminator the name of the discriminator property
     * @param types an array of object schemas
     * @param params
     */
    static create(discriminator, options, params) {
      const optionsMap = /* @__PURE__ */ new Map();
      for (const type of options) {
        const discriminatorValues = getDiscriminator(type.shape[discriminator]);
        if (!discriminatorValues.length) {
          throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
        }
        for (const value of discriminatorValues) {
          if (optionsMap.has(value)) {
            throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
          }
          optionsMap.set(value, type);
        }
      }
      return new _ZodDiscriminatedUnion({
        typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
        discriminator,
        options,
        optionsMap,
        ...processCreateParams(params)
      });
    }
  };
  function mergeValues(a4, b2) {
    const aType = getParsedType(a4);
    const bType = getParsedType(b2);
    if (a4 === b2) {
      return { valid: true, data: a4 };
    } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
      const bKeys = util.objectKeys(b2);
      const sharedKeys = util.objectKeys(a4).filter((key) => bKeys.indexOf(key) !== -1);
      const newObj = { ...a4, ...b2 };
      for (const key of sharedKeys) {
        const sharedValue = mergeValues(a4[key], b2[key]);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newObj[key] = sharedValue.data;
      }
      return { valid: true, data: newObj };
    } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
      if (a4.length !== b2.length) {
        return { valid: false };
      }
      const newArray = [];
      for (let index = 0; index < a4.length; index++) {
        const itemA = a4[index];
        const itemB = b2[index];
        const sharedValue = mergeValues(itemA, itemB);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newArray.push(sharedValue.data);
      }
      return { valid: true, data: newArray };
    } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a4 === +b2) {
      return { valid: true, data: a4 };
    } else {
      return { valid: false };
    }
  }
  var ZodIntersection = class extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const handleParsed = (parsedLeft, parsedRight) => {
        if (isAborted(parsedLeft) || isAborted(parsedRight)) {
          return INVALID;
        }
        const merged = mergeValues(parsedLeft.value, parsedRight.value);
        if (!merged.valid) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_intersection_types
          });
          return INVALID;
        }
        if (isDirty(parsedLeft) || isDirty(parsedRight)) {
          status.dirty();
        }
        return { status: status.value, value: merged.data };
      };
      if (ctx.common.async) {
        return Promise.all([
          this._def.left._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          }),
          this._def.right._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          })
        ]).then(([left, right]) => handleParsed(left, right));
      } else {
        return handleParsed(this._def.left._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }), this._def.right._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }));
      }
    }
  };
  ZodIntersection.create = (left, right, params) => {
    return new ZodIntersection({
      left,
      right,
      typeName: ZodFirstPartyTypeKind.ZodIntersection,
      ...processCreateParams(params)
    });
  };
  var ZodTuple = class _ZodTuple extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (ctx.data.length < this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        return INVALID;
      }
      const rest = this._def.rest;
      if (!rest && ctx.data.length > this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        status.dirty();
      }
      const items = [...ctx.data].map((item, itemIndex) => {
        const schema = this._def.items[itemIndex] || this._def.rest;
        if (!schema)
          return null;
        return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
      }).filter((x2) => !!x2);
      if (ctx.common.async) {
        return Promise.all(items).then((results) => {
          return ParseStatus.mergeArray(status, results);
        });
      } else {
        return ParseStatus.mergeArray(status, items);
      }
    }
    get items() {
      return this._def.items;
    }
    rest(rest) {
      return new _ZodTuple({
        ...this._def,
        rest
      });
    }
  };
  ZodTuple.create = (schemas, params) => {
    if (!Array.isArray(schemas)) {
      throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
    }
    return new ZodTuple({
      items: schemas,
      typeName: ZodFirstPartyTypeKind.ZodTuple,
      rest: null,
      ...processCreateParams(params)
    });
  };
  var ZodRecord = class _ZodRecord extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const pairs = [];
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      for (const key in ctx.data) {
        pairs.push({
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
          value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (ctx.common.async) {
        return ParseStatus.mergeObjectAsync(status, pairs);
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get element() {
      return this._def.valueType;
    }
    static create(first, second, third) {
      if (second instanceof ZodType) {
        return new _ZodRecord({
          keyType: first,
          valueType: second,
          typeName: ZodFirstPartyTypeKind.ZodRecord,
          ...processCreateParams(third)
        });
      }
      return new _ZodRecord({
        keyType: ZodString.create(),
        valueType: first,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(second)
      });
    }
  };
  var ZodMap = class extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.map) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.map,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      const pairs = [...ctx.data.entries()].map(([key, value], index) => {
        return {
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
          value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
        };
      });
      if (ctx.common.async) {
        const finalMap = /* @__PURE__ */ new Map();
        return Promise.resolve().then(async () => {
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            if (key.status === "aborted" || value.status === "aborted") {
              return INVALID;
            }
            if (key.status === "dirty" || value.status === "dirty") {
              status.dirty();
            }
            finalMap.set(key.value, value.value);
          }
          return { status: status.value, value: finalMap };
        });
      } else {
        const finalMap = /* @__PURE__ */ new Map();
        for (const pair of pairs) {
          const key = pair.key;
          const value = pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      }
    }
  };
  ZodMap.create = (keyType, valueType, params) => {
    return new ZodMap({
      valueType,
      keyType,
      typeName: ZodFirstPartyTypeKind.ZodMap,
      ...processCreateParams(params)
    });
  };
  var ZodSet = class _ZodSet extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.set) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.set,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const def = this._def;
      if (def.minSize !== null) {
        if (ctx.data.size < def.minSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.minSize.message
          });
          status.dirty();
        }
      }
      if (def.maxSize !== null) {
        if (ctx.data.size > def.maxSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.maxSize.message
          });
          status.dirty();
        }
      }
      const valueType = this._def.valueType;
      function finalizeSet(elements2) {
        const parsedSet = /* @__PURE__ */ new Set();
        for (const element of elements2) {
          if (element.status === "aborted")
            return INVALID;
          if (element.status === "dirty")
            status.dirty();
          parsedSet.add(element.value);
        }
        return { status: status.value, value: parsedSet };
      }
      const elements = [...ctx.data.values()].map((item, i3) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i3)));
      if (ctx.common.async) {
        return Promise.all(elements).then((elements2) => finalizeSet(elements2));
      } else {
        return finalizeSet(elements);
      }
    }
    min(minSize, message2) {
      return new _ZodSet({
        ...this._def,
        minSize: { value: minSize, message: errorUtil.toString(message2) }
      });
    }
    max(maxSize, message2) {
      return new _ZodSet({
        ...this._def,
        maxSize: { value: maxSize, message: errorUtil.toString(message2) }
      });
    }
    size(size, message2) {
      return this.min(size, message2).max(size, message2);
    }
    nonempty(message2) {
      return this.min(1, message2);
    }
  };
  ZodSet.create = (valueType, params) => {
    return new ZodSet({
      valueType,
      minSize: null,
      maxSize: null,
      typeName: ZodFirstPartyTypeKind.ZodSet,
      ...processCreateParams(params)
    });
  };
  var ZodFunction = class _ZodFunction extends ZodType {
    constructor() {
      super(...arguments);
      this.validate = this.implement;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.function) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.function,
          received: ctx.parsedType
        });
        return INVALID;
      }
      function makeArgsIssue(args, error) {
        return makeIssue({
          data: args,
          path: ctx.path,
          errorMaps: [
            ctx.common.contextualErrorMap,
            ctx.schemaErrorMap,
            getErrorMap(),
            errorMap
          ].filter((x2) => !!x2),
          issueData: {
            code: ZodIssueCode.invalid_arguments,
            argumentsError: error
          }
        });
      }
      function makeReturnsIssue(returns, error) {
        return makeIssue({
          data: returns,
          path: ctx.path,
          errorMaps: [
            ctx.common.contextualErrorMap,
            ctx.schemaErrorMap,
            getErrorMap(),
            errorMap
          ].filter((x2) => !!x2),
          issueData: {
            code: ZodIssueCode.invalid_return_type,
            returnTypeError: error
          }
        });
      }
      const params = { errorMap: ctx.common.contextualErrorMap };
      const fn = ctx.data;
      if (this._def.returns instanceof ZodPromise) {
        const me = this;
        return OK(async function(...args) {
          const error = new ZodError([]);
          const parsedArgs = await me._def.args.parseAsync(args, params).catch((e3) => {
            error.addIssue(makeArgsIssue(args, e3));
            throw error;
          });
          const result = await Reflect.apply(fn, this, parsedArgs);
          const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e3) => {
            error.addIssue(makeReturnsIssue(result, e3));
            throw error;
          });
          return parsedReturns;
        });
      } else {
        const me = this;
        return OK(function(...args) {
          const parsedArgs = me._def.args.safeParse(args, params);
          if (!parsedArgs.success) {
            throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
          }
          const result = Reflect.apply(fn, this, parsedArgs.data);
          const parsedReturns = me._def.returns.safeParse(result, params);
          if (!parsedReturns.success) {
            throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
          }
          return parsedReturns.data;
        });
      }
    }
    parameters() {
      return this._def.args;
    }
    returnType() {
      return this._def.returns;
    }
    args(...items) {
      return new _ZodFunction({
        ...this._def,
        args: ZodTuple.create(items).rest(ZodUnknown.create())
      });
    }
    returns(returnType) {
      return new _ZodFunction({
        ...this._def,
        returns: returnType
      });
    }
    implement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    strictImplement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    static create(args, returns, params) {
      return new _ZodFunction({
        args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
        returns: returns || ZodUnknown.create(),
        typeName: ZodFirstPartyTypeKind.ZodFunction,
        ...processCreateParams(params)
      });
    }
  };
  var ZodLazy = class extends ZodType {
    get schema() {
      return this._def.getter();
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const lazySchema = this._def.getter();
      return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
    }
  };
  ZodLazy.create = (getter, params) => {
    return new ZodLazy({
      getter,
      typeName: ZodFirstPartyTypeKind.ZodLazy,
      ...processCreateParams(params)
    });
  };
  var ZodLiteral = class extends ZodType {
    _parse(input) {
      if (input.data !== this._def.value) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_literal,
          expected: this._def.value
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
    get value() {
      return this._def.value;
    }
  };
  ZodLiteral.create = (value, params) => {
    return new ZodLiteral({
      value,
      typeName: ZodFirstPartyTypeKind.ZodLiteral,
      ...processCreateParams(params)
    });
  };
  function createZodEnum(values, params) {
    return new ZodEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodEnum,
      ...processCreateParams(params)
    });
  }
  var ZodEnum = class _ZodEnum extends ZodType {
    constructor() {
      super(...arguments);
      _ZodEnum_cache.set(this, void 0);
    }
    _parse(input) {
      if (typeof input.data !== "string") {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!__classPrivateFieldGet(this, _ZodEnum_cache, "f")) {
        __classPrivateFieldSet(this, _ZodEnum_cache, new Set(this._def.values), "f");
      }
      if (!__classPrivateFieldGet(this, _ZodEnum_cache, "f").has(input.data)) {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get options() {
      return this._def.values;
    }
    get enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Values() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    extract(values, newDef = this._def) {
      return _ZodEnum.create(values, {
        ...this._def,
        ...newDef
      });
    }
    exclude(values, newDef = this._def) {
      return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
        ...this._def,
        ...newDef
      });
    }
  };
  _ZodEnum_cache = /* @__PURE__ */ new WeakMap();
  ZodEnum.create = createZodEnum;
  var ZodNativeEnum = class extends ZodType {
    constructor() {
      super(...arguments);
      _ZodNativeEnum_cache.set(this, void 0);
    }
    _parse(input) {
      const nativeEnumValues = util.getValidEnumValues(this._def.values);
      const ctx = this._getOrReturnCtx(input);
      if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!__classPrivateFieldGet(this, _ZodNativeEnum_cache, "f")) {
        __classPrivateFieldSet(this, _ZodNativeEnum_cache, new Set(util.getValidEnumValues(this._def.values)), "f");
      }
      if (!__classPrivateFieldGet(this, _ZodNativeEnum_cache, "f").has(input.data)) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get enum() {
      return this._def.values;
    }
  };
  _ZodNativeEnum_cache = /* @__PURE__ */ new WeakMap();
  ZodNativeEnum.create = (values, params) => {
    return new ZodNativeEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
      ...processCreateParams(params)
    });
  };
  var ZodPromise = class extends ZodType {
    unwrap() {
      return this._def.type;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.promise,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
      return OK(promisified.then((data) => {
        return this._def.type.parseAsync(data, {
          path: ctx.path,
          errorMap: ctx.common.contextualErrorMap
        });
      }));
    }
  };
  ZodPromise.create = (schema, params) => {
    return new ZodPromise({
      type: schema,
      typeName: ZodFirstPartyTypeKind.ZodPromise,
      ...processCreateParams(params)
    });
  };
  var ZodEffects = class extends ZodType {
    innerType() {
      return this._def.schema;
    }
    sourceType() {
      return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const effect = this._def.effect || null;
      const checkCtx = {
        addIssue: (arg) => {
          addIssueToContext(ctx, arg);
          if (arg.fatal) {
            status.abort();
          } else {
            status.dirty();
          }
        },
        get path() {
          return ctx.path;
        }
      };
      checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
      if (effect.type === "preprocess") {
        const processed = effect.transform(ctx.data, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(processed).then(async (processed2) => {
            if (status.value === "aborted")
              return INVALID;
            const result = await this._def.schema._parseAsync({
              data: processed2,
              path: ctx.path,
              parent: ctx
            });
            if (result.status === "aborted")
              return INVALID;
            if (result.status === "dirty")
              return DIRTY(result.value);
            if (status.value === "dirty")
              return DIRTY(result.value);
            return result;
          });
        } else {
          if (status.value === "aborted")
            return INVALID;
          const result = this._def.schema._parseSync({
            data: processed,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        }
      }
      if (effect.type === "refinement") {
        const executeRefinement = (acc) => {
          const result = effect.refinement(acc, checkCtx);
          if (ctx.common.async) {
            return Promise.resolve(result);
          }
          if (result instanceof Promise) {
            throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
          }
          return acc;
        };
        if (ctx.common.async === false) {
          const inner = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inner.status === "aborted")
            return INVALID;
          if (inner.status === "dirty")
            status.dirty();
          executeRefinement(inner.value);
          return { status: status.value, value: inner.value };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner) => {
            if (inner.status === "aborted")
              return INVALID;
            if (inner.status === "dirty")
              status.dirty();
            return executeRefinement(inner.value).then(() => {
              return { status: status.value, value: inner.value };
            });
          });
        }
      }
      if (effect.type === "transform") {
        if (ctx.common.async === false) {
          const base = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (!isValid(base))
            return base;
          const result = effect.transform(base.value, checkCtx);
          if (result instanceof Promise) {
            throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
          }
          return { status: status.value, value: result };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
            if (!isValid(base))
              return base;
            return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({ status: status.value, value: result }));
          });
        }
      }
      util.assertNever(effect);
    }
  };
  ZodEffects.create = (schema, effect, params) => {
    return new ZodEffects({
      schema,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect,
      ...processCreateParams(params)
    });
  };
  ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
    return new ZodEffects({
      schema,
      effect: { type: "preprocess", transform: preprocess },
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      ...processCreateParams(params)
    });
  };
  var ZodOptional = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.undefined) {
        return OK(void 0);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodOptional.create = (type, params) => {
    return new ZodOptional({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodOptional,
      ...processCreateParams(params)
    });
  };
  var ZodNullable = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.null) {
        return OK(null);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodNullable.create = (type, params) => {
    return new ZodNullable({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodNullable,
      ...processCreateParams(params)
    });
  };
  var ZodDefault = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      let data = ctx.data;
      if (ctx.parsedType === ZodParsedType.undefined) {
        data = this._def.defaultValue();
      }
      return this._def.innerType._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    removeDefault() {
      return this._def.innerType;
    }
  };
  ZodDefault.create = (type, params) => {
    return new ZodDefault({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodDefault,
      defaultValue: typeof params.default === "function" ? params.default : () => params.default,
      ...processCreateParams(params)
    });
  };
  var ZodCatch = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const newCtx = {
        ...ctx,
        common: {
          ...ctx.common,
          issues: []
        }
      };
      const result = this._def.innerType._parse({
        data: newCtx.data,
        path: newCtx.path,
        parent: {
          ...newCtx
        }
      });
      if (isAsync(result)) {
        return result.then((result2) => {
          return {
            status: "valid",
            value: result2.status === "valid" ? result2.value : this._def.catchValue({
              get error() {
                return new ZodError(newCtx.common.issues);
              },
              input: newCtx.data
            })
          };
        });
      } else {
        return {
          status: "valid",
          value: result.status === "valid" ? result.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      }
    }
    removeCatch() {
      return this._def.innerType;
    }
  };
  ZodCatch.create = (type, params) => {
    return new ZodCatch({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodCatch,
      catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
      ...processCreateParams(params)
    });
  };
  var ZodNaN = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.nan) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.nan,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
  };
  ZodNaN.create = (params) => {
    return new ZodNaN({
      typeName: ZodFirstPartyTypeKind.ZodNaN,
      ...processCreateParams(params)
    });
  };
  var BRAND = Symbol("zod_brand");
  var ZodBranded = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const data = ctx.data;
      return this._def.type._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    unwrap() {
      return this._def.type;
    }
  };
  var ZodPipeline = class _ZodPipeline extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.common.async) {
        const handleAsync = async () => {
          const inResult = await this._def.in._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inResult.status === "aborted")
            return INVALID;
          if (inResult.status === "dirty") {
            status.dirty();
            return DIRTY(inResult.value);
          } else {
            return this._def.out._parseAsync({
              data: inResult.value,
              path: ctx.path,
              parent: ctx
            });
          }
        };
        return handleAsync();
      } else {
        const inResult = this._def.in._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return {
            status: "dirty",
            value: inResult.value
          };
        } else {
          return this._def.out._parseSync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      }
    }
    static create(a4, b2) {
      return new _ZodPipeline({
        in: a4,
        out: b2,
        typeName: ZodFirstPartyTypeKind.ZodPipeline
      });
    }
  };
  var ZodReadonly = class extends ZodType {
    _parse(input) {
      const result = this._def.innerType._parse(input);
      const freeze = (data) => {
        if (isValid(data)) {
          data.value = Object.freeze(data.value);
        }
        return data;
      };
      return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodReadonly.create = (type, params) => {
    return new ZodReadonly({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodReadonly,
      ...processCreateParams(params)
    });
  };
  function custom(check, params = {}, fatal) {
    if (check)
      return ZodAny.create().superRefine((data, ctx) => {
        var _a, _b;
        if (!check(data)) {
          const p3 = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
          const _fatal = (_b = (_a = p3.fatal) !== null && _a !== void 0 ? _a : fatal) !== null && _b !== void 0 ? _b : true;
          const p22 = typeof p3 === "string" ? { message: p3 } : p3;
          ctx.addIssue({ code: "custom", ...p22, fatal: _fatal });
        }
      });
    return ZodAny.create();
  }
  var late = {
    object: ZodObject.lazycreate
  };
  var ZodFirstPartyTypeKind;
  (function(ZodFirstPartyTypeKind2) {
    ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
    ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
    ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
    ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
    ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
    ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
    ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
    ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
    ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
    ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
    ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
    ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
    ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
    ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
    ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
    ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
    ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
    ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
    ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
    ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
    ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
    ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
    ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
    ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
    ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
    ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
    ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
    ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
    ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
    ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
    ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
    ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
    ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
    ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
    ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
    ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
  })(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
  var instanceOfType = (cls, params = {
    message: `Input not instance of ${cls.name}`
  }) => custom((data) => data instanceof cls, params);
  var stringType = ZodString.create;
  var numberType = ZodNumber.create;
  var nanType = ZodNaN.create;
  var bigIntType = ZodBigInt.create;
  var booleanType = ZodBoolean.create;
  var dateType = ZodDate.create;
  var symbolType = ZodSymbol.create;
  var undefinedType = ZodUndefined.create;
  var nullType = ZodNull.create;
  var anyType = ZodAny.create;
  var unknownType = ZodUnknown.create;
  var neverType = ZodNever.create;
  var voidType = ZodVoid.create;
  var arrayType = ZodArray.create;
  var objectType = ZodObject.create;
  var strictObjectType = ZodObject.strictCreate;
  var unionType = ZodUnion.create;
  var discriminatedUnionType = ZodDiscriminatedUnion.create;
  var intersectionType = ZodIntersection.create;
  var tupleType = ZodTuple.create;
  var recordType = ZodRecord.create;
  var mapType = ZodMap.create;
  var setType = ZodSet.create;
  var functionType = ZodFunction.create;
  var lazyType = ZodLazy.create;
  var literalType = ZodLiteral.create;
  var enumType = ZodEnum.create;
  var nativeEnumType = ZodNativeEnum.create;
  var promiseType = ZodPromise.create;
  var effectsType = ZodEffects.create;
  var optionalType = ZodOptional.create;
  var nullableType = ZodNullable.create;
  var preprocessType = ZodEffects.createWithPreprocess;
  var pipelineType = ZodPipeline.create;
  var ostring = () => stringType().optional();
  var onumber = () => numberType().optional();
  var oboolean = () => booleanType().optional();
  var coerce = {
    string: (arg) => ZodString.create({ ...arg, coerce: true }),
    number: (arg) => ZodNumber.create({ ...arg, coerce: true }),
    boolean: (arg) => ZodBoolean.create({
      ...arg,
      coerce: true
    }),
    bigint: (arg) => ZodBigInt.create({ ...arg, coerce: true }),
    date: (arg) => ZodDate.create({ ...arg, coerce: true })
  };
  var NEVER = INVALID;
  var z2 = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    defaultErrorMap: errorMap,
    setErrorMap,
    getErrorMap,
    makeIssue,
    EMPTY_PATH,
    addIssueToContext,
    ParseStatus,
    INVALID,
    DIRTY,
    OK,
    isAborted,
    isDirty,
    isValid,
    isAsync,
    get util() {
      return util;
    },
    get objectUtil() {
      return objectUtil;
    },
    ZodParsedType,
    getParsedType,
    ZodType,
    datetimeRegex,
    ZodString,
    ZodNumber,
    ZodBigInt,
    ZodBoolean,
    ZodDate,
    ZodSymbol,
    ZodUndefined,
    ZodNull,
    ZodAny,
    ZodUnknown,
    ZodNever,
    ZodVoid,
    ZodArray,
    ZodObject,
    ZodUnion,
    ZodDiscriminatedUnion,
    ZodIntersection,
    ZodTuple,
    ZodRecord,
    ZodMap,
    ZodSet,
    ZodFunction,
    ZodLazy,
    ZodLiteral,
    ZodEnum,
    ZodNativeEnum,
    ZodPromise,
    ZodEffects,
    ZodTransformer: ZodEffects,
    ZodOptional,
    ZodNullable,
    ZodDefault,
    ZodCatch,
    ZodNaN,
    BRAND,
    ZodBranded,
    ZodPipeline,
    ZodReadonly,
    custom,
    Schema: ZodType,
    ZodSchema: ZodType,
    late,
    get ZodFirstPartyTypeKind() {
      return ZodFirstPartyTypeKind;
    },
    coerce,
    any: anyType,
    array: arrayType,
    bigint: bigIntType,
    boolean: booleanType,
    date: dateType,
    discriminatedUnion: discriminatedUnionType,
    effect: effectsType,
    "enum": enumType,
    "function": functionType,
    "instanceof": instanceOfType,
    intersection: intersectionType,
    lazy: lazyType,
    literal: literalType,
    map: mapType,
    nan: nanType,
    nativeEnum: nativeEnumType,
    never: neverType,
    "null": nullType,
    nullable: nullableType,
    number: numberType,
    object: objectType,
    oboolean,
    onumber,
    optional: optionalType,
    ostring,
    pipeline: pipelineType,
    preprocess: preprocessType,
    promise: promiseType,
    record: recordType,
    set: setType,
    strictObject: strictObjectType,
    string: stringType,
    symbol: symbolType,
    transformer: effectsType,
    tuple: tupleType,
    "undefined": undefinedType,
    union: unionType,
    unknown: unknownType,
    "void": voidType,
    NEVER,
    ZodIssueCode,
    quotelessJson,
    ZodError
  });

  // core/schema.ts
  var DEFAULT_GRADE_POINT_SCALE = {
    "A+": 4,
    "A": 4,
    "A-": 3.7,
    "B+": 3.3,
    "B": 3,
    "B-": 2.7,
    "C+": 2.3,
    "C": 2,
    "C-": 1.7,
    "D+": 1.3,
    "D": 1,
    "D-": 0.7,
    "F": 0
  };
  var GradingSchemeItemSchema = z2.object({
    minPct: z2.number().min(0).max(100),
    letter: z2.string().min(1)
  });
  var GradePointScaleSchema = z2.record(z2.string(), z2.number().min(0).max(5));
  var DEFAULT_GRADING_SCHEME = [
    { minPct: 93, letter: "A" },
    { minPct: 90, letter: "A-" },
    { minPct: 87, letter: "B+" },
    { minPct: 83, letter: "B" },
    { minPct: 80, letter: "B-" },
    { minPct: 77, letter: "C+" },
    { minPct: 73, letter: "C" },
    { minPct: 70, letter: "C-" },
    { minPct: 67, letter: "D+" },
    { minPct: 63, letter: "D" },
    { minPct: 60, letter: "D-" },
    { minPct: 0, letter: "F" }
  ];
  var CourseSchema = z2.object({
    id: z2.string().min(1),
    name: z2.string().min(1),
    creditHours: z2.number().positive(),
    applyGroupWeights: z2.boolean(),
    gradingScheme: z2.array(GradingSchemeItemSchema).default(() => [...DEFAULT_GRADING_SCHEME]),
    gradePointScale: GradePointScaleSchema.default(() => ({ ...DEFAULT_GRADE_POINT_SCALE }))
  });
  var AssignmentGroupRulesSchema = z2.object({
    dropLowest: z2.number().int().nonnegative().default(0),
    dropHighest: z2.number().int().nonnegative().default(0),
    neverDrop: z2.array(z2.string()).default([])
  });
  var AssignmentGroupSchema = z2.object({
    id: z2.string().min(1),
    name: z2.string().min(1),
    weight: z2.number().nonnegative(),
    rules: AssignmentGroupRulesSchema.default({ dropLowest: 0, dropHighest: 0, neverDrop: [] })
  });
  var RubricRatingSchema = z2.object({
    id: z2.string().optional(),
    description: z2.string(),
    points: z2.number().nonnegative()
  });
  var RubricCriterionSchema = z2.object({
    id: z2.string().min(1),
    description: z2.string(),
    points: z2.number().nonnegative(),
    ratings: z2.array(RubricRatingSchema)
  });
  var AssignmentSchema = z2.object({
    id: z2.string().min(1),
    groupId: z2.string().min(1),
    name: z2.string().min(1),
    pointsPossible: z2.number().nonnegative(),
    dueAt: z2.string().nullable().optional(),
    submissionTypes: z2.array(z2.string()).default([]),
    omitFromFinalGrade: z2.boolean().default(false),
    hasRubric: z2.boolean().default(false),
    rubric: z2.array(RubricCriterionSchema).optional()
  });
  var RubricAssessmentEntrySchema = z2.object({
    points: z2.number().nonnegative(),
    ratingId: z2.string().optional(),
    comments: z2.string().optional()
  });
  var SubmissionCommentSchema = z2.object({
    authorName: z2.string(),
    comment: z2.string(),
    createdAt: z2.string().optional()
  });
  var SubmissionSchema = z2.object({
    assignmentId: z2.string().min(1),
    score: z2.number().nullable(),
    excused: z2.boolean().default(false),
    missing: z2.boolean().default(false),
    late: z2.boolean().default(false),
    posted: z2.boolean().default(true),
    workflowState: z2.enum(["unsubmitted", "submitted", "graded", "pending_review"]).default("graded"),
    rubricAssessment: z2.record(z2.string(), RubricAssessmentEntrySchema).optional(),
    submissionComments: z2.array(SubmissionCommentSchema).optional()
  });

  // extension/options/optionsStorage.ts
  var DEFAULT_GRADIENT_OPTIONS = {
    canvasHosts: [
      "*.instructure.com",
      "localhost",
      "127.0.0.1",
      "canvas.usm.edu"
    ],
    courseCreditHours: {
      "CS-101": 4,
      "MATH-201": 3,
      "BIO-110": 4
    },
    gradePointScale: { ...DEFAULT_GRADE_POINT_SCALE },
    detailLevel: "a_bit_more"
  };
  var STORAGE_KEY = "gradient_user_options";
  async function loadOptions() {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.sync) {
      return new Promise((resolve) => {
        chrome.storage.sync.get(STORAGE_KEY, (res) => {
          if (res && res[STORAGE_KEY]) {
            resolve({ ...DEFAULT_GRADIENT_OPTIONS, ...res[STORAGE_KEY] });
          } else {
            resolve({ ...DEFAULT_GRADIENT_OPTIONS });
          }
        });
      });
    }
    if (typeof localStorage !== "undefined") {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        try {
          return { ...DEFAULT_GRADIENT_OPTIONS, ...JSON.parse(raw) };
        } catch {
        }
      }
    }
    return { ...DEFAULT_GRADIENT_OPTIONS };
  }
  async function saveOptions(options) {
    const current = await loadOptions();
    const updated = { ...current, ...options };
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.sync) {
      await new Promise((resolve) => {
        chrome.storage.sync.set({ [STORAGE_KEY]: updated }, () => resolve());
      });
    }
    if (typeof localStorage !== "undefined") {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    }
    return updated;
  }

  // node_modules/preact/hooks/dist/hooks.mjs
  var t2;
  var r2;
  var u2;
  var i2;
  var o2 = Object.is;
  var f2 = 0;
  var c2 = [];
  var e2 = [];
  var a2 = n;
  var v2 = a2.__b;
  var l2 = a2.__r;
  var m2 = a2.diffed;
  var h2 = a2.__c;
  var s2 = a2.unmount;
  var p2 = a2.__;
  function y2(n2, t3) {
    a2.__h && a2.__h(r2, n2, f2 || t3), f2 = 0;
    var u4 = r2.__H || (r2.__H = { __: [], __h: [] });
    return n2 >= u4.__.length && u4.__.push({}), u4.__[n2];
  }
  function d2(n2) {
    return f2 = 1, _2(G2, n2);
  }
  function _2(n2, u4, i3) {
    var f4 = y2(t2++, 2);
    if (f4.t = n2, !f4.__c && (f4.__ = [i3 ? i3(u4) : G2(void 0, u4), function(n3) {
      var t3 = f4.__N ? f4.__N[0] : f4.__[0], r3 = f4.t(t3, n3);
      o2(t3, r3) || (f4.__N = [r3, f4.__[1]], f4.__c.setState({}));
    }], f4.__c = r2, !r2.__f)) {
      r2.__f = true;
      var c3 = r2.shouldComponentUpdate;
      r2.shouldComponentUpdate = function(n3, t3, r3) {
        var u5 = this.__H;
        if (!u5) return true;
        var i4 = false, f5 = this.props != n3;
        if (u5.__.some(function(n4) {
          n4.__N && (i4 = true, o2(n4.__[0], n4.__N[0]) || (f5 = true));
        }), c3) {
          var e3 = c3.call(this, n3, t3, r3);
          return i4 ? e3 || f5 : e3;
        }
        return !i4 || f5;
      };
    }
    return f4.__;
  }
  function A(n2, u4) {
    var i3 = y2(t2++, 3);
    !a2.__s && E2(i3.__H, u4) && (i3.__P = true, i3.__ = n2, i3.u = u4, r2.__H.__h.push(i3));
  }
  function T2(n2) {
    return f2 = 5, w2(function() {
      return { current: n2 };
    }, []);
  }
  function w2(n2, r3) {
    var u4 = y2(t2++, 7);
    return E2(u4.__H, r3) && (u4.__ = n2(), u4.__H = r3), u4.__;
  }
  function b(n2, t3) {
    return f2 = 8, w2(function() {
      return n2;
    }, t3);
  }
  function g2() {
    var n2;
    do {
      for (; n2 = e2.shift(); ) try {
        C2(n2);
      } catch (t4) {
        a2.__e(t4, { __: (n2 = n2.__P) && n2.__v });
      }
      for (; n2 = c2.shift(); ) {
        var t3 = n2.__H;
        if (n2.__P && t3) try {
          t3.__h.some(C2), t3.__h.some(D2), t3.__h = [];
        } catch (r3) {
          t3.__h = [], a2.__e(r3, n2.__v);
        }
      }
    } while (e2.length);
  }
  a2.__b = function(n2) {
    r2 = null, v2 && v2(n2);
  }, a2.__ = function(n2, t3) {
    n2 && t3.__k && t3.__k.__m && (n2.__m = t3.__k.__m), p2 && p2(n2, t3);
  }, a2.__r = function(n2) {
    l2 && l2(n2), t2 = 0;
    var i3 = (r2 = n2.__c).__H;
    i3 && (u2 == r2 ? r2.__h = [] : (i3.__h.some(C2), i3.__h.some(D2), t2 = 0), i3.__h = [], i3.__.some(function(n3) {
      n3.__N && (n3.__ = n3.__N), n3.u = n3.__N = void 0;
    })), u2 = r2;
  }, a2.diffed = function(n2) {
    m2 && m2(n2);
    var t3 = n2.__c;
    t3 && t3.__H && (t3.__H.__h.length && B2(c2.push(t3)), t3.__H.__.some(function(n3) {
      n3.u && (n3.__H = n3.u);
    })), u2 = r2 = null;
  }, a2.__c = function(n2, t3) {
    t3.some(function(n3) {
      try {
        n3.__h.some(C2), n3.__h = n3.__h.filter(function(n4) {
          return !n4.__ || D2(n4);
        });
      } catch (t4) {
        n3.__h = [function() {
          throw t4;
        }];
      }
    }), h2 && h2(n2, t3);
  }, a2.unmount = function(n2) {
    s2 && s2(n2);
    var t3, r3, u4 = n2.__c;
    u4 && u4.__H && (u4.__H.__.some(function(u5) {
      try {
        if (u5.__P && u5.__c) {
          if (void 0 === r3) {
            for (r3 = n2.__; r3 && (!r3.__c || !r3.__c.__P); ) r3 = r3.__;
            r3 = r3 && r3.__c;
          }
          u5.__P = r3, B2(e2.push(u5));
        } else C2(u5);
      } catch (n3) {
        t3 = n3;
      }
    }), u4.__H = void 0, t3 && a2.__e(t3, u4.__v));
  };
  var k2 = "function" == typeof requestAnimationFrame;
  function z3(n2) {
    var t3, r3 = function() {
      clearTimeout(u4), k2 && cancelAnimationFrame(t3), setTimeout(n2);
    }, u4 = setTimeout(r3, 35);
    k2 && (t3 = requestAnimationFrame(r3));
  }
  function B2(n2) {
    1 != n2 && i2 == a2.requestAnimationFrame || ((i2 = a2.requestAnimationFrame) || z3)(g2);
  }
  function C2(n2) {
    var t3 = r2, u4 = n2.__c;
    "function" == typeof u4 && (n2.__c = void 0, u4()), r2 = t3;
  }
  function D2(n2) {
    var t3 = r2;
    n2.__c = n2.__(), r2 = t3;
  }
  function E2(n2, t3) {
    return !n2 || n2.length != t3.length || t3.some(function(t4, r3) {
      return !o2(t4, n2[r3]);
    });
  }
  function G2(n2, t3) {
    return "function" == typeof t3 ? t3(n2) : t3;
  }

  // extension/adapter/canvasAdapter.ts
  var CanvasAdapter = class {
    lmsName = "Canvas LMS";
    parseCourse(raw, creditHours) {
      const data = raw;
      let gradingScheme = DEFAULT_GRADING_SCHEME.map((item) => ({ ...item }));
      const rawScheme = data.grading_standard ?? data.grading_scheme;
      if (Array.isArray(rawScheme) && rawScheme.length > 0) {
        gradingScheme = rawScheme.map((entry) => {
          let letter = "F";
          let minPct = 0;
          if (Array.isArray(entry) && entry.length >= 2) {
            letter = String(entry[0]);
            const val = Number(entry[1]);
            minPct = val <= 1 ? Math.round(val * 100) : val;
          } else if (typeof entry === "object" && entry !== null) {
            letter = String(entry.name ?? "F");
            const val = Number(entry.value ?? 0);
            minPct = val <= 1 ? Math.round(val * 100) : val;
          }
          return { letter, minPct };
        });
      }
      const courseData = {
        id: String(data.id),
        name: data.name,
        creditHours,
        applyGroupWeights: Boolean(data.apply_assignment_group_weights),
        gradingScheme,
        gradePointScale: DEFAULT_GRADE_POINT_SCALE
      };
      return CourseSchema.parse(courseData);
    }
    parseAssignmentGroups(rawList) {
      return rawList.map((item) => {
        const g3 = item;
        const rules = {
          dropLowest: g3.rules?.drop_lowest ?? 0,
          dropHighest: g3.rules?.drop_highest ?? 0,
          neverDrop: (g3.rules?.never_drop ?? []).map((id) => String(id))
        };
        const groupData = {
          id: String(g3.id),
          name: g3.name,
          weight: Number(g3.group_weight ?? 0),
          rules
        };
        return AssignmentGroupSchema.parse(groupData);
      });
    }
    parseAssignments(rawList) {
      return rawList.map((item) => {
        const a4 = item;
        let rubric;
        if (Array.isArray(a4.rubric) && a4.rubric.length > 0) {
          rubric = a4.rubric.map((r3) => ({
            id: String(r3.id),
            description: r3.description ?? "",
            points: Number(r3.points ?? 0),
            ratings: (r3.ratings ?? []).map((rat) => ({
              id: rat.id ? String(rat.id) : void 0,
              description: rat.description ?? "",
              points: Number(rat.points ?? 0)
            }))
          }));
        }
        const assignmentData = {
          id: String(a4.id),
          groupId: String(a4.assignment_group_id),
          name: a4.name,
          pointsPossible: Number(a4.points_possible ?? 0),
          dueAt: a4.due_at ?? null,
          submissionTypes: a4.submission_types ?? [],
          omitFromFinalGrade: Boolean(a4.omit_from_final_grade),
          hasRubric: Boolean(rubric && rubric.length > 0),
          rubric
        };
        return AssignmentSchema.parse(assignmentData);
      });
    }
    parseSubmissions(rawList) {
      return rawList.map((item) => {
        const s3 = item;
        const posted = s3.posted_at !== null && s3.posted_at !== void 0;
        let workflowState = "graded";
        if (s3.workflow_state === "unsubmitted") {
          workflowState = "unsubmitted";
        } else if (s3.workflow_state === "submitted") {
          workflowState = "submitted";
        } else if (s3.workflow_state === "pending_review") {
          workflowState = "pending_review";
        }
        const submissionData = {
          assignmentId: String(s3.assignment_id),
          score: typeof s3.score === "number" ? s3.score : null,
          excused: Boolean(s3.excused),
          missing: Boolean(s3.missing),
          late: Boolean(s3.late),
          posted,
          workflowState
        };
        return SubmissionSchema.parse(submissionData);
      });
    }
    parseRubrics(rawList) {
      const criteria = [];
      for (const item of rawList) {
        const rawObj = item;
        const rawCriteriaList = Array.isArray(rawObj.rubric) ? rawObj.rubric : Array.isArray(rawObj.data) ? rawObj.data : Array.isArray(rawObj) ? rawObj : [];
        for (const r3 of rawCriteriaList) {
          const criterion = {
            id: String(r3.id),
            description: r3.description ?? "",
            points: Number(r3.points ?? 0),
            ratings: (r3.ratings ?? []).map((rat) => ({
              id: rat.id ? String(rat.id) : void 0,
              description: rat.description ?? "",
              points: Number(rat.points ?? 0)
            }))
          };
          criteria.push(RubricCriterionSchema.parse(criterion));
        }
      }
      return criteria;
    }
  };

  // extension/liveCanvas.ts
  var adapter = new CanvasAdapter();
  var MAX_PAGES = 25;
  var CanvasAuthenticationError = class extends Error {
    constructor() {
      super("Your Canvas session has expired. Sign in to Canvas, then refresh GRADIENT.");
      this.name = "CanvasAuthenticationError";
    }
  };
  var CanvasEndpointError = class extends Error {
    constructor(status, message2) {
      super(message2);
      this.status = status;
    }
  };
  function numberOrNull(value) {
    return typeof value === "number" && Number.isFinite(value) ? value : null;
  }
  function message(error) {
    if (error instanceof CanvasEndpointError && error.status === 403) return "Canvas has restricted access to this section.";
    return error instanceof Error ? error.message : "Canvas could not load this section.";
  }
  function isAbort(error) {
    return error instanceof Error && error.name === "AbortError";
  }
  function studentEnrollment(course) {
    return Array.isArray(course.enrollments) ? course.enrollments.find((e3) => (e3.type === "student" || e3.type === "StudentEnrollment" || e3.role === "StudentEnrollment") && (!e3.enrollment_state || e3.enrollment_state === "active")) : void 0;
  }
  function sameOriginUrl(value, fallback, origin) {
    try {
      const url = new URL(typeof value === "string" ? value : fallback, origin);
      return url.origin === origin && ["http:", "https:"].includes(url.protocol) ? url.href : new URL(fallback, origin).href;
    } catch {
      return new URL(fallback, origin).href;
    }
  }
  function visibleToStudent(record) {
    return record.locked_for_user !== true && record.hidden_for_user !== true && record.published !== false && record.state !== "locked" && record.content_details?.locked_for_user !== true;
  }
  function decodeHtmlText(value) {
    return value.replace(/&amp;/gi, "&").replace(/&quot;/gi, '"').replace(/&#39;|&apos;/gi, "'").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&#(\d+);/g, (_3, n2) => {
      const code = Number(n2);
      return code >= 0 && code <= 1114111 ? String.fromCodePoint(code) : "";
    });
  }
  function courseLinkedResources(html, courseId, origin) {
    const resources = [];
    const anchors = html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi);
    for (const [, attributes = "", contents = ""] of anchors) {
      const href = attributes.match(/\bhref\s*=\s*(?:"([^"]*)"|'([^']*)')/i);
      if (!href) continue;
      try {
        const url = new URL(decodeHtmlText(href[1] ?? href[2] ?? ""), origin);
        if (url.origin !== origin) continue;
        const courseFile = url.pathname.match(/^\/courses\/([^/]+)\/files\/(\d+)(?:\/|$)/);
        const globalFile = url.pathname.match(/^\/files\/(\d+)(?:\/|$)/);
        const page = url.pathname.match(/^\/courses\/([^/]+)\/pages\/([^/]+)\/?$/);
        if (courseFile && courseFile[1] !== courseId) continue;
        if (page && page[1] !== courseId) continue;
        if (!courseFile && !globalFile && !page) continue;
        const type = page ? "page" : "file";
        const contentId = page ? decodeURIComponent(page[2]) : courseFile?.[2] ?? globalFile?.[1];
        if (!contentId) continue;
        const title = decodeHtmlText(contents.replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim();
        resources.push({
          id: contentId,
          type,
          title: title || (page ? "Course page" : "Course file"),
          url: page ? `${origin}/courses/${courseId}/pages/${encodeURIComponent(contentId)}` : `${origin}/courses/${courseId}/files/${contentId}`,
          source: "course-link"
        });
      } catch {
      }
    }
    return resources;
  }
  async function loadCanvasSnapshot(options = {}) {
    const browserOrigin = typeof window !== "undefined" ? window.location.origin : void 0;
    const origin = new URL(browserOrigin ?? options.origin ?? "https://canvas.instructure.com").origin;
    if (browserOrigin && options.origin && new URL(options.origin).origin !== browserOrigin) {
      throw new Error("Canvas sync must use the current tab\u2019s origin.");
    }
    if (!origin.startsWith("https://") && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) {
      throw new Error("Canvas sync requires HTTPS.");
    }
    let active = 0;
    const waiters = [];
    const get = async (target) => {
      const url = new URL(target, origin);
      if (url.origin !== origin || !url.pathname.startsWith("/api/v1/")) {
        throw new Error("Canvas returned an unsafe pagination URL.");
      }
      if (active >= 4) await new Promise((resolve) => waiters.push(resolve));
      else active++;
      const controller = new AbortController();
      const abort = () => controller.abort();
      options.signal?.addEventListener("abort", abort, { once: true });
      if (options.signal?.aborted) controller.abort();
      let timedOut = false;
      const timeout = setTimeout(() => {
        timedOut = true;
        abort();
      }, 2e4);
      try {
        let response;
        for (let attempt = 0; ; attempt++) {
          response = await fetch(url.href, {
            method: "GET",
            credentials: "include",
            cache: "no-store",
            redirect: "error",
            headers: { Accept: "application/json" },
            signal: controller.signal
          });
          const throttled = response.status === 429 || response.status === 403 && response.headers.get("X-Rate-Limit-Remaining") === "0";
          if (!throttled || attempt >= 2) break;
          const retryAfter = response.headers.get("Retry-After");
          const seconds = retryAfter === null ? NaN : Number(retryAfter);
          const requestedDelay = Number.isFinite(seconds) ? seconds * 1e3 : retryAfter ? Date.parse(retryAfter) - Date.now() : NaN;
          const delay = Math.min(1e4, Math.max(0, Number.isFinite(requestedDelay) ? requestedDelay : 500 * 2 ** attempt));
          await response.body?.cancel();
          options.onProgress?.("Canvas is busy. Retrying your sync\u2026");
          await new Promise((resolve, reject) => {
            const cancel = () => {
              clearTimeout(timer);
              reject(new DOMException("Canvas sync was cancelled.", "AbortError"));
            };
            const timer = setTimeout(() => {
              controller.signal.removeEventListener("abort", cancel);
              resolve();
            }, delay);
            controller.signal.addEventListener("abort", cancel, { once: true });
            if (controller.signal.aborted) cancel();
          });
        }
        if (response.status === 401) throw new CanvasAuthenticationError();
        if (!response.ok) {
          const status = response.status === 403 && response.headers.get("X-Rate-Limit-Remaining") === "0" ? 429 : response.status;
          throw new CanvasEndpointError(status, `Canvas returned HTTP ${status}.`);
        }
        let data;
        try {
          const body = (await response.text()).replace(/^\s*while\s*\(\s*1\s*\)\s*;\s*/, "");
          data = JSON.parse(body);
        } catch {
          throw new CanvasAuthenticationError();
        }
        if (data?.errors || data?.status === "unauthorized") throw new CanvasEndpointError(403, "Canvas denied access to this section.");
        if (data?.message && !data.id && !Array.isArray(data)) throw new CanvasEndpointError(403, String(data.message));
        return { data, headers: response.headers };
      } catch (error) {
        if (timedOut && !options.signal?.aborted) throw new CanvasEndpointError(0, "Canvas took too long to respond. Refresh to try again.");
        throw error;
      } finally {
        clearTimeout(timeout);
        options.signal?.removeEventListener("abort", abort);
        const nextWaiter = waiters.shift();
        if (nextWaiter) nextWaiter();
        else active--;
      }
    };
    const all = async (path) => {
      const result = [];
      let next = new URL(path, origin).href;
      const visited = /* @__PURE__ */ new Set();
      for (let page = 0; next && page < MAX_PAGES; page++) {
        if (visited.has(next)) throw new Error("Canvas returned a repeated pagination page.");
        visited.add(next);
        const { data, headers } = await get(next);
        if (!Array.isArray(data)) throw new Error("Canvas returned an unexpected list response.");
        result.push(...data);
        const match = headers.get("Link")?.match(/<([^>]+)>\s*;\s*rel="?next"?/);
        next = match?.[1] ? new URL(match[1], origin).href : null;
      }
      if (next) throw new Error("This Canvas section is too large to sync completely.");
      return result;
    };
    const query = (path, params = {}) => {
      const url = new URL(path, origin);
      url.searchParams.set("per_page", "100");
      for (const [key, value] of Object.entries(params)) {
        for (const item of Array.isArray(value) ? value : [value]) url.searchParams.append(key, item);
      }
      return url.href;
    };
    options.onProgress?.("Connecting to your Canvas account\u2026");
    const profile = (await get("/api/v1/users/self/profile")).data;
    if (!profile?.id) throw new CanvasAuthenticationError();
    const courseList = await all(query("/api/v1/courses", {
      enrollment_type: "student",
      enrollment_state: "active",
      "include[]": ["total_scores", "syllabus_body"]
    }));
    const studentCourses = courseList.filter((c3) => studentEnrollment(c3) && c3.workflow_state !== "deleted");
    studentCourses.sort((a4, b2) => Number(String(b2.id) === options.courseId) - Number(String(a4.id) === options.courseId));
    const issues = [];
    let loaded = 0;
    const loadCourse = async (raw) => {
      const id = String(raw.id);
      const courseIssues = [];
      const materialFailures = /* @__PURE__ */ new Map();
      const optional = async (section, path) => {
        try {
          return await all(path);
        } catch (error) {
          if (error instanceof CanvasAuthenticationError || isAbort(error)) throw error;
          courseIssues.push({ courseId: id, section, message: message(error) });
          return [];
        }
      };
      const materialIndex = async (section, path) => {
        try {
          return await all(path);
        } catch (error) {
          if (error instanceof CanvasAuthenticationError || isAbort(error)) throw error;
          const expected = error instanceof CanvasEndpointError && [403, 404].includes(error.status);
          materialFailures.set(section, expected ? `Canvas does not expose this course's ${section} index (HTTP ${error.status}).` : message(error));
          if (!expected) courseIssues.push({ courseId: id, section, message: message(error) });
          return [];
        }
      };
      try {
        const prefix = `/api/v1/courses/${encodeURIComponent(id)}`;
        const [groups, assignments, selfSubmissions] = await Promise.all([
          all(query(`${prefix}/assignment_groups`)),
          all(query(`${prefix}/assignments`, { "include[]": ["submission", "rubric"] })),
          optional("Submissions", query(`${prefix}/students/submissions`, { "student_ids[]": "self", "include[]": ["rubric_assessment", "submission_comments"] }))
        ]);
        const normalizedAssignments = adapter.parseAssignments(assignments);
        const byAssignment = new Map(assignments.filter((a4) => a4.submission).map((a4) => [String(a4.id), a4.submission]));
        for (const submission of selfSubmissions) byAssignment.set(String(submission.assignment_id), submission);
        const normalizedSubmissions = adapter.parseSubmissions([...byAssignment.values()]).map((submission) => {
          const source = byAssignment.get(submission.assignmentId);
          if (source?.rubric_assessment && typeof source.rubric_assessment === "object") {
            submission.rubricAssessment = Object.fromEntries(Object.entries(source.rubric_assessment).map(([key, value]) => [key, {
              points: Math.max(0, Number(value.points) || 0),
              ratingId: value.rating_id == null ? void 0 : String(value.rating_id),
              comments: typeof value.comments === "string" ? value.comments : void 0
            }]));
          }
          if (Array.isArray(source?.submission_comments)) {
            submission.submissionComments = source.submission_comments.map((c3) => ({ authorName: String(c3.author_name ?? "Instructor"), comment: String(c3.comment ?? ""), createdAt: c3.created_at }));
          }
          return submission;
        });
        const submissionMap = new Map(normalizedSubmissions.map((s3) => [s3.assignmentId, s3]));
        const [modules, pages, files, announcements, calendarEvents, enrollments, tabs] = await Promise.all([
          optional("Modules", query(`${prefix}/modules`, { "include[]": ["items"] })),
          materialIndex("Pages", query(`${prefix}/pages`)),
          materialIndex("Files", query(`${prefix}/files`)),
          optional("Announcements", query("/api/v1/announcements", { "context_codes[]": `course_${id}` })),
          optional("Calendar", query("/api/v1/calendar_events", { "context_codes[]": `course_${id}` })),
          optional("Grade totals", query(`${prefix}/enrollments`, { user_id: "self", "type[]": "StudentEnrollment" })),
          // Navigation visibility describes the index, not permissions on individual module items.
          all(query(`${prefix}/tabs`)).catch((error) => {
            if (error instanceof CanvasAuthenticationError || isAbort(error)) throw error;
            return [];
          })
        ]);
        await Promise.all(modules.filter(visibleToStudent).map(async (module) => {
          if (typeof module.items_count === "number" && module.items_count > (module.items?.length ?? 0)) {
            module.items = await optional("Module items", query(`${prefix}/modules/${module.id}/items`));
          }
        }));
        const enrollment = enrollments.find((e3) => String(e3.user_id) === String(profile.id) && (e3.type === "StudentEnrollment" || e3.role === "StudentEnrollment")) ?? studentEnrollment(raw) ?? {};
        const resourceMap = /* @__PURE__ */ new Map();
        const blockedResourceKeys = /* @__PURE__ */ new Set();
        const addResource = (key, resource) => {
          if (!blockedResourceKeys.has(key) && !resourceMap.has(key)) resourceMap.set(key, resource);
        };
        const pageKey = (slug, pageId) => `page:${String(slug ?? pageId)}`;
        const modulePageSlug = (item) => item.page_url ?? (typeof item.html_url === "string" ? new URL(sameOriginUrl(item.html_url, `/courses/${id}/modules/items/${item.id}`, origin)).pathname.match(/\/pages\/([^/]+)\/?$/)?.[1] : void 0);
        for (const file of files.filter((f4) => !visibleToStudent(f4))) blockedResourceKeys.add(`file:${file.id}`);
        for (const page of pages.filter((p3) => !visibleToStudent(p3))) blockedResourceKeys.add(pageKey(page.url, page.page_id));
        for (const module of modules) {
          for (const item of Array.isArray(module.items) ? module.items : []) {
            if (visibleToStudent(module) && visibleToStudent(item)) continue;
            if (item.type === "File" && item.content_id != null) blockedResourceKeys.add(`file:${item.content_id}`);
            if (item.type === "Page" && modulePageSlug(item)) blockedResourceKeys.add(pageKey(modulePageSlug(item), item.content_id));
          }
        }
        for (const page of pages.filter(visibleToStudent)) {
          addResource(pageKey(page.url, page.page_id), {
            id: String(page.page_id ?? page.url),
            type: "page",
            title: String(page.title ?? "Page"),
            url: sameOriginUrl(page.html_url, `/courses/${id}/pages/${encodeURIComponent(page.url ?? "")}`, origin),
            source: "index"
          });
        }
        for (const file of files.filter(visibleToStudent)) {
          addResource(`file:${file.id}`, {
            id: String(file.id),
            type: "file",
            title: String(file.display_name ?? file.filename ?? "File"),
            url: `${origin}/courses/${id}/files/${file.id}`,
            source: "index"
          });
        }
        for (const module of modules.filter(visibleToStudent)) {
          addResource(`module:${module.id}`, {
            id: String(module.id),
            type: "module",
            title: String(module.name ?? "Module"),
            url: `${origin}/courses/${id}/modules#module_${module.id}`,
            source: "module"
          });
          for (const item of Array.isArray(module.items) ? module.items : []) {
            if (!["Page", "File"].includes(item.type) || !visibleToStudent(item)) continue;
            const type = item.type === "File" ? "file" : "page";
            const slug = modulePageSlug(item);
            const key = type === "file" ? `file:${item.content_id ?? `module-item-${item.id}`}` : pageKey(slug, item.content_id ?? `module-item-${item.id}`);
            addResource(key, {
              id: `module-item-${item.id}`,
              type,
              title: String(item.title ?? "Course resource"),
              url: sameOriginUrl(item.html_url, `/courses/${id}/modules/items/${item.id}`, origin),
              source: "module"
            });
          }
        }
        const courseHtml = [raw.syllabus_body, ...assignments.map((a4) => a4.description), ...announcements.map((a4) => a4.message)];
        for (const html of courseHtml) {
          if (typeof html !== "string") continue;
          for (const resource of courseLinkedResources(html, id, origin)) addResource(`${resource.type}:${resource.id}`, resource);
        }
        const resources = [...resourceMap.values()];
        const materialAccess = ["Pages", "Files"].map((section) => {
          const type = section === "Pages" ? "page" : "file";
          const count = resources.filter((r3) => r3.type === type).length;
          const failure = materialFailures.get(section);
          const navigation = tabs.find((t3) => t3.id === section.toLowerCase());
          const reason = failure && navigation?.hidden === true ? `The ${section} navigation tab is hidden. ${failure}` : failure;
          return { section, status: failure ? count > 0 ? "module-links" : "unavailable" : "direct", count, reason };
        });
        let courseForAdapter = raw;
        if (Number(raw.grading_standard_id) > 0 && !Array.isArray(raw.grading_standard) && !Array.isArray(raw.grading_scheme)) {
          try {
            const standard = (await get(`${prefix}/grading_standards/${raw.grading_standard_id}`)).data;
            if (Array.isArray(standard?.grading_scheme)) courseForAdapter = { ...raw, grading_scheme: standard.grading_scheme };
          } catch (error) {
            if (error instanceof CanvasAuthenticationError || isAbort(error)) throw error;
            courseIssues.push({ courseId: id, section: "Grading scheme", message: message(error) });
          }
        }
        const input = {
          course: adapter.parseCourse(courseForAdapter, 3),
          groups: adapter.parseAssignmentGroups(groups),
          assignments: normalizedAssignments,
          submissions: normalizedSubmissions,
          priorityWeight: 1
        };
        return {
          id,
          name: String(raw.name),
          code: String(raw.course_code ?? raw.name),
          url: `${origin}/courses/${id}`,
          syllabusHtml: typeof raw.syllabus_body === "string" ? raw.syllabus_body : "",
          input,
          currentScore: numberOrNull(enrollment.grades?.current_score ?? enrollment.computed_current_score),
          finalScore: numberOrNull(enrollment.grades?.final_score ?? enrollment.computed_final_score),
          assignments: normalizedAssignments.map((assignment, i3) => ({
            ...assignment,
            htmlUrl: sameOriginUrl(assignments[i3]?.html_url, `/courses/${id}/assignments/${assignment.id}`, origin),
            descriptionHtml: typeof assignments[i3]?.description === "string" ? assignments[i3].description : "",
            submission: submissionMap.get(assignment.id) ?? null
          })),
          resources,
          materialAccess,
          announcements: announcements.map((a4) => ({ id: String(a4.id), title: String(a4.title ?? "Announcement"), bodyHtml: String(a4.message ?? ""), postedAt: a4.posted_at ?? null, url: sameOriginUrl(a4.html_url, `/courses/${id}/discussion_topics/${a4.id}`, origin) })),
          calendarEvents: calendarEvents.map((e3) => ({ id: String(e3.id), title: String(e3.title ?? "Calendar event"), startAt: e3.start_at ?? null, endAt: e3.end_at ?? null, url: sameOriginUrl(e3.html_url, `/courses/${id}`, origin) })),
          issues: courseIssues
        };
      } catch (error) {
        if (error instanceof CanvasAuthenticationError || isAbort(error)) throw error;
        issues.push({ courseId: id, section: String(raw.name ?? "Course"), message: message(error) });
        return null;
      } finally {
        loaded++;
        options.onProgress?.(`Synced ${loaded} of ${studentCourses.length} courses\u2026`);
      }
    };
    const courses = [];
    for (let offset = 0; offset < studentCourses.length; offset += 3) {
      const batch = await Promise.all(studentCourses.slice(offset, offset + 3).map(loadCourse));
      courses.push(...batch.filter((c3) => c3 !== null));
    }
    return {
      origin,
      syncedAt: (/* @__PURE__ */ new Date()).toISOString(),
      user: { id: String(profile.id), name: String(profile.name ?? "Canvas student"), shortName: String(profile.short_name ?? profile.name ?? "Student"), avatarUrl: typeof profile.avatar_url === "string" ? profile.avatar_url : void 0 },
      courses,
      issues
    };
  }

  // core/grade.ts
  function determineDroppedAssignments(items, rules) {
    if (items.length === 0) {
      return { dropped: [], kept: [] };
    }
    const neverDropSet = new Set(rules.neverDrop);
    const droppableCandidates = items.filter(
      (item) => !item.isNeverDrop && !neverDropSet.has(item.assignmentId)
    );
    const lockedItems = items.filter(
      (item) => item.isNeverDrop || neverDropSet.has(item.assignmentId)
    );
    if (droppableCandidates.length === 0 || rules.dropLowest === 0 && rules.dropHighest === 0) {
      return { dropped: [], kept: items };
    }
    let remainingCandidates = [...droppableCandidates];
    const droppedIds = [];
    const dropHighestCount = Math.min(rules.dropHighest, remainingCandidates.length);
    for (let d3 = 0; d3 < dropHighestCount; d3++) {
      if (remainingCandidates.length === 0) break;
      let bestIndex = 0;
      let worstResultingRatio = Infinity;
      for (let i3 = 0; i3 < remainingCandidates.length; i3++) {
        const testRemaining = [
          ...lockedItems,
          ...remainingCandidates.filter((_3, idx) => idx !== i3)
        ];
        const sumEarned = testRemaining.reduce((acc, it) => acc + it.score, 0);
        const sumPossible = testRemaining.reduce((acc, it) => acc + it.pointsPossible, 0);
        const ratio = sumPossible > 0 ? sumEarned / sumPossible : 0;
        if (ratio < worstResultingRatio) {
          worstResultingRatio = ratio;
          bestIndex = i3;
        }
      }
      const removed = remainingCandidates.splice(bestIndex, 1)[0];
      droppedIds.push(removed.assignmentId);
    }
    const dropLowestCount = Math.min(rules.dropLowest, remainingCandidates.length);
    for (let d3 = 0; d3 < dropLowestCount; d3++) {
      if (remainingCandidates.length === 0) break;
      let bestIndex = 0;
      let bestResultingRatio = -Infinity;
      for (let i3 = 0; i3 < remainingCandidates.length; i3++) {
        const candidate = remainingCandidates[i3];
        const testRemaining = [
          ...lockedItems,
          ...remainingCandidates.filter((_3, idx) => idx !== i3)
        ];
        const sumEarned = testRemaining.reduce((acc, it) => acc + it.score, 0);
        const sumPossible = testRemaining.reduce((acc, it) => acc + it.pointsPossible, 0);
        const ratio = sumPossible > 0 ? sumEarned / sumPossible : 1;
        if (ratio > bestResultingRatio) {
          bestResultingRatio = ratio;
          bestIndex = i3;
        } else if (ratio === bestResultingRatio) {
          const currentBest = remainingCandidates[bestIndex];
          if (candidate.pointsPossible > currentBest.pointsPossible) {
            bestIndex = i3;
          }
        }
      }
      const removed = remainingCandidates.splice(bestIndex, 1)[0];
      droppedIds.push(removed.assignmentId);
    }
    const kept = [...lockedItems, ...remainingCandidates];
    return { dropped: droppedIds, kept };
  }
  function getLetterGrade(percentage, scheme) {
    const sortedScheme = [...scheme].sort((a4, b2) => b2.minPct - a4.minPct);
    for (const item of sortedScheme) {
      if (percentage >= item.minPct) {
        return item.letter;
      }
    }
    return sortedScheme[sortedScheme.length - 1]?.letter ?? "F";
  }
  function getGradePoints(letter, scale) {
    return scale[letter] ?? 0;
  }
  function computeCanvasGrade(course, groups, assignments, submissions, options = {}) {
    const {
      includeUnposted = false,
      treatUnsubmittedAsZero = false,
      roundingDecimals = 2
    } = options;
    const submissionMap = /* @__PURE__ */ new Map();
    for (const sub of submissions) {
      submissionMap.set(sub.assignmentId, sub);
    }
    const assignmentMap = /* @__PURE__ */ new Map();
    for (const assign of assignments) {
      assignmentMap.set(assign.id, assign);
    }
    const groupBreakdowns = [];
    const allDroppedAssignmentIds = [];
    let grandTotalEarned = 0;
    let grandTotalPossible = 0;
    for (const group of groups) {
      const groupAssignments = assignments.filter((a4) => a4.groupId === group.id);
      const gradedItems = [];
      for (const assign of groupAssignments) {
        if (assign.omitFromFinalGrade) {
          continue;
        }
        const sub = submissionMap.get(assign.id);
        if (sub?.excused) {
          continue;
        }
        let score2 = null;
        if (sub && !sub.posted && !includeUnposted) {
          if (treatUnsubmittedAsZero) {
            score2 = 0;
          } else {
            continue;
          }
        }
        if (score2 === null) {
          if (sub && sub.score !== null) {
            score2 = sub.score;
          } else if (treatUnsubmittedAsZero) {
            score2 = 0;
          }
        }
        if (score2 !== null) {
          const isNeverDrop = group.rules.neverDrop.includes(assign.id);
          gradedItems.push({
            assignmentId: assign.id,
            name: assign.name,
            score: score2,
            pointsPossible: assign.pointsPossible,
            isNeverDrop
          });
        }
      }
      const { dropped, kept } = determineDroppedAssignments(gradedItems, group.rules);
      allDroppedAssignmentIds.push(...dropped);
      const pointsEarned = kept.reduce((acc, it) => acc + it.score, 0);
      const pointsPossible = kept.reduce((acc, it) => acc + it.pointsPossible, 0);
      const percentage = pointsPossible > 0 ? pointsEarned / pointsPossible * 100 : null;
      grandTotalEarned += pointsEarned;
      grandTotalPossible += pointsPossible;
      groupBreakdowns.push({
        groupId: group.id,
        groupName: group.name,
        weight: group.weight,
        pointsEarned,
        pointsPossible,
        percentage,
        droppedAssignmentIds: dropped,
        keptAssignmentIds: kept.map((it) => it.assignmentId),
        assignmentCount: groupAssignments.length,
        gradedCount: gradedItems.length
      });
    }
    let finalPercentage = null;
    if (course.applyGroupWeights) {
      let weightedEarnedSum = 0;
      let activeWeightTotal = 0;
      for (const bg of groupBreakdowns) {
        if (bg.percentage !== null) {
          weightedEarnedSum += bg.percentage * bg.weight / 100;
          activeWeightTotal += bg.weight;
        } else if (bg.pointsPossible === 0 && bg.pointsEarned > 0) {
          weightedEarnedSum += bg.pointsEarned;
        }
      }
      if (activeWeightTotal > 0) {
        finalPercentage = weightedEarnedSum / (activeWeightTotal / 100);
      }
    } else {
      if (grandTotalPossible > 0) {
        finalPercentage = grandTotalEarned / grandTotalPossible * 100;
      }
    }
    if (finalPercentage !== null) {
      const factor = Math.pow(10, roundingDecimals);
      finalPercentage = Math.round(finalPercentage * factor) / factor;
    }
    const letterGrade = finalPercentage !== null ? getLetterGrade(finalPercentage, course.gradingScheme) : null;
    const gradePoints = letterGrade !== null ? getGradePoints(letterGrade, course.gradePointScale) : null;
    return {
      percentage: finalPercentage,
      letterGrade,
      gradePoints,
      totalPointsEarned: Math.round(grandTotalEarned * 100) / 100,
      totalPointsPossible: Math.round(grandTotalPossible * 100) / 100,
      groups: groupBreakdowns,
      droppedAssignmentIds: allDroppedAssignmentIds,
      groupWeightsApplied: course.applyGroupWeights,
      creditHours: course.creditHours
    };
  }

  // core/gradeModel.ts
  function currentGrade(courseData, options) {
    return computeCanvasGrade(
      courseData.course,
      courseData.groups,
      courseData.assignments,
      courseData.submissions,
      {
        treatUnsubmittedAsZero: false,
        includeUnposted: false,
        roundingDecimals: 2,
        ...options
      }
    );
  }

  // core/optimiserPriors.ts
  var DEFAULT_TASK_PRIORS = {
    homework: {
      taskType: "homework",
      cap: 0.98,
      tau: 3,
      noiseSigma: 0.05,
      alphaLogged: 0.15
    },
    problem_set: {
      taskType: "problem_set",
      cap: 0.96,
      tau: 4,
      noiseSigma: 0.06,
      alphaLogged: 0.15
    },
    essay: {
      taskType: "essay",
      cap: 0.94,
      tau: 6,
      noiseSigma: 0.07,
      alphaLogged: 0.12
    },
    exam: {
      taskType: "exam",
      cap: 0.92,
      tau: 8,
      noiseSigma: 0.08,
      alphaLogged: 0.1
    },
    quiz: {
      taskType: "quiz",
      cap: 0.95,
      tau: 2,
      noiseSigma: 0.05,
      alphaLogged: 0.18
    },
    project: {
      taskType: "project",
      cap: 0.95,
      tau: 10,
      noiseSigma: 0.07,
      alphaLogged: 0.1
    },
    default: {
      taskType: "default",
      cap: 0.95,
      tau: 4,
      noiseSigma: 0.06,
      alphaLogged: 0.14
    }
  };
  function inferTaskType(assignmentName, submissionTypes, groupName) {
    const combined = `${assignmentName} ${groupName ?? ""}`.toLowerCase();
    if (combined.includes("quiz")) {
      return "quiz";
    }
    if (combined.includes("exam") || combined.includes("midterm") || combined.includes("final exam") || combined.includes("test")) {
      return "exam";
    }
    if (combined.includes("essay") || combined.includes("paper") || combined.includes("report") || combined.includes("critique")) {
      return "essay";
    }
    if (combined.includes("project") || combined.includes("proposal") || combined.includes("milestone") || combined.includes("presentation")) {
      return "project";
    }
    if (combined.includes("problem set") || combined.includes("pset") || combined.includes("problem-set")) {
      return "problem_set";
    }
    if (combined.includes("hw") || combined.includes("homework") || combined.includes("lab") || combined.includes("exercise")) {
      return "homework";
    }
    if (submissionTypes?.includes("online_quiz")) {
      return "quiz";
    }
    return "default";
  }
  function computeEffectiveTau(baseTau, loggedHours = 0, alphaLogged = 0.15, tauScale = 1) {
    const safeLogged = Math.max(0, loggedHours);
    const loggedMultiplier = Math.max(0.25, 1 / (1 + alphaLogged * safeLogged));
    return baseTau * tauScale * loggedMultiplier;
  }
  function expectedScoreFraction(hours, cap, tauEffective) {
    if (hours <= 0) return 0;
    if (tauEffective <= 0) return cap;
    return cap * (1 - Math.exp(-hours / tauEffective));
  }

  // core/optimiser.ts
  var SeededRandom = class {
    state;
    constructor(seed = 42) {
      this.state = seed >>> 0;
    }
    /** Uniform random float in [0, 1) */
    next() {
      let z4 = this.state += 1831565813;
      z4 = Math.imul(z4 ^ z4 >>> 15, z4 | 1);
      z4 ^= z4 + Math.imul(z4 ^ z4 >>> 7, z4 | 61);
      return ((z4 ^ z4 >>> 14) >>> 0) / 4294967296;
    }
    /** Standard Normal distribution N(0, 1) using Box-Muller transform */
    nextGaussian() {
      let u4 = 0;
      let v3 = 0;
      while (u4 === 0) u4 = this.next();
      while (v3 === 0) v3 = this.next();
      return Math.sqrt(-2 * Math.log(u4)) * Math.cos(2 * Math.PI * v3);
    }
  };
  function buildCourseEvalContext(input, options, tauScale = 1) {
    const { course, groups, assignments, submissions } = input;
    const loggedHoursMap = input.loggedHours ?? {};
    const studyEligibleIds = input.studyEligibleAssignmentIds === void 0 ? null : new Set(input.studyEligibleAssignmentIds);
    const creditHours = Math.max(0.5, course.creditHours ?? 3);
    const priorityWeight = Math.max(0.01, input.priorityWeight ?? 1);
    const subMap = new Map(submissions.map((s3) => [s3.assignmentId, s3]));
    const groupMap = new Map(groups.map((g3) => [g3.id, g3]));
    const fixedGroupItems = /* @__PURE__ */ new Map();
    const upcomingByGroup = /* @__PURE__ */ new Map();
    for (const g3 of groups) {
      fixedGroupItems.set(g3.id, []);
      upcomingByGroup.set(g3.id, []);
    }
    const allUpcoming = [];
    const nowTime = options.currentTime ? new Date(options.currentTime).getTime() : null;
    for (const assign of assignments) {
      if (assign.omitFromFinalGrade) continue;
      const sub = subMap.get(assign.id);
      if (sub?.excused) continue;
      const group = groupMap.get(assign.groupId);
      if (!group) continue;
      const isNeverDrop = group.rules.neverDrop.includes(assign.id);
      if (sub && sub.score !== null && sub.posted) {
        fixedGroupItems.get(group.id).push({
          assignmentId: assign.id,
          name: assign.name,
          score: sub.score,
          pointsPossible: assign.pointsPossible,
          isNeverDrop
        });
        continue;
      }
      const taskType = inferTaskType(assign.name, assign.submissionTypes, group.name);
      const basePrior = DEFAULT_TASK_PRIORS[taskType] ?? DEFAULT_TASK_PRIORS["default"];
      const customPrior = options.customPriors?.[taskType];
      const cap = customPrior?.cap ?? basePrior.cap;
      const baseTau = customPrior?.tau ?? basePrior.tau;
      const noiseSigma = customPrior?.noiseSigma ?? basePrior.noiseSigma;
      const alphaLogged = customPrior?.alphaLogged ?? basePrior.alphaLogged;
      const logged = loggedHoursMap[assign.id] ?? 0;
      const tauEff = computeEffectiveTau(baseTau, logged, alphaLogged, tauScale);
      let isPastDeadline = false;
      if (nowTime !== null && assign.dueAt) {
        const dueTime = new Date(assign.dueAt).getTime();
        if (dueTime <= nowTime) {
          isPastDeadline = true;
        }
      }
      const isStudyEligible = studyEligibleIds === null || studyEligibleIds.has(assign.id);
      const maxH = isPastDeadline || !isStudyEligible ? 0 : Math.min(options.maxHoursPerAssignment ?? 8, 24);
      const meta = {
        uniqueKey: `${course.id}::${assign.id}`,
        assignmentId: assign.id,
        assignmentName: assign.name,
        courseId: course.id,
        courseName: course.name,
        groupId: group.id,
        groupName: group.name,
        pointsPossible: assign.pointsPossible,
        taskType,
        cap,
        tauEffective: tauEff,
        noiseSigma,
        dueAt: assign.dueAt ?? null,
        isEligible: !isPastDeadline && maxH > 0,
        minHours: options.minHoursPerAssignment ?? 0,
        maxHours: maxH
      };
      upcomingByGroup.get(group.id).push(meta);
      allUpcoming.push(meta);
    }
    return {
      course,
      groups,
      creditHours,
      priorityWeight,
      fixedGroupItems,
      upcomingByGroup,
      allUpcoming
    };
  }
  function evaluateCourseMonteCarlo(ctx, hoursMap, noiseMatrix, numSamples) {
    const { course, groups, fixedGroupItems, upcomingByGroup } = ctx;
    const samplePercentages = new Float64Array(numSamples);
    const sampleGpas = new Float64Array(numSamples);
    let sumGpa = 0;
    let sumPct = 0;
    const fastGroups = groups.map((g3) => {
      const fixed = fixedGroupItems.get(g3.id) ?? [];
      const upcomingList = upcomingByGroup.get(g3.id) ?? [];
      const fixedEarned = fixed.reduce((acc, it) => acc + it.score, 0);
      const fixedPossible = fixed.reduce((acc, it) => acc + it.pointsPossible, 0);
      const hasDropRules = g3.rules.dropLowest > 0 || g3.rules.dropHighest > 0;
      let upcomingPossibleSum = 0;
      const fastUpcoming = [];
      for (const it of upcomingList) {
        const h3 = hoursMap.get(it.uniqueKey) ?? 0;
        const mu = expectedScoreFraction(h3, it.cap, it.tauEffective);
        const zArr = noiseMatrix.get(it.uniqueKey);
        const isNeverDrop = g3.rules.neverDrop.includes(it.assignmentId);
        upcomingPossibleSum += it.pointsPossible;
        fastUpcoming.push({
          meta: it,
          mu,
          sigma: it.noiseSigma,
          pts: it.pointsPossible,
          h: h3,
          zArray: zArr,
          isNeverDrop
        });
      }
      return {
        group: g3,
        hasDropRules,
        fixedEarned,
        fixedPossible,
        fixedItems: fixed,
        upcoming: fastUpcoming,
        upcomingPossibleSum
      };
    });
    const dropBuffer = [];
    for (let s3 = 0; s3 < numSamples; s3++) {
      let grandEarned = 0;
      let grandPossible = 0;
      let weightedEarnedSum = 0;
      let activeWeightSum = 0;
      for (let gIdx = 0; gIdx < fastGroups.length; gIdx++) {
        const fg = fastGroups[gIdx];
        let groupEarned = 0;
        let groupPossible = 0;
        if (!fg.hasDropRules) {
          groupEarned = fg.fixedEarned;
          for (let uIdx = 0; uIdx < fg.upcoming.length; uIdx++) {
            const up = fg.upcoming[uIdx];
            if (up.h > 0) {
              const z4 = up.zArray[s3];
              const frac = Math.min(1, Math.max(0, up.mu + up.sigma * z4));
              groupEarned += frac * up.pts;
            }
          }
          groupPossible = fg.fixedPossible + fg.upcomingPossibleSum;
        } else {
          dropBuffer.length = 0;
          for (let fIdx = 0; fIdx < fg.fixedItems.length; fIdx++) {
            dropBuffer.push(fg.fixedItems[fIdx]);
          }
          for (let uIdx = 0; uIdx < fg.upcoming.length; uIdx++) {
            const up = fg.upcoming[uIdx];
            let score2 = 0;
            if (up.h > 0) {
              const z4 = up.zArray[s3];
              const frac = Math.min(1, Math.max(0, up.mu + up.sigma * z4));
              score2 = frac * up.pts;
            }
            dropBuffer.push({
              assignmentId: up.meta.assignmentId,
              name: up.meta.assignmentName,
              score: score2,
              pointsPossible: up.pts,
              isNeverDrop: up.isNeverDrop
            });
          }
          const { kept } = determineDroppedAssignments(dropBuffer, fg.group.rules);
          for (let k3 = 0; k3 < kept.length; k3++) {
            groupEarned += kept[k3].score;
            groupPossible += kept[k3].pointsPossible;
          }
        }
        grandEarned += groupEarned;
        grandPossible += groupPossible;
        if (groupPossible > 0 && fg.group.weight > 0) {
          const groupPct = groupEarned / groupPossible * 100;
          weightedEarnedSum += groupPct * fg.group.weight;
          activeWeightSum += fg.group.weight;
        }
      }
      let finalPct = 0;
      if (course.applyGroupWeights) {
        finalPct = activeWeightSum > 0 ? weightedEarnedSum / activeWeightSum : 0;
      } else {
        finalPct = grandPossible > 0 ? grandEarned / grandPossible * 100 : 0;
      }
      samplePercentages[s3] = finalPct;
      const letter = getLetterGrade(finalPct, course.gradingScheme);
      const gpa = getGradePoints(letter, course.gradePointScale);
      sampleGpas[s3] = gpa;
      sumPct += finalPct;
      sumGpa += gpa;
    }
    return {
      expectedGpa: sumGpa / numSamples,
      expectedPct: sumPct / numSamples,
      samplePercentages,
      sampleGpas
    };
  }
  function optimizeEffort(courseInputs, options) {
    const startTime = performance.now();
    const capacity = Math.max(0, options.capacityHours);
    const stepSize = options.stepSizeHours ?? 0.5;
    const numSamples = options.numSamples ?? 1e3;
    const seed = options.seed ?? 42;
    const tauScale = options.tauScale ?? 1;
    const rng = new SeededRandom(seed);
    const courseContexts = courseInputs.map(
      (input) => buildCourseEvalContext(input, options, tauScale)
    );
    const noiseMatrix = /* @__PURE__ */ new Map();
    for (const ctx of courseContexts) {
      for (const assign of ctx.allUpcoming) {
        const arr = new Float64Array(numSamples);
        for (let s3 = 0; s3 < numSamples; s3++) {
          arr[s3] = rng.nextGaussian();
        }
        noiseMatrix.set(assign.uniqueKey, arr);
      }
    }
    const totalWeightDenominator = courseContexts.reduce(
      (acc, ctx) => acc + ctx.priorityWeight * ctx.creditHours,
      0
    );
    const courseWeights = courseContexts.map(
      (ctx) => ctx.priorityWeight * ctx.creditHours / (totalWeightDenominator || 1)
    );
    const assignmentToCourseIdx = /* @__PURE__ */ new Map();
    const allEligibleUpcoming = [];
    courseContexts.forEach((ctx, idx) => {
      for (const it of ctx.allUpcoming) {
        assignmentToCourseIdx.set(it.uniqueKey, idx);
        if (it.isEligible) {
          allEligibleUpcoming.push(it);
        }
      }
    });
    const currentHours = /* @__PURE__ */ new Map();
    for (const it of allEligibleUpcoming) {
      currentHours.set(it.uniqueKey, 0);
    }
    let remainingCapacity = capacity;
    if (options.protectMastery && allEligibleUpcoming.length > 0) {
      const floorH = options.masteryFloorHours ?? 0.5;
      for (const it of allEligibleUpcoming) {
        if (remainingCapacity < floorH) break;
        const initialH = Math.min(floorH, it.maxHours);
        currentHours.set(it.uniqueKey, initialH);
        remainingCapacity -= initialH;
      }
    }
    const courseEvals = courseContexts.map(
      (ctx) => evaluateCourseMonteCarlo(ctx, currentHours, noiseMatrix, numSamples)
    );
    const baselineGpa = courseEvals.reduce(
      (acc, ev, idx) => acc + (courseWeights[idx] ?? 0) * ev.expectedGpa,
      0
    );
    const computeOverallSemesterGpa = () => {
      return courseEvals.reduce(
        (acc, ev, idx) => acc + (courseWeights[idx] ?? 0) * ev.expectedGpa,
        0
      );
    };
    while (remainingCapacity >= stepSize - 1e-6) {
      let bestAssignment = null;
      let bestGpaGain = -Infinity;
      let bestPctGain = -Infinity;
      let bestNewCourseEval = null;
      for (const it of allEligibleUpcoming) {
        const hCurr = currentHours.get(it.uniqueKey) ?? 0;
        if (hCurr + stepSize > it.maxHours + 1e-6) continue;
        const cIdx2 = assignmentToCourseIdx.get(it.uniqueKey);
        const ctx = courseContexts[cIdx2];
        const prevEval = courseEvals[cIdx2];
        const cWeight = courseWeights[cIdx2] ?? 0;
        currentHours.set(it.uniqueKey, hCurr + stepSize);
        const testEval = evaluateCourseMonteCarlo(ctx, currentHours, noiseMatrix, numSamples);
        currentHours.set(it.uniqueKey, hCurr);
        const marginalGpaGain = cWeight * (testEval.expectedGpa - prevEval.expectedGpa);
        const marginalPctGain = cWeight * (testEval.expectedPct - prevEval.expectedPct);
        if (marginalGpaGain > bestGpaGain + 1e-6 || Math.abs(marginalGpaGain - bestGpaGain) <= 1e-6 && marginalPctGain > bestPctGain) {
          bestGpaGain = marginalGpaGain;
          bestPctGain = marginalPctGain;
          bestAssignment = it;
          bestNewCourseEval = testEval;
        }
      }
      if (!bestAssignment || !bestNewCourseEval || bestGpaGain <= 0 && bestPctGain <= 0) {
        break;
      }
      const currH = currentHours.get(bestAssignment.uniqueKey) ?? 0;
      currentHours.set(bestAssignment.uniqueKey, currH + stepSize);
      remainingCapacity -= stepSize;
      const cIdx = assignmentToCourseIdx.get(bestAssignment.uniqueKey);
      courseEvals[cIdx] = bestNewCourseEval;
    }
    let swapImproved = true;
    let swapIterations = 0;
    const maxSwapIterations = 40;
    while (swapImproved && swapIterations < maxSwapIterations) {
      swapImproved = false;
      swapIterations++;
      for (const donor of allEligibleUpcoming) {
        const hDonor = currentHours.get(donor.uniqueKey) ?? 0;
        if (hDonor < stepSize - 1e-6) continue;
        for (const recipient of allEligibleUpcoming) {
          if (donor.uniqueKey === recipient.uniqueKey) continue;
          const hRecip = currentHours.get(recipient.uniqueKey) ?? 0;
          if (hRecip + stepSize > recipient.maxHours + 1e-6) continue;
          const dIdx = assignmentToCourseIdx.get(donor.uniqueKey);
          const rIdx = assignmentToCourseIdx.get(recipient.uniqueKey);
          const curGpa = computeOverallSemesterGpa();
          currentHours.set(donor.uniqueKey, hDonor - stepSize);
          currentHours.set(recipient.uniqueKey, hRecip + stepSize);
          const dEvalNew = evaluateCourseMonteCarlo(
            courseContexts[dIdx],
            currentHours,
            noiseMatrix,
            numSamples
          );
          let rEvalNew = dEvalNew;
          if (dIdx !== rIdx) {
            rEvalNew = evaluateCourseMonteCarlo(
              courseContexts[rIdx],
              currentHours,
              noiseMatrix,
              numSamples
            );
          }
          let proposedGpa = 0;
          for (let i3 = 0; i3 < courseContexts.length; i3++) {
            const w3 = courseWeights[i3] ?? 0;
            if (i3 === dIdx) proposedGpa += w3 * dEvalNew.expectedGpa;
            else if (i3 === rIdx) proposedGpa += w3 * rEvalNew.expectedGpa;
            else proposedGpa += w3 * courseEvals[i3].expectedGpa;
          }
          if (proposedGpa > curGpa + 1e-5) {
            courseEvals[dIdx] = dEvalNew;
            courseEvals[rIdx] = rEvalNew;
            swapImproved = true;
            break;
          } else {
            currentHours.set(donor.uniqueKey, hDonor);
            currentHours.set(recipient.uniqueKey, hRecip);
          }
        }
        if (swapImproved) break;
      }
    }
    const finalGpa = computeOverallSemesterGpa();
    const totalAllocated = capacity - remainingCapacity;
    const recommendations = [];
    for (const it of allEligibleUpcoming) {
      const hours = currentHours.get(it.uniqueKey) ?? 0;
      if (hours <= 0) continue;
      const cIdx = assignmentToCourseIdx.get(it.uniqueKey);
      const ctx = courseContexts[cIdx];
      const scoreFrac = expectedScoreFraction(hours, it.cap, it.tauEffective);
      const scorePct = Math.round(scoreFrac * 1e3) / 10;
      const withoutItHours = new Map(currentHours);
      withoutItHours.set(it.uniqueKey, 0);
      const baseCEval = evaluateCourseMonteCarlo(
        ctx,
        withoutItHours,
        noiseMatrix,
        numSamples
      );
      const finalCEval = courseEvals[cIdx];
      const cGain = Math.max(0, finalCEval.expectedGpa - baseCEval.expectedGpa);
      const marginalGpa = hours > 0 ? cGain / hours : 0;
      const baseLetter = getLetterGrade(baseCEval.expectedPct, ctx.course.gradingScheme);
      const optLetter = getLetterGrade(finalCEval.expectedPct, ctx.course.gradingScheme);
      let reason = "";
      if (baseLetter !== optLetter && cGain > 0.01) {
        reason = `Allocating ${hours.toFixed(1)}h elevates ${ctx.course.name.split(":")[0]} from a ${baseLetter} (${baseCEval.expectedPct.toFixed(1)}%) to ${optLetter} (${finalCEval.expectedPct.toFixed(1)}%), achieving a +${cGain.toFixed(2)} course grade-point increase.`;
      } else if (it.groupName.toLowerCase().includes("homework") || it.groupName.toLowerCase().includes("quiz")) {
        reason = `Allocating ${hours.toFixed(1)}h secures ${it.assignmentName} at ~${scorePct}%, protecting your ${it.groupName} group against drop-rule score penalties.`;
      } else {
        reason = `Allocating ${hours.toFixed(1)}h targets ~${scorePct}% on ${it.assignmentName} to buffer ${ctx.course.name.split(":")[0]} against test-day variance.`;
      }
      recommendations.push({
        assignmentId: it.assignmentId,
        assignmentName: it.assignmentName,
        courseId: it.courseId,
        courseName: it.courseName,
        allocatedHours: hours,
        expectedScorePct: scorePct,
        expectedGradePointGain: Math.round(cGain * 100) / 100,
        marginalGainPerHour: Math.round(marginalGpa * 1e3) / 1e3,
        reason
      });
    }
    recommendations.sort((a4, b2) => b2.allocatedHours - a4.allocatedHours);
    const thresholdAlerts = [];
    for (let i3 = 0; i3 < courseContexts.length; i3++) {
      const ctx = courseContexts[i3];
      const ev = courseEvals[i3];
      const curPct = ev.expectedPct;
      const curLetter = getLetterGrade(curPct, ctx.course.gradingScheme);
      const sortedScheme = [...ctx.course.gradingScheme].sort((a4, b2) => b2.minPct - a4.minPct);
      const curIdx = sortedScheme.findIndex((s3) => s3.letter === curLetter);
      if (curIdx > 0) {
        const nextThreshold = sortedScheme[curIdx - 1];
        const targetPct = nextThreshold.minPct;
        const pointsNeeded = Math.max(0, targetPct - curPct);
        let crossingSamples = 0;
        for (let s3 = 0; s3 < numSamples; s3++) {
          if (ev.samplePercentages[s3] >= targetPct) {
            crossingSamples++;
          }
        }
        const prob = crossingSamples / numSamples;
        const courseUpcoming = ctx.allUpcoming.filter((a4) => a4.isEligible);
        const allocatedInCourse = courseUpcoming.reduce(
          (acc, a4) => acc + (currentHours.get(a4.uniqueKey) ?? 0),
          0
        );
        const shortCourseName = ctx.course.name.split(":")[0] ?? ctx.course.name;
        const alertMessage = `${shortCourseName} is ${pointsNeeded.toFixed(2)} points under a ${nextThreshold.letter} (${targetPct.toFixed(1)}%); ${allocatedInCourse.toFixed(1)} hours likely crosses it (${Math.round(prob * 100)}% probability).`;
        thresholdAlerts.push({
          courseId: ctx.course.id,
          courseName: ctx.course.name,
          currentGradePct: Math.round(curPct * 100) / 100,
          currentLetter: curLetter,
          nextLetter: nextThreshold.letter,
          targetPct,
          pointsNeeded: Math.round(pointsNeeded * 100) / 100,
          hoursToLikelyCross: allocatedInCourse,
          probabilityOfCrossing: Math.round(prob * 100) / 100,
          alertMessage
        });
      }
    }
    let robustness;
    if (!options.isRobustnessRun) {
      robustness = computeRobustnessCheck(courseInputs, options, recommendations);
    } else {
      robustness = {
        confidence: "high",
        topAssignmentsMatch: true,
        details: "Internal perturbation run",
        perturbationResults: {
          fasterPace: { tauScale: 0.7, topAssignmentIds: [], expectedGpa: finalGpa },
          slowerPace: { tauScale: 1.3, topAssignmentIds: [], expectedGpa: finalGpa }
        }
      };
    }
    const runtimeMs = Math.round(performance.now() - startTime);
    return {
      totalCapacityHours: capacity,
      allocatedHours: Math.round(totalAllocated * 10) / 10,
      baselineExpectedGpa: Math.round(baselineGpa * 100) / 100,
      optimizedExpectedGpa: Math.round(finalGpa * 100) / 100,
      expectedGpaGain: Math.round((finalGpa - baselineGpa) * 100) / 100,
      recommendations,
      thresholdAlerts,
      robustness,
      metadata: {
        seed,
        numSamples,
        stepSizeHours: stepSize,
        runtimeMs,
        assumptionsUsed: {
          priors: DEFAULT_TASK_PRIORS,
          loggedHoursMultiplier: "tau_effective = tau * max(0.25, 1 / (1 + 0.15 * loggedHours))",
          noiseDistribution: "Truncated Normal N(0, sigma^2) clamped to [0, 1] via Box-Muller CRN"
        }
      }
    };
  }
  function computeRobustnessCheck(courseInputs, baseOptions, baseRecommendations) {
    const baseTopIds = baseRecommendations.slice(0, 2).map((r3) => r3.assignmentId);
    const optFaster = optimizeEffort(courseInputs, {
      ...baseOptions,
      tauScale: 0.7,
      isRobustnessRun: true,
      // Use slightly fewer samples for perturbation speed
      numSamples: Math.min(baseOptions.numSamples ?? 1e3, 500)
    });
    const fastTopIds = optFaster.recommendations.slice(0, 2).map((r3) => r3.assignmentId);
    const optSlower = optimizeEffort(courseInputs, {
      ...baseOptions,
      tauScale: 1.3,
      isRobustnessRun: true,
      numSamples: Math.min(baseOptions.numSamples ?? 1e3, 500)
    });
    const slowTopIds = optSlower.recommendations.slice(0, 2).map((r3) => r3.assignmentId);
    const fastTopMatches = baseTopIds.length === 0 || baseTopIds[0] === fastTopIds[0];
    const slowTopMatches = baseTopIds.length === 0 || baseTopIds[0] === slowTopIds[0];
    let confidence;
    let details;
    if (fastTopMatches && slowTopMatches) {
      confidence = "high";
      details = "High confidence: Top priority assignments remain identical even if individual study pace is 30% faster or slower than assumed.";
    } else if (fastTopMatches || slowTopMatches) {
      confidence = "medium";
      details = "Medium confidence: Top assignment recommendation is moderately sensitive to study pace variations.";
    } else {
      confidence = "low";
      details = "Low confidence: Prioritized coursework shifts significantly under varying learning speed assumptions.";
    }
    return {
      confidence,
      topAssignmentsMatch: fastTopMatches && slowTopMatches,
      details,
      perturbationResults: {
        fasterPace: {
          tauScale: 0.7,
          topAssignmentIds: fastTopIds,
          expectedGpa: optFaster.optimizedExpectedGpa
        },
        slowerPace: {
          tauScale: 1.3,
          topAssignmentIds: slowTopIds,
          expectedGpa: optSlower.optimizedExpectedGpa
        }
      }
    };
  }

  // extension/ui/workspaceStyles.ts
  var WORKSPACE_STYLES = `
:host{all:initial;color-scheme:light;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#182037;font-size:14px;line-height:1.5}
*,*::before,*::after{box-sizing:border-box}
button,input,select,textarea{font:inherit}
button,a,input,select{touch-action:manipulation}
button,a,select{cursor:pointer}
button{color:inherit}
button{transition:background .18s,border-color .18s,color .18s,box-shadow .18s}
a{color:inherit;text-decoration:none}
button:disabled{cursor:wait;opacity:.6}
button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid #2855e8;outline-offset:3px}
svg{display:block;flex-shrink:0}
h1,h2,h3,p{margin:0}
button{border:0}
input,select{max-width:100%}
 .gw,.g-launcher{font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
.gw{position:fixed;right:14px;top:14px;bottom:14px;width:min(480px,calc(100vw - 28px));z-index:2147483646;display:flex;flex-direction:column;background:#f7f8fc;border:1px solid #fff;border-radius:24px;box-shadow:0 14px 80px #111c3e30,0 0 0 1px #1c2b4d10;overflow:hidden;color:#182037;font-size:14px;line-height:1.5;isolation:isolate}
.gw.wide{width:min(860px,calc(100vw - 28px))}
.g-header{display:flex;align-items:center;gap:10px;padding:21px 24px 18px;background:#fff;border-bottom:1px solid #e9edf5;flex-shrink:0}
.g-brand{display:flex;gap:10px;align-items:center;flex:1}
.g-logo{display:grid;place-items:center;width:35px;height:35px;background:#2855e8;color:white;border-radius:11px}
.g-wordmark{font-weight:850;letter-spacing:-1.2px;font-size:23px;line-height:1}
.g-brand-sub{font-size:9px;font-weight:700;letter-spacing:1.7px;color:#667085;margin-top:5px;text-transform:uppercase}
.g-icon-btn{width:32px;height:32px;display:grid;place-items:center;background:transparent;color:#657087;border-radius:8px}
.g-icon-btn:hover{background:#eef2fa;color:#2855e8}
.g-status{padding:12px 24px 0;background:#fff;display:flex;align-items:center;justify-content:space-between;gap:8px;color:#536079;font-size:11px}
.g-live{display:flex;gap:6px;align-items:center;font-size:10px;font-weight:750;letter-spacing:.6px;text-transform:uppercase}
.g-dot{height:6px;width:6px;border-radius:50%;background:#16825c;box-shadow:0 0 0 3px #d9f8e8}
.g-demo-dot{background:#a66a12;box-shadow:0 0 0 3px #fff0cb}
.g-nav{display:flex;gap:3px;padding:15px 16px 16px;background:#fff;border-bottom:1px solid #e5e9f1;flex-shrink:0}
.g-tab{flex:1;min-width:0;display:flex;justify-content:center;gap:6px;align-items:center;padding:9px 4px;border-radius:9px;background:transparent;color:#657087;font-size:11px;font-weight:700;white-space:nowrap}
.g-tab.active{color:#2855e8;background:#edf2ff}
.g-tab:hover{background:#f2f5fb}
.g-body{padding:24px;overflow:auto;overscroll-behavior:contain;flex:1;min-height:0;scrollbar-width:thin;scrollbar-color:#ccd5e6 transparent}
.g-stack{display:flex;flex-direction:column;gap:20px}
.g-eyebrow{color:#66738b;font-size:10px;font-weight:750;letter-spacing:1.5px;text-transform:uppercase}
.g-title{font-size:29px;letter-spacing:-1.3px;line-height:1.14;font-weight:800;margin-top:6px}
.g-title .g-accent{color:#2855e8}
.g-subtitle{font-size:12px;line-height:1.65;color:#647087;margin-top:9px}
.g-greeting{display:flex;justify-content:space-between;gap:8px;align-items:flex-start}
.g-date{font-size:10px;color:#58647b;background:#fff;border:1px solid #e4e9f3;border-radius:8px;padding:6px 8px;white-space:nowrap;margin-top:3px;font-weight:600}
.g-metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px}
.g-metric{background:#fff;padding:16px 12px;border-radius:13px;border:1px solid #e5e9f1}
.g-metric strong{display:block;font-size:27px;font-weight:800;letter-spacing:-1px;line-height:1.25;margin-bottom:5px}
.g-metric small{font-size:10px;color:#5c6880;font-weight:600}
.g-metric.blue{background:#2855e8;border-color:#2855e8;color:#fff}
.g-metric.blue small{color:#e5ebff}
.g-metric.peach{background:#ffede6;border-color:#ffe2d6}
.g-metric.peach strong{color:#a83f20}
.g-section-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}
.g-section-head h2{font-size:15px;letter-spacing:-.3px;font-weight:750}
.g-label-count{font-size:10px;color:#647087;background:#eaf0f7;border-radius:6px;padding:3px 6px;font-weight:700}
.g-link-btn{background:transparent;font-size:11px;font-weight:700;color:#2855e8;display:flex;align-items:center;gap:4px;padding:3px 0}
.g-course-list{display:grid;grid-template-columns:minmax(0,1fr);gap:9px;min-width:0}
.g-course{width:100%;min-width:0;text-align:left;display:flex;gap:12px;align-items:center;padding:15px;background:white;border:1px solid #e5e9f1;border-radius:13px}
.g-course:hover{border-color:#a5b9f7;background:#fcfdff}
.g-course-symbol{white-space:nowrap;height:37px;width:37px;border-radius:10px;display:grid;place-items:center;font-size:11px;font-weight:800;background:var(--tint);color:var(--ink);flex-shrink:0}
.g-course-info{min-width:0;flex:1}
.g-course-info strong{display:block;font-size:12px;font-weight:750;line-height:1.4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.g-course-info small{font-size:10px;color:#647087}
.g-track{height:4px;background:#edf0f6;border-radius:99px;margin-top:8px;overflow:hidden}
.g-track span{display:block;height:100%;background:var(--ink,#2855e8);border-radius:99px}
.g-course-score{flex-shrink:0;font-weight:800;font-size:17px;letter-spacing:-.5px}
.g-course-score small{display:block;font-size:9px;font-weight:500;color:#647087;text-align:right;letter-spacing:0}
.g-task{display:flex;align-items:flex-start;gap:12px;padding:13px 0;border-bottom:1px solid #e9edf4}
.g-task:last-child{border-bottom:0;padding-bottom:0}
.g-task:first-child{padding-top:0}
.g-task-marker{height:30px;width:30px;display:grid;place-items:center;background:#edf2ff;color:#2855e8;border-radius:8px;flex-shrink:0;margin-top:2px}
.g-task-main{flex:1;min-width:0}
.g-task-main strong{display:block;font-size:12px;font-weight:650;line-height:1.5}
.g-task-main a:hover{color:#2855e8}
.g-task-meta{font-size:10px;color:#66738b;display:flex;flex-wrap:wrap;align-items:center;gap:5px;margin-top:4px}
.g-due{font-size:9px;font-weight:750;color:#9c411d;background:#ffecdf;padding:3px 6px;border-radius:5px;white-space:nowrap}
.g-due.normal{color:#426080;background:#edf2f7}
.g-card{background:#fff;border:1px solid #e5e9f1;border-radius:16px;padding:19px}
.g-plan{border:0;background:#edf3ff;position:relative;overflow:hidden}
.g-plan h2{font-size:20px;letter-spacing:-.7px;line-height:1.2;max-width:220px}
.g-plan .g-subtitle{max-width:270px;font-size:11px}
.g-plan-mark{position:absolute;right:20px;top:17px;height:52px;width:52px;border-radius:16px;background:#dbe6ff;color:#2855e8;display:grid;place-items:center;transform:rotate(-9deg)}
.g-plan-controls{display:flex;align-items:center;gap:10px;margin-top:18px}
.g-hours{display:flex;align-items:center;gap:7px;background:#fff;border:1px solid #dbe3f5;border-radius:9px;padding:7px 9px;font-size:11px;color:#5b6880}
.g-hours input{width:38px;border:0;background:transparent;color:#182037;font-weight:750;padding:0}
.g-primary{display:flex;align-items:center;justify-content:center;gap:7px;padding:10px 14px;background:#2855e8;border:1px solid #2855e8;color:#fff;border-radius:9px;font-size:11px;font-weight:700;min-height:37px}
.g-primary:hover{background:#1740c8;border-color:#1740c8}
.g-secondary{display:flex;align-items:center;justify-content:center;gap:7px;background:#fff;border:1px solid #dbe1ed;border-radius:9px;padding:9px 12px;font-size:11px;font-weight:700;min-height:36px}
.g-secondary:hover{background:#f0f4ff;border-color:#b7c8fa}
.g-notice{display:flex;align-items:flex-start;gap:8px;font-size:11px;line-height:1.6;padding:11px 12px;border-radius:9px;background:#fff4df;color:#7f5520}
.g-notice.info{background:#eaf2ff;color:#345276}
.g-notice.success{background:#e7f6ed;color:#276345}
.g-small{font-size:10px;color:#647087;line-height:1.7}
.g-select{width:100%;padding:11px 12px;background:#fff;border:1px solid #dce3ee;border-radius:10px;color:#182037;font-size:12px}
.g-field-label{font-size:11px;font-weight:700;margin-bottom:7px;display:block}
.g-toolbar{display:flex;gap:8px}
.g-search{display:flex;gap:8px;align-items:center;flex:1;background:#fff;border:1px solid #dce3ee;border-radius:10px;padding:10px 12px;color:#647087}
.g-search input{width:100%;min-width:0;border:0;outline:0;background:transparent;color:#182037;font-size:12px;padding:0}
.g-chips{display:flex;gap:6px;flex-wrap:wrap}
.g-chip{font-size:10px;font-weight:700;border-radius:7px;padding:6px 9px;background:#fff;border:1px solid #e2e7f0;color:#5e6c84}
.g-chip.active{background:#2855e8;border-color:#2855e8;color:white}
.g-grade-card{background:#2855e8;color:#fff;display:flex;align-items:center;gap:24px;padding:24px;border-radius:16px}
.g-grade-ring{height:98px;width:98px;border-radius:50%;padding:7px;background:conic-gradient(#c4f69c calc(var(--grade,0)*1%),#ffffff30 0);flex-shrink:0}
.g-grade-ring>div{height:100%;width:100%;border-radius:50%;background:#2855e8;display:flex;flex-direction:column;align-items:center;justify-content:center}
.g-grade-ring strong{font-size:20px;letter-spacing:-.7px;white-space:nowrap}
.g-grade-ring small{font-size:7px;white-space:nowrap;color:#e0e8ff;text-transform:uppercase;font-weight:700;letter-spacing:.5px}
.g-grade-info h2{font-size:15px;line-height:1.4;font-weight:700;letter-spacing:-.3px}
.g-grade-info p{font-size:10px;color:#dce5ff;margin-top:7px}
.g-grade-info span{font-size:9px;background:#ffffff20;display:inline-flex;gap:4px;align-items:center;padding:3px 6px;border-radius:5px;margin-top:9px}
.g-range{width:100%;accent-color:#2855e8;cursor:pointer;margin:17px 0 8px}
.g-whatif-result{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px}
.g-whatif-result>div{background:#f4f6fb;border-radius:9px;padding:12px}
.g-whatif-result strong{display:block;font-size:22px;font-weight:750;letter-spacing:-.8px}
.g-whatif-result small{font-size:10px;color:#647087}
.g-resource{display:flex;gap:11px;padding:14px 0;border-bottom:1px solid #e9edf4}
.g-resource:last-child{border:0;padding-bottom:0}
.g-resource:first-child{padding-top:0}
.g-resource:hover strong{color:#2855e8}
.g-resource-icon{height:34px;width:34px;background:#f0f3fa;color:#5b6c8d;border-radius:9px;display:grid;place-items:center;flex-shrink:0}
.g-resource>span:nth-child(2){flex:1;min-width:0}
.g-resource strong{font-size:12px;display:block;font-weight:650}
.g-resource small{font-size:10px;color:#647087;text-transform:capitalize}
.g-announcement{padding:13px 0;border-bottom:1px solid #e9edf4}
.g-announcement:first-child{padding-top:0}
.g-announcement:last-child{padding-bottom:0;border:0}
.g-announcement summary{font-size:12px;font-weight:650;cursor:pointer;line-height:1.5}
.g-announcement p{font-size:11px;color:#5e6b81;white-space:pre-line;margin-top:9px;max-height:220px;overflow:auto}
.g-announcement a{font-size:10px;color:#2855e8;display:inline-block;margin-top:8px;font-weight:700}
.g-empty{text-align:center;padding:32px 18px;color:#66738b;font-size:12px}
.g-empty-icon{display:grid;place-items:center;height:48px;width:48px;margin:0 auto 14px;background:#edf2ff;border-radius:14px;color:#2855e8}
.g-empty h2{font-size:16px;color:#182037;letter-spacing:-.4px;margin-bottom:6px}
.g-empty p{line-height:1.7;max-width:280px;margin:0 auto}
.g-footer{border-top:1px solid #e5e9f1;padding:11px 24px;background:#fff;display:flex;align-items:center;justify-content:space-between;color:#66738b;font-size:9px;flex-shrink:0}
.g-footer>span{display:flex;gap:5px;align-items:center}
.g-user{height:22px;width:22px;background:#f6e9dc;color:#785733;border-radius:50%;display:grid;place-items:center;font-size:9px;font-weight:750}
.g-launcher{position:fixed;right:20px;bottom:22px;z-index:2147483646;border-radius:18px;background:#2855e8;color:white;padding:14px 19px;display:flex;align-items:center;gap:10px;box-shadow:0 6px 32px #173bbc50;font-weight:750;font-size:14px;border:1px solid #ffffff45}
.g-launcher:hover{background:#1740c8}
.g-setting-row{display:flex;justify-content:space-between;align-items:center;gap:14px;padding:12px 0;border-bottom:1px solid #e9edf4;font-size:11px}
.g-setting-row:last-child{border:0}
.g-setting-row span{color:#647087}
.g-setting-row strong{font-weight:650;overflow-wrap:anywhere;text-align:right}
.g-credit{width:55px;border:1px solid #dce3ee;border-radius:7px;padding:5px 7px;font-size:11px}
.g-credits label{font-size:11px;display:flex;justify-content:space-between;align-items:center;gap:12px;padding:9px 0}
.g-plan-result{margin-top:14px}
.g-plan-result .g-task{border-color:#dce5f7}
.g-plan-result .g-task-marker{background:white}
.g-skeleton{height:92px;border-radius:13px;background:linear-gradient(100deg,#e9edf5 20%,#f8faff 45%,#e9edf5 70%);background-size:220% 100%;animation:g-shimmer 1.6s infinite}
.g-sync-loading{display:flex;gap:8px;align-items:center;color:#2855e8;font-size:11px;margin-bottom:12px}
.g-spinner{animation:g-spin 1.2s linear infinite}
.g-resource-count{font-size:29px;font-weight:800;letter-spacing:-1px;color:#2855e8}
.g-syllabus{font-size:12px;line-height:1.8;color:#536079;white-space:pre-line;max-height:330px;overflow:auto}
.g-title-row{display:flex;justify-content:space-between;align-items:flex-end;gap:14px}
.g-version{font-size:9px;color:#647087;letter-spacing:.5px}
.g-overview-grid>section{min-width:0;width:100%}.g-overview-grid{display:flex;flex-direction:column;gap:20px}
.wide .g-overview-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-items:start}
.wide .g-overview-grid>section:first-child{grid-row:span 2}
.wide .g-title{font-size:34px}
.wide .g-metric{padding:20px}
.wide .g-nav{gap:12px}
.wide .g-tab{font-size:12px}
.wide .g-course{padding:17px}
.wide .g-plan h2{max-width:210px}
.g-issue-details{font-size:11px;color:#7f5520;background:#fff4df;border-radius:10px;padding:11px 13px}
.g-issue-details summary{cursor:pointer;font-weight:650}
.g-issue-details ul{margin:9px 0 0;padding-left:16px;line-height:1.7}
.g-assignment-description{font-size:12px;color:#536079;line-height:1.8;white-space:pre-line;max-height:230px;overflow:auto;margin-top:13px}
.g-legend{display:flex;justify-content:space-between;font-size:10px;color:#647087}
.g-gradient-art{display:flex;align-items:flex-end;gap:4px;position:absolute;right:18px;bottom:23px;pointer-events:none;opacity:.3}
.g-gradient-art i{display:block;width:8px;border-radius:3px;background:#2855e8}
.g-gradient-art i:nth-child(1){height:14px}
.g-gradient-art i:nth-child(2){height:24px}
.g-gradient-art i:nth-child(3){height:36px}
.g-gradient-art i:nth-child(4){height:50px}
.g-gradient-art i:nth-child(5){height:63px}
.g-plan-controls{position:relative;z-index:1}
.g-bottom-note{font-size:10px;color:#647087;display:flex;gap:6px;align-items:center}
.g-loading-sub{font-size:11px;color:#647087;margin-top:9px}
.g-course-link{font-size:10px;font-weight:700;color:#2855e8;display:inline-flex;gap:4px;align-items:center}
.g-bold-number{font-variant-numeric:tabular-nums}
.g-course-menu{display:flex;gap:9px;align-items:center}
.g-course-menu .g-select{flex:1;min-width:0}

.g-feedback-summary{cursor:pointer;font-size:13px;font-weight:750;line-height:1.6}.g-feedback-summary>span:last-child{margin-left:10px;vertical-align:middle}.g-rubric-list{margin-top:14px}.g-rubric-criterion{padding:15px 0;border-top:1px solid #e9edf4}.g-rubric-criterion:last-child{padding-bottom:0}.g-rubric-criterion h3{font-size:12px;font-weight:700;line-height:1.6}.g-rubric-criterion .g-section-head{align-items:flex-start}.g-rubric-criterion .g-label-count{flex-shrink:0}.g-ratings-summary{font-size:11px;color:#2855e8;font-weight:650;cursor:pointer}.g-rubric-ratings{list-style:none;margin:9px 0 0;padding:0;background:#f7f8fc;border:1px solid #e9edf4;border-radius:9px;overflow:hidden}.g-rubric-ratings li{padding:10px 11px;border-bottom:1px solid #e9edf4;font-size:11px;line-height:1.65;display:flex;gap:12px;align-items:flex-start;color:#536079}.g-rubric-ratings li:last-child{border:0}.g-rubric-ratings li>span{flex:1;min-width:0}.g-rubric-ratings strong{white-space:nowrap;font-size:10px;font-weight:700;color:#34425d}.g-feedback-comments{margin-top:17px;padding-top:15px;border-top:1px solid #e9edf4}.g-feedback-comments h3{font-size:12px;font-weight:750}.g-instructor-comment{padding:12px 0;border-bottom:1px solid #e9edf4}.g-instructor-comment:last-child{border:0;padding-bottom:0}.g-comment-author{display:flex;gap:10px;justify-content:space-between;font-size:10px;color:#536079}.g-comment-author strong{font-weight:700;color:#34425d}.g-comment-author time{flex-shrink:0}.g-instructor-comment p{font-size:12px;line-height:1.75;color:#536079;white-space:pre-line;margin-top:6px}
@keyframes g-shimmer{to{background-position:-220% 0}
}
@keyframes g-spin{to{transform:rotate(360deg)}
}
@media(max-width:600px){.gw,.gw.wide{right:0;top:0;bottom:0;width:100vw;border-radius:0;border:0}
.g-header{padding:17px 18px}
.g-status{padding:11px 18px 0}
.g-nav{padding:13px 18px}
.g-body{padding:21px 18px}
.g-footer{padding:11px 18px}
.g-title{font-size:28px}
.g-date{display:none}
.wide .g-overview-grid{display:flex}
.g-tab{gap:4px;font-size:10px}
.g-tab svg{width:14px}
.g-grade-card{padding:20px;gap:17px}
.g-plan-mark{right:15px}
.g-metric{padding:14px 11px}
.g-wordmark{font-size:22px}
.g-launcher{right:14px;bottom:14px}
.g-hide-mobile{display:none}
}
@media(max-width:400px){.g-tab svg{display:none}.g-grade-card{gap:13px}.g-grade-ring{height:88px;width:88px}.g-grade-ring strong{font-size:20px}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}
}

`;
  var ASSISTANT_ENTRY_STYLES = `
.g-assistant-entry{display:flex;align-items:center;gap:12px;text-align:left;border-radius:14px;border:1px solid #dbe3f5;background:#edf3ff;color:#182037;padding:17px 16px;width:100%}
.g-assistant-entry:hover{background:#e5edff;border-color:#b7c8fa}.g-assistant-entry>span:nth-child(2){flex:1;min-width:0}
.g-assistant-entry strong{display:block;font-size:12px;line-height:1.5}.g-assistant-entry small{display:block;margin-top:4px;color:#647087;font-size:10px;line-height:1.6}
.g-assistant-entry-icon{display:grid;place-items:center;width:38px;height:38px;background:#2855e8;border:1px solid #2855e8;border-radius:12px;color:#fff;flex-shrink:0}
@media(max-width:420px){.g-nav{padding-left:10px;padding-right:10px;gap:1px}.g-tab{font-size:10px;gap:3px}.g-tab svg{width:13px;height:13px}}
`;

  // node_modules/preact/jsx-runtime/dist/jsxRuntime.mjs
  var f3 = Symbol.for("pv");
  var o3 = 0;
  var u3 = Array.isArray;
  function a3(t3, e3, n2, u4, a4, i3) {
    e3 || (e3 = {});
    var c3, l3, p3 = e3;
    if ("ref" in p3 && "function" != typeof t3) for (l3 in p3 = {}, e3) "ref" == l3 ? c3 = e3[l3] : p3[l3] = e3[l3];
    var s3 = { type: t3, props: p3, key: n2, ref: c3, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: f3, __v: --o3, __i: -1, __u: 0 };
    return (a4 || i3) && (s3.__source = a4, s3.__self = i3), n.vnode && n.vnode(s3), s3;
  }

  // extension/ui/Icons.tsx
  var paths = {
    grid: "M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z",
    book: "M4 4h6a3 3 0 0 1 3 3v14a4 4 0 0 0-4-3H4z M20 4h-4a3 3 0 0 0-3 3 M20 4v14h-3a4 4 0 0 0-4 3",
    folder: "M3 7V5a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
    settings: "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M9 3l-1 3-3 1-2 3 2 2v3l3 2 1 3h5l1-3 3-1 2-3-2-2v-3l-3-2-1-3z",
    arrow: "M5 12h14 M13 6l6 6-6 6",
    refresh: "M20 7v5h-5 M4 17v-5h5 M6 6a8 8 0 0 1 13 2 M18 18a8 8 0 0 1-13-2",
    close: "M6 6l12 12 M18 6L6 18",
    expand: "M9 3H3v6 M3 3l7 7 M15 21h6v-6 M21 21l-7-7",
    collapse: "M5 12h14",
    calendar: "M5 4h14a2 2 0 0 1 2 2v14H3V6a2 2 0 0 1 2-2z M7 2v5 M17 2v5 M3 10h18 M7 14h2 M12 14h2 M7 17h2",
    clock: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18 M12 7v5l3 2",
    check: "M5 12l4 4L19 6",
    shield: "M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6z M8 12l3 3 5-6",
    search: "M10.5 3a7.5 7.5 0 1 0 0 15 7.5 7.5 0 0 0 0-15 M16 16l5 5",
    file: "M5 3h9l5 5v13H5z M14 3v6h5 M9 13h6 M9 17h6",
    layers: "M12 3L2 8l10 5 10-5z M2 12l10 5 10-5 M2 16l10 5 10-5",
    bolt: "M13 2L4 14h7l-1 8 10-13h-8z",
    chart: "M4 20V4 M4 20h17 M8 15l4-5 4 2 5-7",
    alert: "M12 3L2 21h20z M12 9v5 M12 17v1",
    download: "M12 3v12 M7 10l5 5 5-5 M4 16v5h16v-5",
    chevron: "M9 5l7 7-7 7",
    external: "M14 3h7v7 M21 3L10 14 M10 3H3v18h18v-7",
    spark: "M12 2l2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5z",
    user: "M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M4 21v-3a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v3"
  };
  function Icon({ name, size = 18, className = "" }) {
    return /* @__PURE__ */ a3("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "1.7", "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true", class: className, children: /* @__PURE__ */ a3("path", { d: paths[name] }) });
  }

  // extension/ui/MaterialAccess.tsx
  function MaterialAccess({ courses, compact = false }) {
    const sections = courses.flatMap((course) => (course.materialAccess ?? []).filter((access) => access.status !== "direct").map((access) => ({ course, access })));
    if (!sections.length) return null;
    return /* @__PURE__ */ a3("section", { class: "g-card", role: "region", "aria-label": "Material access", children: [
      /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
        /* @__PURE__ */ a3("h2", { children: compact ? "Material access" : "Course materials" }),
        /* @__PURE__ */ a3(Icon, { name: "folder", size: 17 })
      ] }),
      /* @__PURE__ */ a3("p", { class: "g-small", style: { marginBottom: "12px" }, children: "Some instructors hide the Pages or Files index. GRADIENT also finds material links in modules, the syllabus, and coursework." }),
      /* @__PURE__ */ a3("div", { style: { display: "grid", gap: "12px" }, children: sections.map(({ course, access }) => /* @__PURE__ */ a3("div", { style: { borderTop: "1px solid #e5e9f1", paddingTop: "11px" }, children: [
        !compact && /* @__PURE__ */ a3("div", { class: "g-small", style: { marginBottom: "4px" }, children: course.code }),
        /* @__PURE__ */ a3("strong", { style: { display: "block", fontSize: "12px", color: access.count ? "#187352" : "#536079" }, children: [
          access.section,
          " \xB7 ",
          access.count > 0 ? `${access.count} linked ${access.count === 1 ? "resource" : "resources"}` : "Not available in this course"
        ] }),
        /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "4px" }, children: access.reason }),
        access.count > 0 && /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "3px" }, children: "Linked materials are listed in the course library. Canvas checks access when you open each item." })
      ] }, `${course.id}-${access.section}`)) })
    ] });
  }

  // extension/assistantTransport.ts
  function validateBackendUrl(value) {
    let url;
    try {
      url = new URL(value);
    } catch {
      throw new Error("Enter a local backend URL, for example http://127.0.0.1:8765.");
    }
    if (url.protocol !== "http:" || !["127.0.0.1", "localhost"].includes(url.hostname) || url.username || url.password || url.search || url.hash || !["", "/"].includes(url.pathname)) {
      throw new Error("The AI backend must be an HTTP service on localhost.");
    }
    return url.origin;
  }
  function validateAssistantPath(path, method) {
    const get = method === "GET" && (/^\/api\/v1\/assistant\/health$/.test(path) || /^\/api\/v1\/assistant\/jobs\/[a-zA-Z0-9_-]{1,80}$/.test(path));
    const post = method === "POST" && /^\/api\/v1\/assistant\/(models\/pull|generate|browser\/plan|materials\/extract|jobs)$/.test(path);
    if (!get && !post) throw new Error("This local assistant operation is not supported.");
  }
  async function localAssistantFetch(backendUrl, path, method, body) {
    const origin = validateBackendUrl(backendUrl);
    validateAssistantPath(path, method);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 24e3);
    try {
      const response = await fetch(origin + path, {
        method,
        headers: { "Content-Type": "application/json", "X-Gradient-Client": "gradient-extension" },
        body: body === void 0 ? void 0 : JSON.stringify(body),
        credentials: "omit",
        redirect: "error",
        cache: "no-store",
        signal: controller.signal
      });
      const data = await response.json().catch(() => null);
      if (!response.ok) {
        const detail = data?.detail;
        throw new Error(typeof detail === "string" ? detail : `The local assistant returned HTTP ${response.status}.`);
      }
      return data;
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") throw new Error("The local assistant took too long to respond. Check that the service is running.");
      if (error instanceof TypeError) throw new Error("Cannot reach the local AI service. Start it on 127.0.0.1:8765, then check the connection.");
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }

  // extension/canvasMaterials.ts
  var MAX_FILE_BYTES = 12 * 1024 * 1024;
  function canvasHtmlText(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    doc.querySelectorAll("script,style,iframe,input,textarea,select").forEach((el) => el.remove());
    doc.querySelectorAll("p,br,li,h1,h2,h3,tr").forEach((el) => el.append(doc.createTextNode("\n")));
    return (doc.body.textContent ?? "").replace(/\n{3,}/g, "\n\n").trim();
  }
  function materialEndpoint(value, origin, courseId) {
    try {
      const url = new URL(value, origin);
      if (url.origin !== origin) return null;
      const page = url.pathname.match(/^\/courses\/([^/]+)\/pages\/([^/]+)\/?$/);
      if (page && page[1] === courseId) {
        const slug = decodeURIComponent(page[2]);
        if (/[\\/%]/.test(slug) || /^\.+$/.test(slug)) return null;
        return { kind: "page", path: `/api/v1/courses/${encodeURIComponent(courseId)}/pages/${encodeURIComponent(slug)}` };
      }
      const file = url.pathname.match(/^\/courses\/([^/]+)\/files\/(\d+)(?:\/download)?\/?$/);
      if (file && file[1] === courseId) return { kind: "file", path: `/api/v1/files/${file[2]}` };
      const globalFile = url.pathname.match(/^\/files\/(\d+)(?:\/download)?\/?$/);
      if (globalFile) return { kind: "file", path: `/api/v1/files/${globalFile[1]}` };
      return null;
    } catch {
      return null;
    }
  }
  async function boundedBytes(response) {
    if (Number(response.headers.get("Content-Length")) > MAX_FILE_BYTES) throw new Error("File exceeds the 12 MB reading limit.");
    if (!response.body) throw new Error("Canvas returned an empty file.");
    const reader = response.body.getReader();
    const chunks = [];
    let length = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        length += value.byteLength;
        if (length > MAX_FILE_BYTES) throw new Error("File exceeds the 12 MB reading limit.");
        chunks.push(value);
      }
    } catch (error) {
      await reader.cancel();
      throw error;
    } finally {
      reader.releaseLock();
    }
    const bytes = new Uint8Array(length);
    let position = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, position);
      position += chunk.length;
    }
    return bytes;
  }
  function base64(bytes) {
    let binary = "";
    for (let i3 = 0; i3 < bytes.length; i3 += 32768) binary += String.fromCharCode(...bytes.subarray(i3, i3 + 32768));
    return btoa(binary);
  }
  async function readCanvasMaterials(resources, origin, courseId, extract) {
    const warnings = [];
    const result = [];
    for (const resource of resources.slice(0, 12)) {
      if (resource.text?.trim()) {
        result.push({ ...resource, text: resource.text.slice(0, 22e3) });
        continue;
      }
      const endpoint = materialEndpoint(resource.url, origin, courseId);
      if (!endpoint) {
        result.push(resource);
        continue;
      }
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 18e3);
      try {
        const metadata = await fetch(origin + endpoint.path, { method: "GET", credentials: "include", cache: "no-store", redirect: "error", headers: { Accept: "application/json" }, signal: controller.signal });
        if (!metadata.ok) throw new Error(`Canvas returned HTTP ${metadata.status}.`);
        const record = JSON.parse((await metadata.text()).replace(/^\s*while\s*\(\s*1\s*\)\s*;\s*/, ""));
        if (record.locked_for_user || record.hidden_for_user || record.published === false) throw new Error("This material is locked or unpublished.");
        if (endpoint.kind === "page") {
          if (typeof record.body !== "string") throw new Error("Canvas did not return the page body.");
          result.push({ ...resource, text: canvasHtmlText(record.body).slice(0, 22e3) });
        } else {
          if (typeof record.url !== "string") throw new Error("Canvas did not return a download link.");
          const download2 = new URL(record.url, origin);
          if (download2.protocol !== "https:" && download2.origin !== origin) throw new Error("Canvas returned an unsupported download link.");
          const response = await fetch(download2.href, { method: "GET", credentials: download2.origin === origin ? "include" : "omit", redirect: "follow", signal: controller.signal });
          if (!response.ok) throw new Error(`File download returned HTTP ${response.status}.`);
          const bytes = await boundedBytes(response);
          const extracted = await extract({ title: record.display_name || resource.title, mimeType: record["content-type"] || response.headers.get("Content-Type") || "application/octet-stream", data: base64(bytes) });
          warnings.push(...extracted.warnings.map((w3) => `${resource.title}: ${w3}`));
          result.push({ ...resource, text: extracted.text.slice(0, 22e3) });
        }
      } catch (error) {
        result.push(resource);
        warnings.push(`${resource.title}: could not read contents (${error instanceof Error ? error.message : "access unavailable"}). The link is included for reference only.`);
      } finally {
        clearTimeout(timer);
      }
    }
    return { resources: result, warnings };
  }

  // extension/assistantClient.ts
  var DEFAULT_ASSISTANT_SETTINGS = {
    backendUrl: "http://127.0.0.1:8765",
    reasoningModel: "gpt-oss:20b",
    visionModel: "gemma4:e4b",
    detailLevel: "a_bit_more",
    webResearch: true
  };
  var SETTINGS_KEY = "gradient_assistant_settings";
  var settingsSchema = z2.object({
    backendUrl: z2.string().transform(validateBackendUrl),
    reasoningModel: z2.string().min(1).max(200),
    visionModel: z2.string().min(1).max(100),
    detailLevel: z2.enum(["a_bit", "a_bit_more", "all_in"]),
    webResearch: z2.boolean()
  });
  var packetSchema = z2.object({
    title: z2.string().max(1e3),
    summary: z2.string().max(1e4),
    markdown: z2.string().max(2e5),
    sampleMarkdown: z2.string().max(2e5),
    sources: z2.array(z2.object({ id: z2.string(), title: z2.string(), url: z2.string(), excerpt: z2.string().optional(), kind: z2.enum(["canvas", "web"]).optional() })).max(80),
    diagrams: z2.array(z2.object({ title: z2.string(), nodes: z2.array(z2.object({ id: z2.string(), label: z2.string() })).max(20), edges: z2.array(z2.object({ from: z2.string(), to: z2.string(), label: z2.string().optional() })).max(40) })).max(10),
    graphs: z2.array(z2.object({ title: z2.string(), xLabel: z2.string().optional(), yLabel: z2.string().optional(), points: z2.array(z2.object({ label: z2.string(), value: z2.number().finite() })).max(100) })).max(10),
    images: z2.array(z2.object({ title: z2.string(), url: z2.string(), alt: z2.string(), sourceUrl: z2.string() })).max(20),
    warnings: z2.array(z2.string()).max(100),
    checklist: z2.array(z2.string()).optional(),
    generatedAt: z2.string().optional()
  });
  function extensionAvailable() {
    return typeof chrome !== "undefined" && !!chrome.runtime?.id;
  }
  async function sendMessage(message2) {
    const response = await chrome.runtime.sendMessage(message2);
    if (!response?.ok) throw new Error(response?.error || "The extension could not complete this operation. Reload the extension and Canvas tab.");
    return response.data;
  }
  async function request(settings, path, method, body) {
    const backendUrl = validateBackendUrl(settings.backendUrl);
    if (extensionAvailable()) return sendMessage({ type: "GRADIENT_ASSISTANT_REQUEST", backendUrl, path: `/api/v1/assistant/${path}`, method, body });
    return localAssistantFetch(backendUrl, `/api/v1/assistant/${path}`, method, body);
  }
  async function loadAssistantSettings() {
    let saved;
    if (typeof chrome !== "undefined" && chrome.storage?.local) saved = (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY];
    else if (typeof localStorage !== "undefined") {
      try {
        saved = JSON.parse(localStorage.getItem(SETTINGS_KEY) || "{}");
      } catch {
        saved = {};
      }
    }
    const parsed = settingsSchema.safeParse({ ...DEFAULT_ASSISTANT_SETTINGS, ...saved && typeof saved === "object" ? saved : {} });
    return parsed.success ? parsed.data : { ...DEFAULT_ASSISTANT_SETTINGS };
  }
  var settingsWrite = Promise.resolve();
  function saveAssistantSettings(patch) {
    const write = settingsWrite.catch(() => {
    }).then(async () => {
      const next = settingsSchema.parse({ ...await loadAssistantSettings(), ...patch });
      if (typeof chrome !== "undefined" && chrome.storage?.local) await chrome.storage.local.set({ [SETTINGS_KEY]: next });
      else if (typeof localStorage !== "undefined") localStorage.setItem(SETTINGS_KEY, JSON.stringify(next));
      return next;
    });
    settingsWrite = write;
    return write;
  }
  async function getAssistantHealth(settings) {
    return z2.object({
      ok: z2.boolean(),
      ollamaConnected: z2.boolean(),
      models: z2.array(z2.string()),
      message: z2.string().optional(),
      pullStates: z2.record(z2.string()).optional(),
      modelDetails: z2.array(z2.object({ name: z2.string(), size: z2.number(), capabilities: z2.array(z2.string()), parameterSize: z2.string().optional(), quantization: z2.string().optional(), remote: z2.boolean().optional() })).optional(),
      recommended: z2.object({ reasoningModel: z2.string(), visionModel: z2.string(), reason: z2.string().optional(), contextLength: z2.number().optional() }).optional()
    }).parse(await request(settings, "health", "GET"));
  }
  async function runJob(settings, type, input) {
    const job = z2.object({ id: z2.string().regex(/^[a-zA-Z0-9_-]{1,80}$/) }).parse(await request(settings, "jobs", "POST", { type, request: input }));
    const start = Date.now();
    while (Date.now() - start < 15 * 60 * 1e3) {
      const state = await request(settings, `jobs/${job.id}`, "GET");
      if (state.status === "complete") return state.result;
      if (state.status === "error") throw new Error(state.error || "Local model generation failed.");
      await new Promise((resolve) => setTimeout(resolve, 1500));
    }
    throw new Error("Generation exceeded 15 minutes. Try a smaller installed model or a lower detail level.");
  }
  async function generateStudyPacket(settings, input) {
    const origin = typeof window !== "undefined" ? window.location.origin : new URL(input.assignment.url).origin;
    const materials = await readCanvasMaterials(
      input.resources,
      origin,
      input.course.id,
      (file) => request(settings, "materials/extract", "POST", file)
    );
    const packet = packetSchema.parse(await runJob(settings, "generate", { ...input, resources: materials.resources }));
    packet.warnings = [...materials.warnings, ...packet.warnings];
    return packet;
  }
  async function captureBrowserContext() {
    const root = (document.querySelector("main") || document.body).cloneNode(true);
    root.querySelectorAll("#gradient-panel-host,script,style,input,textarea,select,[contenteditable],iframe").forEach((el) => el.remove());
    const links = Array.from(root.querySelectorAll("a[href]")).slice(0, 100).flatMap((anchor) => {
      try {
        const url = new URL(anchor.getAttribute("href") || "", window.location.href);
        return url.origin === window.location.origin && ["http:", "https:"].includes(url.protocol) ? [`${(anchor.textContent || "").trim().slice(0, 150)}: ${url.href}`] : [];
      } catch {
        return [];
      }
    });
    const text = (root.textContent || "").replace(/\s+/g, " ").trim().slice(0, 16e3) + "\n\nVisible resource links:\n" + links.join("\n").slice(0, 8e3);
    let screenshot;
    if (extensionAvailable()) {
      const host = document.getElementById("gradient-panel-host");
      const oldVisibility = host?.style.getPropertyValue("visibility") || "";
      const oldPriority = host?.style.getPropertyPriority("visibility") || "";
      try {
        host?.style.setProperty("visibility", "hidden", "important");
        await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
        const capture = await sendMessage({ type: "GRADIENT_CAPTURE_CONTEXT" });
        screenshot = capture.screenshot;
      } finally {
        if (oldVisibility) host?.style.setProperty("visibility", oldVisibility, oldPriority);
        else host?.style.removeProperty("visibility");
      }
    }
    return { url: window.location.href, title: document.title, text, ...screenshot ? { screenshot } : {} };
  }
  async function planBrowserAction(settings, input) {
    return z2.object({ summary: z2.string(), actions: z2.array(z2.object({ kind: z2.enum(["open", "find", "scroll", "read"]), description: z2.string(), url: z2.string().optional(), text: z2.string().optional() })).max(12), warnings: z2.array(z2.string()) }).parse(await runJob(settings, "browser", input));
  }
  function safeBrowserUrl(value) {
    const url = new URL(value, window.location.href);
    if (!["https:", "http:"].includes(url.protocol) || url.username || url.password) throw new Error("The model suggested an unsupported link.");
    let path = url.pathname;
    for (let i3 = 0; i3 < 3 && /%[0-9a-f]{2}/i.test(path); i3++) path = decodeURIComponent(path);
    if (/\/(?:quizzes|assessments)\/.*(?:take|resume)|\/logout(?:\/|$)|\/(?:submissions|submit)(?:\/|$)/i.test(path)) throw new Error("This action is outside the study browser workspace.");
    return url.href;
  }
  async function applyBrowserAction(action) {
    if (action.kind === "open" && action.url) {
      const url = safeBrowserUrl(action.url);
      window.open(url, "_blank", "noopener,noreferrer");
    } else if (action.kind === "find" && action.text) {
      const found = window.find?.(action.text.slice(0, 300));
      if (!found) throw new Error("That text is not visible on this page. Open the relevant resource and inspect it again.");
    } else if (action.kind === "scroll") {
      window.scrollBy({ top: Math.round(window.innerHeight * 0.75), behavior: "smooth" });
    } else if (action.kind === "read") {
      if (action.url) window.open(safeBrowserUrl(action.url), "_blank", "noopener,noreferrer");
      else if (action.text) {
        const found = window.find?.(action.text.slice(0, 300));
        if (!found) throw new Error("The suggested text was not found on this page.");
      } else throw new Error("The model did not provide a section or link to read. Inspect the page again with a more specific goal.");
    } else throw new Error("This action needs a link or text target.");
  }

  // extension/ui/assistantStyles.ts
  var ASSISTANT_STYLES = `
.ja{--ja-bg:#f7f8fc;--ja-panel:#ffffff;--ja-border:#dce3ee;--ja-muted:#647087;--ja-cyan:#2855e8;background:var(--ja-bg);color:#182037;border:1px solid #e5e9f1;border-radius:16px;overflow:hidden;font-size:12px;line-height:1.6;min-width:0;color-scheme:light}
.ja *{box-sizing:border-box}.ja button,.ja input,.ja select,.ja textarea{font:inherit}.ja button{cursor:pointer}.ja button:disabled{cursor:wait;opacity:.55}.ja a{color:var(--ja-cyan);text-decoration:none}.ja a:hover{text-decoration:underline}.ja button:focus-visible,.ja a:focus-visible,.ja input:focus-visible,.ja select:focus-visible,.ja textarea:focus-visible,.ja summary:focus-visible{outline:2px solid var(--ja-cyan);outline-offset:3px}
.ja-head{display:flex;align-items:center;gap:13px;padding:23px 20px 18px;background:#fff;border-bottom:1px solid var(--ja-border)}
.ja-core{width:47px;height:47px;flex-shrink:0;border:1px solid #dbe3f5;border-radius:11px;padding:7px;display:grid;place-items:center}.ja-core>span{width:100%;height:100%;display:grid;place-items:center;border:0;border-radius:7px;color:var(--ja-cyan)}
.ja-eyebrow{font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--ja-cyan)}.ja-head h1{font-size:29px;line-height:1.2;letter-spacing:-.7px;margin:3px 0 4px}.ja-head p{font-size:10px;color:var(--ja-muted);margin:0}.ja-status{margin-left:auto;align-self:flex-start;font-size:9px;white-space:nowrap;color:#647087;display:flex;align-items:center;gap:5px}.ja-led{width:6px;height:6px;border-radius:50%;background:#d2a975}.ja-led.ready{background:#16825c;box-shadow:0 0 8px #16825c60}
.ja-inner{padding:18px 20px;display:flex;flex-direction:column;gap:19px;min-width:0}.ja-section{min-width:0}.ja-row{display:flex;align-items:center;justify-content:space-between;gap:9px}.ja h2{font-size:14px;font-weight:700;letter-spacing:-.2px;margin:0}.ja h3{font-size:12px;margin:0}.ja-note{font-size:10px;color:var(--ja-muted);line-height:1.6;margin:5px 0 0}.ja-label{display:block;font-size:10px;font-weight:650;color:#34425d;margin-bottom:6px}.ja-control{background:#ffffff;border:1px solid var(--ja-border);border-radius:8px;color:#182037;padding:9px 10px;width:100%;min-width:0;line-height:1.5}.ja-control::placeholder{color:#647087}.ja-control:focus{border-color:#2855e8}.ja textarea{resize:vertical;min-height:80px}.ja-fields{display:grid;grid-template-columns:minmax(0,1fr);gap:11px}.ja-fields.two{grid-template-columns:1fr 1fr}.ja small{font-size:10px;color:var(--ja-muted)}
.ja-detail{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;margin-top:9px}.ja-detail button{border:1px solid var(--ja-border);border-radius:9px;background:#ffffff;color:#536079;padding:11px 6px;text-align:left;line-height:1.4;min-width:0}.ja-detail button.active{border-color:var(--ja-cyan);background:#edf2ff;color:#2855e8;box-shadow:0 0 0 1px var(--ja-cyan)}.ja-detail strong{display:block;font-size:11px;letter-spacing:-.2px}.ja-detail small{display:block;font-size:9px;margin-top:5px;color:#647087}.ja-detail button.active small{color:#426080}
.ja-switches{display:flex;flex-wrap:wrap;gap:9px 14px;margin-top:12px}.ja-switch{display:flex;align-items:center;gap:6px;font-size:10px;color:#536079;cursor:pointer}.ja-switch input{accent-color:var(--ja-cyan);margin:0;width:13px;height:13px}.ja-btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:1px solid var(--ja-border);background:#ffffff;color:#34425d;border-radius:8px;padding:8px 11px;font-size:10px;font-weight:650;line-height:1.5;white-space:normal}.ja-btn:hover{border-color:#b7c8fa;background:#f0f4ff}.ja-btn.primary{background:var(--ja-cyan);border-color:var(--ja-cyan);color:#ffffff;min-height:42px;font-size:11px}.ja-btn.primary:hover{background:#1740c8}.ja-btn.full{width:100%}.ja-btn.link{background:transparent;border:0;color:var(--ja-cyan);padding:0}.ja-actions{display:flex;gap:8px;flex-wrap:wrap}.ja-rule{border:0;border-top:1px solid var(--ja-border);margin:0}.ja-mode{display:flex;gap:6px;margin-top:9px}.ja-mode .ja-btn{flex:1}.ja-mode .ja-btn.active{color:var(--ja-cyan);border-color:#b7c8fa;background:#edf2ff}
.ja-settings{background:#ffffff;border:1px solid var(--ja-border);border-radius:10px;padding:12px}.ja-settings>summary{display:flex;align-items:center;gap:7px;font-size:11px;font-weight:650;cursor:pointer;list-style:none}.ja-settings>summary::after{content:'+';margin-left:auto;color:var(--ja-cyan)}.ja-settings[open]>summary::after{content:'\u2212'}.ja-settings[open]>summary{margin-bottom:13px}.ja-settings .ja-note code{word-break:break-word;color:#34425d}.ja-setup{background:#edf3ff;border:1px solid #dbe3f5;border-radius:9px;padding:11px 12px}.ja-setup strong{font-size:11px;color:#2855e8}.ja-setup code{display:block;margin-top:8px;background:#ffffff;color:#34425d;padding:9px;border-radius:6px;white-space:pre-wrap;font-size:10px;overflow-wrap:anywhere}.ja-notice{font-size:10px;line-height:1.7;border:1px solid #dbe3f5;background:#eaf2ff;color:#345276;border-radius:8px;padding:10px 11px;overflow-wrap:anywhere}.ja-notice.error{border-color:#f0c9ce;background:#fff0f1;color:#963b48}.ja-notice.warning{border-color:#ead7b1;background:#fff4df;color:#7f5520}.ja-progress{display:flex;align-items:center;gap:8px;color:#2855e8;font-size:11px;padding:11px 0}.ja-progress span{animation:ja-pulse 1.8s ease-in-out infinite}
.ja-context{font-size:10px;color:#536079;padding:10px 11px;background:#f4f6fb;border-left:2px solid #2855e8;border-radius:0 7px 7px 0;margin-top:9px}.ja-context strong{display:block;color:#182037;font-size:11px}.ja-context a{display:inline-flex;align-items:center;gap:4px;margin-top:4px}.ja-context details{margin-top:7px}.ja-context summary{cursor:pointer;color:#2855e8}.ja-context .ja-brief{white-space:pre-wrap;font-size:10px;max-height:200px;overflow:auto;margin-top:7px}
.ja-result{background:#f4f7fb;color:#1c3046;border-radius:11px;overflow:hidden;border:1px solid #c3d3e2}.ja-result-header{padding:17px 16px;background:#e8f0f6;border-bottom:1px solid #cfdae6}.ja-result-header h2{font-size:17px;color:#142e43;line-height:1.35}.ja-result-header p{font-size:11px;color:#4b6275;margin:7px 0 0}.ja-result-body{padding:16px;min-width:0}.ja-result a{color:#2855e8}.ja-result .ja-note{color:#50667a}.ja-result .ja-eyebrow{color:#2855e8;margin-bottom:7px}.ja-export{display:flex;gap:7px;flex-wrap:wrap;margin-top:13px}.ja-export .ja-btn{background:#fff;border-color:#c3d1df;color:#23445b;font-size:10px}.ja-prose{font-size:12px;line-height:1.8;overflow-wrap:anywhere}.ja-prose p{margin:0 0 11px;white-space:pre-wrap}.ja-prose h2{font-size:15px;margin:19px 0 9px;color:#173b52}.ja-prose h3{font-size:13px;margin:15px 0 7px;color:#173b52}.ja-prose h4{font-size:12px;margin:13px 0 5px}.ja-prose ul,.ja-prose ol{padding-left:19px;margin:9px 0 13px}.ja-prose li{padding-left:2px;margin:4px 0}.ja-prose pre{background:#122437;color:#d9eaf8;border-radius:7px;padding:11px;overflow:auto;font-size:10px;white-space:pre-wrap}.ja-prose code{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:.9em;background:#dae7ef;padding:1px 4px;border-radius:3px}.ja-prose pre code{background:transparent;padding:0}.ja-prose blockquote{border-left:3px solid #4d93a5;padding:4px 12px;margin:12px 0;color:#4c6376}.ja-prose hr{border:0;border-top:1px solid #d2dde6;margin:17px 0}
.ja-visual{margin:17px 0;padding:13px;background:#fff;border:1px solid #d0dde6;border-radius:9px;overflow:hidden;break-inside:avoid}.ja-visual figcaption{font-size:11px;font-weight:700;color:#294c60;margin-bottom:12px}.ja-visual svg{display:block;width:100%;height:auto;overflow:visible}.ja-diagram-node{border:1px solid #a8c6d2;background:#edf2ff;border-radius:7px;padding:8px 10px;color:#34425d;font-size:11px;overflow-wrap:anywhere}.ja-diagram-edge{color:#617b88;font-size:10px;display:flex;align-items:center;gap:7px;margin:7px 0}.ja-diagram-edge>span:first-child{color:#2855e8;font-size:16px}.ja-visual img{width:100%;max-height:300px;object-fit:contain;display:block;border-radius:6px;margin:9px 0}.ja-visual a{font-size:10px}.ja-chart-table{font-size:10px;width:100%;border-collapse:collapse;margin-top:7px}.ja-chart-table th,.ja-chart-table td{text-align:left;padding:5px 7px;border-bottom:1px solid #d9e3eb}.ja-chart-table th{color:#49677a}.ja-chart-table td:last-child{text-align:right;font-variant-numeric:tabular-nums}
.ja-table-wrap{overflow:auto;margin:12px 0 17px;border:1px solid #d1dee8;border-radius:7px}.ja-table-wrap table{width:100%;border-collapse:collapse;font-size:11px;line-height:1.6}.ja-table-wrap th{text-align:left;background:#e4eef4;font-weight:650;color:#274c61}.ja-table-wrap th,.ja-table-wrap td{padding:8px 10px;border-bottom:1px solid #d1dee8;vertical-align:top;min-width:85px}.ja-table-wrap tr:last-child td{border:0}
.ja-sample{margin-top:18px;border-top:1px solid #cfdae6;padding-top:18px}.ja-sample-tag{display:inline-block;color:#815921;background:#fff0cf;border:1px solid #e5cc9d;border-radius:5px;padding:3px 7px;font-size:9px;font-weight:750;margin-bottom:9px}.ja-sources{border-top:1px solid #cfdae6;margin-top:19px;padding-top:15px}.ja-sources ol{padding-left:19px;margin:9px 0 0}.ja-sources li{margin:0 0 11px;padding-left:3px;font-size:10px}.ja-sources a{font-weight:650;overflow-wrap:anywhere}.ja-sources p{font-size:10px;color:#586e7e;margin:3px 0 0}.ja-sources small{color:#62798b}.ja-browser{border-top:1px solid var(--ja-border);padding-top:17px}.ja-browser-steps{list-style:none;padding:0;margin:13px 0 0;display:flex;flex-direction:column;gap:8px}.ja-browser-steps li{padding:10px;border:1px solid var(--ja-border);border-radius:8px;background:#f4f6fb}.ja-browser-steps strong{color:#182037;font-size:11px}.ja-browser-steps p{font-size:10px;margin:4px 0 8px;color:#647087}.ja-checklist{padding-left:18px;font-size:11px;color:#35566b}.ja-model-row{display:flex;gap:7px;align-items:flex-start}.ja-model-row .ja-control{flex:1}.ja-model-row .ja-btn{min-height:38px;flex-shrink:0}.ja-footnote{font-size:9px;color:#647087;display:flex;align-items:flex-start;gap:6px}.ja-footnote svg{margin-top:2px;flex-shrink:0}
@keyframes ja-pulse{0%,100%{opacity:.55}50%{opacity:1}}@media(prefers-reduced-motion:reduce){.ja-progress span{animation:none}}@media(max-width:420px){.ja-inner{padding:16px 13px}.ja-head{padding:19px 13px}.ja-status{font-size:8px}.ja-fields.two{grid-template-columns:1fr}.ja-detail strong{font-size:10px}.ja-detail small{font-size:8px}}
`;

  // extension/ui/AssistantView.tsx
  var DEFAULTS = { backendUrl: "http://127.0.0.1:8765", reasoningModel: "gpt-oss:20b", visionModel: "gemma4:e4b", detailLevel: "a_bit_more", webResearch: true };
  var LEVELS = [
    { id: "a_bit", title: "A bit", description: "Key ideas + a starting point" },
    { id: "a_bit_more", title: "A bit more", description: "Worked explanations + sources" },
    { id: "all_in", title: "Go all in", description: "A complete research packet" }
  ];
  function errorMessage(error) {
    return error instanceof Error ? error.message : "The local assistant could not complete this request.";
  }
  function installedModels(health, capability) {
    if (!health) return [];
    const raw = [...new Set(health.models)].filter((name) => {
      const detail = health.modelDetails?.find((model) => model.name === name);
      if (detail?.remote || /(?:-cloud|:cloud)$/.test(name)) return false;
      return detail ? detail.capabilities.includes(capability) : capability === "completion";
    });
    const humanNames = raw.filter((name) => !/^llamacpp[:/]/i.test(name));
    return humanNames.length ? humanNames : raw;
  }
  function modelLabel(name, health) {
    const detail = health?.modelDetails?.find((model) => model.name === name);
    const size = detail && detail.size > 0 ? `${(detail.size / 1024 ** 3).toFixed(1)} GB` : "";
    return [name, detail?.parameterSize, detail?.quantization, size].filter(Boolean).join(" \xB7 ");
  }
  function recommendedSettings(health, current) {
    const patch = {};
    for (const [key, capability] of [["reasoningModel", "completion"], ["visionModel", "vision"]]) {
      const candidates = installedModels(health, capability);
      if (candidates.includes(current[key])) continue;
      const recommended = health.recommended?.[key];
      const replacement = recommended && candidates.includes(recommended) ? recommended : candidates[0];
      if (replacement) patch[key] = replacement;
    }
    return patch;
  }
  function safeUrl(value) {
    try {
      const url = new URL(value);
      return ["http:", "https:"].includes(url.protocol) ? url.href : void 0;
    } catch {
      return void 0;
    }
  }
  function plain(value) {
    const doc = new DOMParser().parseFromString(value, "text/html");
    doc.querySelectorAll("script,style,noscript").forEach((node) => node.remove());
    doc.querySelectorAll("p,br,li,h1,h2,h3,div").forEach((node) => node.append(doc.createTextNode("\n")));
    return (doc.body.textContent ?? "").replace(/\n{3,}/g, "\n\n").trim();
  }
  function inline(text) {
    const nodes = [];
    const pattern = /\[([^\]]+)\]\(([^\s)]+)\)|\*\*([^*]+)\*\*|`([^`]+)`/g;
    let start = 0;
    for (const match of text.matchAll(pattern)) {
      const index = match.index ?? 0;
      if (index > start) nodes.push(text.slice(start, index));
      if (match[1] !== void 0) {
        const href = safeUrl(match[2] ?? "");
        nodes.push(href ? /* @__PURE__ */ a3("a", { href, target: "_blank", rel: "noopener noreferrer", children: match[1] }) : match[1]);
      } else if (match[3] !== void 0) nodes.push(/* @__PURE__ */ a3("strong", { children: match[3] }));
      else nodes.push(/* @__PURE__ */ a3("code", { children: match[4] }));
      start = index + match[0].length;
    }
    if (start < text.length) nodes.push(text.slice(start));
    return nodes;
  }
  function AssistantMarkdown({ text }) {
    const blocks = [];
    const lines = text.replace(/\r/g, "").split("\n");
    for (let i3 = 0; i3 < lines.length; i3++) {
      const line = lines[i3] ?? "";
      if (!line.trim()) continue;
      if (/^```/.test(line)) {
        const code = [];
        while (++i3 < lines.length && !/^```/.test(lines[i3] ?? "")) code.push(lines[i3] ?? "");
        blocks.push(/* @__PURE__ */ a3("pre", { children: /* @__PURE__ */ a3("code", { children: code.join("\n") }) }));
        continue;
      }
      if (line.includes("|") && /^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(lines[i3 + 1] ?? "")) {
        const cells = (row) => row.trim().replace(/^\|/, "").replace(/\|$/, "").split(/(?<!\\)\|/).map((cell) => cell.trim().replace(/\\\|/g, "|"));
        const headers = cells(line);
        const rows = [];
        i3 += 2;
        while (i3 < lines.length && (lines[i3] ?? "").includes("|") && (lines[i3] ?? "").trim()) rows.push(cells(lines[i3++] ?? ""));
        i3--;
        blocks.push(/* @__PURE__ */ a3("div", { class: "ja-table-wrap", children: /* @__PURE__ */ a3("table", { children: [
          /* @__PURE__ */ a3("thead", { children: /* @__PURE__ */ a3("tr", { children: headers.map((header, index) => /* @__PURE__ */ a3("th", { children: inline(header) }, index)) }) }),
          /* @__PURE__ */ a3("tbody", { children: rows.map((row, index) => /* @__PURE__ */ a3("tr", { children: headers.map((_header, column) => /* @__PURE__ */ a3("td", { children: inline(row[column] ?? "") }, column)) }, index)) })
        ] }) }));
        continue;
      }
      const heading = line.match(/^(#{1,6})\s+(.+)$/);
      if (heading) {
        const children = inline(heading[2] ?? "");
        blocks.push((heading[1]?.length ?? 1) <= 2 ? /* @__PURE__ */ a3("h2", { children }) : (heading[1]?.length ?? 3) === 3 ? /* @__PURE__ */ a3("h3", { children }) : /* @__PURE__ */ a3("h4", { children }));
        continue;
      }
      if (/^\s*([-*_])(?:\s*\1){2,}\s*$/.test(line)) {
        blocks.push(/* @__PURE__ */ a3("hr", {}));
        continue;
      }
      if (/^\s*[-*+]\s+/.test(line) || /^\s*\d+[.)]\s+/.test(line)) {
        const ordered = /^\s*\d+[.)]\s+/.test(line);
        const items = [];
        const pattern = ordered ? /^\s*\d+[.)]\s+/ : /^\s*[-*+]\s+/;
        do {
          items.push(/* @__PURE__ */ a3("li", { children: inline((lines[i3] ?? "").replace(pattern, "")) }));
          i3++;
        } while (i3 < lines.length && pattern.test(lines[i3] ?? ""));
        i3--;
        blocks.push(ordered ? /* @__PURE__ */ a3("ol", { children: items }) : /* @__PURE__ */ a3("ul", { children: items }));
        continue;
      }
      if (/^>\s?/.test(line)) {
        blocks.push(/* @__PURE__ */ a3("blockquote", { children: inline(line.replace(/^>\s?/, "")) }));
        continue;
      }
      const paragraph = [line];
      while (i3 + 1 < lines.length && (lines[i3 + 1] ?? "").trim() && !/^(?:#{1,6}\s|```|\s*[-*+]\s|\s*\d+[.)]\s|>)/.test(lines[i3 + 1] ?? "")) paragraph.push(lines[++i3] ?? "");
      blocks.push(/* @__PURE__ */ a3("p", { children: inline(paragraph.join("\n")) }));
    }
    return /* @__PURE__ */ a3("div", { class: "ja-prose", children: blocks });
  }
  function ConceptDiagram({ diagram }) {
    const nodes = diagram.nodes.slice(0, 16);
    const labels = new Map(nodes.map((node) => [node.id, node.label]));
    return /* @__PURE__ */ a3("figure", { class: "ja-visual", children: [
      /* @__PURE__ */ a3("figcaption", { children: diagram.title }),
      /* @__PURE__ */ a3("div", { role: "img", "aria-label": `${diagram.title}: ${nodes.map((node) => node.label).join(", ")}`, children: [
        nodes.map((node, i3) => {
          const edge = diagram.edges.find((item) => item.from === node.id && item.to === nodes[i3 + 1]?.id);
          return /* @__PURE__ */ a3("div", { children: [
            /* @__PURE__ */ a3("div", { class: "ja-diagram-node", children: node.label }),
            edge ? /* @__PURE__ */ a3("div", { class: "ja-diagram-edge", children: [
              /* @__PURE__ */ a3("span", { "aria-hidden": "true", children: "\u2193" }),
              /* @__PURE__ */ a3("span", { children: edge.label ?? "" })
            ] }) : i3 < nodes.length - 1 ? /* @__PURE__ */ a3("div", { style: { height: "9px" } }) : null
          ] }, node.id);
        }),
        diagram.edges.filter((edge) => !nodes.some((node, i3) => node.id === edge.from && nodes[i3 + 1]?.id === edge.to)).map((edge, i3) => /* @__PURE__ */ a3("div", { class: "ja-diagram-edge", children: [
          /* @__PURE__ */ a3("span", { "aria-hidden": "true", children: "\u21B3" }),
          /* @__PURE__ */ a3("span", { children: [
            labels.get(edge.from) ?? edge.from,
            " \u2192 ",
            labels.get(edge.to) ?? edge.to,
            edge.label ? `: ${edge.label}` : ""
          ] })
        ] }, i3))
      ] })
    ] });
  }
  function DataGraph({ graph }) {
    const points = graph.points.filter((point) => Number.isFinite(point.value)).slice(0, 16);
    if (!points.length) return null;
    const maximum = Math.max(1, ...points.map((point) => Math.abs(point.value)));
    const width = 420, height = Math.max(130, 43 + points.length * 29);
    const displayValue = (value) => Math.abs(value) >= 1e12 || value !== 0 && Math.abs(value) < 1e-3 ? value.toExponential(2) : value.toLocaleString(void 0, { maximumFractionDigits: 3 });
    return /* @__PURE__ */ a3("figure", { class: "ja-visual", children: [
      /* @__PURE__ */ a3("figcaption", { children: graph.title }),
      /* @__PURE__ */ a3("svg", { viewBox: `0 0 ${width} ${height}`, role: "img", "aria-label": graph.title, children: [
        points.map((point, i3) => /* @__PURE__ */ a3("g", { children: [
          /* @__PURE__ */ a3("text", { x: "0", y: 23 + i3 * 29, fill: "#45657a", "font-size": "10", children: point.label.slice(0, 19) }),
          /* @__PURE__ */ a3("rect", { x: "130", y: 10 + i3 * 29, width: Math.max(1, Math.abs(point.value) / maximum * 195), height: "18", rx: "3", fill: point.value < 0 ? "#bd7958" : "#237e95" }),
          /* @__PURE__ */ a3("text", { x: "415", y: 23 + i3 * 29, "text-anchor": "end", fill: "#274e63", "font-size": "10", children: displayValue(point.value) })
        ] }, i3)),
        /* @__PURE__ */ a3("text", { x: "130", y: height - 5, fill: "#5b7484", "font-size": "9", children: [
          (graph.yLabel ?? "Value").slice(0, 24),
          " \xB7 bar length represents magnitude"
        ] })
      ] }),
      /* @__PURE__ */ a3("details", { children: [
        /* @__PURE__ */ a3("summary", { class: "ja-note", children: "View data values" }),
        /* @__PURE__ */ a3("table", { class: "ja-chart-table", children: [
          /* @__PURE__ */ a3("thead", { children: /* @__PURE__ */ a3("tr", { children: [
            /* @__PURE__ */ a3("th", { children: graph.xLabel ?? "Label" }),
            /* @__PURE__ */ a3("th", { children: graph.yLabel ?? "Value" })
          ] }) }),
          /* @__PURE__ */ a3("tbody", { children: points.map((point, i3) => /* @__PURE__ */ a3("tr", { children: [
            /* @__PURE__ */ a3("td", { children: point.label }),
            /* @__PURE__ */ a3("td", { children: point.value })
          ] }, i3)) })
        ] })
      ] })
    ] });
  }
  function download(content, name, type) {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = name;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function filename(title) {
    return title.replace(/[^a-z0-9_-]+/gi, "-").replace(/^-|-$/g, "").slice(0, 80) || "gradient-study-packet";
  }
  function escapeHtml(value) {
    return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function packetMarkdown(packet) {
    return `# ${packet.title}

${packet.summary}

${packet.markdown}${packet.sampleMarkdown ? `

## Sample assignment

AI-generated reference sample. Review, verify, and follow your course policy before using it.

${packet.sampleMarkdown}` : ""}

${packet.diagrams.map((diagram) => `## ${diagram.title}

${diagram.nodes.map((node) => `- ${node.id}: ${node.label}`).join("\n")}
${diagram.edges.map((edge) => `- ${edge.from} -> ${edge.to}${edge.label ? `: ${edge.label}` : ""}`).join("\n")}`).join("\n\n")}

${packet.graphs.map((graph) => `## ${graph.title}

| Label | Value |
| --- | ---: |
${graph.points.map((point) => `| ${point.label.replace(/\|/g, "\\|")} | ${point.value} |`).join("\n")}`).join("\n\n")}

${packet.images.filter((image) => safeUrl(image.url) && safeUrl(image.sourceUrl)).map((image) => `![${image.alt.replace(/[\[\]]/g, "")}](${safeUrl(image.url)})
[Image source](${safeUrl(image.sourceUrl)})`).join("\n\n")}

## Sources

${packet.sources.filter((source) => safeUrl(source.url)).map((source) => `- [${source.title.replace(/[\[\]]/g, "")}](${safeUrl(source.url)})${source.excerpt ? `: ${source.excerpt}` : ""}`).join("\n")}${packet.warnings.length ? `

## Notes to verify

${packet.warnings.map((warning) => `- ${warning}`).join("\n")}` : ""}
`;
  }
  function assignmentBrief(assignment) {
    return assignment ? plain(assignment.descriptionHtml) : "";
  }
  function AssistantView({ snapshot, preview = false, initialCourseId, initialAssignmentId }) {
    const [settings, setSettings] = d2(DEFAULTS);
    const [health, setHealth] = d2(null);
    const [checking, setChecking] = d2(false);
    const [connectionError, setConnectionError] = d2("");
    const [courseId, setCourseId] = d2(initialCourseId ?? snapshot.courses[0]?.id ?? "");
    const course = snapshot.courses.find((item) => item.id === courseId) ?? snapshot.courses[0];
    const [assignmentId, setAssignmentId] = d2(initialAssignmentId ?? "");
    const assignment = course?.assignments.find((item) => item.id === assignmentId) ?? course?.assignments.find((item) => !item.submission?.excused && item.submission?.score == null && !["submitted", "pending_review", "graded"].includes(item.submission?.workflowState ?? "")) ?? course?.assignments[0];
    const [prompt, setPrompt] = d2("");
    const [mode, setMode] = d2("explain");
    const [visuals, setVisuals] = d2({ diagrams: true, graphs: true, images: true });
    const [generating, setGenerating] = d2(false);
    const [packet, setPacket] = d2(null);
    const [generationError, setGenerationError] = d2("");
    const [browserGoal, setBrowserGoal] = d2("Find the assignment instructions and the course materials that will help me.");
    const [browserBusy, setBrowserBusy] = d2(false);
    const [browserPlan, setBrowserPlan] = d2(null);
    const [browserError, setBrowserError] = d2("");
    const [actionMessage, setActionMessage] = d2("");
    const resultRef = T2(null);
    const mounted = T2(true);
    const settingsRef = T2(DEFAULTS);
    const earlySettingsEdits = T2({});
    const settingsLoaded = T2(false);
    const healthRequest = T2(0);
    const reasoningModels = installedModels(health, "completion");
    const visionModels = installedModels(health, "vision");
    const ready = health?.ok && health.ollamaConnected && reasoningModels.includes(settings.reasoningModel);
    const visionReady = health?.ok && health.ollamaConnected && visionModels.includes(settings.visionModel);
    const brief = assignmentBrief(assignment);
    const resources = w2(() => {
      const words = new Set(`${assignment?.name ?? ""} ${brief.slice(0, 1e3)}`.toLowerCase().match(/[a-z]{4,}/g) ?? []);
      return (course?.resources ?? []).map((resource) => ({ resource, rank: (resource.title.toLowerCase().match(/[a-z]{4,}/g) ?? []).filter((word) => words.has(word)).length })).sort((a4, b2) => b2.rank - a4.rank).slice(0, 12).map((item) => item.resource);
    }, [course, assignment, brief]);
    A(() => {
      mounted.current = true;
      loadAssistantSettings().then(async (saved) => {
        if (!mounted.current) return;
        const initial = { ...saved, ...earlySettingsEdits.current };
        settingsLoaded.current = true;
        settingsRef.current = initial;
        setSettings(initial);
        await checkHealth(initial);
      }).catch((error) => {
        if (mounted.current) setConnectionError(errorMessage(error));
      });
      return () => {
        mounted.current = false;
        healthRequest.current++;
      };
    }, []);
    const updateSettings = (patch) => {
      if (!settingsLoaded.current) earlySettingsEdits.current = { ...earlySettingsEdits.current, ...patch };
      settingsRef.current = { ...settingsRef.current, ...patch };
      setSettings((current) => ({ ...current, ...patch }));
      if (patch.backendUrl !== void 0) {
        healthRequest.current++;
        setChecking(false);
        setHealth(null);
      }
      saveAssistantSettings(patch).catch((error) => {
        if (mounted.current) setConnectionError(errorMessage(error));
      });
    };
    const checkHealth = async (requestSettings) => {
      const requestId = ++healthRequest.current;
      const currentRequest = () => mounted.current && requestId === healthRequest.current && settingsRef.current.backendUrl === requestSettings.backendUrl;
      setChecking(true);
      setConnectionError("");
      try {
        const status = await getAssistantHealth(requestSettings);
        if (!currentRequest()) return;
        setHealth(status);
        const patch = recommendedSettings(status, settingsRef.current);
        if (Object.keys(patch).length) {
          settingsRef.current = { ...settingsRef.current, ...patch };
          setSettings((current) => ({ ...current, ...patch }));
          await saveAssistantSettings(patch);
        }
      } catch (error) {
        if (currentRequest()) {
          setHealth(null);
          setConnectionError(errorMessage(error));
        }
      } finally {
        if (currentRequest()) setChecking(false);
      }
    };
    const checkConnection = () => checkHealth(settingsRef.current);
    const generate = async () => {
      if (!course || !assignment || generating) return;
      setGenerating(true);
      setGenerationError("");
      try {
        const preferences = `Visual preferences: ${visuals.diagrams ? "include clean concept diagrams when helpful" : "omit diagrams"}; ${visuals.graphs ? "include graphs only when numerical data is available and label illustrative examples" : "omit graphs"}; ${visuals.images ? "include only relevant, attributed images from retrieved resources when available" : "omit images"}. Never invent sources, measurements, or image URLs.`;
        const result = await generateStudyPacket(settings, {
          course: { id: course.id, name: course.name, code: course.code },
          assignment: { id: assignment.id, title: assignment.name, description: brief, url: assignment.htmlUrl, dueAt: assignment.dueAt ?? null, rubric: assignment.rubric?.map((criterion) => `${plain(criterion.description)} (${criterion.points} points): ${criterion.ratings.map((rating) => plain(rating.description)).join("; ")}`).join("\n") },
          prompt: `${prompt.trim()}

${preferences}`,
          level: settings.detailLevel,
          mode,
          model: settings.reasoningModel,
          webResearch: settings.webResearch,
          resources: resources.map((resource) => ({ title: resource.title, url: resource.url }))
        });
        if (mounted.current) setPacket({ ...result, diagrams: visuals.diagrams ? result.diagrams : [], graphs: visuals.graphs ? result.graphs : [], images: visuals.images ? result.images : [] });
      } catch (error) {
        if (mounted.current) setGenerationError(errorMessage(error));
      } finally {
        if (mounted.current) setGenerating(false);
      }
    };
    const inspectPage = async () => {
      setBrowserBusy(true);
      setBrowserError("");
      setActionMessage("");
      try {
        const context = await captureBrowserContext();
        const plan = await planBrowserAction(settings, { ...context, goal: browserGoal, model: settings.visionModel });
        if (mounted.current) setBrowserPlan(plan);
      } catch (error) {
        if (mounted.current) setBrowserError(errorMessage(error));
      } finally {
        if (mounted.current) setBrowserBusy(false);
      }
    };
    const exportHtml = () => {
      if (!packet || !resultRef.current) return;
      download(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(packet.title)}</title><style>body{margin:0;background:#e8eef4;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;padding:30px 15px}main{max-width:850px;margin:auto}${ASSISTANT_STYLES}.ja{border:0}.ja-result{border:0}.ja-result-header{padding:30px}.ja-result-body{padding:30px}@media print{body{background:white;padding:0}.ja{border:0}.ja-result{overflow:visible}.ja-result-header,.ja-result-body{padding:15px}.ja-visual{break-inside:avoid}a{overflow-wrap:anywhere}}</style></head><body><main class="ja"><article class="ja-result">${resultRef.current.innerHTML}</article></main></body></html>`, `${filename(packet.title)}.html`, "text/html;charset=utf-8");
    };
    return /* @__PURE__ */ a3(M, { children: [
      /* @__PURE__ */ a3("style", { children: ASSISTANT_STYLES }),
      /* @__PURE__ */ a3("section", { class: "ja", "aria-label": "Local AI study assistant", children: [
        /* @__PURE__ */ a3("header", { class: "ja-head", children: [
          /* @__PURE__ */ a3("div", { class: "ja-core", "aria-hidden": "true", children: /* @__PURE__ */ a3("span", { children: /* @__PURE__ */ a3(Icon, { name: "spark", size: 19 }) }) }),
          /* @__PURE__ */ a3("div", { children: [
            /* @__PURE__ */ a3("div", { class: "ja-eyebrow", children: "Your local intelligence" }),
            /* @__PURE__ */ a3("h1", { children: "Consider it handled." }),
            /* @__PURE__ */ a3("p", { children: "Research. Understand. Create. Stay ahead." })
          ] }),
          /* @__PURE__ */ a3("span", { class: "ja-status", children: [
            /* @__PURE__ */ a3("i", { class: `ja-led ${ready ? "ready" : ""}` }),
            checking ? "Connecting" : ready ? "Local AI ready" : "Setup needed"
          ] })
        ] }),
        /* @__PURE__ */ a3("div", { class: "ja-inner", children: [
          preview && /* @__PURE__ */ a3("div", { class: "ja-notice warning", children: "Canvas is showing sample courses. AI requests use the local models you connect below." }),
          /* @__PURE__ */ a3("details", { class: "ja-settings", open: !ready, children: [
            /* @__PURE__ */ a3("summary", { children: [
              /* @__PURE__ */ a3(Icon, { name: "settings", size: 14 }),
              "Local model connection"
            ] }),
            /* @__PURE__ */ a3("div", { class: "ja-fields", children: [
              /* @__PURE__ */ a3("label", { children: [
                /* @__PURE__ */ a3("span", { class: "ja-label", children: "Local assistant service" }),
                /* @__PURE__ */ a3("input", { class: "ja-control", "aria-label": "Local assistant service URL", type: "url", value: settings.backendUrl, disabled: generating, onChange: (e3) => updateSettings({ backendUrl: e3.currentTarget.value }), placeholder: "http://127.0.0.1:8765" })
              ] }),
              /* @__PURE__ */ a3("div", { children: [
                /* @__PURE__ */ a3("label", { class: "ja-label", for: "ja-reasoning-model", children: "Reasoning model \xB7 installed on your Mac" }),
                /* @__PURE__ */ a3("select", { id: "ja-reasoning-model", class: "ja-control", value: settings.reasoningModel, disabled: generating || checking || !reasoningModels.length, onChange: (e3) => updateSettings({ reasoningModel: e3.currentTarget.value }), children: reasoningModels.length ? reasoningModels.map((name) => /* @__PURE__ */ a3("option", { value: name, children: [
                  modelLabel(name, health),
                  health?.recommended?.reasoningModel === name ? " \xB7 Recommended" : ""
                ] }, name)) : /* @__PURE__ */ a3("option", { value: "", children: "Connect Ollama to discover your installed models" }) })
              ] }),
              /* @__PURE__ */ a3("div", { children: [
                /* @__PURE__ */ a3("label", { class: "ja-label", for: "ja-vision-model", children: "Vision & browser companion \xB7 installed" }),
                /* @__PURE__ */ a3("select", { id: "ja-vision-model", class: "ja-control", value: settings.visionModel, disabled: browserBusy || checking || !visionModels.length, onChange: (e3) => updateSettings({ visionModel: e3.currentTarget.value }), children: visionModels.length ? visionModels.map((name) => /* @__PURE__ */ a3("option", { value: name, children: [
                  modelLabel(name, health),
                  health?.recommended?.visionModel === name ? " \xB7 Recommended" : ""
                ] }, name)) : /* @__PURE__ */ a3("option", { value: "", children: "No installed vision model detected" }) })
              ] }),
              /* @__PURE__ */ a3("button", { class: "ja-btn", disabled: checking, onClick: checkConnection, children: [
                /* @__PURE__ */ a3(Icon, { name: "refresh", size: 13, className: checking ? "g-spinner" : "" }),
                checking ? "Checking local services\u2026" : "Check connection"
              ] }),
              health && /* @__PURE__ */ a3("p", { class: "ja-note", children: health.ollamaConnected ? `Ollama connected \xB7 ${health.models.length} installed model${health.models.length === 1 ? "" : "s"}` : health.message ?? "Start Ollama, then check again." }),
              (health?.recommended?.reason || health?.recommendationReason) && /* @__PURE__ */ a3("div", { class: "ja-notice", children: [
                /* @__PURE__ */ a3("strong", { children: "Recommended for this Mac:" }),
                " ",
                health?.recommended?.reason ?? health?.recommendationReason,
                health?.recommended?.contextLength ? ` \xB7 ${health.recommended.contextLength.toLocaleString()} token context` : ""
              ] }),
              health?.recommended && reasoningModels.includes(health.recommended.reasoningModel) && visionModels.includes(health.recommended.visionModel) && (settings.reasoningModel !== health.recommended.reasoningModel || settings.visionModel !== health.recommended.visionModel) && /* @__PURE__ */ a3("button", { class: "ja-btn", disabled: generating || browserBusy, onClick: () => updateSettings({ reasoningModel: health.recommended.reasoningModel, visionModel: health.recommended.visionModel }), children: [
                /* @__PURE__ */ a3(Icon, { name: "bolt", size: 13 }),
                "Use recommended model pair"
              ] }),
              !ready && /* @__PURE__ */ a3("div", { class: "ja-setup", children: [
                /* @__PURE__ */ a3("strong", { children: "Connect your local engine" }),
                /* @__PURE__ */ a3("p", { class: "ja-note", children: "Run this from the project folder after installing the backend dependencies, and keep Ollama running. Your existing models will appear here." }),
                /* @__PURE__ */ a3("code", { children: "make assistant" }),
                /* @__PURE__ */ a3("p", { class: "ja-note", children: [
                  "Ollama listens on ",
                  /* @__PURE__ */ a3("code", { style: { display: "inline", padding: 0, background: "transparent" }, children: "127.0.0.1:11434" }),
                  ". See gradient/docs/LOCAL_AI.md for setup and memory guidance."
                ] })
              ] }),
              connectionError && /* @__PURE__ */ a3("div", { class: "ja-notice error", role: "alert", children: connectionError })
            ] })
          ] }),
          /* @__PURE__ */ a3("section", { class: "ja-section", children: [
            /* @__PURE__ */ a3("div", { class: "ja-row", children: [
              /* @__PURE__ */ a3("h2", { children: "What are we working on?" }),
              /* @__PURE__ */ a3(Icon, { name: "book", size: 16 })
            ] }),
            /* @__PURE__ */ a3("div", { class: "ja-fields", style: { marginTop: "11px" }, children: [
              /* @__PURE__ */ a3("label", { children: [
                /* @__PURE__ */ a3("span", { class: "ja-label", children: "Course" }),
                /* @__PURE__ */ a3("select", { class: "ja-control", "aria-label": "Assistant course", value: course?.id ?? "", disabled: generating, onChange: (e3) => {
                  setCourseId(e3.currentTarget.value);
                  setAssignmentId("");
                }, children: snapshot.courses.map((item) => /* @__PURE__ */ a3("option", { value: item.id, children: [
                  item.code,
                  " \xB7 ",
                  item.name
                ] }, item.id)) })
              ] }),
              /* @__PURE__ */ a3("label", { children: [
                /* @__PURE__ */ a3("span", { class: "ja-label", children: "Assignment or homework" }),
                /* @__PURE__ */ a3("select", { class: "ja-control", "aria-label": "Assistant assignment", value: assignment?.id ?? "", disabled: generating || !course?.assignments.length, onChange: (e3) => setAssignmentId(e3.currentTarget.value), children: course?.assignments.length ? course.assignments.map((item) => /* @__PURE__ */ a3("option", { value: item.id, children: item.name }, item.id)) : /* @__PURE__ */ a3("option", { value: "", children: "No assignments available" }) })
              ] })
            ] }),
            assignment && /* @__PURE__ */ a3("div", { class: "ja-context", children: [
              /* @__PURE__ */ a3("strong", { children: assignment.name }),
              /* @__PURE__ */ a3("span", { children: [
                assignment.dueAt && Number.isFinite(Date.parse(assignment.dueAt)) ? `Due ${new Date(assignment.dueAt).toLocaleString(void 0, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })} \xB7 ` : "",
                resources.length,
                " course materials in context"
              ] }),
              safeUrl(assignment.htmlUrl) && /* @__PURE__ */ a3("div", { children: /* @__PURE__ */ a3("a", { href: safeUrl(assignment.htmlUrl), target: "_blank", rel: "noopener noreferrer", children: [
                "Open in Canvas ",
                /* @__PURE__ */ a3(Icon, { name: "external", size: 10 })
              ] }) }),
              brief && /* @__PURE__ */ a3("details", { children: [
                /* @__PURE__ */ a3("summary", { children: "Read the assignment brief" }),
                /* @__PURE__ */ a3("div", { class: "ja-brief", children: brief })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ a3("section", { class: "ja-section", children: [
            /* @__PURE__ */ a3("h2", { children: "How far should I go?" }),
            /* @__PURE__ */ a3("div", { class: "ja-detail", role: "group", "aria-label": "Response detail level", children: LEVELS.map((level) => /* @__PURE__ */ a3("button", { class: settings.detailLevel === level.id ? "active" : "", "aria-pressed": settings.detailLevel === level.id, disabled: generating, onClick: () => updateSettings({ detailLevel: level.id }), children: [
              /* @__PURE__ */ a3("strong", { children: level.title }),
              /* @__PURE__ */ a3("small", { children: level.description })
            ] }, level.id)) }),
            /* @__PURE__ */ a3("div", { class: "ja-mode", role: "group", "aria-label": "Assistant output type", children: [
              /* @__PURE__ */ a3("button", { class: `ja-btn ${mode === "explain" ? "active" : ""}`, "aria-pressed": mode === "explain", disabled: generating, onClick: () => setMode("explain"), children: [
                /* @__PURE__ */ a3(Icon, { name: "layers", size: 12 }),
                "Study & understand"
              ] }),
              /* @__PURE__ */ a3("button", { class: `ja-btn ${mode === "sample" ? "active" : ""}`, "aria-pressed": mode === "sample", disabled: generating, onClick: () => setMode("sample"), children: [
                /* @__PURE__ */ a3(Icon, { name: "file", size: 12 }),
                "Sample assignment"
              ] })
            ] }),
            mode === "sample" && /* @__PURE__ */ a3("p", { class: "ja-note", children: "A complete reference draft, clearly marked as an AI-generated sample. Verify it and follow your course\u2019s AI policy." }),
            /* @__PURE__ */ a3("div", { class: "ja-switches", children: [
              /* @__PURE__ */ a3("label", { class: "ja-switch", children: [
                /* @__PURE__ */ a3("input", { type: "checkbox", checked: settings.webResearch, disabled: generating, onChange: (e3) => updateSettings({ webResearch: e3.currentTarget.checked }) }),
                "Research the web"
              ] }),
              ["diagrams", "graphs", "images"].map((key) => /* @__PURE__ */ a3("label", { class: "ja-switch", children: [
                /* @__PURE__ */ a3("input", { type: "checkbox", checked: visuals[key], disabled: generating, onChange: (e3) => setVisuals({ ...visuals, [key]: e3.currentTarget.checked }) }),
                key[0]?.toUpperCase(),
                key.slice(1)
              ] }, key))
            ] })
          ] }),
          /* @__PURE__ */ a3("section", { class: "ja-section", children: [
            /* @__PURE__ */ a3("label", { class: "ja-label", for: "ja-prompt", children: "Anything you want me to focus on?" }),
            /* @__PURE__ */ a3("textarea", { id: "ja-prompt", class: "ja-control", rows: 3, value: prompt, disabled: generating, onInput: (e3) => setPrompt(e3.currentTarget.value), placeholder: "Explain the hard parts, compare approaches, or write a sample with diagrams and references\u2026" }),
            /* @__PURE__ */ a3("button", { class: "ja-btn primary full", style: { marginTop: "11px" }, disabled: !ready || !assignment || generating, onClick: generate, children: generating ? /* @__PURE__ */ a3(M, { children: [
              /* @__PURE__ */ a3(Icon, { name: "refresh", size: 15, className: "g-spinner" }),
              "Working on your request\u2026"
            ] }) : /* @__PURE__ */ a3(M, { children: [
              /* @__PURE__ */ a3(Icon, { name: "spark", size: 15 }),
              mode === "sample" ? "Create my sample assignment" : "Build my study packet",
              /* @__PURE__ */ a3(Icon, { name: "arrow", size: 14 })
            ] }) }),
            generating && /* @__PURE__ */ a3("div", { class: "ja-progress", role: "status", children: /* @__PURE__ */ a3("span", { children: [
              "Reading Canvas materials, researching, then drafting with ",
              settings.reasoningModel,
              ". This can take several minutes."
            ] }) }),
            generationError && /* @__PURE__ */ a3("div", { class: "ja-notice error", role: "alert", style: { marginTop: "10px" }, children: generationError }),
            /* @__PURE__ */ a3("p", { class: "ja-note", style: { marginTop: "9px" }, children: "Coursework is sent to the local service on your computer. Web research sends search queries to public search engines. Generated work stays in this tab until you export it." })
          ] }),
          packet && /* @__PURE__ */ a3("section", { "aria-label": "Generated study packet", children: [
            /* @__PURE__ */ a3("div", { class: "ja-row", style: { marginBottom: "10px" }, children: [
              /* @__PURE__ */ a3("h2", { children: "Your study packet" }),
              /* @__PURE__ */ a3("span", { class: "ja-eyebrow", children: "Ready for review" })
            ] }),
            /* @__PURE__ */ a3("article", { class: "ja-result", ref: resultRef, children: [
              /* @__PURE__ */ a3("header", { class: "ja-result-header", children: [
                /* @__PURE__ */ a3("div", { class: "ja-eyebrow", children: "Gradient \xB7 AI-generated study reference" }),
                /* @__PURE__ */ a3("h2", { children: packet.title }),
                /* @__PURE__ */ a3("p", { children: packet.summary }),
                packet.generatedAt && /* @__PURE__ */ a3("p", { children: [
                  "Created ",
                  new Date(packet.generatedAt).toLocaleString()
                ] })
              ] }),
              /* @__PURE__ */ a3("div", { class: "ja-result-body", children: [
                /* @__PURE__ */ a3(AssistantMarkdown, { text: packet.markdown }),
                packet.diagrams.map((diagram, i3) => /* @__PURE__ */ a3(ConceptDiagram, { diagram }, i3)),
                packet.graphs.map((graph, i3) => /* @__PURE__ */ a3(DataGraph, { graph }, i3)),
                packet.images.filter((image) => safeUrl(image.url) && safeUrl(image.sourceUrl)).map((image, i3) => /* @__PURE__ */ a3("figure", { class: "ja-visual", children: [
                  /* @__PURE__ */ a3("figcaption", { children: image.title }),
                  /* @__PURE__ */ a3("img", { src: safeUrl(image.url), alt: image.alt, loading: "lazy", referrerPolicy: "no-referrer", onError: (e3) => {
                    e3.currentTarget.style.display = "none";
                  } }),
                  /* @__PURE__ */ a3("a", { href: safeUrl(image.sourceUrl), target: "_blank", rel: "noopener noreferrer", children: "View image source" })
                ] }, i3)),
                packet.sampleMarkdown && /* @__PURE__ */ a3("section", { class: "ja-sample", children: [
                  /* @__PURE__ */ a3("span", { class: "ja-sample-tag", children: "AI-GENERATED SAMPLE \xB7 REVIEW BEFORE USE" }),
                  /* @__PURE__ */ a3(AssistantMarkdown, { text: packet.sampleMarkdown })
                ] }),
                !!packet.checklist?.length && /* @__PURE__ */ a3("section", { class: "ja-sample", children: [
                  /* @__PURE__ */ a3("h3", { children: "Before you finish" }),
                  /* @__PURE__ */ a3("ul", { class: "ja-checklist", children: packet.checklist.map((item, i3) => /* @__PURE__ */ a3("li", { children: item }, i3)) })
                ] }),
                packet.warnings.map((warning, i3) => /* @__PURE__ */ a3("p", { class: "ja-note", style: { marginTop: "10px" }, children: [
                  /* @__PURE__ */ a3("strong", { children: "Verify:" }),
                  " ",
                  warning
                ] }, i3)),
                /* @__PURE__ */ a3("section", { class: "ja-sources", children: [
                  /* @__PURE__ */ a3("h3", { children: "Sources & further reading" }),
                  packet.sources.length ? /* @__PURE__ */ a3("ol", { children: packet.sources.map((source, i3) => /* @__PURE__ */ a3("li", { children: [
                    safeUrl(source.url) ? /* @__PURE__ */ a3("a", { href: safeUrl(source.url), target: "_blank", rel: "noopener noreferrer", children: source.title }) : /* @__PURE__ */ a3("strong", { children: source.title }),
                    source.kind && /* @__PURE__ */ a3("small", { children: [
                      " \xB7 ",
                      source.kind === "canvas" ? "Course material" : "Web resource"
                    ] }),
                    source.excerpt && /* @__PURE__ */ a3("p", { children: source.excerpt })
                  ] }, source.id || i3)) }) : /* @__PURE__ */ a3("p", { class: "ja-note", children: "No verified external sources were returned. Check claims against your course materials." })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ a3("div", { class: "ja-export", children: [
              /* @__PURE__ */ a3("button", { class: "ja-btn", onClick: exportHtml, children: [
                /* @__PURE__ */ a3(Icon, { name: "download", size: 13 }),
                "Export illustrated HTML"
              ] }),
              /* @__PURE__ */ a3("button", { class: "ja-btn", onClick: () => download(packetMarkdown(packet), `${filename(packet.title)}.md`, "text/markdown;charset=utf-8"), children: [
                /* @__PURE__ */ a3(Icon, { name: "download", size: 13 }),
                "Markdown"
              ] })
            ] }),
            /* @__PURE__ */ a3("p", { class: "ja-note", children: "Open the HTML in your browser to print or save it as a PDF, with diagrams and references." })
          ] }),
          /* @__PURE__ */ a3("section", { class: "ja-browser", children: [
            /* @__PURE__ */ a3("div", { class: "ja-row", children: [
              /* @__PURE__ */ a3("h2", { children: "Eyes on your browser" }),
              /* @__PURE__ */ a3(Icon, { name: "search", size: 16 })
            ] }),
            /* @__PURE__ */ a3("p", { class: "ja-note", children: "Your local vision model reads a screenshot and page text, then suggests a sequence of browsing steps. You choose each step." }),
            /* @__PURE__ */ a3("label", { style: { display: "block", marginTop: "10px" }, children: [
              /* @__PURE__ */ a3("span", { class: "ja-label", children: "What should the vision model look for?" }),
              /* @__PURE__ */ a3("textarea", { class: "ja-control", "aria-label": "Browser companion goal", rows: 2, value: browserGoal, disabled: browserBusy, onInput: (e3) => setBrowserGoal(e3.currentTarget.value) })
            ] }),
            /* @__PURE__ */ a3("button", { class: "ja-btn full", style: { marginTop: "9px" }, disabled: !visionReady || browserBusy || !browserGoal.trim(), onClick: inspectPage, children: [
              /* @__PURE__ */ a3(Icon, { name: browserBusy ? "refresh" : "search", size: 14, className: browserBusy ? "g-spinner" : "" }),
              browserBusy ? `Inspecting with ${settings.visionModel}\u2026` : "Inspect this Canvas page"
            ] }),
            !visionReady && /* @__PURE__ */ a3("p", { class: "ja-note", children: "Connect Ollama and select an installed model with vision support to enable page inspection." }),
            browserError && /* @__PURE__ */ a3("div", { class: "ja-notice error", role: "alert", style: { marginTop: "9px" }, children: browserError }),
            browserPlan && /* @__PURE__ */ a3("div", { style: { marginTop: "12px" }, children: [
              /* @__PURE__ */ a3("p", { class: "ja-note", children: browserPlan.summary }),
              /* @__PURE__ */ a3("ol", { class: "ja-browser-steps", children: browserPlan.actions.map((action, i3) => /* @__PURE__ */ a3("li", { children: [
                /* @__PURE__ */ a3("strong", { children: [
                  i3 + 1,
                  ". ",
                  action.kind === "open" ? "Open a resource" : action.kind === "find" ? "Find on this page" : action.kind === "scroll" ? "Move through the page" : "Read this section"
                ] }),
                /* @__PURE__ */ a3("p", { children: action.description }),
                /* @__PURE__ */ a3("button", { class: "ja-btn", onClick: async () => {
                  try {
                    await applyBrowserAction(action);
                    setActionMessage(`Step ${i3 + 1}: ${action.description}`);
                  } catch (error) {
                    setBrowserError(errorMessage(error));
                  }
                }, children: [
                  action.kind === "open" ? "Open link" : action.kind === "find" ? "Find text" : action.kind === "scroll" ? "Scroll" : "Show section",
                  /* @__PURE__ */ a3(Icon, { name: "arrow", size: 11 })
                ] })
              ] }, i3)) }),
              browserPlan.warnings.map((warning, i3) => /* @__PURE__ */ a3("p", { class: "ja-note", children: warning }, i3))
            ] }),
            actionMessage && /* @__PURE__ */ a3("p", { class: "ja-note", role: "status", children: actionMessage })
          ] }),
          /* @__PURE__ */ a3("div", { class: "ja-footnote", children: [
            /* @__PURE__ */ a3(Icon, { name: "shield", size: 12 }),
            /* @__PURE__ */ a3("span", { children: "Local models. Your Canvas access. References you can inspect. The assistant does not submit assignments." })
          ] })
        ] })
      ] })
    ] });
  }

  // extension/deadlineCalendar.ts
  var STORAGE_KEY2 = "gradient_deadline_tracking_v1";
  var HOUR = 60 * 60 * 1e3;
  var emptyStore = () => ({ accounts: {}, delivered: {} });
  var emptyState = () => ({ enabled: false, excludedIds: [], deadlines: [], updatedAt: "" });
  var scope = (origin, userId) => `${origin}|${userId}`;
  var extensionAvailable2 = () => typeof chrome !== "undefined" && !!chrome.runtime?.id;
  function getSnapshotDeadlines(snapshot) {
    const deadlines = [];
    for (const course of snapshot.courses) for (const assignment of course.assignments) {
      if (!assignment.dueAt || !Number.isFinite(Date.parse(assignment.dueAt))) continue;
      if (assignment.submission?.excused || assignment.submission?.score != null || ["submitted", "pending_review", "graded"].includes(assignment.submission?.workflowState ?? "")) continue;
      deadlines.push({
        id: `${scope(snapshot.origin, snapshot.user.id)}|${course.id}|${assignment.id}`,
        origin: snapshot.origin,
        userId: snapshot.user.id,
        courseId: course.id,
        assignmentId: assignment.id,
        title: assignment.name,
        courseName: course.name,
        courseCode: course.code,
        dueAt: new Date(assignment.dueAt).toISOString(),
        url: `${snapshot.origin}/courses/${encodeURIComponent(course.id)}/assignments/${encodeURIComponent(assignment.id)}`
      });
    }
    return [...new Map(deadlines.map((deadline) => [deadline.id, deadline])).values()].sort((a4, b2) => Date.parse(a4.dueAt) - Date.parse(b2.dueAt));
  }
  function escapeIcs(value) {
    return value.replace(/\\/g, "\\\\").replace(/\r\n|\r|\n/g, "\\n").replace(/,/g, "\\,").replace(/;/g, "\\;");
  }
  function icsDate(date) {
    return date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
  }
  function foldIcsLine(line) {
    let result = "", octets = 0;
    for (const char of line) {
      const size = new TextEncoder().encode(char).length;
      if (octets + size > 75) {
        result += "\r\n ";
        octets = 1;
      }
      result += char;
      octets += size;
    }
    return result;
  }
  function createDeadlineCalendar(deadlines, now = /* @__PURE__ */ new Date()) {
    const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//GRADIENT//Assignment Deadlines//EN", "CALSCALE:GREGORIAN", "METHOD:PUBLISH"];
    for (const deadline of new Map(deadlines.map((d3) => [d3.id, d3])).values()) {
      const due = new Date(deadline.dueAt);
      if (!Number.isFinite(due.getTime())) continue;
      const hostname = new URL(deadline.origin).hostname;
      lines.push(
        "BEGIN:VEVENT",
        `UID:gradient-${encodeURIComponent(deadline.userId)}-${encodeURIComponent(deadline.courseId)}-${encodeURIComponent(deadline.assignmentId)}@${hostname}`,
        `DTSTAMP:${icsDate(now)}`,
        `DTSTART:${icsDate(due)}`,
        `DTEND:${icsDate(new Date(due.getTime() + 15 * 6e4))}`,
        `SUMMARY:${escapeIcs(`${deadline.courseCode}: ${deadline.title}`)}`,
        `DESCRIPTION:${escapeIcs(`${deadline.courseName}
Assignment deadline from Canvas.
${deadline.url}`)}`,
        `URL:${escapeIcs(deadline.url)}`
      );
      for (const hours of [24, 1]) lines.push("BEGIN:VALARM", `TRIGGER:-PT${hours}H`, "ACTION:DISPLAY", `DESCRIPTION:${escapeIcs(`${deadline.title} is due in ${hours} hour${hours === 1 ? "" : "s"}.`)}`, "END:VALARM");
      lines.push("END:VEVENT");
    }
    return [...lines, "END:VCALENDAR"].map(foldIcsLine).join("\r\n") + "\r\n";
  }
  function googleCalendarUrl(deadline) {
    const due = new Date(deadline.dueAt);
    if (!Number.isFinite(due.getTime())) throw new Error("This deadline has no valid date.");
    const url = new URL("https://calendar.google.com/calendar/render");
    url.searchParams.set("action", "TEMPLATE");
    url.searchParams.set("text", `${deadline.courseCode}: ${deadline.title}`);
    url.searchParams.set("dates", `${icsDate(due)}/${icsDate(new Date(due.getTime() + 15 * 6e4))}`);
    url.searchParams.set("details", `${deadline.courseName}
Assignment deadline from Canvas.
${deadline.url}`);
    return url.href;
  }
  function downloadDeadlineCalendar(deadlines) {
    const url = URL.createObjectURL(new Blob([createDeadlineCalendar(deadlines)], { type: "text/calendar;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "gradient-canvas-deadlines.ics";
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  async function readStore() {
    let stored;
    if (typeof chrome !== "undefined" && chrome.storage?.local) stored = (await chrome.storage.local.get(STORAGE_KEY2))[STORAGE_KEY2];
    else if (typeof localStorage !== "undefined") {
      const raw = localStorage.getItem(STORAGE_KEY2);
      if (raw) try {
        stored = JSON.parse(raw);
      } catch {
      }
    }
    if (!stored || typeof stored !== "object") return emptyStore();
    const value = stored;
    return { accounts: value.accounts && typeof value.accounts === "object" ? value.accounts : {}, delivered: value.delivered && typeof value.delivered === "object" ? value.delivered : {} };
  }
  async function writeStore(store) {
    if (typeof chrome !== "undefined" && chrome.storage?.local) await chrome.storage.local.set({ [STORAGE_KEY2]: store });
    else if (typeof localStorage !== "undefined") localStorage.setItem(STORAGE_KEY2, JSON.stringify(store));
  }
  async function sendTrackingMessage(message2) {
    const response = await chrome.runtime.sendMessage(message2);
    if (!response?.ok || !response.state) throw new Error(response?.error || "The extension could not update your reminders. Reload your Canvas tab and try again.");
    return response.state;
  }
  async function getDeadlineTracking(snapshot) {
    if (extensionAvailable2()) return sendTrackingMessage({ type: "GRADIENT_GET_TRACKING", origin: snapshot.origin, userId: snapshot.user.id });
    return (await readStore()).accounts[scope(snapshot.origin, snapshot.user.id)] ?? emptyState();
  }
  async function setDeadlineTracking(snapshot, enabled, excludedIds) {
    const message2 = { type: "GRADIENT_TRACK_DEADLINES", origin: snapshot.origin, userId: snapshot.user.id, enabled, deadlines: getSnapshotDeadlines(snapshot), ...excludedIds ? { excludedIds } : {} };
    if (extensionAvailable2()) return sendTrackingMessage(message2);
    const store = await readStore();
    const key = scope(snapshot.origin, snapshot.user.id);
    const previous = store.accounts[key] ?? emptyState();
    const state = { ...previous, enabled, deadlines: message2.deadlines, excludedIds: excludedIds ?? previous.excludedIds, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    store.accounts[key] = state;
    await writeStore(store);
    return state;
  }
  async function syncTrackedDeadlines(snapshot) {
    if (!extensionAvailable2()) return;
    await sendTrackingMessage({ type: "GRADIENT_SYNC_DEADLINES", origin: snapshot.origin, userId: snapshot.user.id, deadlines: getSnapshotDeadlines(snapshot) });
  }
  var queue = Promise.resolve();

  // extension/ui/DeadlineTracker.tsx
  function DeadlineTracker({ snapshot, preview = false }) {
    const deadlines = w2(() => getSnapshotDeadlines(snapshot), [snapshot]);
    const [state, setState] = d2(null);
    const [busy, setBusy] = d2(false);
    const [error, setError] = d2("");
    const [showPast, setShowPast] = d2(false);
    A(() => {
      let mounted = true;
      const load = async () => {
        if (!preview) await syncTrackedDeadlines(snapshot);
        const loaded = await getDeadlineTracking(snapshot);
        if (mounted) {
          setState(loaded);
          setError("");
        }
      };
      load().catch((err) => {
        if (mounted) setError(err instanceof Error ? err.message : "Could not read deadline preferences.");
      });
      return () => {
        mounted = false;
      };
    }, [snapshot, preview]);
    const future = deadlines.filter((d3) => Date.parse(d3.dueAt) > Date.now());
    const overdue = deadlines.filter((d3) => Date.parse(d3.dueAt) <= Date.now());
    const excluded = new Set(state?.excludedIds ?? []);
    const selected = future.filter((d3) => !excluded.has(d3.id));
    const update = async (enabled, excludedIds) => {
      setBusy(true);
      setError("");
      try {
        setState(await setDeadlineTracking(snapshot, enabled, excludedIds));
      } catch (err) {
        setError(err instanceof Error ? err.message : "Your reminder preferences could not be saved.");
      } finally {
        setBusy(false);
      }
    };
    const visible = showPast ? deadlines : future;
    const canNotify = !preview && typeof chrome !== "undefined" && !!chrome.runtime?.id;
    return /* @__PURE__ */ a3("section", { class: "g-card", "aria-label": "Deadline tracking and calendar", children: [
      /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
        /* @__PURE__ */ a3("h2", { children: "Keep your deadlines close." }),
        /* @__PURE__ */ a3(Icon, { name: "calendar", size: 18 })
      ] }),
      /* @__PURE__ */ a3("p", { class: "g-small", children: [
        future.length,
        " upcoming deadline",
        future.length === 1 ? "" : "s",
        overdue.length ? ` \xB7 ${overdue.length} past due` : "",
        ". Browser reminders arrive 24 hours and 1 hour before selected deadlines."
      ] }),
      /* @__PURE__ */ a3("div", { style: { display: "flex", gap: "8px", flexWrap: "wrap", marginTop: "14px" }, children: [
        /* @__PURE__ */ a3("button", { class: state?.enabled ? "g-secondary" : "g-primary", disabled: busy || state === null || preview, onClick: () => update(!state?.enabled), children: [
          /* @__PURE__ */ a3(Icon, { name: state?.enabled ? "check" : "clock", size: 14 }),
          busy ? "Saving\u2026" : state?.enabled ? "Pause reminders" : "Track deadlines"
        ] }),
        /* @__PURE__ */ a3("button", { class: "g-secondary", disabled: !selected.length, onClick: () => downloadDeadlineCalendar(selected), children: [
          /* @__PURE__ */ a3(Icon, { name: "download", size: 14 }),
          "Download calendar (.ics)"
        ] })
      ] }),
      state?.enabled && /* @__PURE__ */ a3("p", { class: "g-small", role: "status", style: { marginTop: "10px", color: "#187352" }, children: canNotify ? "Browser reminders are on. Keep Chrome running to receive them." : "Preferences saved. Load the extension in Chrome to receive browser reminders." }),
      preview && /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "10px" }, children: "Sample deadlines. Install the extension on Canvas to enable reminders for your real coursework." }),
      /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "10px" }, children: "Import the .ics file into Apple Calendar or Google Calendar. Google links let you review and save one event. Calendar copies do not automatically sync; refresh Canvas and export again after a deadline changes." }),
      error && /* @__PURE__ */ a3("p", { class: "g-notice", role: "alert", style: { marginTop: "12px" }, children: error }),
      !!overdue.length && /* @__PURE__ */ a3("label", { class: "g-small", style: { display: "flex", gap: "7px", alignItems: "center", marginTop: "14px", cursor: "pointer" }, children: [
        /* @__PURE__ */ a3("input", { type: "checkbox", checked: showPast, onChange: (e3) => setShowPast(e3.currentTarget.checked) }),
        "Show past-due work"
      ] }),
      /* @__PURE__ */ a3("div", { style: { marginTop: "12px", maxHeight: "350px", overflowY: "auto" }, children: [
        visible.map((deadline) => {
          const past = Date.parse(deadline.dueAt) <= Date.now();
          return /* @__PURE__ */ a3("div", { class: "g-task", style: { alignItems: "flex-start" }, children: [
            /* @__PURE__ */ a3("input", { type: "checkbox", "aria-label": `Include ${deadline.title} in reminders and calendar export`, disabled: busy || !state || preview || past, checked: !past && !excluded.has(deadline.id), style: { marginTop: "4px", accentColor: "#2855e8" }, onChange: (e3) => {
              const next = new Set(excluded);
              if (e3.currentTarget.checked) next.delete(deadline.id);
              else next.add(deadline.id);
              update(state?.enabled ?? false, [...next]);
            } }),
            /* @__PURE__ */ a3("div", { class: "g-task-main", children: [
              /* @__PURE__ */ a3("strong", { children: /* @__PURE__ */ a3("a", { href: deadline.url, children: deadline.title }) }),
              /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "4px" }, children: [
                deadline.courseCode,
                " \xB7 ",
                new Date(deadline.dueAt).toLocaleString(void 0, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }),
                past ? " \xB7 Past due" : ""
              ] }),
              !past && /* @__PURE__ */ a3("a", { class: "g-link-btn", style: { display: "inline-flex", marginTop: "7px", fontSize: "10px" }, href: googleCalendarUrl(deadline), target: "_blank", rel: "noopener noreferrer", children: [
                "Add to Google Calendar ",
                /* @__PURE__ */ a3(Icon, { name: "external", size: 11 })
              ] })
            ] })
          ] }, deadline.id);
        }),
        !visible.length && /* @__PURE__ */ a3("p", { class: "g-small", style: { padding: "14px 0" }, children: "No upcoming, unsubmitted assignments with a due date were found." })
      ] }),
      /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "12px" }, children: "Saved locally: assignment titles, course names, deadlines, and Canvas links. Reminder schedules update whenever GRADIENT refreshes Canvas. Submitted work is removed from the schedule." })
    ] });
  }

  // extension/ui/Workspace.tsx
  var colors = [
    { tint: "#edf2ff", ink: "#2855e8" },
    { tint: "#fff0e8", ink: "#a84726" },
    { tint: "#e6f5ee", ink: "#187352" },
    { tint: "#f1eafd", ink: "#7950b9" },
    { tint: "#fff5d9", ink: "#87651b" },
    { tint: "#e6f5fa", ink: "#22708c" }
  ];
  function plain2(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    doc.querySelectorAll("script,style").forEach((el) => el.remove());
    doc.querySelectorAll("p,br,li,h1,h2,h3").forEach((el) => el.append(doc.createTextNode("\n")));
    return (doc.body.textContent ?? "").replace(/\n{3,}/g, "\n\n").trim();
  }
  function safeLink(value) {
    try {
      const url = new URL(value, window.location.origin);
      return ["https:", "http:"].includes(url.protocol) ? url.href : "#";
    } catch {
      return "#";
    }
  }
  function score(value) {
    return value == null ? "\u2014" : `${value.toFixed(1)}%`;
  }
  function pending(a4) {
    return !a4.submission?.excused && a4.submission?.score == null && a4.submission?.workflowState !== "submitted" && a4.submission?.workflowState !== "pending_review" && a4.submission?.workflowState !== "graded";
  }
  function dueDate(a4) {
    return a4.dueAt ? Date.parse(a4.dueAt) : Number.POSITIVE_INFINITY;
  }
  function dueLabel(a4) {
    if (!a4.dueAt) return "No due date";
    const date = new Date(a4.dueAt);
    const now = /* @__PURE__ */ new Date();
    if (!Number.isFinite(date.getTime())) return "No due date";
    if (date.getTime() < now.getTime()) return "Past due";
    const dayKey = (d3) => Date.UTC(d3.getFullYear(), d3.getMonth(), d3.getDate());
    const days = (dayKey(date) - dayKey(now)) / 864e5;
    if (days === 0) return "Due today";
    if (days === 1) return "Tomorrow";
    return date.toLocaleDateString(void 0, { month: "short", day: "numeric" });
  }
  function taskStatus(a4) {
    if (a4.submission?.excused) return "Excused";
    if (a4.submission?.score != null) return `${a4.submission.score} / ${a4.pointsPossible} pts`;
    if (a4.submission?.workflowState === "graded") return "Graded \xB7 score hidden";
    if (a4.submission?.workflowState === "submitted" || a4.submission?.workflowState === "pending_review") return "Submitted";
    return "To do";
  }
  function initials(name) {
    return name.split(" ").filter(Boolean).slice(0, 2).map((n2) => n2[0]).join("").toUpperCase();
  }
  function exportCalendar(tasks, origin) {
    const esc = (s3) => s3.replace(/\\/g, "\\\\").replace(/\r?\n/g, "\\n").replace(/,/g, "\\,").replace(/;/g, "\\;");
    const stamp = (d3) => d3.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
    const now = stamp(/* @__PURE__ */ new Date());
    const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//GRADIENT//Canvas Coursework//EN", "CALSCALE:GREGORIAN"];
    for (const { course, assignment: a4 } of tasks.filter((t3) => t3.assignment.dueAt)) {
      const start = new Date(a4.dueAt);
      if (!Number.isFinite(start.getTime())) continue;
      lines.push("BEGIN:VEVENT", `UID:gradient-${course.id}-${a4.id}@${new URL(origin).hostname}`, `DTSTAMP:${now}`, `DTSTART:${stamp(start)}`, `DTEND:${stamp(new Date(start.getTime() + 15 * 6e4))}`, `SUMMARY:${esc(a4.name)}`, `DESCRIPTION:${esc(course.name + "\nAssignment deadline from Canvas.\n" + a4.htmlUrl)}`, `URL:${safeLink(a4.htmlUrl)}`, "END:VEVENT");
    }
    lines.push("END:VCALENDAR");
    const folded = lines.map((line) => {
      let result = "", count = 0;
      for (const char of line) {
        const bytes = new TextEncoder().encode(char).length;
        if (count + bytes > 74) {
          result += "\r\n ";
          count = 1;
        }
        result += char;
        count += bytes;
      }
      return result;
    }).join("\r\n") + "\r\n";
    const url = URL.createObjectURL(new Blob([folded], { type: "text/calendar;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "gradient-canvas-deadlines.ics";
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function Empty({ title, children }) {
    return /* @__PURE__ */ a3("div", { class: "g-empty", children: [
      /* @__PURE__ */ a3("div", { class: "g-empty-icon", children: /* @__PURE__ */ a3(Icon, { name: "check", size: 22 }) }),
      /* @__PURE__ */ a3("h2", { children: title }),
      /* @__PURE__ */ a3("p", { children })
    ] });
  }
  function TaskRow({ task, onSelect }) {
    const { course, assignment: a4 } = task;
    return /* @__PURE__ */ a3("div", { class: "g-task", children: [
      /* @__PURE__ */ a3("div", { class: "g-task-marker", children: /* @__PURE__ */ a3(Icon, { name: "book", size: 15 }) }),
      /* @__PURE__ */ a3("div", { class: "g-task-main", children: [
        /* @__PURE__ */ a3("strong", { children: onSelect ? /* @__PURE__ */ a3("button", { class: "g-link-btn", style: { textAlign: "left", color: "inherit", fontSize: "12px", fontWeight: 650 }, onClick: onSelect, children: a4.name }) : /* @__PURE__ */ a3("a", { href: safeLink(a4.htmlUrl), children: a4.name }) }),
        /* @__PURE__ */ a3("div", { class: "g-task-meta", children: [
          /* @__PURE__ */ a3("span", { children: course.code }),
          /* @__PURE__ */ a3("span", { children: "\xB7" }),
          /* @__PURE__ */ a3("span", { children: [
            a4.pointsPossible,
            " pts"
          ] }),
          !pending(a4) && /* @__PURE__ */ a3(M, { children: [
            /* @__PURE__ */ a3("span", { children: "\xB7" }),
            /* @__PURE__ */ a3("span", { children: taskStatus(a4) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ a3("span", { class: `g-due ${dueDate(a4) > Date.now() + 2 * 864e5 || !a4.dueAt ? "normal" : ""}`, children: dueLabel(a4) })
    ] });
  }
  function AssignmentFeedback({ assignment }) {
    const rubric = assignment.rubric ?? [];
    const comments = assignment.submission?.submissionComments ?? [];
    const assessment = assignment.submission?.rubricAssessment ?? {};
    if (!rubric.length && !comments.length) return null;
    return /* @__PURE__ */ a3("section", { class: "g-card", "aria-label": "Assignment rubric and instructor feedback", children: /* @__PURE__ */ a3("details", { children: [
      /* @__PURE__ */ a3("summary", { class: "g-feedback-summary", children: [
        /* @__PURE__ */ a3("span", { children: "Rubric & instructor feedback" }),
        /* @__PURE__ */ a3("span", { class: "g-label-count", children: "FROM CANVAS" })
      ] }),
      /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "10px" }, children: [
        "The criteria and feedback published for ",
        assignment.name,
        "."
      ] }),
      rubric.length > 0 && /* @__PURE__ */ a3("div", { class: "g-rubric-list", children: rubric.map((criterion) => {
        const assessed = assessment[criterion.id];
        return /* @__PURE__ */ a3("div", { class: "g-rubric-criterion", children: [
          /* @__PURE__ */ a3("div", { class: "g-section-head", style: { marginBottom: "8px" }, children: [
            /* @__PURE__ */ a3("h3", { children: plain2(criterion.description) || "Rubric criterion" }),
            /* @__PURE__ */ a3("span", { class: "g-label-count", children: [
              criterion.points,
              " pts"
            ] })
          ] }),
          assessed && /* @__PURE__ */ a3("div", { class: "g-notice info", style: { marginBottom: "9px" }, children: [
            /* @__PURE__ */ a3(Icon, { name: "check", size: 14 }),
            /* @__PURE__ */ a3("div", { children: [
              /* @__PURE__ */ a3("strong", { children: [
                "Instructor assessment: ",
                assessed.points,
                " / ",
                criterion.points,
                " pts"
              ] }),
              assessed.comments && /* @__PURE__ */ a3("p", { style: { marginTop: "4px" }, children: plain2(assessed.comments) })
            ] })
          ] }),
          criterion.ratings.length > 0 && /* @__PURE__ */ a3("details", { children: [
            /* @__PURE__ */ a3("summary", { class: "g-ratings-summary", children: "Rating descriptions" }),
            /* @__PURE__ */ a3("ul", { class: "g-rubric-ratings", children: criterion.ratings.map((rating, i3) => /* @__PURE__ */ a3("li", { children: [
              /* @__PURE__ */ a3("span", { children: plain2(rating.description) || "No description provided" }),
              /* @__PURE__ */ a3("strong", { children: [
                rating.points,
                " pts"
              ] })
            ] }, rating.id ?? i3)) })
          ] })
        ] }, criterion.id);
      }) }),
      comments.length > 0 && /* @__PURE__ */ a3("div", { class: "g-feedback-comments", children: [
        /* @__PURE__ */ a3("h3", { children: "Submission comments" }),
        comments.map((comment, i3) => /* @__PURE__ */ a3("div", { class: "g-instructor-comment", children: [
          /* @__PURE__ */ a3("div", { class: "g-comment-author", children: [
            /* @__PURE__ */ a3("strong", { children: comment.authorName || "Canvas user" }),
            comment.createdAt && Number.isFinite(Date.parse(comment.createdAt)) && /* @__PURE__ */ a3("time", { dateTime: comment.createdAt, children: new Date(comment.createdAt).toLocaleDateString(void 0, { month: "short", day: "numeric" }) })
          ] }),
          /* @__PURE__ */ a3("p", { children: plain2(comment.comment) })
        ] }, i3))
      ] })
    ] }) });
  }
  function Workspace({ snapshot, loading, error, onRefresh, initialCourseId, initialAssignmentId, progress, preview = false }) {
    const [tab, setTab] = d2("overview");
    const [assistantOpened, setAssistantOpened] = d2(false);
    A(() => {
      if (tab === "assistant") setAssistantOpened(true);
    }, [tab]);
    const assistantSnapshot = T2(null);
    if (snapshot) assistantSnapshot.current = snapshot;
    else if (!loading) assistantSnapshot.current = null;
    const [minimized, setMinimized] = d2(false);
    const [wide, setWide] = d2(false);
    A(() => {
      const toggle = () => setMinimized((previous) => !previous);
      window.addEventListener("gradient:toggle", toggle);
      return () => window.removeEventListener("gradient:toggle", toggle);
    }, []);
    const [selectedCourseId, setSelectedCourseId] = d2(initialCourseId ?? "");
    const [query, setQuery] = d2("");
    const [resourceQuery, setResourceQuery] = d2("");
    const [filter, setFilter] = d2("todo");
    const [resourceFilter, setResourceFilter] = d2("all");
    const [assignmentId, setAssignmentId] = d2("");
    const [whatIf, setWhatIf] = d2(85);
    const [hours, setHours] = d2(8);
    const [planning, setPlanning] = d2(false);
    const [plan, setPlan] = d2(null);
    const [planError, setPlanError] = d2("");
    const [credits, setCredits] = d2({});
    const [creditError, setCreditError] = d2("");
    const courses = snapshot?.courses ?? [];
    const active = courses.find((c3) => c3.id === selectedCourseId) ?? courses[0];
    A(() => {
      if (initialCourseId) setSelectedCourseId(initialCourseId);
    }, [initialCourseId]);
    A(() => {
      if (initialAssignmentId) {
        setAssignmentId(initialAssignmentId);
        setTab("coursework");
      }
    }, [initialAssignmentId]);
    A(() => {
      let mounted = true;
      loadOptions().then((o4) => {
        if (mounted) setCredits(o4.courseCreditHours);
      }).catch(() => {
      });
      return () => {
        mounted = false;
      };
    }, []);
    A(() => {
      setPlan(null);
      setPlanError("");
    }, [snapshot, selectedCourseId, credits, hours]);
    const tasks = w2(() => courses.flatMap((course) => course.assignments.map((assignment) => ({ course, assignment }))).sort((a4, b2) => dueDate(a4.assignment) - dueDate(b2.assignment)), [snapshot]);
    const upcoming = tasks.filter((t3) => pending(t3.assignment) && dueDate(t3.assignment) >= Date.now());
    const dueThisWeek = upcoming.filter((t3) => dueDate(t3.assignment) < Date.now() + 7 * 864e5);
    const submittedCount = tasks.filter((t3) => t3.assignment.submission?.workflowState === "submitted" || t3.assignment.submission?.workflowState === "pending_review").length;
    const activeTasks = tasks.filter((t3) => t3.course.id === active?.id && t3.assignment.name.toLowerCase().includes(query.toLowerCase())).filter((t3) => filter === "all" || filter === "todo" && pending(t3.assignment) || filter === "submitted" && ["submitted", "pending_review"].includes(t3.assignment.submission?.workflowState ?? "") || filter === "graded" && (t3.assignment.submission?.score != null || t3.assignment.submission?.workflowState === "graded"));
    const simAssignment = active?.assignments.find((a4) => a4.id === assignmentId) ?? active?.assignments.find((a4) => pending(a4) && a4.pointsPossible > 0) ?? active?.assignments.find((a4) => a4.pointsPossible > 0);
    const simulated = w2(() => {
      if (!active || !simAssignment) return null;
      const otherSubmissions = active.input.submissions.filter((s3) => s3.assignmentId !== simAssignment.id);
      return currentGrade({ ...active.input, submissions: [...otherSubmissions, { assignmentId: simAssignment.id, score: simAssignment.pointsPossible * whatIf / 100, posted: true, excused: false, missing: false, late: false, workflowState: "graded" }] }).percentage;
    }, [active, simAssignment, whatIf]);
    const computed = w2(() => active ? currentGrade(active.input).percentage : null, [active]);
    const gradeMatches = active?.currentScore != null && computed != null && Math.abs(active.currentScore - computed) <= 0.01;
    const allIssues = [...snapshot?.issues ?? [], ...courses.flatMap((c3) => c3.issues)];
    const changeTab = (next) => {
      setTab(next);
    };
    const selectCourse = (id) => {
      setSelectedCourseId(id);
      setAssignmentId("");
      setPlan(null);
    };
    const buildPlan = () => {
      if (!active || planning) return;
      setPlanning(true);
      setPlanError("");
      setTimeout(() => {
        try {
          const input = { ...active.input, studyEligibleAssignmentIds: active.assignments.filter(pending).map((assignment) => assignment.id), course: { ...active.input.course, creditHours: credits[active.id] ?? 3 } };
          const result = optimizeEffort([input], { capacityHours: hours, stepSizeHours: 0.5, numSamples: 100, seed: 42, currentTime: /* @__PURE__ */ new Date(), protectMastery: true, masteryFloorHours: 0.5, isRobustnessRun: true });
          setPlan(result);
        } catch (e3) {
          setPlanError(e3 instanceof Error ? e3.message : "The study plan could not be calculated.");
        } finally {
          setPlanning(false);
        }
      }, 30);
    };
    const saveCredit = (id, n2) => {
      if (!Number.isFinite(n2) || n2 <= 0 || n2 > 30) return;
      const next = { ...credits, [id]: n2 };
      setCredits(next);
      saveOptions({ courseCreditHours: next }).catch(() => setCreditError("Your credit hours could not be saved. They will apply for this session."));
    };
    const coursePicker = active ? /* @__PURE__ */ a3("div", { class: "g-course-menu", children: [
      /* @__PURE__ */ a3("select", { class: "g-select", "aria-label": "Choose a course", value: active.id, onChange: (e3) => selectCourse(e3.currentTarget.value), children: courses.map((c3) => /* @__PURE__ */ a3("option", { value: c3.id, children: [
        c3.code,
        " \xB7 ",
        c3.name
      ] }, c3.id)) }),
      /* @__PURE__ */ a3("a", { class: "g-icon-btn", href: safeLink(active.url), title: "Open course in Canvas", "aria-label": "Open course in Canvas", children: /* @__PURE__ */ a3(Icon, { name: "external", size: 17 }) })
    ] }) : null;
    return /* @__PURE__ */ a3(M, { children: [
      /* @__PURE__ */ a3("style", { children: WORKSPACE_STYLES + ASSISTANT_ENTRY_STYLES }),
      minimized ? /* @__PURE__ */ a3("button", { id: "gradient-launcher", class: "g-launcher", "aria-label": "Open GRADIENT", onClick: () => setMinimized(false), children: [
        /* @__PURE__ */ a3(Icon, { name: "chart", size: 21 }),
        "GRADIENT",
        /* @__PURE__ */ a3(Icon, { name: "chevron", size: 16 })
      ] }) : /* @__PURE__ */ a3("aside", { id: "gradient-workspace", class: `gw ${wide ? "wide" : ""}`, "aria-label": "GRADIENT Canvas workspace", children: [
        /* @__PURE__ */ a3("header", { class: "g-header", children: [
          /* @__PURE__ */ a3("div", { class: "g-brand", children: [
            /* @__PURE__ */ a3("div", { class: "g-logo", children: /* @__PURE__ */ a3(Icon, { name: "chart", size: 22 }) }),
            /* @__PURE__ */ a3("div", { children: [
              /* @__PURE__ */ a3("div", { class: "g-wordmark", children: [
                "gradient",
                /* @__PURE__ */ a3("span", { style: { color: "#2855e8" }, children: "." })
              ] }),
              /* @__PURE__ */ a3("div", { class: "g-brand-sub", children: "Your academic advantage" })
            ] })
          ] }),
          /* @__PURE__ */ a3("button", { class: "g-icon-btn g-hide-mobile", "aria-label": wide ? "Compact workspace" : "Expand workspace", title: wide ? "Compact workspace" : "Expand workspace", onClick: () => setWide(!wide), children: /* @__PURE__ */ a3(Icon, { name: "expand", size: 16 }) }),
          /* @__PURE__ */ a3("button", { class: "g-icon-btn", "aria-label": "Refresh Canvas data", title: "Refresh Canvas data", disabled: loading, onClick: onRefresh, children: /* @__PURE__ */ a3(Icon, { name: "refresh", size: 16, className: loading ? "g-spinner" : "" }) }),
          /* @__PURE__ */ a3("button", { class: "g-icon-btn", "aria-label": "Minimize GRADIENT", title: "Minimize GRADIENT", onClick: () => setMinimized(true), children: /* @__PURE__ */ a3(Icon, { name: "collapse", size: 17 }) })
        ] }),
        /* @__PURE__ */ a3("div", { class: "g-status", children: [
          /* @__PURE__ */ a3("span", { class: "g-live", children: [
            /* @__PURE__ */ a3("i", { class: `g-dot ${preview ? "g-demo-dot" : ""}` }),
            preview ? "Demo preview" : loading && !snapshot ? "Connecting to Canvas" : error && !snapshot ? "Connection needed" : "Canvas connected"
          ] }),
          /* @__PURE__ */ a3("span", { children: snapshot?.syncedAt ? `Synced ${new Date(snapshot.syncedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}` : "Your account. Your workspace." })
        ] }),
        /* @__PURE__ */ a3("nav", { class: "g-nav", role: "tablist", "aria-label": "Workspace views", children: [{ id: "overview", label: "Overview", icon: "grid" }, { id: "assistant", label: "Assistant", icon: "spark" }, { id: "coursework", label: "Coursework", icon: "book" }, { id: "resources", label: "Resources", icon: "folder" }, { id: "settings", label: "Settings", icon: "settings" }].map((item) => /* @__PURE__ */ a3("button", { id: `g-tab-${item.id}`, class: `g-tab ${tab === item.id ? "active" : ""}`, role: "tab", "aria-selected": tab === item.id, "aria-controls": "gradient-tab-content", onClick: () => changeTab(item.id), children: [
          /* @__PURE__ */ a3(Icon, { name: item.icon, size: 15 }),
          item.label
        ] }, item.id)) }),
        /* @__PURE__ */ a3("div", { id: "gradient-tab-content", class: "g-body", role: "tabpanel", "aria-labelledby": `g-tab-${tab}`, children: [
          loading && /* @__PURE__ */ a3("div", { class: "g-sync-loading", role: "status", children: [
            /* @__PURE__ */ a3(Icon, { name: "refresh", size: 14, className: "g-spinner" }),
            progress || "Syncing your Canvas account\u2026"
          ] }),
          error && /* @__PURE__ */ a3("div", { class: "g-notice", role: "alert", style: { marginBottom: "16px" }, children: [
            /* @__PURE__ */ a3(Icon, { name: "alert", size: 16 }),
            /* @__PURE__ */ a3("div", { children: [
              error,
              /* @__PURE__ */ a3("button", { class: "g-link-btn", onClick: onRefresh, disabled: loading, children: [
                "Try again ",
                /* @__PURE__ */ a3(Icon, { name: "arrow", size: 12 })
              ] })
            ] })
          ] }),
          !snapshot && loading ? /* @__PURE__ */ a3("div", { class: "g-stack", children: [
            /* @__PURE__ */ a3("div", { children: [
              /* @__PURE__ */ a3("div", { class: "g-eyebrow", children: "Everything, in one place" }),
              /* @__PURE__ */ a3("h1", { class: "g-title", children: [
                "Making room",
                /* @__PURE__ */ a3("br", {}),
                "for your ",
                /* @__PURE__ */ a3("span", { class: "g-accent", children: "next win." })
              ] }),
              /* @__PURE__ */ a3("p", { class: "g-subtitle", children: "Connecting your courses, deadlines, and materials." })
            ] }),
            /* @__PURE__ */ a3("div", { class: "g-skeleton" }),
            /* @__PURE__ */ a3("div", { class: "g-skeleton" }),
            /* @__PURE__ */ a3("div", { class: "g-skeleton" })
          ] }) : !snapshot ? /* @__PURE__ */ a3(Empty, { title: "Let's connect your Canvas", children: "Open Canvas and sign in, then refresh GRADIENT to see your courses here." }) : /* @__PURE__ */ a3(M, { children: [
            tab === "overview" && /* @__PURE__ */ a3("div", { class: "g-stack", children: [
              /* @__PURE__ */ a3("div", { class: "g-greeting", children: [
                /* @__PURE__ */ a3("div", { children: [
                  /* @__PURE__ */ a3("div", { class: "g-eyebrow", children: "Your semester, in focus" }),
                  /* @__PURE__ */ a3("h1", { class: "g-title", children: [
                    "Hey ",
                    snapshot.user.shortName?.split(" ")[0] || snapshot.user.name.split(" ")[0],
                    ",",
                    /* @__PURE__ */ a3("br", {}),
                    "let's make ",
                    /* @__PURE__ */ a3("span", { class: "g-accent", children: "progress." })
                  ] }),
                  /* @__PURE__ */ a3("p", { class: "g-subtitle", children: "A little clarity. A better plan. All inside Canvas." })
                ] }),
                /* @__PURE__ */ a3("span", { class: "g-date", children: (/* @__PURE__ */ new Date()).toLocaleDateString(void 0, { month: "short", day: "numeric" }) })
              ] }),
              /* @__PURE__ */ a3("button", { class: "g-assistant-entry", onClick: () => setTab("assistant"), children: [
                /* @__PURE__ */ a3("span", { class: "g-assistant-entry-icon", children: /* @__PURE__ */ a3(Icon, { name: "spark", size: 22 }) }),
                /* @__PURE__ */ a3("span", { children: [
                  /* @__PURE__ */ a3("strong", { children: "Your local AI, ready for the mission." }),
                  /* @__PURE__ */ a3("small", { children: "Read the brief. Research the web. Build your study packet." })
                ] }),
                /* @__PURE__ */ a3(Icon, { name: "arrow", size: 18 })
              ] }),
              /* @__PURE__ */ a3("div", { class: "g-metrics", children: [
                /* @__PURE__ */ a3("div", { class: "g-metric blue", children: [
                  /* @__PURE__ */ a3("strong", { children: courses.length.toString().padStart(2, "0") }),
                  /* @__PURE__ */ a3("small", { children: "Active courses" })
                ] }),
                /* @__PURE__ */ a3("div", { class: "g-metric peach", children: [
                  /* @__PURE__ */ a3("strong", { children: dueThisWeek.length.toString().padStart(2, "0") }),
                  /* @__PURE__ */ a3("small", { children: "Due this week" })
                ] }),
                /* @__PURE__ */ a3("div", { class: "g-metric", children: [
                  /* @__PURE__ */ a3("strong", { children: submittedCount.toString().padStart(2, "0") }),
                  /* @__PURE__ */ a3("small", { children: "Awaiting grades" })
                ] })
              ] }),
              /* @__PURE__ */ a3("div", { class: "g-overview-grid", children: [
                /* @__PURE__ */ a3("section", { children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("h2", { children: "Your courses" }),
                    /* @__PURE__ */ a3("span", { class: "g-label-count", children: "FROM CANVAS" })
                  ] }),
                  /* @__PURE__ */ a3("div", { class: "g-course-list", children: [
                    courses.map((course, i3) => {
                      const color = colors[i3 % colors.length];
                      return /* @__PURE__ */ a3("button", { class: "g-course", style: { "--tint": color.tint, "--ink": color.ink }, onClick: () => {
                        selectCourse(course.id);
                        setTab("coursework");
                      }, children: [
                        /* @__PURE__ */ a3("div", { class: "g-course-symbol", children: course.code.replace(/[^A-Za-z]/g, "").slice(0, 3).toUpperCase() }),
                        /* @__PURE__ */ a3("div", { class: "g-course-info", children: [
                          /* @__PURE__ */ a3("strong", { children: course.name }),
                          /* @__PURE__ */ a3("small", { children: [
                            course.assignments.filter(pending).length,
                            " to do \xB7 ",
                            course.resources.length,
                            " resources"
                          ] }),
                          /* @__PURE__ */ a3("div", { class: "g-track", children: /* @__PURE__ */ a3("span", { style: { width: `${Math.min(100, Math.max(0, course.currentScore ?? 0))}%` } }) })
                        ] }),
                        /* @__PURE__ */ a3("div", { class: "g-course-score g-bold-number", children: [
                          score(course.currentScore),
                          /* @__PURE__ */ a3("small", { children: "current grade" })
                        ] })
                      ] }, course.id);
                    }),
                    !courses.length && /* @__PURE__ */ a3(Empty, { title: "No student courses found", children: "Your active student enrollments will appear here when Canvas makes them available." })
                  ] })
                ] }),
                /* @__PURE__ */ a3("section", { class: "g-card", children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("h2", { children: "Up next" }),
                    /* @__PURE__ */ a3("button", { class: "g-link-btn", onClick: () => setTab("coursework"), children: [
                      "View all ",
                      /* @__PURE__ */ a3(Icon, { name: "arrow", size: 13 })
                    ] })
                  ] }),
                  upcoming.length ? upcoming.slice(0, 4).map((task) => /* @__PURE__ */ a3(TaskRow, { task, onSelect: () => {
                    selectCourse(task.course.id);
                    setAssignmentId(task.assignment.id);
                    setTab("coursework");
                  } }, `${task.course.id}-${task.assignment.id}`)) : /* @__PURE__ */ a3(Empty, { title: "A little breathing room", children: "No upcoming unsubmitted assignments with deadlines were found." })
                ] }),
                /* @__PURE__ */ a3("section", { class: "g-card g-plan", children: [
                  /* @__PURE__ */ a3("div", { class: "g-eyebrow", style: { color: "#2855e8", marginBottom: "9px" }, children: "Make time for what matters" }),
                  /* @__PURE__ */ a3("h2", { children: [
                    "A smarter week",
                    /* @__PURE__ */ a3("br", {}),
                    "starts here."
                  ] }),
                  /* @__PURE__ */ a3("p", { class: "g-subtitle", children: "Turn your available study hours into a focused plan for your course." }),
                  /* @__PURE__ */ a3("div", { class: "g-gradient-art", children: [
                    /* @__PURE__ */ a3("i", {}),
                    /* @__PURE__ */ a3("i", {}),
                    /* @__PURE__ */ a3("i", {}),
                    /* @__PURE__ */ a3("i", {}),
                    /* @__PURE__ */ a3("i", {})
                  ] }),
                  /* @__PURE__ */ a3("button", { class: "g-primary", style: { marginTop: "17px", width: "fit-content" }, onClick: () => {
                    setTab("coursework");
                  }, children: [
                    "Plan my study time ",
                    /* @__PURE__ */ a3(Icon, { name: "arrow", size: 14 })
                  ] })
                ] })
              ] }),
              allIssues.length > 0 && /* @__PURE__ */ a3("div", { class: "g-bottom-note", children: [
                /* @__PURE__ */ a3(Icon, { name: "shield", size: 13 }),
                /* @__PURE__ */ a3("span", { children: [
                  "Some sections need attention. ",
                  /* @__PURE__ */ a3("button", { class: "g-link-btn", style: { display: "inline", fontSize: "10px" }, onClick: () => setTab("settings"), children: "View sync details" })
                ] })
              ] })
            ] }),
            tab === "coursework" && /* @__PURE__ */ a3("div", { class: "g-stack", children: [
              /* @__PURE__ */ a3("div", { children: [
                /* @__PURE__ */ a3("div", { class: "g-eyebrow", children: "One thing at a time" }),
                /* @__PURE__ */ a3("h1", { class: "g-title", children: [
                  "Your next ",
                  /* @__PURE__ */ a3("span", { class: "g-accent", children: "move." })
                ] }),
                /* @__PURE__ */ a3("p", { class: "g-subtitle", children: "The work ahead, the grade behind it, and a plan to get there." })
              ] }),
              coursePicker,
              active ? /* @__PURE__ */ a3(M, { children: [
                /* @__PURE__ */ a3("div", { class: "g-grade-card", children: [
                  /* @__PURE__ */ a3("div", { class: "g-grade-ring", style: { "--grade": Math.min(100, Math.max(0, active.currentScore ?? 0)) }, children: /* @__PURE__ */ a3("div", { children: [
                    /* @__PURE__ */ a3("strong", { children: score(active.currentScore) }),
                    /* @__PURE__ */ a3("small", { children: "Current grade" })
                  ] }) }),
                  /* @__PURE__ */ a3("div", { class: "g-grade-info", children: [
                    /* @__PURE__ */ a3("h2", { children: active.code }),
                    /* @__PURE__ */ a3("p", { children: [
                      active.input.course.applyGroupWeights ? "Weighted assignment groups" : "Total points grading",
                      /* @__PURE__ */ a3("br", {}),
                      active.assignments.length,
                      " assignments in Canvas"
                    ] }),
                    gradeMatches ? /* @__PURE__ */ a3("span", { children: [
                      /* @__PURE__ */ a3(Icon, { name: "check", size: 11 }),
                      "Grade model matches Canvas"
                    ] }) : /* @__PURE__ */ a3("span", { children: [
                      /* @__PURE__ */ a3(Icon, { name: "shield", size: 11 }),
                      "Official Canvas total"
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ a3("section", { children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("h2", { children: "Coursework" }),
                    /* @__PURE__ */ a3("button", { class: "g-link-btn", onClick: () => exportCalendar(tasks.filter((t3) => t3.course.id === active.id && pending(t3.assignment) && dueDate(t3.assignment) >= Date.now()), snapshot.origin), title: "Download upcoming assignment deadlines", children: [
                      /* @__PURE__ */ a3(Icon, { name: "download", size: 13 }),
                      "Calendar"
                    ] })
                  ] }),
                  /* @__PURE__ */ a3("div", { class: "g-search", children: [
                    /* @__PURE__ */ a3(Icon, { name: "search", size: 15 }),
                    /* @__PURE__ */ a3("input", { "aria-label": "Search coursework", placeholder: "Find an assignment\u2026", value: query, onInput: (e3) => setQuery(e3.currentTarget.value) })
                  ] }),
                  /* @__PURE__ */ a3("div", { class: "g-chips", style: { margin: "10px 0 14px" }, children: [{ value: "todo", label: "To do" }, { value: "submitted", label: "Submitted" }, { value: "graded", label: "Graded" }, { value: "all", label: "All work" }].map((f4) => /* @__PURE__ */ a3("button", { class: `g-chip ${filter === f4.value ? "active" : ""}`, "aria-pressed": filter === f4.value, onClick: () => setFilter(f4.value), children: f4.label }, f4.value)) }),
                  /* @__PURE__ */ a3("div", { class: "g-card", children: activeTasks.length ? activeTasks.map((task) => /* @__PURE__ */ a3(TaskRow, { task }, task.assignment.id)) : /* @__PURE__ */ a3(Empty, { title: "Nothing in this view", children: "Try a different filter or search to find your coursework." }) })
                ] }),
                simAssignment && /* @__PURE__ */ a3("section", { class: "g-card", children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("h2", { children: "What if you scored\u2026" }),
                    /* @__PURE__ */ a3("span", { class: "g-label-count", children: "SIMULATOR" })
                  ] }),
                  /* @__PURE__ */ a3("label", { class: "g-field-label", for: "g-whatif-assignment", children: "Assignment" }),
                  /* @__PURE__ */ a3("select", { id: "g-whatif-assignment", "aria-label": "Assignment to simulate", class: "g-select", value: simAssignment.id, onChange: (e3) => setAssignmentId(e3.currentTarget.value), children: active.assignments.filter((a4) => a4.pointsPossible > 0).map((a4) => /* @__PURE__ */ a3("option", { value: a4.id, children: a4.name }, a4.id)) }),
                  /* @__PURE__ */ a3("div", { class: "g-title-row", style: { marginTop: "16px" }, children: [
                    /* @__PURE__ */ a3("span", { class: "g-small", children: "Hypothetical assignment score" }),
                    /* @__PURE__ */ a3("strong", { style: { fontSize: "24px", color: "#2855e8", letterSpacing: "-.8px" }, children: [
                      whatIf,
                      "%"
                    ] })
                  ] }),
                  /* @__PURE__ */ a3("input", { class: "g-range", "aria-label": "What-if score percentage", type: "range", min: "0", max: "100", step: "1", value: whatIf, onInput: (e3) => setWhatIf(Number(e3.currentTarget.value)) }),
                  /* @__PURE__ */ a3("div", { class: "g-legend", children: [
                    /* @__PURE__ */ a3("span", { children: "0%" }),
                    /* @__PURE__ */ a3("span", { children: "50%" }),
                    /* @__PURE__ */ a3("span", { children: "100%" })
                  ] }),
                  /* @__PURE__ */ a3("div", { class: "g-whatif-result", children: [
                    /* @__PURE__ */ a3("div", { children: [
                      /* @__PURE__ */ a3("strong", { children: score(computed) }),
                      /* @__PURE__ */ a3("small", { children: "Model current grade" })
                    ] }),
                    /* @__PURE__ */ a3("div", { style: { background: "#e8f5ed" }, children: [
                      /* @__PURE__ */ a3("strong", { style: { color: "#187352" }, children: score(simulated) }),
                      /* @__PURE__ */ a3("small", { children: "With this assignment score" })
                    ] })
                  ] }),
                  /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "10px" }, children: "A local calculation using visible scores and Canvas group rules. Hidden grades and extra-credit rules may differ. Nothing is saved to Canvas." }),
                  plain2(simAssignment.descriptionHtml) && /* @__PURE__ */ a3("details", { style: { marginTop: "13px" }, children: [
                    /* @__PURE__ */ a3("summary", { style: { cursor: "pointer", fontSize: "11px", fontWeight: 700 }, children: "Assignment brief" }),
                    /* @__PURE__ */ a3("p", { class: "g-assignment-description", children: plain2(simAssignment.descriptionHtml) }),
                    /* @__PURE__ */ a3("a", { class: "g-course-link", href: safeLink(simAssignment.htmlUrl), style: { marginTop: "10px" }, children: [
                      "Open assignment in Canvas ",
                      /* @__PURE__ */ a3(Icon, { name: "arrow", size: 12 })
                    ] })
                  ] })
                ] }),
                simAssignment && /* @__PURE__ */ a3(AssignmentFeedback, { assignment: simAssignment }),
                /* @__PURE__ */ a3("section", { class: "g-card g-plan", children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("div", { children: [
                      /* @__PURE__ */ a3("div", { class: "g-eyebrow", style: { color: "#2855e8", marginBottom: "7px" }, children: "A plan with purpose" }),
                      /* @__PURE__ */ a3("h2", { children: "Make your hours count." })
                    ] }),
                    /* @__PURE__ */ a3(Icon, { name: "bolt", size: 26 })
                  ] }),
                  /* @__PURE__ */ a3("p", { class: "g-subtitle", style: { maxWidth: "100%" }, children: [
                    "A suggested allocation for ",
                    active.code,
                    ", based on upcoming work and the grade model."
                  ] }),
                  /* @__PURE__ */ a3("div", { class: "g-plan-controls", children: [
                    /* @__PURE__ */ a3("label", { class: "g-hours", children: [
                      /* @__PURE__ */ a3("input", { "aria-label": "Study hours available", type: "number", min: ".5", max: "30", step: ".5", value: hours, onChange: (e3) => setHours(Math.max(0.5, Math.min(30, Number(e3.currentTarget.value) || 0.5))) }),
                      "hours"
                    ] }),
                    /* @__PURE__ */ a3("button", { class: "g-primary", onClick: buildPlan, disabled: planning, children: planning ? /* @__PURE__ */ a3(M, { children: [
                      /* @__PURE__ */ a3(Icon, { name: "refresh", size: 14, className: "g-spinner" }),
                      "Planning\u2026"
                    ] }) : /* @__PURE__ */ a3(M, { children: [
                      "Build my study plan ",
                      /* @__PURE__ */ a3(Icon, { name: "arrow", size: 13 })
                    ] }) })
                  ] }),
                  planError && /* @__PURE__ */ a3("p", { class: "g-notice", role: "alert", style: { marginTop: "12px" }, children: planError }),
                  plan && /* @__PURE__ */ a3("div", { class: "g-plan-result", "aria-live": "polite", children: [
                    plan.recommendations.length ? plan.recommendations.map((rec) => /* @__PURE__ */ a3("div", { class: "g-task", children: [
                      /* @__PURE__ */ a3("div", { class: "g-task-marker", children: /* @__PURE__ */ a3(Icon, { name: "clock", size: 14 }) }),
                      /* @__PURE__ */ a3("div", { class: "g-task-main", children: [
                        /* @__PURE__ */ a3("strong", { children: rec.assignmentName }),
                        /* @__PURE__ */ a3("p", { class: "g-small", children: "Suggested focus block" })
                      ] }),
                      /* @__PURE__ */ a3("span", { class: "g-due normal", children: [
                        rec.allocatedHours.toFixed(1),
                        " hrs"
                      ] })
                    ] }, rec.assignmentId)) : /* @__PURE__ */ a3("p", { class: "g-small", children: "No eligible upcoming work to allocate. You may be all caught up." }),
                    /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "12px" }, children: [
                      plan.allocatedHours.toFixed(1),
                      " of ",
                      hours,
                      " hours allocated. Effort curves are assumptions, not a promise of a score or grade."
                    ] })
                  ] })
                ] })
              ] }) : /* @__PURE__ */ a3(Empty, { title: "No courses to show", children: "Active student courses will appear after a successful sync." })
            ] }),
            tab === "resources" && /* @__PURE__ */ a3("div", { class: "g-stack", children: [
              /* @__PURE__ */ a3("div", { children: [
                /* @__PURE__ */ a3("div", { class: "g-eyebrow", children: "Less searching. More learning." }),
                /* @__PURE__ */ a3("h1", { class: "g-title", children: [
                  "Find your ",
                  /* @__PURE__ */ a3("span", { class: "g-accent", children: "flow." })
                ] }),
                /* @__PURE__ */ a3("p", { class: "g-subtitle", children: "Your course materials and updates, one click away." })
              ] }),
              coursePicker,
              active && /* @__PURE__ */ a3(M, { children: [
                /* @__PURE__ */ a3("div", { class: "g-search", children: [
                  /* @__PURE__ */ a3(Icon, { name: "search", size: 15 }),
                  /* @__PURE__ */ a3("input", { "aria-label": "Search resources", placeholder: "Search your course materials\u2026", value: resourceQuery, onInput: (e3) => setResourceQuery(e3.currentTarget.value) })
                ] }),
                /* @__PURE__ */ a3("div", { class: "g-chips", children: [{ id: "all", label: "Everything" }, { id: "module", label: "Modules" }, { id: "page", label: "Pages" }, { id: "file", label: "Files" }].map((f4) => /* @__PURE__ */ a3("button", { class: `g-chip ${resourceFilter === f4.id ? "active" : ""}`, "aria-pressed": resourceFilter === f4.id, onClick: () => setResourceFilter(f4.id), children: f4.label })) }),
                /* @__PURE__ */ a3("section", { class: "g-card", children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("h2", { children: "Course library" }),
                    /* @__PURE__ */ a3("span", { class: "g-label-count", children: [
                      active.resources.length,
                      " ITEMS"
                    ] })
                  ] }),
                  active.resources.filter((r3) => (resourceFilter === "all" || r3.type === resourceFilter) && r3.title.toLowerCase().includes(resourceQuery.toLowerCase())).map((r3) => /* @__PURE__ */ a3("a", { class: "g-resource", href: safeLink(r3.url), children: [
                    /* @__PURE__ */ a3("span", { class: "g-resource-icon", children: /* @__PURE__ */ a3(Icon, { name: r3.type === "module" ? "layers" : r3.type === "file" ? "file" : "book", size: 17 }) }),
                    /* @__PURE__ */ a3("span", { children: [
                      /* @__PURE__ */ a3("strong", { children: r3.title }),
                      /* @__PURE__ */ a3("small", { children: r3.type })
                    ] }),
                    /* @__PURE__ */ a3(Icon, { name: "chevron", size: 14 })
                  ] }, `${r3.type}-${r3.id}`)),
                  !active.resources.filter((r3) => (resourceFilter === "all" || r3.type === resourceFilter) && r3.title.toLowerCase().includes(resourceQuery.toLowerCase())).length && /* @__PURE__ */ a3(Empty, { title: "No matching materials", children: "Try another search. Some materials may only be available through your course's Modules page." })
                ] }),
                /* @__PURE__ */ a3("section", { class: "g-card", children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("h2", { children: "Course updates" }),
                    /* @__PURE__ */ a3(Icon, { name: "calendar", size: 16 })
                  ] }),
                  active.announcements.length ? active.announcements.slice(0, 10).map((a4) => /* @__PURE__ */ a3("details", { class: "g-announcement", children: [
                    /* @__PURE__ */ a3("summary", { children: a4.title }),
                    /* @__PURE__ */ a3("p", { children: plain2(a4.bodyHtml) }),
                    a4.postedAt && /* @__PURE__ */ a3("div", { class: "g-small", style: { marginTop: "6px" }, children: new Date(a4.postedAt).toLocaleDateString() }),
                    /* @__PURE__ */ a3("a", { href: safeLink(a4.url), children: "Read in Canvas \u2192" })
                  ] }, a4.id)) : /* @__PURE__ */ a3("p", { class: "g-small", children: "No announcements returned for this course." })
                ] }),
                active.syllabusHtml && /* @__PURE__ */ a3("section", { class: "g-card", children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("h2", { children: "Syllabus" }),
                    /* @__PURE__ */ a3("a", { class: "g-course-link", href: `${safeLink(active.url)}/assignments/syllabus`, children: [
                      "Open ",
                      /* @__PURE__ */ a3(Icon, { name: "arrow", size: 12 })
                    ] })
                  ] }),
                  /* @__PURE__ */ a3("p", { class: "g-syllabus", children: plain2(active.syllabusHtml) })
                ] }),
                /* @__PURE__ */ a3(MaterialAccess, { courses: [active], compact: true }),
                active.issues.length > 0 && /* @__PURE__ */ a3("div", { class: "g-notice", children: [
                  /* @__PURE__ */ a3(Icon, { name: "shield", size: 16 }),
                  /* @__PURE__ */ a3("span", { children: "Some sections could not finish syncing. Available materials are listed above; see sync details in Settings." })
                ] })
              ] })
            ] }),
            tab === "settings" && /* @__PURE__ */ a3("div", { class: "g-stack", children: [
              /* @__PURE__ */ a3("div", { children: [
                /* @__PURE__ */ a3("div", { class: "g-eyebrow", children: "Built around you" }),
                /* @__PURE__ */ a3("h1", { class: "g-title", children: [
                  "Your ",
                  /* @__PURE__ */ a3("span", { class: "g-accent", children: "workspace." })
                ] }),
                /* @__PURE__ */ a3("p", { class: "g-subtitle", children: "A clear view of your connection and preferences." })
              ] }),
              /* @__PURE__ */ a3("section", { class: "g-card", children: [
                /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                  /* @__PURE__ */ a3("h2", { children: "Connected account" }),
                  /* @__PURE__ */ a3("div", { class: "g-user", children: initials(snapshot.user.name) })
                ] }),
                /* @__PURE__ */ a3("div", { class: "g-setting-row", children: [
                  /* @__PURE__ */ a3("span", { children: "Signed in as" }),
                  /* @__PURE__ */ a3("strong", { children: snapshot.user.name })
                ] }),
                /* @__PURE__ */ a3("div", { class: "g-setting-row", children: [
                  /* @__PURE__ */ a3("span", { children: "Canvas" }),
                  /* @__PURE__ */ a3("strong", { children: new URL(snapshot.origin).hostname })
                ] }),
                /* @__PURE__ */ a3("div", { class: "g-setting-row", children: [
                  /* @__PURE__ */ a3("span", { children: "Last updated" }),
                  /* @__PURE__ */ a3("strong", { children: new Date(snapshot.syncedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) })
                ] }),
                /* @__PURE__ */ a3("div", { class: "g-setting-row", children: [
                  /* @__PURE__ */ a3("span", { children: "Data source" }),
                  /* @__PURE__ */ a3("strong", { children: preview ? "Sample preview data" : "Your signed-in Canvas session" })
                ] }),
                /* @__PURE__ */ a3("button", { class: "g-secondary", style: { marginTop: "14px", width: "100%" }, onClick: onRefresh, disabled: loading, children: [
                  /* @__PURE__ */ a3(Icon, { name: "refresh", size: 14 }),
                  "Refresh now"
                ] })
              ] }),
              /* @__PURE__ */ a3("div", { class: "g-notice success", children: [
                /* @__PURE__ */ a3(Icon, { name: "shield", size: 18 }),
                /* @__PURE__ */ a3("span", { children: [
                  /* @__PURE__ */ a3("strong", { children: "Your account stays yours." }),
                  /* @__PURE__ */ a3("br", {}),
                  "GRADIENT reads your student courses in this tab. When you ask the assistant, selected coursework goes to your local AI service. Web research sends topic searches to public search services. Canvas access stays read-only."
                ] })
              ] }),
              /* @__PURE__ */ a3("section", { class: "g-card g-credits", children: [
                /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                  /* @__PURE__ */ a3("h2", { children: "Course credit hours" }),
                  /* @__PURE__ */ a3(Icon, { name: "book", size: 16 })
                ] }),
                /* @__PURE__ */ a3("p", { class: "g-small", style: { marginBottom: "10px" }, children: "Canvas doesn't provide credit hours. Set them here for planning; each course defaults to 3." }),
                courses.map((c3) => /* @__PURE__ */ a3("label", { children: [
                  /* @__PURE__ */ a3("span", { children: c3.code }),
                  /* @__PURE__ */ a3("input", { class: "g-credit", "aria-label": `Credit hours for ${c3.code}`, type: "number", min: ".5", max: "30", step: ".5", value: credits[c3.id] ?? 3, onChange: (e3) => saveCredit(c3.id, Number(e3.currentTarget.value)) })
                ] }, c3.id)),
                creditError && /* @__PURE__ */ a3("p", { class: "g-notice", role: "alert", children: creditError })
              ] }),
              /* @__PURE__ */ a3(DeadlineTracker, { snapshot, preview }),
              /* @__PURE__ */ a3(MaterialAccess, { courses }),
              allIssues.length > 0 && /* @__PURE__ */ a3("details", { class: "g-issue-details", children: [
                /* @__PURE__ */ a3("summary", { children: [
                  "Sync issues \xB7 ",
                  allIssues.length,
                  " need attention"
                ] }),
                /* @__PURE__ */ a3("ul", { children: allIssues.map((issue, i3) => /* @__PURE__ */ a3("li", { children: [
                  /* @__PURE__ */ a3("strong", { children: [
                    courses.find((c3) => c3.id === issue.courseId)?.code ?? "Canvas",
                    " \xB7 ",
                    issue.section,
                    ":"
                  ] }),
                  " ",
                  issue.message
                ] }, i3)) })
              ] }),
              /* @__PURE__ */ a3("p", { class: "g-small", children: "GRADIENT respects your existing Canvas permissions. Unpublished, locked, and instructor-only materials remain unavailable. Course contents stay in memory for this tab. Preferences and enabled reminder metadata are saved locally. Completed AI jobs expire from local service memory after 30 minutes." })
            ] })
          ] }),
          assistantSnapshot.current && (assistantOpened || tab === "assistant") && /* @__PURE__ */ a3("div", { hidden: tab !== "assistant" || !snapshot, children: /* @__PURE__ */ a3(AssistantView, { snapshot: assistantSnapshot.current, preview, initialCourseId: selectedCourseId || initialCourseId, initialAssignmentId }, `${assistantSnapshot.current.origin}|${assistantSnapshot.current.user.id}`) }, "local-assistant")
        ] }),
        /* @__PURE__ */ a3("footer", { class: "g-footer", children: [
          /* @__PURE__ */ a3("span", { children: [
            /* @__PURE__ */ a3(Icon, { name: "shield", size: 11 }),
            preview ? "Preview environment" : "Read-only \xB7 In your Canvas tab"
          ] }),
          /* @__PURE__ */ a3("span", { children: [
            snapshot?.user.shortName || "Made for your next step",
            /* @__PURE__ */ a3("span", { class: "g-user", children: snapshot ? initials(snapshot.user.name) : "G" })
          ] })
        ] })
      ] })
    ] });
  }

  // extension/ui/CanvasApp.tsx
  function CanvasApp({ initialUrl }) {
    const [snapshot, setSnapshot] = d2(null);
    const [loading, setLoading] = d2(true);
    const [error, setError] = d2(null);
    const [progress, setProgress] = d2("Connecting to your Canvas account\u2026");
    const activeRequest = T2(null);
    const courseId = new URL(initialUrl).pathname.match(/^\/courses\/(\d+)/)?.[1];
    const assignmentId = new URL(initialUrl).pathname.match(/^\/courses\/\d+\/assignments\/(\d+)/)?.[1];
    const refresh = b(() => {
      activeRequest.current?.abort();
      const controller = new AbortController();
      activeRequest.current = controller;
      setLoading(true);
      setSnapshot(null);
      setError(null);
      loadCanvasSnapshot({ courseId, signal: controller.signal, onProgress: (message2) => {
        if (!controller.signal.aborted) setProgress(message2);
      } }).then((result) => {
        if (!controller.signal.aborted) {
          setSnapshot(result);
          void syncTrackedDeadlines(result).catch(() => {
          });
        }
      }).catch((reason) => {
        if (!controller.signal.aborted) {
          setSnapshot(null);
          setError(reason instanceof Error ? reason.message : "Canvas could not be reached. Sign in and try again.");
        }
      }).finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    }, [courseId]);
    A(() => {
      refresh();
      return () => activeRequest.current?.abort();
    }, [refresh]);
    return /* @__PURE__ */ a3(
      Workspace,
      {
        snapshot,
        loading,
        error,
        progress,
        onRefresh: refresh,
        initialCourseId: courseId,
        initialAssignmentId: assignmentId
      }
    );
  }

  // extension/content.ts
  function matchesCanvasHost(hostname, pattern) {
    if (pattern.startsWith("*.")) {
      const suffix = pattern.slice(2).toLowerCase();
      return hostname === suffix || hostname.endsWith(`.${suffix}`);
    }
    return hostname === pattern.toLowerCase();
  }
  async function initPanel() {
    if (window.top !== window.self) return { injected: false, reason: "Top-level Canvas pages only" };
    if (!shouldRunOnPage(window.location.href, document)) {
      return { injected: false, reason: "Assessment page or unsupported Canvas view" };
    }
    const options = await loadOptions();
    if (!options.canvasHosts.some((host2) => matchesCanvasHost(window.location.hostname, host2))) {
      return { injected: false, reason: "This host is not configured as Canvas" };
    }
    if (!shouldRunOnPage(window.location.href, document)) return { injected: false, reason: "Canvas navigated to an assessment" };
    if (document.getElementById("gradient-panel-host")) return { injected: true, reason: "Already mounted" };
    const host = document.createElement("div");
    host.id = "gradient-panel-host";
    host.style.cssText = "all:initial;position:fixed;inset:0 0 auto auto;width:0;height:0;z-index:2147483646;";
    const shadow = host.attachShadow({ mode: "open" });
    document.body.appendChild(host);
    K(k(CanvasApp, { initialUrl: window.location.href }), shadow);
    return { injected: true, reason: "Connected Canvas workspace mounted" };
  }
  var lastUrl = "";
  var mounting = false;
  async function reconcilePage() {
    if (mounting) return;
    const host = document.getElementById("gradient-panel-host");
    if (!shouldRunOnPage(window.location.href, document)) {
      if (host?.shadowRoot) K(null, host.shadowRoot);
      host?.remove();
      lastUrl = "";
      return;
    }
    if (host && lastUrl === window.location.href) return;
    if (host?.shadowRoot) {
      K(k(CanvasApp, { initialUrl: window.location.href }), host.shadowRoot);
      lastUrl = window.location.href;
      return;
    }
    mounting = true;
    try {
      const result = await initPanel();
      if (result.injected) lastUrl = window.location.href;
    } finally {
      mounting = false;
    }
  }
  if (typeof window !== "undefined" && typeof document !== "undefined") {
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => void reconcilePage(), { once: true });
    else void reconcilePage();
    window.setInterval(() => void reconcilePage(), 1e3);
    window.addEventListener("popstate", () => void reconcilePage());
    if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
      chrome.runtime.onMessage.addListener((message2) => {
        if (message2?.type === "GRADIENT_TOGGLE") window.dispatchEvent(new Event("gradient:toggle"));
      });
    }
  }
})();
