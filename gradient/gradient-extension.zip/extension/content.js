"use strict";
(() => {
  // node_modules/preact/dist/preact.mjs
  var n;
  var t;
  var r;
  var i;
  var u;
  var f;
  var e;
  var o;
  var l;
  var c;
  var a;
  var s;
  var h = Symbol.for("pv");
  var p = {};
  var v = [];
  var y = /^m(i|n|o|s|text|space)$/;
  var w = Array.isArray;
  var d = v.slice;
  var _ = Object.assign;
  function g(n2) {
    n2 && n2.parentNode && n2.remove();
  }
  function k(n2, t3, r3) {
    var i3, u4, f4, e3 = {}, o4 = arguments.length;
    for (f4 in t3) "key" == f4 ? i3 = t3[f4] : "ref" == f4 && "function" != typeof n2 ? u4 = t3[f4] : e3[f4] = t3[f4];
    return o4 > 2 && (e3.children = o4 > 3 ? d.call(arguments, 2) : r3), m(n2, e3, i3, u4, null);
  }
  function m(r3, i3, u4, f4, e3) {
    var o4 = { type: r3, props: i3, key: u4, ref: f4, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: h, __v: e3 || ++t, __i: -1, __u: 0 };
    return !e3 && n.vnode && n.vnode(o4), o4;
  }
  function M(n2) {
    return n2.children;
  }
  function x(n2, t3) {
    this.props = n2, this.context = t3, this.__g = 0;
  }
  function S(n2, t3) {
    if (null == t3) return n2.__ && S(n2.__, n2.__i + 1);
    for (var r3; t3 < n2.__k.length; t3++) if ((r3 = n2.__k[t3]) && r3.__e) return r3.__e;
    return "function" != typeof n2.type || n2.props.__P ? null : S(n2);
  }
  function C(n2) {
    if ((n2 = n2.__) && n2.__c && !n2.props.__P) return n2.__e = null, n2.__k.some(function(t3) {
      return t3 && (n2.__e = t3.__e);
    }), C(n2);
  }
  function j(t3) {
    (8 & t3.__g || (t3.__g |= 8, i.push(t3), f++)) && u == n.debounceRendering || ((u = n.debounceRendering) || queueMicrotask)(L);
  }
  function L() {
    var t3, r3, o4, l3, c3, a4, s3, p3, v3;
    try {
      for (r3 = 1; i.length; ) i.length > r3 && i.sort(e), t3 = i.shift(), r3 = i.length, 8 & t3.__g && (l3 = void 0, c3 = void 0, a4 = (c3 = (o4 = t3).__v).__e, s3 = [], p3 = [], (v3 = o4.__P) && ((l3 = _({ constructor: h }, c3)).__v = c3.__v + 1, n.vnode && n.vnode(l3), V(v3, l3, c3, o4.__n, v3.namespaceURI, 32 & c3.__u ? [a4] : null, s3, a4 || S(c3), 32 & c3.__u, p3), l3.__v = c3.__v, l3.__.__k[l3.__i] = l3, D(s3, l3, p3), c3.__ = c3.__e = null, l3.__e != a4 && C(l3)));
    } finally {
      (f = i.length) && (u || queueMicrotask)(L);
    }
  }
  function H(n2, t3, r3, i3, u4, f4, e3, o4, l3, c3, a4) {
    var s3, h3, y3, w3, d3, _3, g3 = i3.__k || v, k3 = t3.length;
    for (l3 = I(r3, t3, g3, l3, k3), s3 = 0; s3 < k3; s3++) null != (y3 = r3.__k[s3]) && (h3 = ~y3.__i && g3[y3.__i] || p, y3.__i = s3, _3 = V(n2, y3, h3, u4, f4, e3, o4, l3, c3, a4), w3 = y3.__e, (h3.ref != y3.ref || 8 & h3.__u) && (h3.ref && F(h3.ref, null, y3, h3), y3.ref && a4.push(y3.ref, y3.__c || w3, y3)), d3 = d3 || w3, 4 & y3.__u ? (l3 = q(y3, l3, n2, !h3.__v), h3.__e && (h3.__e = null)) : "function" == typeof y3.type && void 0 !== _3 ? l3 = _3 : w3 && (l3 = w3.nextSibling), y3.__u &= -21);
    return r3.__e = d3, l3;
  }
  function I(n2, t3, r3, i3, u4) {
    var f4, e3, o4, l3, c3, a4, s3, p3, v3, y3 = r3.length, d3 = y3, _3 = 0, g3 = 0, k3 = n2.__k = Array(u4);
    for (f4 = 0; f4 < u4; f4++) null != (e3 = t3[f4]) && "boolean" != typeof e3 && "function" != typeof e3 ? ("object" != typeof e3 || e3.constructor === String ? e3 = k3[f4] = m(null, e3) : w(e3) ? e3 = k3[f4] = m(M, { children: e3 }) : e3.constructor === h && e3.__b ? e3 = k3[f4] = m(e3.type, e3.props, e3.key, e3.ref, e3.__v) : k3[f4] = e3, l3 = f4 + _3, e3.__ = n2, e3.__b = n2.__b + 1, o4 = null, ~(c3 = e3.__i = O(e3, r3, l3, d3)) && (d3--, (o4 = r3[c3]) && (o4.__u |= 2)), o4 && o4.__v ? (e3.__u |= 16, c3 == l3 - 1 ? _3-- : c3 == l3 + 1 ? _3++ : c3 != l3 && (c3 > l3 ? _3-- : _3++, g3 = 1)) : (~c3 || (u4 > y3 ? _3-- : u4 < y3 && _3++), "function" != typeof e3.type && (e3.__u |= 4))) : k3[f4] = null;
    if (g3) {
      for (a4 = [], s3 = [], f4 = 0; f4 < u4; f4++) if ((e3 = k3[f4]) && 16 & e3.__u) {
        for (_3 = 0, p3 = a4.length; _3 < p3; ) a4[v3 = _3 + p3 >> 1] < e3.__i ? _3 = v3 + 1 : p3 = v3;
        a4[_3] = e3.__i, s3[f4] = _3 + 1;
      }
      for (_3 = a4.length; f4--; ) s3[f4] && (s3[f4] == _3 ? _3-- : k3[f4].__u |= 4);
    }
    if (d3) for (f4 = 0; f4 < y3; f4++) !(o4 = r3[f4]) || 2 & o4.__u || (o4.__e == i3 && (i3 = S(o4)), G(o4, o4));
    return i3;
  }
  function q(n2, t3, r3, i3) {
    var u4, f4, e3, o4;
    if ("function" == typeof n2.type) {
      if (n2.props.__P) return t3;
      if (u4 = n2.__k) for (f4 = 0; f4 < u4.length; f4++) u4[f4] && (u4[f4].__ = n2, t3 = q(u4[f4], t3, r3, false));
      return t3;
    }
    for (t3 && !t3.parentNode && (t3 = S(n2)) && !t3.parentNode && (t3 = null), e3 = n2.__e, o4 = t3; o4 && 8 == o4.nodeType; ) o4 = o4.nextSibling;
    for (e3 != o4 && (!i3 && r3.moveBefore && e3.parentNode ? r3.moveBefore(e3, t3) : r3.insertBefore(e3, t3 || null)), t3 = e3; (t3 = t3 && t3.nextSibling) && 8 == t3.nodeType && !t3.data.startsWith("$s"); ) ;
    return t3;
  }
  function O(n2, t3, r3, i3) {
    var u4, f4 = n2.key, e3 = n2.type, o4 = t3[r3], l3 = o4 && !(2 & o4.__u);
    if (null === o4 && null == f4 || l3 && f4 == o4.key && e3 == o4.type) return r3;
    if (i3 > (l3 ? 1 : 0)) {
      for (u4 = r3 - 1; u4 >= 0; u4--) if ((o4 = t3[u4]) && !(2 & o4.__u) && f4 == o4.key && e3 == o4.type) return u4;
      for (u4 = r3 + 1; u4 < t3.length; u4++) if ((o4 = t3[u4]) && !(2 & o4.__u) && f4 == o4.key && e3 == o4.type) return u4;
    }
    return -1;
  }
  function P(n2, t3, r3) {
    null == r3 && (r3 = ""), "-" == t3[0] ? n2.setProperty(t3, r3) : n2[t3] = r3;
  }
  function T(n2, t3, r3, i3, u4) {
    var f4, e3;
    if ("style" == t3) if ("string" == typeof r3) n2.style.cssText = r3;
    else {
      if ("string" == typeof i3 && (n2.style.cssText = i3 = ""), i3) for (t3 in i3) r3 && t3 in r3 || P(n2.style, t3);
      if (r3) for (t3 in r3) i3 && r3[t3] == i3[t3] || P(n2.style, t3, r3[t3]);
    }
    else if ("o" == t3[0] && "n" == t3[1]) (n2.__e || (n2.__e = {}))[t3] = r3, r3 && i3 || (e3 = a[t3] || (a[t3] = N(t3)), (n2.__a || (n2.__a = {}))[t3] = c, f4 = t3 != (t3 = t3.replace(l, "$1")), (t3 = t3.slice(2))[0] < "a" && (t3 = t3.toLowerCase()), r3 ? n2.addEventListener(t3, e3, f4) : n2.removeEventListener(t3, e3, f4));
    else {
      if ("http://www.w3.org/2000/svg" == u4) t3 = t3.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
      else if ("width" != t3 && "height" != t3 && "href" != t3 && "list" != t3 && "form" != t3 && "tabIndex" != t3 && "download" != t3 && "rowSpan" != t3 && "colSpan" != t3 && "role" != t3 && "popover" != t3 && t3 in n2) try {
        return void (n2[t3] = null == r3 ? "" : r3);
      } catch (n3) {
      }
      if ("function" == typeof r3) return;
      null == r3 || false === r3 && "-" != t3[4] ? n2.removeAttribute(t3) : n2.setAttribute(t3, "popover" == t3 && 1 == r3 ? "" : r3);
    }
  }
  function N(t3) {
    return function(r3) {
      var i3 = this.__e;
      if (i3) {
        if (i3 = i3[t3], null == r3[o]) r3[o] = c++;
        else if (r3[o] < this.__a[t3]) return;
        return i3(n.event ? n.event(r3) : r3);
      }
    };
  }
  function V(t3, r3, i3, u4, f4, e3, o4, l3, c3, a4) {
    var s3, p3, y3, d3, k3, b2, m3, $, C3, j2, L2, I2, q2, A2, O2, P2, T4, N2, V2 = r3.type;
    if (r3.constructor !== h) return null;
    128 & i3.__u && (c3 = 32 & i3.__u, s3 = i3.__c.__z) && (r3.__u |= c3, p3 = e3 = [], 8 == s3.nodeType ? l3 = z(s3, e3) : e3.push(s3), l3 = e3[0] || l3), (s3 = n.__b) && s3(r3);
    n: if ("function" == typeof V2) {
      y3 = o4.length;
      try {
        if ($ = r3.props, C3 = (s3 = V2.prototype) && s3.render, j2 = (s3 = V2.contextType) && u4[s3.__c], L2 = s3 ? j2 ? j2.props.value : s3.__ : u4, (d3 = i3.__c) ? (r3.__c = d3, 2 & d3.__g && (d3.__g |= 1)) : (C3 ? r3.__c = d3 = new V2($, L2) : (r3.__c = d3 = new x($, L2), d3.constructor = V2, d3.render = J), j2 && j2.sub(d3), d3.state || (d3.state = {}), d3.__n = u4, d3.__g |= 8, d3.__h = [], d3.__k = []), C3 && (d3.__s || (d3.__s = d3.state), V2.getDerivedStateFromProps && (d3.__s == d3.state && (d3.__s = _({}, d3.__s)), _(d3.__s, V2.getDerivedStateFromProps($, d3.__s)))), k3 = d3.props, b2 = d3.state, d3.__v = r3, i3.__c) {
          if ($ !== k3 && C3 && !V2.getDerivedStateFromProps && d3.componentWillReceiveProps && d3.componentWillReceiveProps($, L2), r3.__v == i3.__v && !(8 & d3.__g) || !(4 & d3.__g) && d3.shouldComponentUpdate && false === d3.shouldComponentUpdate($, d3.__s, L2)) {
            r3.__v != i3.__v && (d3.props = $, d3.state = d3.__s, d3.__g &= -9), r3.__e = i3.__e, r3.__k = i3.__k, r3.__k.some(function(n2) {
              n2 && (n2.__ = r3);
            }), v.push.apply(d3.__h, d3.__k), d3.__k = [], d3.__h.length && o4.push(d3), l3 = S(i3);
            break n;
          }
          d3.componentWillUpdate && d3.componentWillUpdate($, d3.__s, L2), C3 && d3.componentDidUpdate && d3.__h.push(function() {
            d3.componentDidUpdate(k3, b2, m3);
          });
        } else C3 && !V2.getDerivedStateFromProps && d3.componentWillMount && d3.componentWillMount(), C3 && d3.componentDidMount && d3.__h.push(d3.componentDidMount);
        if (d3.context = L2, d3.props = $, d3.__P = t3, d3.__g &= -5, I2 = n.__r, q2 = 0, C3) d3.state = d3.__s, d3.__g &= -9, I2 && I2(r3), s3 = d3.render(d3.props, d3.state, d3.context), v.push.apply(d3.__h, d3.__k), d3.__k = [];
        else do {
          d3.__g &= -9, I2 && I2(r3), s3 = d3.render(d3.props, d3.state, d3.context), d3.state = d3.__s;
        } while (8 & d3.__g && ++q2 < 25);
        d3.state = d3.__s, d3.getChildContext && (u4 = _({}, u4, d3.getChildContext())), C3 && i3.__c && d3.getSnapshotBeforeUpdate && (m3 = d3.getSnapshotBeforeUpdate(k3, b2)), A2 = s3 && s3.type === M && null == s3.key ? s3.props.children : s3, $.__P && (s3 = l3, f4 = (t3 = $.__P).namespaceURI, c3 = e3 = null, i3.props && i3.props.__P != t3 && (i3.__k.some(function(n2) {
          n2 && G(n2, n2);
        }), i3.__k = null), l3 = i3.__k ? S(i3, 0) : null), l3 = H(t3, w(A2) ? A2 : [A2], r3, i3, u4, f4, e3, o4, l3, c3, a4), $.__P && (r3.__e = null, l3 = s3), r3.__u &= -161, p3 && p3.some(g), d3.__h.length && o4.push(d3), 1 & d3.__g && (d3.__g &= -4);
      } catch (t4) {
        if (o4.length = y3, r3.__v = null, c3 || e3) if (t4.then) {
          if (O2 = 0, r3.__u |= 128 | c3, e3) {
            for (~(T4 = e3.indexOf(l3 || void 0)) || (T4 = e3.length); (N2 = e3[T4 - 1]) && 8 == N2.nodeType; ) T4--;
            for (; T4 < e3.length; T4++) if (N2 = e3[T4]) {
              if (e3[T4] = null, 8 == N2.nodeType) {
                if (N2.data.startsWith("$s")) O2++ || (P2 = N2);
                else if (O2 && N2.data.startsWith("/$s") && !--O2) break;
              } else if (!O2) break;
            }
          }
          if (!P2) {
            for (; l3 && 8 == l3.nodeType && l3.nextSibling; ) l3 = l3.nextSibling;
            P2 = l3;
          }
          (s3 = z(P2 = r3.__c.__z || (r3.__c.__z = P2))) ? (r3.__e = P2, l3 = s3) : r3.__e = l3, l3 = l3 && l3.nextSibling;
        } else e3 && e3.some(g);
        else r3.__e = i3.__e;
        r3.__k || (r3.__k = i3.__k || []), t4.then || B(r3), n.__e(t4, r3, i3);
      }
    } else l3 = r3.__e = E(i3.__e, r3, i3, u4, f4, e3, o4, c3, a4, t3);
    return (s3 = n.diffed) && s3(r3), l3;
  }
  function z(n2, t3) {
    if (n2 && 8 == n2.nodeType && n2.data.startsWith("$s")) for (var r3 = 1; n2 = n2.nextSibling; ) {
      if (8 == n2.nodeType) {
        if (n2.data.startsWith("$s")) r3++;
        else if (n2.data.startsWith("/$s") && !--r3) return n2;
      }
      t3 && t3.push(n2);
    }
  }
  function B(n2) {
    n2 && (n2.__c && (n2.__c.__g |= 4), n2.__k && n2.__k.some(B));
  }
  function D(t3, r3, i3) {
    for (var u4 = 0; u4 < i3.length; ) F(i3[u4++], i3[u4++], i3[u4++]);
    n.__c && n.__c(r3, t3), t3.some(function(r4) {
      try {
        t3 = r4.__h, r4.__h = [], t3.some(function(n2) {
          n2.call(r4);
        });
      } catch (t4) {
        n.__e(t4, r4.__v);
      }
    });
  }
  function E(t3, r3, i3, u4, f4, e3, o4, l3, c3, a4) {
    var s3, h3, v3, _3, k3, b2, m3, $, M2, x2 = i3.props || p, C3 = r3.props, j2 = r3.type;
    if ("svg" == j2 ? f4 = "http://www.w3.org/2000/svg" : "math" == j2 ? f4 = "http://www.w3.org/1998/Math/MathML" : f4 || (f4 = "http://www.w3.org/1999/xhtml"), e3) {
      for (s3 = 0; s3 < e3.length; s3++) if ((k3 = e3[s3]) && (j2 ? k3.localName == j2 : 3 == k3.nodeType)) {
        t3 = k3, e3[s3] = null;
        break;
      }
    }
    if (!t3) {
      if ($ = a4.ownerDocument || document, !j2) return $.createTextNode(C3);
      t3 = $.createElementNS(f4, j2, C3.is && C3), l3 && (n.__m && n.__m(r3, e3), l3 = false), e3 = null;
    }
    if (j2) {
      if (a4 = "template" == j2 && t3.content || t3, e3 = "textarea" == j2 && null != C3.defaultValue ? null : e3 && d.call(a4.childNodes), !l3 && e3) for (x2 = {}, s3 = 0; s3 < t3.attributes.length; s3++) x2[(k3 = t3.attributes[s3]).name] = k3.value;
      for (s3 in x2) k3 = x2[s3], "dangerouslySetInnerHTML" == s3 ? v3 = k3 : "children" == s3 || s3 in C3 || "value" == s3 && "defaultValue" in C3 || "checked" == s3 && "defaultChecked" in C3 || T(t3, s3, null, k3, f4);
      for (s3 in M2 = 1 & i3.__u, C3) k3 = C3[s3], "children" == s3 ? _3 = k3 : "dangerouslySetInnerHTML" == s3 ? h3 = k3 : "value" == s3 ? b2 = k3 : "checked" == s3 ? m3 = k3 : l3 && "function" != typeof k3 || !(x2[s3] !== k3 || M2 && null != k3) || T(t3, s3, k3, x2[s3], f4);
      h3 ? (l3 || v3 && (h3.__html == v3.__html || h3.__html == t3.innerHTML) || (t3.innerHTML = h3.__html), r3.__k = []) : (v3 && (t3.textContent = ""), ("foreignObject" == j2 || "http://www.w3.org/1998/Math/MathML" == f4 && y.test(j2)) && (f4 = "http://www.w3.org/1999/xhtml"), H(a4, w(_3) ? _3 : [_3], r3, i3, u4, f4, e3, o4, e3 ? e3[0] : i3.__k && S(i3, 0), l3, c3), e3 && e3.some(g)), l3 && "textarea" != j2 || (s3 = "value", "progress" == j2 && null == b2 ? t3.removeAttribute(s3) : null == b2 || b2 === t3[s3] && ("progress" != j2 || b2) || T(t3, s3, b2, x2[s3], f4), s3 = "checked", null != m3 && m3 != t3[s3] && T(t3, s3, m3, x2[s3], f4));
    } else x2 === C3 || l3 && t3.data == C3 || (t3.data = C3);
    return t3;
  }
  function F(t3, r3, i3, u4) {
    try {
      "function" == typeof t3 ? r3 ? r3.__x = t3(r3) || 1 : u4 && (u4 = u4.__c || u4.__e) && (r3 = u4.__x) && (u4.__x = null, "function" == typeof r3 ? r3() : t3(null)) : t3.current = r3;
    } catch (t4) {
      n.__e(t4, i3);
    }
  }
  function G(t3, r3, i3) {
    var u4, f4, e3, o4;
    if (n.unmount && n.unmount(t3), !(u4 = t3.ref) || u4.current && u4.current != t3.__e || F(u4, null, r3, t3), u4 = t3.__c) {
      if (u4.componentWillUnmount) try {
        u4.componentWillUnmount();
      } catch (t4) {
        n.__e(t4, r3);
      }
      u4.__P = u4.__n = null;
    }
    if (u4 = t3.__k) for (o4 = 0; o4 < u4.length; o4++) u4[o4] && G(u4[o4], r3, "function" != typeof t3.type || i3 && !t3.props.__P);
    !i3 && (u4 = t3.__c) && (u4 = u4.__z) && (f4 = z(u4, e3 = [])) && (u4 == t3.__e && e3.some(g), g(f4), g(u4)), (u4 = t3.__e) && (i3 || g(u4), u4.__e && (u4.__e = null)), t3.__e = t3.__c = t3.__ = null;
  }
  function J(n2, t3, r3) {
    return this.constructor(n2, r3);
  }
  function K(t3, r3) {
    var i3, u4, f4, e3;
    n.__ && n.__(t3, r3), 9 == r3.nodeType && (r3 = r3.documentElement), u4 = (i3 = t3 && 32 & t3.__u) ? null : r3.__k, r3.__k = m(M, { children: [t3] }), f4 = [], e3 = [], V(r3, r3.__k, u4 || p, p, r3.namespaceURI, u4 ? null : r3.firstChild ? d.call(r3.childNodes) : null, f4, u4 ? u4.__e : r3.firstChild, i3, e3), D(f4, r3.__k, e3), r3.__k.props.children = null;
  }
  n = { __e: function(n2, t3, r3, i3) {
    for (var u4, e3, o4; t3 = t3.__; ) if ((u4 = t3.__c) && !(1 & u4.__g)) {
      u4.__g |= 4;
      try {
        if ((o4 = (e3 = u4.constructor) && e3.getDerivedStateFromError) && u4.setState(e3.getDerivedStateFromError(n2)), u4.componentDidCatch && (u4.componentDidCatch(n2, i3 || {}), o4 = 1), o4 && 8 & u4.__g) return void (u4.__g |= 2);
      } catch (t4) {
        n2 = t4;
      }
    }
    throw f = 0, n2;
  } }, t = 0, r = function(n2) {
    return null != n2 && n2.constructor === h;
  }, x.prototype.setState = function(n2, t3) {
    var r3 = this.__s;
    r3 && r3 != this.state || (r3 = this.__s = _({}, this.state)), "function" == typeof n2 && (n2 = n2(_({}, r3), this.props)), n2 && (_(r3, n2), this.__v && (t3 && this.__k.push(t3), j(this)));
  }, x.prototype.forceUpdate = function(n2) {
    this.__v && (this.__g |= 4, n2 && this.__h.push(n2), j(this));
  }, x.prototype.render = M, i = [], f = 0, e = function(n2, t3) {
    return n2.__v.__b - t3.__v.__b;
  }, o = Symbol(), l = /(PointerCapture)$|Capture$/i, c = 0, a = {}, s = 0;

  // extension/safetyGuard.ts
  var DEFAULT_BLOCKED_URL_PATTERNS = [
    // Classic Canvas quiz taking
    /\/courses\/\d+\/quizzes\/\d+\/take(\/.*)?$/i,
    /\/courses\/\d+\/quizzes\/\d+\/take\/questions/i,
    /\/courses\/\d+\/quizzes\/\d+\/submissions/i,
    // Assignment take / in-progress assessment submission
    /\/courses\/\d+\/assignments\/\d+\/take/i,
    // LTI / New Quizzes launches & embed containers
    /\/external_tools\/.*quiz.*/i,
    /\/external_tools\/.*assessment.*/i,
    /canvas\.quiz-lti-iad-prod\.instructure\.com/i,
    /launch_type=assessment/i,
    /launch_type=quiz/i,
    // Remote proctoring & lockdown browser indicators
    /proctorio/i,
    /honorlock/i,
    /respondus/i
  ];
  var DEFAULT_BLOCKED_DOM_SELECTORS = [
    // Active quiz submission forms
    "#submit_quiz_form",
    "form.take_quiz_form",
    "form#take_quiz_form",
    "div.quiz-submission",
    // Active timers & countdown clocks
    "#quiz_timer",
    "#timer_running",
    ".quiz-timer",
    ".quiz-submission-timer",
    '[data-testid="timer-display"]',
    '[aria-label*="time remaining" i]',
    '[aria-label*="quiz timer" i]',
    // Active question containers
    "#questions.quiz-questions",
    "div.display_question.question",
    'div[data-testid="question-content"]',
    // LTI / New Quizzes embed containers
    'iframe#tool_content[src*="quiz"]',
    'iframe[data-testid="lti-frame"][src*="assessment"]',
    'iframe[src*="new_quizzes"]'
  ];
  var DEFAULT_ALLOWED_PATH_PATTERNS = [
    /^https?:\/\/[^/?#]+\/(?:[?#].*)?$/i,
    /\/(?:dashboard|courses)\/?(?:[?#].*)?$/i,
    /\/courses\/\d+\/?$/i,
    /\/courses\/\d+\/grades\/?$/i,
    /\/courses\/\d+\/assignments\/?$/i,
    /\/courses\/\d+\/assignments\/\d+\/?$/i,
    /\/courses\/\d+\/assignments\/syllabus\/?$/i,
    /\/courses\/\d+\/discussion_topics(?:\/\d+)?\/?$/i,
    /\/courses\/\d+\/quizzes\/?$/i,
    /\/courses\/\d+\/quizzes\/\d+\/?$/i,
    // Near-miss: Quiz landing/overview page is SAFE
    /\/courses\/\d+\/quizzes\/\d+\/edit\/?$/i,
    // Near-miss: Quiz edit page is SAFE
    /\/courses\/\d+\/modules\/?.*$/i,
    /\/courses\/\d+\/pages\/?.*$/i,
    /\/courses\/\d+\/announcements\/?.*$/i,
    /\/courses\/\d+\/syllabus\/?$/i,
    /\/courses\/\d+\/files\/?.*$/i,
    /\/courses\/\d+\/calendar_events\/?.*$/i,
    /\/calendar\/?.*$/i
  ];
  var SafetyGuard = class {
    config;
    constructor(customConfig) {
      this.config = {
        blockedUrlPatterns: customConfig?.blockedUrlPatterns ?? DEFAULT_BLOCKED_URL_PATTERNS,
        blockedDomSelectors: customConfig?.blockedDomSelectors ?? DEFAULT_BLOCKED_DOM_SELECTORS,
        allowedPathPatterns: customConfig?.allowedPathPatterns ?? DEFAULT_ALLOWED_PATH_PATTERNS,
        defaultDenyWhenUnsure: customConfig?.defaultDenyWhenUnsure ?? true
      };
    }
    evaluate(url, dom) {
      if (!url || typeof url !== "string") {
        return { allowed: false, blocked: true, reason: "Invalid or missing URL (default deny)" };
      }
      for (const pattern of this.config.blockedUrlPatterns) {
        if (pattern.test(url)) {
          return {
            allowed: false,
            blocked: true,
            reason: `Blocked by URL safety rule: matches assessment pattern '${pattern.source}'`
          };
        }
      }
      if (dom) {
        for (const selector of this.config.blockedDomSelectors) {
          try {
            const elem = dom.querySelector(selector);
            if (elem) {
              return {
                allowed: false,
                blocked: true,
                reason: `Blocked by DOM safety marker: detected active assessment element '${selector}'`
              };
            }
          } catch {
            continue;
          }
        }
      }
      if (this.config.defaultDenyWhenUnsure) {
        const isRecognizedSafe = this.config.allowedPathPatterns.some((pattern) => pattern.test(url));
        if (!isRecognizedSafe) {
          return {
            allowed: false,
            blocked: true,
            reason: `Blocked by fail-closed policy: URL '${url}' is outside recognized safe Canvas course views`
          };
        }
      }
      return {
        allowed: true,
        blocked: false,
        reason: "Safe to inject: allowlisted Canvas course page with zero assessment markers"
      };
    }
    canInject(url, dom) {
      return this.evaluate(url, dom);
    }
  };
  var defaultSafetyGuard = new SafetyGuard();
  function shouldRunOnPage(url, dom, config) {
    const guard = config ? new SafetyGuard(config) : defaultSafetyGuard;
    return guard.evaluate(url, dom).allowed;
  }

  // node_modules/zod/lib/index.mjs
  var util;
  (function(util2) {
    util2.assertEqual = (val) => val;
    function assertIs(_arg) {
    }
    util2.assertIs = assertIs;
    function assertNever(_x) {
      throw new Error();
    }
    util2.assertNever = assertNever;
    util2.arrayToEnum = (items) => {
      const obj = {};
      for (const item of items) {
        obj[item] = item;
      }
      return obj;
    };
    util2.getValidEnumValues = (obj) => {
      const validKeys = util2.objectKeys(obj).filter((k3) => typeof obj[obj[k3]] !== "number");
      const filtered = {};
      for (const k3 of validKeys) {
        filtered[k3] = obj[k3];
      }
      return util2.objectValues(filtered);
    };
    util2.objectValues = (obj) => {
      return util2.objectKeys(obj).map(function(e3) {
        return obj[e3];
      });
    };
    util2.objectKeys = typeof Object.keys === "function" ? (obj) => Object.keys(obj) : (object) => {
      const keys = [];
      for (const key in object) {
        if (Object.prototype.hasOwnProperty.call(object, key)) {
          keys.push(key);
        }
      }
      return keys;
    };
    util2.find = (arr, checker) => {
      for (const item of arr) {
        if (checker(item))
          return item;
      }
      return void 0;
    };
    util2.isInteger = typeof Number.isInteger === "function" ? (val) => Number.isInteger(val) : (val) => typeof val === "number" && isFinite(val) && Math.floor(val) === val;
    function joinValues(array, separator = " | ") {
      return array.map((val) => typeof val === "string" ? `'${val}'` : val).join(separator);
    }
    util2.joinValues = joinValues;
    util2.jsonStringifyReplacer = (_3, value) => {
      if (typeof value === "bigint") {
        return value.toString();
      }
      return value;
    };
  })(util || (util = {}));
  var objectUtil;
  (function(objectUtil2) {
    objectUtil2.mergeShapes = (first, second) => {
      return {
        ...first,
        ...second
        // second overwrites first
      };
    };
  })(objectUtil || (objectUtil = {}));
  var ZodParsedType = util.arrayToEnum([
    "string",
    "nan",
    "number",
    "integer",
    "float",
    "boolean",
    "date",
    "bigint",
    "symbol",
    "function",
    "undefined",
    "null",
    "array",
    "object",
    "unknown",
    "promise",
    "void",
    "never",
    "map",
    "set"
  ]);
  var getParsedType = (data) => {
    const t3 = typeof data;
    switch (t3) {
      case "undefined":
        return ZodParsedType.undefined;
      case "string":
        return ZodParsedType.string;
      case "number":
        return isNaN(data) ? ZodParsedType.nan : ZodParsedType.number;
      case "boolean":
        return ZodParsedType.boolean;
      case "function":
        return ZodParsedType.function;
      case "bigint":
        return ZodParsedType.bigint;
      case "symbol":
        return ZodParsedType.symbol;
      case "object":
        if (Array.isArray(data)) {
          return ZodParsedType.array;
        }
        if (data === null) {
          return ZodParsedType.null;
        }
        if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
          return ZodParsedType.promise;
        }
        if (typeof Map !== "undefined" && data instanceof Map) {
          return ZodParsedType.map;
        }
        if (typeof Set !== "undefined" && data instanceof Set) {
          return ZodParsedType.set;
        }
        if (typeof Date !== "undefined" && data instanceof Date) {
          return ZodParsedType.date;
        }
        return ZodParsedType.object;
      default:
        return ZodParsedType.unknown;
    }
  };
  var ZodIssueCode = util.arrayToEnum([
    "invalid_type",
    "invalid_literal",
    "custom",
    "invalid_union",
    "invalid_union_discriminator",
    "invalid_enum_value",
    "unrecognized_keys",
    "invalid_arguments",
    "invalid_return_type",
    "invalid_date",
    "invalid_string",
    "too_small",
    "too_big",
    "invalid_intersection_types",
    "not_multiple_of",
    "not_finite"
  ]);
  var quotelessJson = (obj) => {
    const json = JSON.stringify(obj, null, 2);
    return json.replace(/"([^"]+)":/g, "$1:");
  };
  var ZodError = class _ZodError extends Error {
    constructor(issues) {
      super();
      this.issues = [];
      this.addIssue = (sub2) => {
        this.issues = [...this.issues, sub2];
      };
      this.addIssues = (subs = []) => {
        this.issues = [...this.issues, ...subs];
      };
      const actualProto = new.target.prototype;
      if (Object.setPrototypeOf) {
        Object.setPrototypeOf(this, actualProto);
      } else {
        this.__proto__ = actualProto;
      }
      this.name = "ZodError";
      this.issues = issues;
    }
    get errors() {
      return this.issues;
    }
    format(_mapper) {
      const mapper = _mapper || function(issue) {
        return issue.message;
      };
      const fieldErrors = { _errors: [] };
      const processError = (error) => {
        for (const issue of error.issues) {
          if (issue.code === "invalid_union") {
            issue.unionErrors.map(processError);
          } else if (issue.code === "invalid_return_type") {
            processError(issue.returnTypeError);
          } else if (issue.code === "invalid_arguments") {
            processError(issue.argumentsError);
          } else if (issue.path.length === 0) {
            fieldErrors._errors.push(mapper(issue));
          } else {
            let curr = fieldErrors;
            let i3 = 0;
            while (i3 < issue.path.length) {
              const el = issue.path[i3];
              const terminal = i3 === issue.path.length - 1;
              if (!terminal) {
                curr[el] = curr[el] || { _errors: [] };
              } else {
                curr[el] = curr[el] || { _errors: [] };
                curr[el]._errors.push(mapper(issue));
              }
              curr = curr[el];
              i3++;
            }
          }
        }
      };
      processError(this);
      return fieldErrors;
    }
    static assert(value) {
      if (!(value instanceof _ZodError)) {
        throw new Error(`Not a ZodError: ${value}`);
      }
    }
    toString() {
      return this.message;
    }
    get message() {
      return JSON.stringify(this.issues, util.jsonStringifyReplacer, 2);
    }
    get isEmpty() {
      return this.issues.length === 0;
    }
    flatten(mapper = (issue) => issue.message) {
      const fieldErrors = {};
      const formErrors = [];
      for (const sub2 of this.issues) {
        if (sub2.path.length > 0) {
          fieldErrors[sub2.path[0]] = fieldErrors[sub2.path[0]] || [];
          fieldErrors[sub2.path[0]].push(mapper(sub2));
        } else {
          formErrors.push(mapper(sub2));
        }
      }
      return { formErrors, fieldErrors };
    }
    get formErrors() {
      return this.flatten();
    }
  };
  ZodError.create = (issues) => {
    const error = new ZodError(issues);
    return error;
  };
  var errorMap = (issue, _ctx) => {
    let message2;
    switch (issue.code) {
      case ZodIssueCode.invalid_type:
        if (issue.received === ZodParsedType.undefined) {
          message2 = "Required";
        } else {
          message2 = `Expected ${issue.expected}, received ${issue.received}`;
        }
        break;
      case ZodIssueCode.invalid_literal:
        message2 = `Invalid literal value, expected ${JSON.stringify(issue.expected, util.jsonStringifyReplacer)}`;
        break;
      case ZodIssueCode.unrecognized_keys:
        message2 = `Unrecognized key(s) in object: ${util.joinValues(issue.keys, ", ")}`;
        break;
      case ZodIssueCode.invalid_union:
        message2 = `Invalid input`;
        break;
      case ZodIssueCode.invalid_union_discriminator:
        message2 = `Invalid discriminator value. Expected ${util.joinValues(issue.options)}`;
        break;
      case ZodIssueCode.invalid_enum_value:
        message2 = `Invalid enum value. Expected ${util.joinValues(issue.options)}, received '${issue.received}'`;
        break;
      case ZodIssueCode.invalid_arguments:
        message2 = `Invalid function arguments`;
        break;
      case ZodIssueCode.invalid_return_type:
        message2 = `Invalid function return type`;
        break;
      case ZodIssueCode.invalid_date:
        message2 = `Invalid date`;
        break;
      case ZodIssueCode.invalid_string:
        if (typeof issue.validation === "object") {
          if ("includes" in issue.validation) {
            message2 = `Invalid input: must include "${issue.validation.includes}"`;
            if (typeof issue.validation.position === "number") {
              message2 = `${message2} at one or more positions greater than or equal to ${issue.validation.position}`;
            }
          } else if ("startsWith" in issue.validation) {
            message2 = `Invalid input: must start with "${issue.validation.startsWith}"`;
          } else if ("endsWith" in issue.validation) {
            message2 = `Invalid input: must end with "${issue.validation.endsWith}"`;
          } else {
            util.assertNever(issue.validation);
          }
        } else if (issue.validation !== "regex") {
          message2 = `Invalid ${issue.validation}`;
        } else {
          message2 = "Invalid";
        }
        break;
      case ZodIssueCode.too_small:
        if (issue.type === "array")
          message2 = `Array must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `more than`} ${issue.minimum} element(s)`;
        else if (issue.type === "string")
          message2 = `String must contain ${issue.exact ? "exactly" : issue.inclusive ? `at least` : `over`} ${issue.minimum} character(s)`;
        else if (issue.type === "number")
          message2 = `Number must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${issue.minimum}`;
        else if (issue.type === "date")
          message2 = `Date must be ${issue.exact ? `exactly equal to ` : issue.inclusive ? `greater than or equal to ` : `greater than `}${new Date(Number(issue.minimum))}`;
        else
          message2 = "Invalid input";
        break;
      case ZodIssueCode.too_big:
        if (issue.type === "array")
          message2 = `Array must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `less than`} ${issue.maximum} element(s)`;
        else if (issue.type === "string")
          message2 = `String must contain ${issue.exact ? `exactly` : issue.inclusive ? `at most` : `under`} ${issue.maximum} character(s)`;
        else if (issue.type === "number")
          message2 = `Number must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "bigint")
          message2 = `BigInt must be ${issue.exact ? `exactly` : issue.inclusive ? `less than or equal to` : `less than`} ${issue.maximum}`;
        else if (issue.type === "date")
          message2 = `Date must be ${issue.exact ? `exactly` : issue.inclusive ? `smaller than or equal to` : `smaller than`} ${new Date(Number(issue.maximum))}`;
        else
          message2 = "Invalid input";
        break;
      case ZodIssueCode.custom:
        message2 = `Invalid input`;
        break;
      case ZodIssueCode.invalid_intersection_types:
        message2 = `Intersection results could not be merged`;
        break;
      case ZodIssueCode.not_multiple_of:
        message2 = `Number must be a multiple of ${issue.multipleOf}`;
        break;
      case ZodIssueCode.not_finite:
        message2 = "Number must be finite";
        break;
      default:
        message2 = _ctx.defaultError;
        util.assertNever(issue);
    }
    return { message: message2 };
  };
  var overrideErrorMap = errorMap;
  function setErrorMap(map) {
    overrideErrorMap = map;
  }
  function getErrorMap() {
    return overrideErrorMap;
  }
  var makeIssue = (params) => {
    const { data, path: path2, errorMaps, issueData } = params;
    const fullPath = [...path2, ...issueData.path || []];
    const fullIssue = {
      ...issueData,
      path: fullPath
    };
    if (issueData.message !== void 0) {
      return {
        ...issueData,
        path: fullPath,
        message: issueData.message
      };
    }
    let errorMessage2 = "";
    const maps = errorMaps.filter((m3) => !!m3).slice().reverse();
    for (const map of maps) {
      errorMessage2 = map(fullIssue, { data, defaultError: errorMessage2 }).message;
    }
    return {
      ...issueData,
      path: fullPath,
      message: errorMessage2
    };
  };
  var EMPTY_PATH = [];
  function addIssueToContext(ctx, issueData) {
    const overrideMap = getErrorMap();
    const issue = makeIssue({
      issueData,
      data: ctx.data,
      path: ctx.path,
      errorMaps: [
        ctx.common.contextualErrorMap,
        ctx.schemaErrorMap,
        overrideMap,
        overrideMap === errorMap ? void 0 : errorMap
        // then global default map
      ].filter((x2) => !!x2)
    });
    ctx.common.issues.push(issue);
  }
  var ParseStatus = class _ParseStatus {
    constructor() {
      this.value = "valid";
    }
    dirty() {
      if (this.value === "valid")
        this.value = "dirty";
    }
    abort() {
      if (this.value !== "aborted")
        this.value = "aborted";
    }
    static mergeArray(status, results) {
      const arrayValue = [];
      for (const s3 of results) {
        if (s3.status === "aborted")
          return INVALID;
        if (s3.status === "dirty")
          status.dirty();
        arrayValue.push(s3.value);
      }
      return { status: status.value, value: arrayValue };
    }
    static async mergeObjectAsync(status, pairs) {
      const syncPairs = [];
      for (const pair of pairs) {
        const key = await pair.key;
        const value = await pair.value;
        syncPairs.push({
          key,
          value
        });
      }
      return _ParseStatus.mergeObjectSync(status, syncPairs);
    }
    static mergeObjectSync(status, pairs) {
      const finalObject = {};
      for (const pair of pairs) {
        const { key, value } = pair;
        if (key.status === "aborted")
          return INVALID;
        if (value.status === "aborted")
          return INVALID;
        if (key.status === "dirty")
          status.dirty();
        if (value.status === "dirty")
          status.dirty();
        if (key.value !== "__proto__" && (typeof value.value !== "undefined" || pair.alwaysSet)) {
          finalObject[key.value] = value.value;
        }
      }
      return { status: status.value, value: finalObject };
    }
  };
  var INVALID = Object.freeze({
    status: "aborted"
  });
  var DIRTY = (value) => ({ status: "dirty", value });
  var OK = (value) => ({ status: "valid", value });
  var isAborted = (x2) => x2.status === "aborted";
  var isDirty = (x2) => x2.status === "dirty";
  var isValid = (x2) => x2.status === "valid";
  var isAsync = (x2) => typeof Promise !== "undefined" && x2 instanceof Promise;
  function __classPrivateFieldGet(receiver, state, kind, f4) {
    if (kind === "a" && !f4) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f4 : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f4 : kind === "a" ? f4.call(receiver) : f4 ? f4.value : state.get(receiver);
  }
  function __classPrivateFieldSet(receiver, state, value, kind, f4) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f4) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f4 : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return kind === "a" ? f4.call(receiver, value) : f4 ? f4.value = value : state.set(receiver, value), value;
  }
  var errorUtil;
  (function(errorUtil2) {
    errorUtil2.errToObj = (message2) => typeof message2 === "string" ? { message: message2 } : message2 || {};
    errorUtil2.toString = (message2) => typeof message2 === "string" ? message2 : message2 === null || message2 === void 0 ? void 0 : message2.message;
  })(errorUtil || (errorUtil = {}));
  var _ZodEnum_cache;
  var _ZodNativeEnum_cache;
  var ParseInputLazyPath = class {
    constructor(parent, value, path2, key) {
      this._cachedPath = [];
      this.parent = parent;
      this.data = value;
      this._path = path2;
      this._key = key;
    }
    get path() {
      if (!this._cachedPath.length) {
        if (this._key instanceof Array) {
          this._cachedPath.push(...this._path, ...this._key);
        } else {
          this._cachedPath.push(...this._path, this._key);
        }
      }
      return this._cachedPath;
    }
  };
  var handleResult = (ctx, result) => {
    if (isValid(result)) {
      return { success: true, data: result.value };
    } else {
      if (!ctx.common.issues.length) {
        throw new Error("Validation failed but no issues detected.");
      }
      return {
        success: false,
        get error() {
          if (this._error)
            return this._error;
          const error = new ZodError(ctx.common.issues);
          this._error = error;
          return this._error;
        }
      };
    }
  };
  function processCreateParams(params) {
    if (!params)
      return {};
    const { errorMap: errorMap2, invalid_type_error, required_error, description } = params;
    if (errorMap2 && (invalid_type_error || required_error)) {
      throw new Error(`Can't use "invalid_type_error" or "required_error" in conjunction with custom error map.`);
    }
    if (errorMap2)
      return { errorMap: errorMap2, description };
    const customMap = (iss, ctx) => {
      var _a, _b;
      const { message: message2 } = params;
      if (iss.code === "invalid_enum_value") {
        return { message: message2 !== null && message2 !== void 0 ? message2 : ctx.defaultError };
      }
      if (typeof ctx.data === "undefined") {
        return { message: (_a = message2 !== null && message2 !== void 0 ? message2 : required_error) !== null && _a !== void 0 ? _a : ctx.defaultError };
      }
      if (iss.code !== "invalid_type")
        return { message: ctx.defaultError };
      return { message: (_b = message2 !== null && message2 !== void 0 ? message2 : invalid_type_error) !== null && _b !== void 0 ? _b : ctx.defaultError };
    };
    return { errorMap: customMap, description };
  }
  var ZodType = class {
    constructor(def) {
      this.spa = this.safeParseAsync;
      this._def = def;
      this.parse = this.parse.bind(this);
      this.safeParse = this.safeParse.bind(this);
      this.parseAsync = this.parseAsync.bind(this);
      this.safeParseAsync = this.safeParseAsync.bind(this);
      this.spa = this.spa.bind(this);
      this.refine = this.refine.bind(this);
      this.refinement = this.refinement.bind(this);
      this.superRefine = this.superRefine.bind(this);
      this.optional = this.optional.bind(this);
      this.nullable = this.nullable.bind(this);
      this.nullish = this.nullish.bind(this);
      this.array = this.array.bind(this);
      this.promise = this.promise.bind(this);
      this.or = this.or.bind(this);
      this.and = this.and.bind(this);
      this.transform = this.transform.bind(this);
      this.brand = this.brand.bind(this);
      this.default = this.default.bind(this);
      this.catch = this.catch.bind(this);
      this.describe = this.describe.bind(this);
      this.pipe = this.pipe.bind(this);
      this.readonly = this.readonly.bind(this);
      this.isNullable = this.isNullable.bind(this);
      this.isOptional = this.isOptional.bind(this);
    }
    get description() {
      return this._def.description;
    }
    _getType(input) {
      return getParsedType(input.data);
    }
    _getOrReturnCtx(input, ctx) {
      return ctx || {
        common: input.parent.common,
        data: input.data,
        parsedType: getParsedType(input.data),
        schemaErrorMap: this._def.errorMap,
        path: input.path,
        parent: input.parent
      };
    }
    _processInputParams(input) {
      return {
        status: new ParseStatus(),
        ctx: {
          common: input.parent.common,
          data: input.data,
          parsedType: getParsedType(input.data),
          schemaErrorMap: this._def.errorMap,
          path: input.path,
          parent: input.parent
        }
      };
    }
    _parseSync(input) {
      const result = this._parse(input);
      if (isAsync(result)) {
        throw new Error("Synchronous parse encountered promise.");
      }
      return result;
    }
    _parseAsync(input) {
      const result = this._parse(input);
      return Promise.resolve(result);
    }
    parse(data, params) {
      const result = this.safeParse(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    safeParse(data, params) {
      var _a;
      const ctx = {
        common: {
          issues: [],
          async: (_a = params === null || params === void 0 ? void 0 : params.async) !== null && _a !== void 0 ? _a : false,
          contextualErrorMap: params === null || params === void 0 ? void 0 : params.errorMap
        },
        path: (params === null || params === void 0 ? void 0 : params.path) || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const result = this._parseSync({ data, path: ctx.path, parent: ctx });
      return handleResult(ctx, result);
    }
    async parseAsync(data, params) {
      const result = await this.safeParseAsync(data, params);
      if (result.success)
        return result.data;
      throw result.error;
    }
    async safeParseAsync(data, params) {
      const ctx = {
        common: {
          issues: [],
          contextualErrorMap: params === null || params === void 0 ? void 0 : params.errorMap,
          async: true
        },
        path: (params === null || params === void 0 ? void 0 : params.path) || [],
        schemaErrorMap: this._def.errorMap,
        parent: null,
        data,
        parsedType: getParsedType(data)
      };
      const maybeAsyncResult = this._parse({ data, path: ctx.path, parent: ctx });
      const result = await (isAsync(maybeAsyncResult) ? maybeAsyncResult : Promise.resolve(maybeAsyncResult));
      return handleResult(ctx, result);
    }
    refine(check, message2) {
      const getIssueProperties = (val) => {
        if (typeof message2 === "string" || typeof message2 === "undefined") {
          return { message: message2 };
        } else if (typeof message2 === "function") {
          return message2(val);
        } else {
          return message2;
        }
      };
      return this._refinement((val, ctx) => {
        const result = check(val);
        const setError = () => ctx.addIssue({
          code: ZodIssueCode.custom,
          ...getIssueProperties(val)
        });
        if (typeof Promise !== "undefined" && result instanceof Promise) {
          return result.then((data) => {
            if (!data) {
              setError();
              return false;
            } else {
              return true;
            }
          });
        }
        if (!result) {
          setError();
          return false;
        } else {
          return true;
        }
      });
    }
    refinement(check, refinementData) {
      return this._refinement((val, ctx) => {
        if (!check(val)) {
          ctx.addIssue(typeof refinementData === "function" ? refinementData(val, ctx) : refinementData);
          return false;
        } else {
          return true;
        }
      });
    }
    _refinement(refinement) {
      return new ZodEffects({
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "refinement", refinement }
      });
    }
    superRefine(refinement) {
      return this._refinement(refinement);
    }
    optional() {
      return ZodOptional.create(this, this._def);
    }
    nullable() {
      return ZodNullable.create(this, this._def);
    }
    nullish() {
      return this.nullable().optional();
    }
    array() {
      return ZodArray.create(this, this._def);
    }
    promise() {
      return ZodPromise.create(this, this._def);
    }
    or(option) {
      return ZodUnion.create([this, option], this._def);
    }
    and(incoming) {
      return ZodIntersection.create(this, incoming, this._def);
    }
    transform(transform) {
      return new ZodEffects({
        ...processCreateParams(this._def),
        schema: this,
        typeName: ZodFirstPartyTypeKind.ZodEffects,
        effect: { type: "transform", transform }
      });
    }
    default(def) {
      const defaultValueFunc = typeof def === "function" ? def : () => def;
      return new ZodDefault({
        ...processCreateParams(this._def),
        innerType: this,
        defaultValue: defaultValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodDefault
      });
    }
    brand() {
      return new ZodBranded({
        typeName: ZodFirstPartyTypeKind.ZodBranded,
        type: this,
        ...processCreateParams(this._def)
      });
    }
    catch(def) {
      const catchValueFunc = typeof def === "function" ? def : () => def;
      return new ZodCatch({
        ...processCreateParams(this._def),
        innerType: this,
        catchValue: catchValueFunc,
        typeName: ZodFirstPartyTypeKind.ZodCatch
      });
    }
    describe(description) {
      const This = this.constructor;
      return new This({
        ...this._def,
        description
      });
    }
    pipe(target) {
      return ZodPipeline.create(this, target);
    }
    readonly() {
      return ZodReadonly.create(this);
    }
    isOptional() {
      return this.safeParse(void 0).success;
    }
    isNullable() {
      return this.safeParse(null).success;
    }
  };
  var cuidRegex = /^c[^\s-]{8,}$/i;
  var cuid2Regex = /^[0-9a-z]+$/;
  var ulidRegex = /^[0-9A-HJKMNP-TV-Z]{26}$/;
  var uuidRegex = /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/i;
  var nanoidRegex = /^[a-z0-9_-]{21}$/i;
  var durationRegex = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
  var emailRegex = /^(?!\.)(?!.*\.\.)([A-Z0-9_'+\-\.]*)[A-Z0-9_+-]@([A-Z0-9][A-Z0-9\-]*\.)+[A-Z]{2,}$/i;
  var _emojiRegex = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
  var emojiRegex;
  var ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
  var ipv6Regex = /^(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))$/;
  var base64Regex = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
  var dateRegexSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
  var dateRegex = new RegExp(`^${dateRegexSource}$`);
  function timeRegexSource(args) {
    let regex = `([01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d`;
    if (args.precision) {
      regex = `${regex}\\.\\d{${args.precision}}`;
    } else if (args.precision == null) {
      regex = `${regex}(\\.\\d+)?`;
    }
    return regex;
  }
  function timeRegex(args) {
    return new RegExp(`^${timeRegexSource(args)}$`);
  }
  function datetimeRegex(args) {
    let regex = `${dateRegexSource}T${timeRegexSource(args)}`;
    const opts = [];
    opts.push(args.local ? `Z?` : `Z`);
    if (args.offset)
      opts.push(`([+-]\\d{2}:?\\d{2})`);
    regex = `${regex}(${opts.join("|")})`;
    return new RegExp(`^${regex}$`);
  }
  function isValidIP(ip, version) {
    if ((version === "v4" || !version) && ipv4Regex.test(ip)) {
      return true;
    }
    if ((version === "v6" || !version) && ipv6Regex.test(ip)) {
      return true;
    }
    return false;
  }
  var ZodString = class _ZodString extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = String(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.string) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.string,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.length < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.length > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "string",
              inclusive: true,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "length") {
          const tooBig = input.data.length > check.value;
          const tooSmall = input.data.length < check.value;
          if (tooBig || tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            if (tooBig) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_big,
                maximum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            } else if (tooSmall) {
              addIssueToContext(ctx, {
                code: ZodIssueCode.too_small,
                minimum: check.value,
                type: "string",
                inclusive: true,
                exact: true,
                message: check.message
              });
            }
            status.dirty();
          }
        } else if (check.kind === "email") {
          if (!emailRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "email",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "emoji") {
          if (!emojiRegex) {
            emojiRegex = new RegExp(_emojiRegex, "u");
          }
          if (!emojiRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "emoji",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "uuid") {
          if (!uuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "uuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "nanoid") {
          if (!nanoidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "nanoid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid") {
          if (!cuidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "cuid2") {
          if (!cuid2Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "cuid2",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ulid") {
          if (!ulidRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ulid",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "url") {
          try {
            new URL(input.data);
          } catch (_a) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "url",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "regex") {
          check.regex.lastIndex = 0;
          const testResult = check.regex.test(input.data);
          if (!testResult) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "regex",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "trim") {
          input.data = input.data.trim();
        } else if (check.kind === "includes") {
          if (!input.data.includes(check.value, check.position)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { includes: check.value, position: check.position },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "toLowerCase") {
          input.data = input.data.toLowerCase();
        } else if (check.kind === "toUpperCase") {
          input.data = input.data.toUpperCase();
        } else if (check.kind === "startsWith") {
          if (!input.data.startsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { startsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "endsWith") {
          if (!input.data.endsWith(check.value)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: { endsWith: check.value },
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "datetime") {
          const regex = datetimeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "datetime",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "date") {
          const regex = dateRegex;
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "date",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "time") {
          const regex = timeRegex(check);
          if (!regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_string,
              validation: "time",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "duration") {
          if (!durationRegex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "duration",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "ip") {
          if (!isValidIP(input.data, check.version)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "ip",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "base64") {
          if (!base64Regex.test(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              validation: "base64",
              code: ZodIssueCode.invalid_string,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    _regex(regex, validation, message2) {
      return this.refinement((data) => regex.test(data), {
        validation,
        code: ZodIssueCode.invalid_string,
        ...errorUtil.errToObj(message2)
      });
    }
    _addCheck(check) {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    email(message2) {
      return this._addCheck({ kind: "email", ...errorUtil.errToObj(message2) });
    }
    url(message2) {
      return this._addCheck({ kind: "url", ...errorUtil.errToObj(message2) });
    }
    emoji(message2) {
      return this._addCheck({ kind: "emoji", ...errorUtil.errToObj(message2) });
    }
    uuid(message2) {
      return this._addCheck({ kind: "uuid", ...errorUtil.errToObj(message2) });
    }
    nanoid(message2) {
      return this._addCheck({ kind: "nanoid", ...errorUtil.errToObj(message2) });
    }
    cuid(message2) {
      return this._addCheck({ kind: "cuid", ...errorUtil.errToObj(message2) });
    }
    cuid2(message2) {
      return this._addCheck({ kind: "cuid2", ...errorUtil.errToObj(message2) });
    }
    ulid(message2) {
      return this._addCheck({ kind: "ulid", ...errorUtil.errToObj(message2) });
    }
    base64(message2) {
      return this._addCheck({ kind: "base64", ...errorUtil.errToObj(message2) });
    }
    ip(options) {
      return this._addCheck({ kind: "ip", ...errorUtil.errToObj(options) });
    }
    datetime(options) {
      var _a, _b;
      if (typeof options === "string") {
        return this._addCheck({
          kind: "datetime",
          precision: null,
          offset: false,
          local: false,
          message: options
        });
      }
      return this._addCheck({
        kind: "datetime",
        precision: typeof (options === null || options === void 0 ? void 0 : options.precision) === "undefined" ? null : options === null || options === void 0 ? void 0 : options.precision,
        offset: (_a = options === null || options === void 0 ? void 0 : options.offset) !== null && _a !== void 0 ? _a : false,
        local: (_b = options === null || options === void 0 ? void 0 : options.local) !== null && _b !== void 0 ? _b : false,
        ...errorUtil.errToObj(options === null || options === void 0 ? void 0 : options.message)
      });
    }
    date(message2) {
      return this._addCheck({ kind: "date", message: message2 });
    }
    time(options) {
      if (typeof options === "string") {
        return this._addCheck({
          kind: "time",
          precision: null,
          message: options
        });
      }
      return this._addCheck({
        kind: "time",
        precision: typeof (options === null || options === void 0 ? void 0 : options.precision) === "undefined" ? null : options === null || options === void 0 ? void 0 : options.precision,
        ...errorUtil.errToObj(options === null || options === void 0 ? void 0 : options.message)
      });
    }
    duration(message2) {
      return this._addCheck({ kind: "duration", ...errorUtil.errToObj(message2) });
    }
    regex(regex, message2) {
      return this._addCheck({
        kind: "regex",
        regex,
        ...errorUtil.errToObj(message2)
      });
    }
    includes(value, options) {
      return this._addCheck({
        kind: "includes",
        value,
        position: options === null || options === void 0 ? void 0 : options.position,
        ...errorUtil.errToObj(options === null || options === void 0 ? void 0 : options.message)
      });
    }
    startsWith(value, message2) {
      return this._addCheck({
        kind: "startsWith",
        value,
        ...errorUtil.errToObj(message2)
      });
    }
    endsWith(value, message2) {
      return this._addCheck({
        kind: "endsWith",
        value,
        ...errorUtil.errToObj(message2)
      });
    }
    min(minLength, message2) {
      return this._addCheck({
        kind: "min",
        value: minLength,
        ...errorUtil.errToObj(message2)
      });
    }
    max(maxLength, message2) {
      return this._addCheck({
        kind: "max",
        value: maxLength,
        ...errorUtil.errToObj(message2)
      });
    }
    length(len, message2) {
      return this._addCheck({
        kind: "length",
        value: len,
        ...errorUtil.errToObj(message2)
      });
    }
    /**
     * @deprecated Use z.string().min(1) instead.
     * @see {@link ZodString.min}
     */
    nonempty(message2) {
      return this.min(1, errorUtil.errToObj(message2));
    }
    trim() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "trim" }]
      });
    }
    toLowerCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toLowerCase" }]
      });
    }
    toUpperCase() {
      return new _ZodString({
        ...this._def,
        checks: [...this._def.checks, { kind: "toUpperCase" }]
      });
    }
    get isDatetime() {
      return !!this._def.checks.find((ch) => ch.kind === "datetime");
    }
    get isDate() {
      return !!this._def.checks.find((ch) => ch.kind === "date");
    }
    get isTime() {
      return !!this._def.checks.find((ch) => ch.kind === "time");
    }
    get isDuration() {
      return !!this._def.checks.find((ch) => ch.kind === "duration");
    }
    get isEmail() {
      return !!this._def.checks.find((ch) => ch.kind === "email");
    }
    get isURL() {
      return !!this._def.checks.find((ch) => ch.kind === "url");
    }
    get isEmoji() {
      return !!this._def.checks.find((ch) => ch.kind === "emoji");
    }
    get isUUID() {
      return !!this._def.checks.find((ch) => ch.kind === "uuid");
    }
    get isNANOID() {
      return !!this._def.checks.find((ch) => ch.kind === "nanoid");
    }
    get isCUID() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid");
    }
    get isCUID2() {
      return !!this._def.checks.find((ch) => ch.kind === "cuid2");
    }
    get isULID() {
      return !!this._def.checks.find((ch) => ch.kind === "ulid");
    }
    get isIP() {
      return !!this._def.checks.find((ch) => ch.kind === "ip");
    }
    get isBase64() {
      return !!this._def.checks.find((ch) => ch.kind === "base64");
    }
    get minLength() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxLength() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodString.create = (params) => {
    var _a;
    return new ZodString({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodString,
      coerce: (_a = params === null || params === void 0 ? void 0 : params.coerce) !== null && _a !== void 0 ? _a : false,
      ...processCreateParams(params)
    });
  };
  function floatSafeRemainder(val, step) {
    const valDecCount = (val.toString().split(".")[1] || "").length;
    const stepDecCount = (step.toString().split(".")[1] || "").length;
    const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
    const valInt = parseInt(val.toFixed(decCount).replace(".", ""));
    const stepInt = parseInt(step.toFixed(decCount).replace(".", ""));
    return valInt % stepInt / Math.pow(10, decCount);
  }
  var ZodNumber = class _ZodNumber extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
      this.step = this.multipleOf;
    }
    _parse(input) {
      if (this._def.coerce) {
        input.data = Number(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.number) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.number,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "int") {
          if (!util.isInteger(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.invalid_type,
              expected: "integer",
              received: "float",
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              minimum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              maximum: check.value,
              type: "number",
              inclusive: check.inclusive,
              exact: false,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (floatSafeRemainder(input.data, check.value) !== 0) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "finite") {
          if (!Number.isFinite(input.data)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_finite,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    gte(value, message2) {
      return this.setLimit("min", value, true, errorUtil.toString(message2));
    }
    gt(value, message2) {
      return this.setLimit("min", value, false, errorUtil.toString(message2));
    }
    lte(value, message2) {
      return this.setLimit("max", value, true, errorUtil.toString(message2));
    }
    lt(value, message2) {
      return this.setLimit("max", value, false, errorUtil.toString(message2));
    }
    setLimit(kind, value, inclusive, message2) {
      return new _ZodNumber({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message2)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodNumber({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    int(message2) {
      return this._addCheck({
        kind: "int",
        message: errorUtil.toString(message2)
      });
    }
    positive(message2) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    negative(message2) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    nonpositive(message2) {
      return this._addCheck({
        kind: "max",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    nonnegative(message2) {
      return this._addCheck({
        kind: "min",
        value: 0,
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    multipleOf(value, message2) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message2)
      });
    }
    finite(message2) {
      return this._addCheck({
        kind: "finite",
        message: errorUtil.toString(message2)
      });
    }
    safe(message2) {
      return this._addCheck({
        kind: "min",
        inclusive: true,
        value: Number.MIN_SAFE_INTEGER,
        message: errorUtil.toString(message2)
      })._addCheck({
        kind: "max",
        inclusive: true,
        value: Number.MAX_SAFE_INTEGER,
        message: errorUtil.toString(message2)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
    get isInt() {
      return !!this._def.checks.find((ch) => ch.kind === "int" || ch.kind === "multipleOf" && util.isInteger(ch.value));
    }
    get isFinite() {
      let max = null, min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "finite" || ch.kind === "int" || ch.kind === "multipleOf") {
          return true;
        } else if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        } else if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return Number.isFinite(min) && Number.isFinite(max);
    }
  };
  ZodNumber.create = (params) => {
    return new ZodNumber({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodNumber,
      coerce: (params === null || params === void 0 ? void 0 : params.coerce) || false,
      ...processCreateParams(params)
    });
  };
  var ZodBigInt = class _ZodBigInt extends ZodType {
    constructor() {
      super(...arguments);
      this.min = this.gte;
      this.max = this.lte;
    }
    _parse(input) {
      if (this._def.coerce) {
        input.data = BigInt(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.bigint) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.bigint,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      let ctx = void 0;
      const status = new ParseStatus();
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          const tooSmall = check.inclusive ? input.data < check.value : input.data <= check.value;
          if (tooSmall) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              type: "bigint",
              minimum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          const tooBig = check.inclusive ? input.data > check.value : input.data >= check.value;
          if (tooBig) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              type: "bigint",
              maximum: check.value,
              inclusive: check.inclusive,
              message: check.message
            });
            status.dirty();
          }
        } else if (check.kind === "multipleOf") {
          if (input.data % check.value !== BigInt(0)) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.not_multiple_of,
              multipleOf: check.value,
              message: check.message
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return { status: status.value, value: input.data };
    }
    gte(value, message2) {
      return this.setLimit("min", value, true, errorUtil.toString(message2));
    }
    gt(value, message2) {
      return this.setLimit("min", value, false, errorUtil.toString(message2));
    }
    lte(value, message2) {
      return this.setLimit("max", value, true, errorUtil.toString(message2));
    }
    lt(value, message2) {
      return this.setLimit("max", value, false, errorUtil.toString(message2));
    }
    setLimit(kind, value, inclusive, message2) {
      return new _ZodBigInt({
        ...this._def,
        checks: [
          ...this._def.checks,
          {
            kind,
            value,
            inclusive,
            message: errorUtil.toString(message2)
          }
        ]
      });
    }
    _addCheck(check) {
      return new _ZodBigInt({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    positive(message2) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    negative(message2) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: false,
        message: errorUtil.toString(message2)
      });
    }
    nonpositive(message2) {
      return this._addCheck({
        kind: "max",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    nonnegative(message2) {
      return this._addCheck({
        kind: "min",
        value: BigInt(0),
        inclusive: true,
        message: errorUtil.toString(message2)
      });
    }
    multipleOf(value, message2) {
      return this._addCheck({
        kind: "multipleOf",
        value,
        message: errorUtil.toString(message2)
      });
    }
    get minValue() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min;
    }
    get maxValue() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max;
    }
  };
  ZodBigInt.create = (params) => {
    var _a;
    return new ZodBigInt({
      checks: [],
      typeName: ZodFirstPartyTypeKind.ZodBigInt,
      coerce: (_a = params === null || params === void 0 ? void 0 : params.coerce) !== null && _a !== void 0 ? _a : false,
      ...processCreateParams(params)
    });
  };
  var ZodBoolean = class extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = Boolean(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.boolean) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.boolean,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodBoolean.create = (params) => {
    return new ZodBoolean({
      typeName: ZodFirstPartyTypeKind.ZodBoolean,
      coerce: (params === null || params === void 0 ? void 0 : params.coerce) || false,
      ...processCreateParams(params)
    });
  };
  var ZodDate = class _ZodDate extends ZodType {
    _parse(input) {
      if (this._def.coerce) {
        input.data = new Date(input.data);
      }
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.date) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.date,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      if (isNaN(input.data.getTime())) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_date
        });
        return INVALID;
      }
      const status = new ParseStatus();
      let ctx = void 0;
      for (const check of this._def.checks) {
        if (check.kind === "min") {
          if (input.data.getTime() < check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_small,
              message: check.message,
              inclusive: true,
              exact: false,
              minimum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else if (check.kind === "max") {
          if (input.data.getTime() > check.value) {
            ctx = this._getOrReturnCtx(input, ctx);
            addIssueToContext(ctx, {
              code: ZodIssueCode.too_big,
              message: check.message,
              inclusive: true,
              exact: false,
              maximum: check.value,
              type: "date"
            });
            status.dirty();
          }
        } else {
          util.assertNever(check);
        }
      }
      return {
        status: status.value,
        value: new Date(input.data.getTime())
      };
    }
    _addCheck(check) {
      return new _ZodDate({
        ...this._def,
        checks: [...this._def.checks, check]
      });
    }
    min(minDate, message2) {
      return this._addCheck({
        kind: "min",
        value: minDate.getTime(),
        message: errorUtil.toString(message2)
      });
    }
    max(maxDate, message2) {
      return this._addCheck({
        kind: "max",
        value: maxDate.getTime(),
        message: errorUtil.toString(message2)
      });
    }
    get minDate() {
      let min = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "min") {
          if (min === null || ch.value > min)
            min = ch.value;
        }
      }
      return min != null ? new Date(min) : null;
    }
    get maxDate() {
      let max = null;
      for (const ch of this._def.checks) {
        if (ch.kind === "max") {
          if (max === null || ch.value < max)
            max = ch.value;
        }
      }
      return max != null ? new Date(max) : null;
    }
  };
  ZodDate.create = (params) => {
    return new ZodDate({
      checks: [],
      coerce: (params === null || params === void 0 ? void 0 : params.coerce) || false,
      typeName: ZodFirstPartyTypeKind.ZodDate,
      ...processCreateParams(params)
    });
  };
  var ZodSymbol = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.symbol) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.symbol,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodSymbol.create = (params) => {
    return new ZodSymbol({
      typeName: ZodFirstPartyTypeKind.ZodSymbol,
      ...processCreateParams(params)
    });
  };
  var ZodUndefined = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.undefined,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodUndefined.create = (params) => {
    return new ZodUndefined({
      typeName: ZodFirstPartyTypeKind.ZodUndefined,
      ...processCreateParams(params)
    });
  };
  var ZodNull = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.null) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.null,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodNull.create = (params) => {
    return new ZodNull({
      typeName: ZodFirstPartyTypeKind.ZodNull,
      ...processCreateParams(params)
    });
  };
  var ZodAny = class extends ZodType {
    constructor() {
      super(...arguments);
      this._any = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodAny.create = (params) => {
    return new ZodAny({
      typeName: ZodFirstPartyTypeKind.ZodAny,
      ...processCreateParams(params)
    });
  };
  var ZodUnknown = class extends ZodType {
    constructor() {
      super(...arguments);
      this._unknown = true;
    }
    _parse(input) {
      return OK(input.data);
    }
  };
  ZodUnknown.create = (params) => {
    return new ZodUnknown({
      typeName: ZodFirstPartyTypeKind.ZodUnknown,
      ...processCreateParams(params)
    });
  };
  var ZodNever = class extends ZodType {
    _parse(input) {
      const ctx = this._getOrReturnCtx(input);
      addIssueToContext(ctx, {
        code: ZodIssueCode.invalid_type,
        expected: ZodParsedType.never,
        received: ctx.parsedType
      });
      return INVALID;
    }
  };
  ZodNever.create = (params) => {
    return new ZodNever({
      typeName: ZodFirstPartyTypeKind.ZodNever,
      ...processCreateParams(params)
    });
  };
  var ZodVoid = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.undefined) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.void,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return OK(input.data);
    }
  };
  ZodVoid.create = (params) => {
    return new ZodVoid({
      typeName: ZodFirstPartyTypeKind.ZodVoid,
      ...processCreateParams(params)
    });
  };
  var ZodArray = class _ZodArray extends ZodType {
    _parse(input) {
      const { ctx, status } = this._processInputParams(input);
      const def = this._def;
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (def.exactLength !== null) {
        const tooBig = ctx.data.length > def.exactLength.value;
        const tooSmall = ctx.data.length < def.exactLength.value;
        if (tooBig || tooSmall) {
          addIssueToContext(ctx, {
            code: tooBig ? ZodIssueCode.too_big : ZodIssueCode.too_small,
            minimum: tooSmall ? def.exactLength.value : void 0,
            maximum: tooBig ? def.exactLength.value : void 0,
            type: "array",
            inclusive: true,
            exact: true,
            message: def.exactLength.message
          });
          status.dirty();
        }
      }
      if (def.minLength !== null) {
        if (ctx.data.length < def.minLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.minLength.message
          });
          status.dirty();
        }
      }
      if (def.maxLength !== null) {
        if (ctx.data.length > def.maxLength.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxLength.value,
            type: "array",
            inclusive: true,
            exact: false,
            message: def.maxLength.message
          });
          status.dirty();
        }
      }
      if (ctx.common.async) {
        return Promise.all([...ctx.data].map((item, i3) => {
          return def.type._parseAsync(new ParseInputLazyPath(ctx, item, ctx.path, i3));
        })).then((result2) => {
          return ParseStatus.mergeArray(status, result2);
        });
      }
      const result = [...ctx.data].map((item, i3) => {
        return def.type._parseSync(new ParseInputLazyPath(ctx, item, ctx.path, i3));
      });
      return ParseStatus.mergeArray(status, result);
    }
    get element() {
      return this._def.type;
    }
    min(minLength, message2) {
      return new _ZodArray({
        ...this._def,
        minLength: { value: minLength, message: errorUtil.toString(message2) }
      });
    }
    max(maxLength, message2) {
      return new _ZodArray({
        ...this._def,
        maxLength: { value: maxLength, message: errorUtil.toString(message2) }
      });
    }
    length(len, message2) {
      return new _ZodArray({
        ...this._def,
        exactLength: { value: len, message: errorUtil.toString(message2) }
      });
    }
    nonempty(message2) {
      return this.min(1, message2);
    }
  };
  ZodArray.create = (schema, params) => {
    return new ZodArray({
      type: schema,
      minLength: null,
      maxLength: null,
      exactLength: null,
      typeName: ZodFirstPartyTypeKind.ZodArray,
      ...processCreateParams(params)
    });
  };
  function deepPartialify(schema) {
    if (schema instanceof ZodObject) {
      const newShape = {};
      for (const key in schema.shape) {
        const fieldSchema = schema.shape[key];
        newShape[key] = ZodOptional.create(deepPartialify(fieldSchema));
      }
      return new ZodObject({
        ...schema._def,
        shape: () => newShape
      });
    } else if (schema instanceof ZodArray) {
      return new ZodArray({
        ...schema._def,
        type: deepPartialify(schema.element)
      });
    } else if (schema instanceof ZodOptional) {
      return ZodOptional.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodNullable) {
      return ZodNullable.create(deepPartialify(schema.unwrap()));
    } else if (schema instanceof ZodTuple) {
      return ZodTuple.create(schema.items.map((item) => deepPartialify(item)));
    } else {
      return schema;
    }
  }
  var ZodObject = class _ZodObject extends ZodType {
    constructor() {
      super(...arguments);
      this._cached = null;
      this.nonstrict = this.passthrough;
      this.augment = this.extend;
    }
    _getCached() {
      if (this._cached !== null)
        return this._cached;
      const shape = this._def.shape();
      const keys = util.objectKeys(shape);
      return this._cached = { shape, keys };
    }
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.object) {
        const ctx2 = this._getOrReturnCtx(input);
        addIssueToContext(ctx2, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx2.parsedType
        });
        return INVALID;
      }
      const { status, ctx } = this._processInputParams(input);
      const { shape, keys: shapeKeys } = this._getCached();
      const extraKeys = [];
      if (!(this._def.catchall instanceof ZodNever && this._def.unknownKeys === "strip")) {
        for (const key in ctx.data) {
          if (!shapeKeys.includes(key)) {
            extraKeys.push(key);
          }
        }
      }
      const pairs = [];
      for (const key of shapeKeys) {
        const keyValidator = shape[key];
        const value = ctx.data[key];
        pairs.push({
          key: { status: "valid", value: key },
          value: keyValidator._parse(new ParseInputLazyPath(ctx, value, ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (this._def.catchall instanceof ZodNever) {
        const unknownKeys = this._def.unknownKeys;
        if (unknownKeys === "passthrough") {
          for (const key of extraKeys) {
            pairs.push({
              key: { status: "valid", value: key },
              value: { status: "valid", value: ctx.data[key] }
            });
          }
        } else if (unknownKeys === "strict") {
          if (extraKeys.length > 0) {
            addIssueToContext(ctx, {
              code: ZodIssueCode.unrecognized_keys,
              keys: extraKeys
            });
            status.dirty();
          }
        } else if (unknownKeys === "strip") ;
        else {
          throw new Error(`Internal ZodObject error: invalid unknownKeys value.`);
        }
      } else {
        const catchall = this._def.catchall;
        for (const key of extraKeys) {
          const value = ctx.data[key];
          pairs.push({
            key: { status: "valid", value: key },
            value: catchall._parse(
              new ParseInputLazyPath(ctx, value, ctx.path, key)
              //, ctx.child(key), value, getParsedType(value)
            ),
            alwaysSet: key in ctx.data
          });
        }
      }
      if (ctx.common.async) {
        return Promise.resolve().then(async () => {
          const syncPairs = [];
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            syncPairs.push({
              key,
              value,
              alwaysSet: pair.alwaysSet
            });
          }
          return syncPairs;
        }).then((syncPairs) => {
          return ParseStatus.mergeObjectSync(status, syncPairs);
        });
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get shape() {
      return this._def.shape();
    }
    strict(message2) {
      errorUtil.errToObj;
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strict",
        ...message2 !== void 0 ? {
          errorMap: (issue, ctx) => {
            var _a, _b, _c, _d;
            const defaultError = (_c = (_b = (_a = this._def).errorMap) === null || _b === void 0 ? void 0 : _b.call(_a, issue, ctx).message) !== null && _c !== void 0 ? _c : ctx.defaultError;
            if (issue.code === "unrecognized_keys")
              return {
                message: (_d = errorUtil.errToObj(message2).message) !== null && _d !== void 0 ? _d : defaultError
              };
            return {
              message: defaultError
            };
          }
        } : {}
      });
    }
    strip() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "strip"
      });
    }
    passthrough() {
      return new _ZodObject({
        ...this._def,
        unknownKeys: "passthrough"
      });
    }
    // const AugmentFactory =
    //   <Def extends ZodObjectDef>(def: Def) =>
    //   <Augmentation extends ZodRawShape>(
    //     augmentation: Augmentation
    //   ): ZodObject<
    //     extendShape<ReturnType<Def["shape"]>, Augmentation>,
    //     Def["unknownKeys"],
    //     Def["catchall"]
    //   > => {
    //     return new ZodObject({
    //       ...def,
    //       shape: () => ({
    //         ...def.shape(),
    //         ...augmentation,
    //       }),
    //     }) as any;
    //   };
    extend(augmentation) {
      return new _ZodObject({
        ...this._def,
        shape: () => ({
          ...this._def.shape(),
          ...augmentation
        })
      });
    }
    /**
     * Prior to zod@1.0.12 there was a bug in the
     * inferred type of merged objects. Please
     * upgrade if you are experiencing issues.
     */
    merge(merging) {
      const merged = new _ZodObject({
        unknownKeys: merging._def.unknownKeys,
        catchall: merging._def.catchall,
        shape: () => ({
          ...this._def.shape(),
          ...merging._def.shape()
        }),
        typeName: ZodFirstPartyTypeKind.ZodObject
      });
      return merged;
    }
    // merge<
    //   Incoming extends AnyZodObject,
    //   Augmentation extends Incoming["shape"],
    //   NewOutput extends {
    //     [k in keyof Augmentation | keyof Output]: k extends keyof Augmentation
    //       ? Augmentation[k]["_output"]
    //       : k extends keyof Output
    //       ? Output[k]
    //       : never;
    //   },
    //   NewInput extends {
    //     [k in keyof Augmentation | keyof Input]: k extends keyof Augmentation
    //       ? Augmentation[k]["_input"]
    //       : k extends keyof Input
    //       ? Input[k]
    //       : never;
    //   }
    // >(
    //   merging: Incoming
    // ): ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"],
    //   NewOutput,
    //   NewInput
    // > {
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    setKey(key, schema) {
      return this.augment({ [key]: schema });
    }
    // merge<Incoming extends AnyZodObject>(
    //   merging: Incoming
    // ): //ZodObject<T & Incoming["_shape"], UnknownKeys, Catchall> = (merging) => {
    // ZodObject<
    //   extendShape<T, ReturnType<Incoming["_def"]["shape"]>>,
    //   Incoming["_def"]["unknownKeys"],
    //   Incoming["_def"]["catchall"]
    // > {
    //   // const mergedShape = objectUtil.mergeShapes(
    //   //   this._def.shape(),
    //   //   merging._def.shape()
    //   // );
    //   const merged: any = new ZodObject({
    //     unknownKeys: merging._def.unknownKeys,
    //     catchall: merging._def.catchall,
    //     shape: () =>
    //       objectUtil.mergeShapes(this._def.shape(), merging._def.shape()),
    //     typeName: ZodFirstPartyTypeKind.ZodObject,
    //   }) as any;
    //   return merged;
    // }
    catchall(index) {
      return new _ZodObject({
        ...this._def,
        catchall: index
      });
    }
    pick(mask) {
      const shape = {};
      util.objectKeys(mask).forEach((key) => {
        if (mask[key] && this.shape[key]) {
          shape[key] = this.shape[key];
        }
      });
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    omit(mask) {
      const shape = {};
      util.objectKeys(this.shape).forEach((key) => {
        if (!mask[key]) {
          shape[key] = this.shape[key];
        }
      });
      return new _ZodObject({
        ...this._def,
        shape: () => shape
      });
    }
    /**
     * @deprecated
     */
    deepPartial() {
      return deepPartialify(this);
    }
    partial(mask) {
      const newShape = {};
      util.objectKeys(this.shape).forEach((key) => {
        const fieldSchema = this.shape[key];
        if (mask && !mask[key]) {
          newShape[key] = fieldSchema;
        } else {
          newShape[key] = fieldSchema.optional();
        }
      });
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    required(mask) {
      const newShape = {};
      util.objectKeys(this.shape).forEach((key) => {
        if (mask && !mask[key]) {
          newShape[key] = this.shape[key];
        } else {
          const fieldSchema = this.shape[key];
          let newField = fieldSchema;
          while (newField instanceof ZodOptional) {
            newField = newField._def.innerType;
          }
          newShape[key] = newField;
        }
      });
      return new _ZodObject({
        ...this._def,
        shape: () => newShape
      });
    }
    keyof() {
      return createZodEnum(util.objectKeys(this.shape));
    }
  };
  ZodObject.create = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.strictCreate = (shape, params) => {
    return new ZodObject({
      shape: () => shape,
      unknownKeys: "strict",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  ZodObject.lazycreate = (shape, params) => {
    return new ZodObject({
      shape,
      unknownKeys: "strip",
      catchall: ZodNever.create(),
      typeName: ZodFirstPartyTypeKind.ZodObject,
      ...processCreateParams(params)
    });
  };
  var ZodUnion = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const options = this._def.options;
      function handleResults(results) {
        for (const result of results) {
          if (result.result.status === "valid") {
            return result.result;
          }
        }
        for (const result of results) {
          if (result.result.status === "dirty") {
            ctx.common.issues.push(...result.ctx.common.issues);
            return result.result;
          }
        }
        const unionErrors = results.map((result) => new ZodError(result.ctx.common.issues));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return Promise.all(options.map(async (option) => {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          return {
            result: await option._parseAsync({
              data: ctx.data,
              path: ctx.path,
              parent: childCtx
            }),
            ctx: childCtx
          };
        })).then(handleResults);
      } else {
        let dirty = void 0;
        const issues = [];
        for (const option of options) {
          const childCtx = {
            ...ctx,
            common: {
              ...ctx.common,
              issues: []
            },
            parent: null
          };
          const result = option._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: childCtx
          });
          if (result.status === "valid") {
            return result;
          } else if (result.status === "dirty" && !dirty) {
            dirty = { result, ctx: childCtx };
          }
          if (childCtx.common.issues.length) {
            issues.push(childCtx.common.issues);
          }
        }
        if (dirty) {
          ctx.common.issues.push(...dirty.ctx.common.issues);
          return dirty.result;
        }
        const unionErrors = issues.map((issues2) => new ZodError(issues2));
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union,
          unionErrors
        });
        return INVALID;
      }
    }
    get options() {
      return this._def.options;
    }
  };
  ZodUnion.create = (types, params) => {
    return new ZodUnion({
      options: types,
      typeName: ZodFirstPartyTypeKind.ZodUnion,
      ...processCreateParams(params)
    });
  };
  var getDiscriminator = (type) => {
    if (type instanceof ZodLazy) {
      return getDiscriminator(type.schema);
    } else if (type instanceof ZodEffects) {
      return getDiscriminator(type.innerType());
    } else if (type instanceof ZodLiteral) {
      return [type.value];
    } else if (type instanceof ZodEnum) {
      return type.options;
    } else if (type instanceof ZodNativeEnum) {
      return util.objectValues(type.enum);
    } else if (type instanceof ZodDefault) {
      return getDiscriminator(type._def.innerType);
    } else if (type instanceof ZodUndefined) {
      return [void 0];
    } else if (type instanceof ZodNull) {
      return [null];
    } else if (type instanceof ZodOptional) {
      return [void 0, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodNullable) {
      return [null, ...getDiscriminator(type.unwrap())];
    } else if (type instanceof ZodBranded) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodReadonly) {
      return getDiscriminator(type.unwrap());
    } else if (type instanceof ZodCatch) {
      return getDiscriminator(type._def.innerType);
    } else {
      return [];
    }
  };
  var ZodDiscriminatedUnion = class _ZodDiscriminatedUnion extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const discriminator = this.discriminator;
      const discriminatorValue = ctx.data[discriminator];
      const option = this.optionsMap.get(discriminatorValue);
      if (!option) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_union_discriminator,
          options: Array.from(this.optionsMap.keys()),
          path: [discriminator]
        });
        return INVALID;
      }
      if (ctx.common.async) {
        return option._parseAsync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      } else {
        return option._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
      }
    }
    get discriminator() {
      return this._def.discriminator;
    }
    get options() {
      return this._def.options;
    }
    get optionsMap() {
      return this._def.optionsMap;
    }
    /**
     * The constructor of the discriminated union schema. Its behaviour is very similar to that of the normal z.union() constructor.
     * However, it only allows a union of objects, all of which need to share a discriminator property. This property must
     * have a different value for each object in the union.
     * @param discriminator the name of the discriminator property
     * @param types an array of object schemas
     * @param params
     */
    static create(discriminator, options, params) {
      const optionsMap = /* @__PURE__ */ new Map();
      for (const type of options) {
        const discriminatorValues = getDiscriminator(type.shape[discriminator]);
        if (!discriminatorValues.length) {
          throw new Error(`A discriminator value for key \`${discriminator}\` could not be extracted from all schema options`);
        }
        for (const value of discriminatorValues) {
          if (optionsMap.has(value)) {
            throw new Error(`Discriminator property ${String(discriminator)} has duplicate value ${String(value)}`);
          }
          optionsMap.set(value, type);
        }
      }
      return new _ZodDiscriminatedUnion({
        typeName: ZodFirstPartyTypeKind.ZodDiscriminatedUnion,
        discriminator,
        options,
        optionsMap,
        ...processCreateParams(params)
      });
    }
  };
  function mergeValues(a4, b2) {
    const aType = getParsedType(a4);
    const bType = getParsedType(b2);
    if (a4 === b2) {
      return { valid: true, data: a4 };
    } else if (aType === ZodParsedType.object && bType === ZodParsedType.object) {
      const bKeys = util.objectKeys(b2);
      const sharedKeys = util.objectKeys(a4).filter((key) => bKeys.indexOf(key) !== -1);
      const newObj = { ...a4, ...b2 };
      for (const key of sharedKeys) {
        const sharedValue = mergeValues(a4[key], b2[key]);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newObj[key] = sharedValue.data;
      }
      return { valid: true, data: newObj };
    } else if (aType === ZodParsedType.array && bType === ZodParsedType.array) {
      if (a4.length !== b2.length) {
        return { valid: false };
      }
      const newArray = [];
      for (let index = 0; index < a4.length; index++) {
        const itemA = a4[index];
        const itemB = b2[index];
        const sharedValue = mergeValues(itemA, itemB);
        if (!sharedValue.valid) {
          return { valid: false };
        }
        newArray.push(sharedValue.data);
      }
      return { valid: true, data: newArray };
    } else if (aType === ZodParsedType.date && bType === ZodParsedType.date && +a4 === +b2) {
      return { valid: true, data: a4 };
    } else {
      return { valid: false };
    }
  }
  var ZodIntersection = class extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const handleParsed = (parsedLeft, parsedRight) => {
        if (isAborted(parsedLeft) || isAborted(parsedRight)) {
          return INVALID;
        }
        const merged = mergeValues(parsedLeft.value, parsedRight.value);
        if (!merged.valid) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.invalid_intersection_types
          });
          return INVALID;
        }
        if (isDirty(parsedLeft) || isDirty(parsedRight)) {
          status.dirty();
        }
        return { status: status.value, value: merged.data };
      };
      if (ctx.common.async) {
        return Promise.all([
          this._def.left._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          }),
          this._def.right._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          })
        ]).then(([left, right]) => handleParsed(left, right));
      } else {
        return handleParsed(this._def.left._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }), this._def.right._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        }));
      }
    }
  };
  ZodIntersection.create = (left, right, params) => {
    return new ZodIntersection({
      left,
      right,
      typeName: ZodFirstPartyTypeKind.ZodIntersection,
      ...processCreateParams(params)
    });
  };
  var ZodTuple = class _ZodTuple extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.array) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.array,
          received: ctx.parsedType
        });
        return INVALID;
      }
      if (ctx.data.length < this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_small,
          minimum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        return INVALID;
      }
      const rest = this._def.rest;
      if (!rest && ctx.data.length > this._def.items.length) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.too_big,
          maximum: this._def.items.length,
          inclusive: true,
          exact: false,
          type: "array"
        });
        status.dirty();
      }
      const items = [...ctx.data].map((item, itemIndex) => {
        const schema = this._def.items[itemIndex] || this._def.rest;
        if (!schema)
          return null;
        return schema._parse(new ParseInputLazyPath(ctx, item, ctx.path, itemIndex));
      }).filter((x2) => !!x2);
      if (ctx.common.async) {
        return Promise.all(items).then((results) => {
          return ParseStatus.mergeArray(status, results);
        });
      } else {
        return ParseStatus.mergeArray(status, items);
      }
    }
    get items() {
      return this._def.items;
    }
    rest(rest) {
      return new _ZodTuple({
        ...this._def,
        rest
      });
    }
  };
  ZodTuple.create = (schemas, params) => {
    if (!Array.isArray(schemas)) {
      throw new Error("You must pass an array of schemas to z.tuple([ ... ])");
    }
    return new ZodTuple({
      items: schemas,
      typeName: ZodFirstPartyTypeKind.ZodTuple,
      rest: null,
      ...processCreateParams(params)
    });
  };
  var ZodRecord = class _ZodRecord extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.object) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.object,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const pairs = [];
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      for (const key in ctx.data) {
        pairs.push({
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, key)),
          value: valueType._parse(new ParseInputLazyPath(ctx, ctx.data[key], ctx.path, key)),
          alwaysSet: key in ctx.data
        });
      }
      if (ctx.common.async) {
        return ParseStatus.mergeObjectAsync(status, pairs);
      } else {
        return ParseStatus.mergeObjectSync(status, pairs);
      }
    }
    get element() {
      return this._def.valueType;
    }
    static create(first, second, third) {
      if (second instanceof ZodType) {
        return new _ZodRecord({
          keyType: first,
          valueType: second,
          typeName: ZodFirstPartyTypeKind.ZodRecord,
          ...processCreateParams(third)
        });
      }
      return new _ZodRecord({
        keyType: ZodString.create(),
        valueType: first,
        typeName: ZodFirstPartyTypeKind.ZodRecord,
        ...processCreateParams(second)
      });
    }
  };
  var ZodMap = class extends ZodType {
    get keySchema() {
      return this._def.keyType;
    }
    get valueSchema() {
      return this._def.valueType;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.map) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.map,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const keyType = this._def.keyType;
      const valueType = this._def.valueType;
      const pairs = [...ctx.data.entries()].map(([key, value], index) => {
        return {
          key: keyType._parse(new ParseInputLazyPath(ctx, key, ctx.path, [index, "key"])),
          value: valueType._parse(new ParseInputLazyPath(ctx, value, ctx.path, [index, "value"]))
        };
      });
      if (ctx.common.async) {
        const finalMap = /* @__PURE__ */ new Map();
        return Promise.resolve().then(async () => {
          for (const pair of pairs) {
            const key = await pair.key;
            const value = await pair.value;
            if (key.status === "aborted" || value.status === "aborted") {
              return INVALID;
            }
            if (key.status === "dirty" || value.status === "dirty") {
              status.dirty();
            }
            finalMap.set(key.value, value.value);
          }
          return { status: status.value, value: finalMap };
        });
      } else {
        const finalMap = /* @__PURE__ */ new Map();
        for (const pair of pairs) {
          const key = pair.key;
          const value = pair.value;
          if (key.status === "aborted" || value.status === "aborted") {
            return INVALID;
          }
          if (key.status === "dirty" || value.status === "dirty") {
            status.dirty();
          }
          finalMap.set(key.value, value.value);
        }
        return { status: status.value, value: finalMap };
      }
    }
  };
  ZodMap.create = (keyType, valueType, params) => {
    return new ZodMap({
      valueType,
      keyType,
      typeName: ZodFirstPartyTypeKind.ZodMap,
      ...processCreateParams(params)
    });
  };
  var ZodSet = class _ZodSet extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.set) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.set,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const def = this._def;
      if (def.minSize !== null) {
        if (ctx.data.size < def.minSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_small,
            minimum: def.minSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.minSize.message
          });
          status.dirty();
        }
      }
      if (def.maxSize !== null) {
        if (ctx.data.size > def.maxSize.value) {
          addIssueToContext(ctx, {
            code: ZodIssueCode.too_big,
            maximum: def.maxSize.value,
            type: "set",
            inclusive: true,
            exact: false,
            message: def.maxSize.message
          });
          status.dirty();
        }
      }
      const valueType = this._def.valueType;
      function finalizeSet(elements2) {
        const parsedSet = /* @__PURE__ */ new Set();
        for (const element of elements2) {
          if (element.status === "aborted")
            return INVALID;
          if (element.status === "dirty")
            status.dirty();
          parsedSet.add(element.value);
        }
        return { status: status.value, value: parsedSet };
      }
      const elements = [...ctx.data.values()].map((item, i3) => valueType._parse(new ParseInputLazyPath(ctx, item, ctx.path, i3)));
      if (ctx.common.async) {
        return Promise.all(elements).then((elements2) => finalizeSet(elements2));
      } else {
        return finalizeSet(elements);
      }
    }
    min(minSize, message2) {
      return new _ZodSet({
        ...this._def,
        minSize: { value: minSize, message: errorUtil.toString(message2) }
      });
    }
    max(maxSize, message2) {
      return new _ZodSet({
        ...this._def,
        maxSize: { value: maxSize, message: errorUtil.toString(message2) }
      });
    }
    size(size, message2) {
      return this.min(size, message2).max(size, message2);
    }
    nonempty(message2) {
      return this.min(1, message2);
    }
  };
  ZodSet.create = (valueType, params) => {
    return new ZodSet({
      valueType,
      minSize: null,
      maxSize: null,
      typeName: ZodFirstPartyTypeKind.ZodSet,
      ...processCreateParams(params)
    });
  };
  var ZodFunction = class _ZodFunction extends ZodType {
    constructor() {
      super(...arguments);
      this.validate = this.implement;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.function) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.function,
          received: ctx.parsedType
        });
        return INVALID;
      }
      function makeArgsIssue(args, error) {
        return makeIssue({
          data: args,
          path: ctx.path,
          errorMaps: [
            ctx.common.contextualErrorMap,
            ctx.schemaErrorMap,
            getErrorMap(),
            errorMap
          ].filter((x2) => !!x2),
          issueData: {
            code: ZodIssueCode.invalid_arguments,
            argumentsError: error
          }
        });
      }
      function makeReturnsIssue(returns, error) {
        return makeIssue({
          data: returns,
          path: ctx.path,
          errorMaps: [
            ctx.common.contextualErrorMap,
            ctx.schemaErrorMap,
            getErrorMap(),
            errorMap
          ].filter((x2) => !!x2),
          issueData: {
            code: ZodIssueCode.invalid_return_type,
            returnTypeError: error
          }
        });
      }
      const params = { errorMap: ctx.common.contextualErrorMap };
      const fn = ctx.data;
      if (this._def.returns instanceof ZodPromise) {
        const me = this;
        return OK(async function(...args) {
          const error = new ZodError([]);
          const parsedArgs = await me._def.args.parseAsync(args, params).catch((e3) => {
            error.addIssue(makeArgsIssue(args, e3));
            throw error;
          });
          const result = await Reflect.apply(fn, this, parsedArgs);
          const parsedReturns = await me._def.returns._def.type.parseAsync(result, params).catch((e3) => {
            error.addIssue(makeReturnsIssue(result, e3));
            throw error;
          });
          return parsedReturns;
        });
      } else {
        const me = this;
        return OK(function(...args) {
          const parsedArgs = me._def.args.safeParse(args, params);
          if (!parsedArgs.success) {
            throw new ZodError([makeArgsIssue(args, parsedArgs.error)]);
          }
          const result = Reflect.apply(fn, this, parsedArgs.data);
          const parsedReturns = me._def.returns.safeParse(result, params);
          if (!parsedReturns.success) {
            throw new ZodError([makeReturnsIssue(result, parsedReturns.error)]);
          }
          return parsedReturns.data;
        });
      }
    }
    parameters() {
      return this._def.args;
    }
    returnType() {
      return this._def.returns;
    }
    args(...items) {
      return new _ZodFunction({
        ...this._def,
        args: ZodTuple.create(items).rest(ZodUnknown.create())
      });
    }
    returns(returnType) {
      return new _ZodFunction({
        ...this._def,
        returns: returnType
      });
    }
    implement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    strictImplement(func) {
      const validatedFunc = this.parse(func);
      return validatedFunc;
    }
    static create(args, returns, params) {
      return new _ZodFunction({
        args: args ? args : ZodTuple.create([]).rest(ZodUnknown.create()),
        returns: returns || ZodUnknown.create(),
        typeName: ZodFirstPartyTypeKind.ZodFunction,
        ...processCreateParams(params)
      });
    }
  };
  var ZodLazy = class extends ZodType {
    get schema() {
      return this._def.getter();
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const lazySchema = this._def.getter();
      return lazySchema._parse({ data: ctx.data, path: ctx.path, parent: ctx });
    }
  };
  ZodLazy.create = (getter, params) => {
    return new ZodLazy({
      getter,
      typeName: ZodFirstPartyTypeKind.ZodLazy,
      ...processCreateParams(params)
    });
  };
  var ZodLiteral = class extends ZodType {
    _parse(input) {
      if (input.data !== this._def.value) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_literal,
          expected: this._def.value
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
    get value() {
      return this._def.value;
    }
  };
  ZodLiteral.create = (value, params) => {
    return new ZodLiteral({
      value,
      typeName: ZodFirstPartyTypeKind.ZodLiteral,
      ...processCreateParams(params)
    });
  };
  function createZodEnum(values, params) {
    return new ZodEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodEnum,
      ...processCreateParams(params)
    });
  }
  var ZodEnum = class _ZodEnum extends ZodType {
    constructor() {
      super(...arguments);
      _ZodEnum_cache.set(this, void 0);
    }
    _parse(input) {
      if (typeof input.data !== "string") {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!__classPrivateFieldGet(this, _ZodEnum_cache, "f")) {
        __classPrivateFieldSet(this, _ZodEnum_cache, new Set(this._def.values), "f");
      }
      if (!__classPrivateFieldGet(this, _ZodEnum_cache, "f").has(input.data)) {
        const ctx = this._getOrReturnCtx(input);
        const expectedValues = this._def.values;
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get options() {
      return this._def.values;
    }
    get enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Values() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    get Enum() {
      const enumValues = {};
      for (const val of this._def.values) {
        enumValues[val] = val;
      }
      return enumValues;
    }
    extract(values, newDef = this._def) {
      return _ZodEnum.create(values, {
        ...this._def,
        ...newDef
      });
    }
    exclude(values, newDef = this._def) {
      return _ZodEnum.create(this.options.filter((opt) => !values.includes(opt)), {
        ...this._def,
        ...newDef
      });
    }
  };
  _ZodEnum_cache = /* @__PURE__ */ new WeakMap();
  ZodEnum.create = createZodEnum;
  var ZodNativeEnum = class extends ZodType {
    constructor() {
      super(...arguments);
      _ZodNativeEnum_cache.set(this, void 0);
    }
    _parse(input) {
      const nativeEnumValues = util.getValidEnumValues(this._def.values);
      const ctx = this._getOrReturnCtx(input);
      if (ctx.parsedType !== ZodParsedType.string && ctx.parsedType !== ZodParsedType.number) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          expected: util.joinValues(expectedValues),
          received: ctx.parsedType,
          code: ZodIssueCode.invalid_type
        });
        return INVALID;
      }
      if (!__classPrivateFieldGet(this, _ZodNativeEnum_cache, "f")) {
        __classPrivateFieldSet(this, _ZodNativeEnum_cache, new Set(util.getValidEnumValues(this._def.values)), "f");
      }
      if (!__classPrivateFieldGet(this, _ZodNativeEnum_cache, "f").has(input.data)) {
        const expectedValues = util.objectValues(nativeEnumValues);
        addIssueToContext(ctx, {
          received: ctx.data,
          code: ZodIssueCode.invalid_enum_value,
          options: expectedValues
        });
        return INVALID;
      }
      return OK(input.data);
    }
    get enum() {
      return this._def.values;
    }
  };
  _ZodNativeEnum_cache = /* @__PURE__ */ new WeakMap();
  ZodNativeEnum.create = (values, params) => {
    return new ZodNativeEnum({
      values,
      typeName: ZodFirstPartyTypeKind.ZodNativeEnum,
      ...processCreateParams(params)
    });
  };
  var ZodPromise = class extends ZodType {
    unwrap() {
      return this._def.type;
    }
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      if (ctx.parsedType !== ZodParsedType.promise && ctx.common.async === false) {
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.promise,
          received: ctx.parsedType
        });
        return INVALID;
      }
      const promisified = ctx.parsedType === ZodParsedType.promise ? ctx.data : Promise.resolve(ctx.data);
      return OK(promisified.then((data) => {
        return this._def.type.parseAsync(data, {
          path: ctx.path,
          errorMap: ctx.common.contextualErrorMap
        });
      }));
    }
  };
  ZodPromise.create = (schema, params) => {
    return new ZodPromise({
      type: schema,
      typeName: ZodFirstPartyTypeKind.ZodPromise,
      ...processCreateParams(params)
    });
  };
  var ZodEffects = class extends ZodType {
    innerType() {
      return this._def.schema;
    }
    sourceType() {
      return this._def.schema._def.typeName === ZodFirstPartyTypeKind.ZodEffects ? this._def.schema.sourceType() : this._def.schema;
    }
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      const effect = this._def.effect || null;
      const checkCtx = {
        addIssue: (arg) => {
          addIssueToContext(ctx, arg);
          if (arg.fatal) {
            status.abort();
          } else {
            status.dirty();
          }
        },
        get path() {
          return ctx.path;
        }
      };
      checkCtx.addIssue = checkCtx.addIssue.bind(checkCtx);
      if (effect.type === "preprocess") {
        const processed = effect.transform(ctx.data, checkCtx);
        if (ctx.common.async) {
          return Promise.resolve(processed).then(async (processed2) => {
            if (status.value === "aborted")
              return INVALID;
            const result = await this._def.schema._parseAsync({
              data: processed2,
              path: ctx.path,
              parent: ctx
            });
            if (result.status === "aborted")
              return INVALID;
            if (result.status === "dirty")
              return DIRTY(result.value);
            if (status.value === "dirty")
              return DIRTY(result.value);
            return result;
          });
        } else {
          if (status.value === "aborted")
            return INVALID;
          const result = this._def.schema._parseSync({
            data: processed,
            path: ctx.path,
            parent: ctx
          });
          if (result.status === "aborted")
            return INVALID;
          if (result.status === "dirty")
            return DIRTY(result.value);
          if (status.value === "dirty")
            return DIRTY(result.value);
          return result;
        }
      }
      if (effect.type === "refinement") {
        const executeRefinement = (acc) => {
          const result = effect.refinement(acc, checkCtx);
          if (ctx.common.async) {
            return Promise.resolve(result);
          }
          if (result instanceof Promise) {
            throw new Error("Async refinement encountered during synchronous parse operation. Use .parseAsync instead.");
          }
          return acc;
        };
        if (ctx.common.async === false) {
          const inner2 = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inner2.status === "aborted")
            return INVALID;
          if (inner2.status === "dirty")
            status.dirty();
          executeRefinement(inner2.value);
          return { status: status.value, value: inner2.value };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((inner2) => {
            if (inner2.status === "aborted")
              return INVALID;
            if (inner2.status === "dirty")
              status.dirty();
            return executeRefinement(inner2.value).then(() => {
              return { status: status.value, value: inner2.value };
            });
          });
        }
      }
      if (effect.type === "transform") {
        if (ctx.common.async === false) {
          const base = this._def.schema._parseSync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (!isValid(base))
            return base;
          const result = effect.transform(base.value, checkCtx);
          if (result instanceof Promise) {
            throw new Error(`Asynchronous transform encountered during synchronous parse operation. Use .parseAsync instead.`);
          }
          return { status: status.value, value: result };
        } else {
          return this._def.schema._parseAsync({ data: ctx.data, path: ctx.path, parent: ctx }).then((base) => {
            if (!isValid(base))
              return base;
            return Promise.resolve(effect.transform(base.value, checkCtx)).then((result) => ({ status: status.value, value: result }));
          });
        }
      }
      util.assertNever(effect);
    }
  };
  ZodEffects.create = (schema, effect, params) => {
    return new ZodEffects({
      schema,
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      effect,
      ...processCreateParams(params)
    });
  };
  ZodEffects.createWithPreprocess = (preprocess, schema, params) => {
    return new ZodEffects({
      schema,
      effect: { type: "preprocess", transform: preprocess },
      typeName: ZodFirstPartyTypeKind.ZodEffects,
      ...processCreateParams(params)
    });
  };
  var ZodOptional = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.undefined) {
        return OK(void 0);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodOptional.create = (type, params) => {
    return new ZodOptional({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodOptional,
      ...processCreateParams(params)
    });
  };
  var ZodNullable = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType === ZodParsedType.null) {
        return OK(null);
      }
      return this._def.innerType._parse(input);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodNullable.create = (type, params) => {
    return new ZodNullable({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodNullable,
      ...processCreateParams(params)
    });
  };
  var ZodDefault = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      let data = ctx.data;
      if (ctx.parsedType === ZodParsedType.undefined) {
        data = this._def.defaultValue();
      }
      return this._def.innerType._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    removeDefault() {
      return this._def.innerType;
    }
  };
  ZodDefault.create = (type, params) => {
    return new ZodDefault({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodDefault,
      defaultValue: typeof params.default === "function" ? params.default : () => params.default,
      ...processCreateParams(params)
    });
  };
  var ZodCatch = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const newCtx = {
        ...ctx,
        common: {
          ...ctx.common,
          issues: []
        }
      };
      const result = this._def.innerType._parse({
        data: newCtx.data,
        path: newCtx.path,
        parent: {
          ...newCtx
        }
      });
      if (isAsync(result)) {
        return result.then((result2) => {
          return {
            status: "valid",
            value: result2.status === "valid" ? result2.value : this._def.catchValue({
              get error() {
                return new ZodError(newCtx.common.issues);
              },
              input: newCtx.data
            })
          };
        });
      } else {
        return {
          status: "valid",
          value: result.status === "valid" ? result.value : this._def.catchValue({
            get error() {
              return new ZodError(newCtx.common.issues);
            },
            input: newCtx.data
          })
        };
      }
    }
    removeCatch() {
      return this._def.innerType;
    }
  };
  ZodCatch.create = (type, params) => {
    return new ZodCatch({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodCatch,
      catchValue: typeof params.catch === "function" ? params.catch : () => params.catch,
      ...processCreateParams(params)
    });
  };
  var ZodNaN = class extends ZodType {
    _parse(input) {
      const parsedType = this._getType(input);
      if (parsedType !== ZodParsedType.nan) {
        const ctx = this._getOrReturnCtx(input);
        addIssueToContext(ctx, {
          code: ZodIssueCode.invalid_type,
          expected: ZodParsedType.nan,
          received: ctx.parsedType
        });
        return INVALID;
      }
      return { status: "valid", value: input.data };
    }
  };
  ZodNaN.create = (params) => {
    return new ZodNaN({
      typeName: ZodFirstPartyTypeKind.ZodNaN,
      ...processCreateParams(params)
    });
  };
  var BRAND = Symbol("zod_brand");
  var ZodBranded = class extends ZodType {
    _parse(input) {
      const { ctx } = this._processInputParams(input);
      const data = ctx.data;
      return this._def.type._parse({
        data,
        path: ctx.path,
        parent: ctx
      });
    }
    unwrap() {
      return this._def.type;
    }
  };
  var ZodPipeline = class _ZodPipeline extends ZodType {
    _parse(input) {
      const { status, ctx } = this._processInputParams(input);
      if (ctx.common.async) {
        const handleAsync = async () => {
          const inResult = await this._def.in._parseAsync({
            data: ctx.data,
            path: ctx.path,
            parent: ctx
          });
          if (inResult.status === "aborted")
            return INVALID;
          if (inResult.status === "dirty") {
            status.dirty();
            return DIRTY(inResult.value);
          } else {
            return this._def.out._parseAsync({
              data: inResult.value,
              path: ctx.path,
              parent: ctx
            });
          }
        };
        return handleAsync();
      } else {
        const inResult = this._def.in._parseSync({
          data: ctx.data,
          path: ctx.path,
          parent: ctx
        });
        if (inResult.status === "aborted")
          return INVALID;
        if (inResult.status === "dirty") {
          status.dirty();
          return {
            status: "dirty",
            value: inResult.value
          };
        } else {
          return this._def.out._parseSync({
            data: inResult.value,
            path: ctx.path,
            parent: ctx
          });
        }
      }
    }
    static create(a4, b2) {
      return new _ZodPipeline({
        in: a4,
        out: b2,
        typeName: ZodFirstPartyTypeKind.ZodPipeline
      });
    }
  };
  var ZodReadonly = class extends ZodType {
    _parse(input) {
      const result = this._def.innerType._parse(input);
      const freeze = (data) => {
        if (isValid(data)) {
          data.value = Object.freeze(data.value);
        }
        return data;
      };
      return isAsync(result) ? result.then((data) => freeze(data)) : freeze(result);
    }
    unwrap() {
      return this._def.innerType;
    }
  };
  ZodReadonly.create = (type, params) => {
    return new ZodReadonly({
      innerType: type,
      typeName: ZodFirstPartyTypeKind.ZodReadonly,
      ...processCreateParams(params)
    });
  };
  function custom(check, params = {}, fatal) {
    if (check)
      return ZodAny.create().superRefine((data, ctx) => {
        var _a, _b;
        if (!check(data)) {
          const p3 = typeof params === "function" ? params(data) : typeof params === "string" ? { message: params } : params;
          const _fatal = (_b = (_a = p3.fatal) !== null && _a !== void 0 ? _a : fatal) !== null && _b !== void 0 ? _b : true;
          const p22 = typeof p3 === "string" ? { message: p3 } : p3;
          ctx.addIssue({ code: "custom", ...p22, fatal: _fatal });
        }
      });
    return ZodAny.create();
  }
  var late = {
    object: ZodObject.lazycreate
  };
  var ZodFirstPartyTypeKind;
  (function(ZodFirstPartyTypeKind2) {
    ZodFirstPartyTypeKind2["ZodString"] = "ZodString";
    ZodFirstPartyTypeKind2["ZodNumber"] = "ZodNumber";
    ZodFirstPartyTypeKind2["ZodNaN"] = "ZodNaN";
    ZodFirstPartyTypeKind2["ZodBigInt"] = "ZodBigInt";
    ZodFirstPartyTypeKind2["ZodBoolean"] = "ZodBoolean";
    ZodFirstPartyTypeKind2["ZodDate"] = "ZodDate";
    ZodFirstPartyTypeKind2["ZodSymbol"] = "ZodSymbol";
    ZodFirstPartyTypeKind2["ZodUndefined"] = "ZodUndefined";
    ZodFirstPartyTypeKind2["ZodNull"] = "ZodNull";
    ZodFirstPartyTypeKind2["ZodAny"] = "ZodAny";
    ZodFirstPartyTypeKind2["ZodUnknown"] = "ZodUnknown";
    ZodFirstPartyTypeKind2["ZodNever"] = "ZodNever";
    ZodFirstPartyTypeKind2["ZodVoid"] = "ZodVoid";
    ZodFirstPartyTypeKind2["ZodArray"] = "ZodArray";
    ZodFirstPartyTypeKind2["ZodObject"] = "ZodObject";
    ZodFirstPartyTypeKind2["ZodUnion"] = "ZodUnion";
    ZodFirstPartyTypeKind2["ZodDiscriminatedUnion"] = "ZodDiscriminatedUnion";
    ZodFirstPartyTypeKind2["ZodIntersection"] = "ZodIntersection";
    ZodFirstPartyTypeKind2["ZodTuple"] = "ZodTuple";
    ZodFirstPartyTypeKind2["ZodRecord"] = "ZodRecord";
    ZodFirstPartyTypeKind2["ZodMap"] = "ZodMap";
    ZodFirstPartyTypeKind2["ZodSet"] = "ZodSet";
    ZodFirstPartyTypeKind2["ZodFunction"] = "ZodFunction";
    ZodFirstPartyTypeKind2["ZodLazy"] = "ZodLazy";
    ZodFirstPartyTypeKind2["ZodLiteral"] = "ZodLiteral";
    ZodFirstPartyTypeKind2["ZodEnum"] = "ZodEnum";
    ZodFirstPartyTypeKind2["ZodEffects"] = "ZodEffects";
    ZodFirstPartyTypeKind2["ZodNativeEnum"] = "ZodNativeEnum";
    ZodFirstPartyTypeKind2["ZodOptional"] = "ZodOptional";
    ZodFirstPartyTypeKind2["ZodNullable"] = "ZodNullable";
    ZodFirstPartyTypeKind2["ZodDefault"] = "ZodDefault";
    ZodFirstPartyTypeKind2["ZodCatch"] = "ZodCatch";
    ZodFirstPartyTypeKind2["ZodPromise"] = "ZodPromise";
    ZodFirstPartyTypeKind2["ZodBranded"] = "ZodBranded";
    ZodFirstPartyTypeKind2["ZodPipeline"] = "ZodPipeline";
    ZodFirstPartyTypeKind2["ZodReadonly"] = "ZodReadonly";
  })(ZodFirstPartyTypeKind || (ZodFirstPartyTypeKind = {}));
  var instanceOfType = (cls, params = {
    message: `Input not instance of ${cls.name}`
  }) => custom((data) => data instanceof cls, params);
  var stringType = ZodString.create;
  var numberType = ZodNumber.create;
  var nanType = ZodNaN.create;
  var bigIntType = ZodBigInt.create;
  var booleanType = ZodBoolean.create;
  var dateType = ZodDate.create;
  var symbolType = ZodSymbol.create;
  var undefinedType = ZodUndefined.create;
  var nullType = ZodNull.create;
  var anyType = ZodAny.create;
  var unknownType = ZodUnknown.create;
  var neverType = ZodNever.create;
  var voidType = ZodVoid.create;
  var arrayType = ZodArray.create;
  var objectType = ZodObject.create;
  var strictObjectType = ZodObject.strictCreate;
  var unionType = ZodUnion.create;
  var discriminatedUnionType = ZodDiscriminatedUnion.create;
  var intersectionType = ZodIntersection.create;
  var tupleType = ZodTuple.create;
  var recordType = ZodRecord.create;
  var mapType = ZodMap.create;
  var setType = ZodSet.create;
  var functionType = ZodFunction.create;
  var lazyType = ZodLazy.create;
  var literalType = ZodLiteral.create;
  var enumType = ZodEnum.create;
  var nativeEnumType = ZodNativeEnum.create;
  var promiseType = ZodPromise.create;
  var effectsType = ZodEffects.create;
  var optionalType = ZodOptional.create;
  var nullableType = ZodNullable.create;
  var preprocessType = ZodEffects.createWithPreprocess;
  var pipelineType = ZodPipeline.create;
  var ostring = () => stringType().optional();
  var onumber = () => numberType().optional();
  var oboolean = () => booleanType().optional();
  var coerce = {
    string: (arg) => ZodString.create({ ...arg, coerce: true }),
    number: (arg) => ZodNumber.create({ ...arg, coerce: true }),
    boolean: (arg) => ZodBoolean.create({
      ...arg,
      coerce: true
    }),
    bigint: (arg) => ZodBigInt.create({ ...arg, coerce: true }),
    date: (arg) => ZodDate.create({ ...arg, coerce: true })
  };
  var NEVER = INVALID;
  var z2 = /* @__PURE__ */ Object.freeze({
    __proto__: null,
    defaultErrorMap: errorMap,
    setErrorMap,
    getErrorMap,
    makeIssue,
    EMPTY_PATH,
    addIssueToContext,
    ParseStatus,
    INVALID,
    DIRTY,
    OK,
    isAborted,
    isDirty,
    isValid,
    isAsync,
    get util() {
      return util;
    },
    get objectUtil() {
      return objectUtil;
    },
    ZodParsedType,
    getParsedType,
    ZodType,
    datetimeRegex,
    ZodString,
    ZodNumber,
    ZodBigInt,
    ZodBoolean,
    ZodDate,
    ZodSymbol,
    ZodUndefined,
    ZodNull,
    ZodAny,
    ZodUnknown,
    ZodNever,
    ZodVoid,
    ZodArray,
    ZodObject,
    ZodUnion,
    ZodDiscriminatedUnion,
    ZodIntersection,
    ZodTuple,
    ZodRecord,
    ZodMap,
    ZodSet,
    ZodFunction,
    ZodLazy,
    ZodLiteral,
    ZodEnum,
    ZodNativeEnum,
    ZodPromise,
    ZodEffects,
    ZodTransformer: ZodEffects,
    ZodOptional,
    ZodNullable,
    ZodDefault,
    ZodCatch,
    ZodNaN,
    BRAND,
    ZodBranded,
    ZodPipeline,
    ZodReadonly,
    custom,
    Schema: ZodType,
    ZodSchema: ZodType,
    late,
    get ZodFirstPartyTypeKind() {
      return ZodFirstPartyTypeKind;
    },
    coerce,
    any: anyType,
    array: arrayType,
    bigint: bigIntType,
    boolean: booleanType,
    date: dateType,
    discriminatedUnion: discriminatedUnionType,
    effect: effectsType,
    "enum": enumType,
    "function": functionType,
    "instanceof": instanceOfType,
    intersection: intersectionType,
    lazy: lazyType,
    literal: literalType,
    map: mapType,
    nan: nanType,
    nativeEnum: nativeEnumType,
    never: neverType,
    "null": nullType,
    nullable: nullableType,
    number: numberType,
    object: objectType,
    oboolean,
    onumber,
    optional: optionalType,
    ostring,
    pipeline: pipelineType,
    preprocess: preprocessType,
    promise: promiseType,
    record: recordType,
    set: setType,
    strictObject: strictObjectType,
    string: stringType,
    symbol: symbolType,
    transformer: effectsType,
    tuple: tupleType,
    "undefined": undefinedType,
    union: unionType,
    unknown: unknownType,
    "void": voidType,
    NEVER,
    ZodIssueCode,
    quotelessJson,
    ZodError
  });

  // core/schema.ts
  var DEFAULT_GRADE_POINT_SCALE = {
    "A+": 4,
    "A": 4,
    "A-": 3.7,
    "B+": 3.3,
    "B": 3,
    "B-": 2.7,
    "C+": 2.3,
    "C": 2,
    "C-": 1.7,
    "D+": 1.3,
    "D": 1,
    "D-": 0.7,
    "F": 0
  };
  var GradingSchemeItemSchema = z2.object({
    minPct: z2.number().min(0).max(100),
    letter: z2.string().min(1)
  });
  var GradePointScaleSchema = z2.record(z2.string(), z2.number().min(0).max(5));
  var DEFAULT_GRADING_SCHEME = [
    { minPct: 93, letter: "A" },
    { minPct: 90, letter: "A-" },
    { minPct: 87, letter: "B+" },
    { minPct: 83, letter: "B" },
    { minPct: 80, letter: "B-" },
    { minPct: 77, letter: "C+" },
    { minPct: 73, letter: "C" },
    { minPct: 70, letter: "C-" },
    { minPct: 67, letter: "D+" },
    { minPct: 63, letter: "D" },
    { minPct: 60, letter: "D-" },
    { minPct: 0, letter: "F" }
  ];
  var CourseSchema = z2.object({
    id: z2.string().min(1),
    name: z2.string().min(1),
    creditHours: z2.number().positive(),
    applyGroupWeights: z2.boolean(),
    gradingScheme: z2.array(GradingSchemeItemSchema).default(() => [...DEFAULT_GRADING_SCHEME]),
    gradePointScale: GradePointScaleSchema.default(() => ({ ...DEFAULT_GRADE_POINT_SCALE }))
  });
  var AssignmentGroupRulesSchema = z2.object({
    dropLowest: z2.number().int().nonnegative().default(0),
    dropHighest: z2.number().int().nonnegative().default(0),
    neverDrop: z2.array(z2.string()).default([])
  });
  var AssignmentGroupSchema = z2.object({
    id: z2.string().min(1),
    name: z2.string().min(1),
    weight: z2.number().nonnegative(),
    rules: AssignmentGroupRulesSchema.default({ dropLowest: 0, dropHighest: 0, neverDrop: [] })
  });
  var RubricRatingSchema = z2.object({
    id: z2.string().optional(),
    description: z2.string(),
    points: z2.number().nonnegative()
  });
  var RubricCriterionSchema = z2.object({
    id: z2.string().min(1),
    description: z2.string(),
    points: z2.number().nonnegative(),
    ratings: z2.array(RubricRatingSchema)
  });
  var AssignmentSchema = z2.object({
    id: z2.string().min(1),
    groupId: z2.string().min(1),
    name: z2.string().min(1),
    pointsPossible: z2.number().nonnegative(),
    dueAt: z2.string().nullable().optional(),
    submissionTypes: z2.array(z2.string()).default([]),
    omitFromFinalGrade: z2.boolean().default(false),
    hasRubric: z2.boolean().default(false),
    rubric: z2.array(RubricCriterionSchema).optional()
  });
  var RubricAssessmentEntrySchema = z2.object({
    points: z2.number().nonnegative(),
    ratingId: z2.string().optional(),
    comments: z2.string().optional()
  });
  var SubmissionCommentSchema = z2.object({
    authorName: z2.string(),
    comment: z2.string(),
    createdAt: z2.string().optional()
  });
  var SubmissionSchema = z2.object({
    assignmentId: z2.string().min(1),
    score: z2.number().nullable(),
    excused: z2.boolean().default(false),
    missing: z2.boolean().default(false),
    late: z2.boolean().default(false),
    posted: z2.boolean().default(true),
    workflowState: z2.enum(["unsubmitted", "submitted", "graded", "pending_review"]).default("graded"),
    rubricAssessment: z2.record(z2.string(), RubricAssessmentEntrySchema).optional(),
    submissionComments: z2.array(SubmissionCommentSchema).optional()
  });

  // extension/options/optionsStorage.ts
  var DEFAULT_GRADIENT_OPTIONS = {
    canvasHosts: [
      "*.instructure.com",
      "localhost",
      "127.0.0.1",
      "canvas.usm.edu"
    ],
    courseCreditHours: {
      "CS-101": 4,
      "MATH-201": 3,
      "BIO-110": 4
    },
    gradePointScale: { ...DEFAULT_GRADE_POINT_SCALE },
    detailLevel: "a_bit_more"
  };
  var STORAGE_KEY = "gradient_user_options";
  async function loadOptions() {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.sync) {
      return new Promise((resolve) => {
        chrome.storage.sync.get(STORAGE_KEY, (res) => {
          if (res && res[STORAGE_KEY]) {
            resolve({ ...DEFAULT_GRADIENT_OPTIONS, ...res[STORAGE_KEY] });
          } else {
            resolve({ ...DEFAULT_GRADIENT_OPTIONS });
          }
        });
      });
    }
    if (typeof localStorage !== "undefined") {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        try {
          return { ...DEFAULT_GRADIENT_OPTIONS, ...JSON.parse(raw) };
        } catch {
        }
      }
    }
    return { ...DEFAULT_GRADIENT_OPTIONS };
  }
  async function saveOptions(options) {
    const current = await loadOptions();
    const updated = { ...current, ...options };
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.sync) {
      await new Promise((resolve) => {
        chrome.storage.sync.set({ [STORAGE_KEY]: updated }, () => resolve());
      });
    }
    if (typeof localStorage !== "undefined") {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    }
    return updated;
  }

  // node_modules/preact/hooks/dist/hooks.mjs
  var t2;
  var r2;
  var u2;
  var i2;
  var o2 = Object.is;
  var f2 = 0;
  var c2 = [];
  var e2 = [];
  var a2 = n;
  var v2 = a2.__b;
  var l2 = a2.__r;
  var m2 = a2.diffed;
  var h2 = a2.__c;
  var s2 = a2.unmount;
  var p2 = a2.__;
  function y2(n2, t3) {
    a2.__h && a2.__h(r2, n2, f2 || t3), f2 = 0;
    var u4 = r2.__H || (r2.__H = { __: [], __h: [] });
    return n2 >= u4.__.length && u4.__.push({}), u4.__[n2];
  }
  function d2(n2) {
    return f2 = 1, _2(G2, n2);
  }
  function _2(n2, u4, i3) {
    var f4 = y2(t2++, 2);
    if (f4.t = n2, !f4.__c && (f4.__ = [i3 ? i3(u4) : G2(void 0, u4), function(n3) {
      var t3 = f4.__N ? f4.__N[0] : f4.__[0], r3 = f4.t(t3, n3);
      o2(t3, r3) || (f4.__N = [r3, f4.__[1]], f4.__c.setState({}));
    }], f4.__c = r2, !r2.__f)) {
      r2.__f = true;
      var c3 = r2.shouldComponentUpdate;
      r2.shouldComponentUpdate = function(n3, t3, r3) {
        var u5 = this.__H;
        if (!u5) return true;
        var i4 = false, f5 = this.props != n3;
        if (u5.__.some(function(n4) {
          n4.__N && (i4 = true, o2(n4.__[0], n4.__N[0]) || (f5 = true));
        }), c3) {
          var e3 = c3.call(this, n3, t3, r3);
          return i4 ? e3 || f5 : e3;
        }
        return !i4 || f5;
      };
    }
    return f4.__;
  }
  function A(n2, u4) {
    var i3 = y2(t2++, 3);
    !a2.__s && E2(i3.__H, u4) && (i3.__P = true, i3.__ = n2, i3.u = u4, r2.__H.__h.push(i3));
  }
  function T2(n2) {
    return f2 = 5, w2(function() {
      return { current: n2 };
    }, []);
  }
  function w2(n2, r3) {
    var u4 = y2(t2++, 7);
    return E2(u4.__H, r3) && (u4.__ = n2(), u4.__H = r3), u4.__;
  }
  function b(n2, t3) {
    return f2 = 8, w2(function() {
      return n2;
    }, t3);
  }
  function g2() {
    var n2;
    do {
      for (; n2 = e2.shift(); ) try {
        C2(n2);
      } catch (t4) {
        a2.__e(t4, { __: (n2 = n2.__P) && n2.__v });
      }
      for (; n2 = c2.shift(); ) {
        var t3 = n2.__H;
        if (n2.__P && t3) try {
          t3.__h.some(C2), t3.__h.some(D2), t3.__h = [];
        } catch (r3) {
          t3.__h = [], a2.__e(r3, n2.__v);
        }
      }
    } while (e2.length);
  }
  a2.__b = function(n2) {
    r2 = null, v2 && v2(n2);
  }, a2.__ = function(n2, t3) {
    n2 && t3.__k && t3.__k.__m && (n2.__m = t3.__k.__m), p2 && p2(n2, t3);
  }, a2.__r = function(n2) {
    l2 && l2(n2), t2 = 0;
    var i3 = (r2 = n2.__c).__H;
    i3 && (u2 == r2 ? r2.__h = [] : (i3.__h.some(C2), i3.__h.some(D2), t2 = 0), i3.__h = [], i3.__.some(function(n3) {
      n3.__N && (n3.__ = n3.__N), n3.u = n3.__N = void 0;
    })), u2 = r2;
  }, a2.diffed = function(n2) {
    m2 && m2(n2);
    var t3 = n2.__c;
    t3 && t3.__H && (t3.__H.__h.length && B2(c2.push(t3)), t3.__H.__.some(function(n3) {
      n3.u && (n3.__H = n3.u);
    })), u2 = r2 = null;
  }, a2.__c = function(n2, t3) {
    t3.some(function(n3) {
      try {
        n3.__h.some(C2), n3.__h = n3.__h.filter(function(n4) {
          return !n4.__ || D2(n4);
        });
      } catch (t4) {
        n3.__h = [function() {
          throw t4;
        }];
      }
    }), h2 && h2(n2, t3);
  }, a2.unmount = function(n2) {
    s2 && s2(n2);
    var t3, r3, u4 = n2.__c;
    u4 && u4.__H && (u4.__H.__.some(function(u5) {
      try {
        if (u5.__P && u5.__c) {
          if (void 0 === r3) {
            for (r3 = n2.__; r3 && (!r3.__c || !r3.__c.__P); ) r3 = r3.__;
            r3 = r3 && r3.__c;
          }
          u5.__P = r3, B2(e2.push(u5));
        } else C2(u5);
      } catch (n3) {
        t3 = n3;
      }
    }), u4.__H = void 0, t3 && a2.__e(t3, u4.__v));
  };
  var k2 = "function" == typeof requestAnimationFrame;
  function z3(n2) {
    var t3, r3 = function() {
      clearTimeout(u4), k2 && cancelAnimationFrame(t3), setTimeout(n2);
    }, u4 = setTimeout(r3, 35);
    k2 && (t3 = requestAnimationFrame(r3));
  }
  function B2(n2) {
    1 != n2 && i2 == a2.requestAnimationFrame || ((i2 = a2.requestAnimationFrame) || z3)(g2);
  }
  function C2(n2) {
    var t3 = r2, u4 = n2.__c;
    "function" == typeof u4 && (n2.__c = void 0, u4()), r2 = t3;
  }
  function D2(n2) {
    var t3 = r2;
    n2.__c = n2.__(), r2 = t3;
  }
  function E2(n2, t3) {
    return !n2 || n2.length != t3.length || t3.some(function(t4, r3) {
      return !o2(t4, n2[r3]);
    });
  }
  function G2(n2, t3) {
    return "function" == typeof t3 ? t3(n2) : t3;
  }

  // extension/adapter/canvasAdapter.ts
  var CanvasAdapter = class {
    lmsName = "Canvas LMS";
    parseCourse(raw, creditHours) {
      const data = raw;
      let gradingScheme = DEFAULT_GRADING_SCHEME.map((item) => ({ ...item }));
      const rawScheme = data.grading_standard ?? data.grading_scheme;
      if (Array.isArray(rawScheme) && rawScheme.length > 0) {
        gradingScheme = rawScheme.map((entry) => {
          let letter = "F";
          let minPct = 0;
          if (Array.isArray(entry) && entry.length >= 2) {
            letter = String(entry[0]);
            const val = Number(entry[1]);
            minPct = val <= 1 ? Math.round(val * 100) : val;
          } else if (typeof entry === "object" && entry !== null) {
            letter = String(entry.name ?? "F");
            const val = Number(entry.value ?? 0);
            minPct = val <= 1 ? Math.round(val * 100) : val;
          }
          return { letter, minPct };
        });
      }
      const courseData = {
        id: String(data.id),
        name: data.name,
        creditHours,
        applyGroupWeights: Boolean(data.apply_assignment_group_weights),
        gradingScheme,
        gradePointScale: DEFAULT_GRADE_POINT_SCALE
      };
      return CourseSchema.parse(courseData);
    }
    parseAssignmentGroups(rawList) {
      return rawList.map((item) => {
        const g3 = item;
        const rules = {
          dropLowest: g3.rules?.drop_lowest ?? 0,
          dropHighest: g3.rules?.drop_highest ?? 0,
          neverDrop: (g3.rules?.never_drop ?? []).map((id) => String(id))
        };
        const groupData = {
          id: String(g3.id),
          name: g3.name,
          weight: Number(g3.group_weight ?? 0),
          rules
        };
        return AssignmentGroupSchema.parse(groupData);
      });
    }
    parseAssignments(rawList) {
      return rawList.map((item) => {
        const a4 = item;
        let rubric;
        if (Array.isArray(a4.rubric) && a4.rubric.length > 0) {
          rubric = a4.rubric.map((r3) => ({
            id: String(r3.id),
            description: r3.description ?? "",
            points: Number(r3.points ?? 0),
            ratings: (r3.ratings ?? []).map((rat) => ({
              id: rat.id ? String(rat.id) : void 0,
              description: rat.description ?? "",
              points: Number(rat.points ?? 0)
            }))
          }));
        }
        const assignmentData = {
          id: String(a4.id),
          groupId: String(a4.assignment_group_id),
          name: a4.name,
          pointsPossible: Number(a4.points_possible ?? 0),
          dueAt: a4.due_at ?? null,
          submissionTypes: a4.submission_types ?? [],
          omitFromFinalGrade: Boolean(a4.omit_from_final_grade),
          hasRubric: Boolean(rubric && rubric.length > 0),
          rubric
        };
        return AssignmentSchema.parse(assignmentData);
      });
    }
    parseSubmissions(rawList) {
      return rawList.map((item) => {
        const s3 = item;
        const posted = s3.posted_at !== null && s3.posted_at !== void 0;
        let workflowState = "graded";
        if (s3.workflow_state === "unsubmitted") {
          workflowState = "unsubmitted";
        } else if (s3.workflow_state === "submitted") {
          workflowState = "submitted";
        } else if (s3.workflow_state === "pending_review") {
          workflowState = "pending_review";
        }
        const submissionData = {
          assignmentId: String(s3.assignment_id),
          score: typeof s3.score === "number" ? s3.score : null,
          excused: Boolean(s3.excused),
          missing: Boolean(s3.missing),
          late: Boolean(s3.late),
          posted,
          workflowState
        };
        return SubmissionSchema.parse(submissionData);
      });
    }
    parseRubrics(rawList) {
      const criteria = [];
      for (const item of rawList) {
        const rawObj = item;
        const rawCriteriaList = Array.isArray(rawObj.rubric) ? rawObj.rubric : Array.isArray(rawObj.data) ? rawObj.data : Array.isArray(rawObj) ? rawObj : [];
        for (const r3 of rawCriteriaList) {
          const criterion = {
            id: String(r3.id),
            description: r3.description ?? "",
            points: Number(r3.points ?? 0),
            ratings: (r3.ratings ?? []).map((rat) => ({
              id: rat.id ? String(rat.id) : void 0,
              description: rat.description ?? "",
              points: Number(rat.points ?? 0)
            }))
          };
          criteria.push(RubricCriterionSchema.parse(criterion));
        }
      }
      return criteria;
    }
  };

  // extension/liveCanvas.ts
  var adapter = new CanvasAdapter();
  var MAX_PAGES = 25;
  var CanvasAuthenticationError = class extends Error {
    constructor() {
      super("Your Canvas session has expired. Sign in to Canvas, then refresh GRADIENT.");
      this.name = "CanvasAuthenticationError";
    }
  };
  var CanvasEndpointError = class extends Error {
    constructor(status, message2) {
      super(message2);
      this.status = status;
    }
  };
  function numberOrNull(value) {
    return typeof value === "number" && Number.isFinite(value) ? value : null;
  }
  function message(error) {
    if (error instanceof CanvasEndpointError && error.status === 403) return "Canvas has restricted access to this section.";
    return error instanceof Error ? error.message : "Canvas could not load this section.";
  }
  function isAbort(error) {
    return error instanceof Error && error.name === "AbortError";
  }
  function studentEnrollment(course) {
    return Array.isArray(course.enrollments) ? course.enrollments.find((e3) => (e3.type === "student" || e3.type === "StudentEnrollment" || e3.role === "StudentEnrollment") && (!e3.enrollment_state || e3.enrollment_state === "active")) : void 0;
  }
  function sameOriginUrl(value, fallback, origin) {
    try {
      const url = new URL(typeof value === "string" ? value : fallback, origin);
      return url.origin === origin && ["http:", "https:"].includes(url.protocol) ? url.href : new URL(fallback, origin).href;
    } catch {
      return new URL(fallback, origin).href;
    }
  }
  function visibleToStudent(record) {
    return record.locked_for_user !== true && record.hidden_for_user !== true && record.published !== false && record.state !== "locked" && record.content_details?.locked_for_user !== true;
  }
  function decodeHtmlText(value) {
    return value.replace(/&amp;/gi, "&").replace(/&quot;/gi, '"').replace(/&#39;|&apos;/gi, "'").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&#(\d+);/g, (_3, n2) => {
      const code = Number(n2);
      return code >= 0 && code <= 1114111 ? String.fromCodePoint(code) : "";
    });
  }
  function courseLinkedResources(html, courseId, origin) {
    const resources = [];
    const anchors = html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi);
    for (const [, attributes = "", contents = ""] of anchors) {
      const href = attributes.match(/\bhref\s*=\s*(?:"([^"]*)"|'([^']*)')/i);
      if (!href) continue;
      try {
        const url = new URL(decodeHtmlText(href[1] ?? href[2] ?? ""), origin);
        if (url.origin !== origin) continue;
        const courseFile = url.pathname.match(/^\/courses\/([^/]+)\/files\/(\d+)(?:\/|$)/);
        const globalFile = url.pathname.match(/^\/files\/(\d+)(?:\/|$)/);
        const page = url.pathname.match(/^\/courses\/([^/]+)\/pages\/([^/]+)\/?$/);
        if (courseFile && courseFile[1] !== courseId) continue;
        if (page && page[1] !== courseId) continue;
        if (!courseFile && !globalFile && !page) continue;
        const type = page ? "page" : "file";
        const contentId = page ? decodeURIComponent(page[2]) : courseFile?.[2] ?? globalFile?.[1];
        if (!contentId) continue;
        const title = decodeHtmlText(contents.replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim();
        resources.push({
          id: contentId,
          type,
          title: title || (page ? "Course page" : "Course file"),
          url: page ? `${origin}/courses/${courseId}/pages/${encodeURIComponent(contentId)}` : `${origin}/courses/${courseId}/files/${contentId}`,
          source: "course-link"
        });
      } catch {
      }
    }
    return resources;
  }
  async function loadCanvasSnapshot(options = {}) {
    const browserOrigin = typeof window !== "undefined" ? window.location.origin : void 0;
    const origin = new URL(browserOrigin ?? options.origin ?? "https://canvas.instructure.com").origin;
    if (browserOrigin && options.origin && new URL(options.origin).origin !== browserOrigin) {
      throw new Error("Canvas sync must use the current tab\u2019s origin.");
    }
    if (!origin.startsWith("https://") && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) {
      throw new Error("Canvas sync requires HTTPS.");
    }
    let active = 0;
    const waiters = [];
    const get = async (target) => {
      const url = new URL(target, origin);
      if (url.origin !== origin || !url.pathname.startsWith("/api/v1/")) {
        throw new Error("Canvas returned an unsafe pagination URL.");
      }
      if (active >= 4) await new Promise((resolve) => waiters.push(resolve));
      else active++;
      const controller = new AbortController();
      const abort = () => controller.abort();
      options.signal?.addEventListener("abort", abort, { once: true });
      if (options.signal?.aborted) controller.abort();
      let timedOut = false;
      const timeout = setTimeout(() => {
        timedOut = true;
        abort();
      }, 2e4);
      try {
        let response;
        for (let attempt = 0; ; attempt++) {
          response = await fetch(url.href, {
            method: "GET",
            credentials: "include",
            cache: "no-store",
            redirect: "error",
            headers: { Accept: "application/json" },
            signal: controller.signal
          });
          const throttled = response.status === 429 || response.status === 403 && response.headers.get("X-Rate-Limit-Remaining") === "0";
          if (!throttled || attempt >= 2) break;
          const retryAfter = response.headers.get("Retry-After");
          const seconds = retryAfter === null ? NaN : Number(retryAfter);
          const requestedDelay = Number.isFinite(seconds) ? seconds * 1e3 : retryAfter ? Date.parse(retryAfter) - Date.now() : NaN;
          const delay = Math.min(1e4, Math.max(0, Number.isFinite(requestedDelay) ? requestedDelay : 500 * 2 ** attempt));
          await response.body?.cancel();
          options.onProgress?.("Canvas is busy. Retrying your sync\u2026");
          await new Promise((resolve, reject) => {
            const cancel = () => {
              clearTimeout(timer);
              reject(new DOMException("Canvas sync was cancelled.", "AbortError"));
            };
            const timer = setTimeout(() => {
              controller.signal.removeEventListener("abort", cancel);
              resolve();
            }, delay);
            controller.signal.addEventListener("abort", cancel, { once: true });
            if (controller.signal.aborted) cancel();
          });
        }
        if (response.status === 401) throw new CanvasAuthenticationError();
        if (!response.ok) {
          const status = response.status === 403 && response.headers.get("X-Rate-Limit-Remaining") === "0" ? 429 : response.status;
          throw new CanvasEndpointError(status, `Canvas returned HTTP ${status}.`);
        }
        let data;
        try {
          const body = (await response.text()).replace(/^\s*while\s*\(\s*1\s*\)\s*;\s*/, "");
          data = JSON.parse(body);
        } catch {
          throw new CanvasAuthenticationError();
        }
        if (data?.errors || data?.status === "unauthorized") throw new CanvasEndpointError(403, "Canvas denied access to this section.");
        if (data?.message && !data.id && !Array.isArray(data)) throw new CanvasEndpointError(403, String(data.message));
        return { data, headers: response.headers };
      } catch (error) {
        if (timedOut && !options.signal?.aborted) throw new CanvasEndpointError(0, "Canvas took too long to respond. Refresh to try again.");
        throw error;
      } finally {
        clearTimeout(timeout);
        options.signal?.removeEventListener("abort", abort);
        const nextWaiter = waiters.shift();
        if (nextWaiter) nextWaiter();
        else active--;
      }
    };
    const all = async (path2) => {
      const result = [];
      let next = new URL(path2, origin).href;
      const visited = /* @__PURE__ */ new Set();
      for (let page = 0; next && page < MAX_PAGES; page++) {
        if (visited.has(next)) throw new Error("Canvas returned a repeated pagination page.");
        visited.add(next);
        const { data, headers } = await get(next);
        if (!Array.isArray(data)) throw new Error("Canvas returned an unexpected list response.");
        result.push(...data);
        const match = headers.get("Link")?.match(/<([^>]+)>\s*;\s*rel="?next"?/);
        next = match?.[1] ? new URL(match[1], origin).href : null;
      }
      if (next) throw new Error("This Canvas section is too large to sync completely.");
      return result;
    };
    const query = (path2, params = {}) => {
      const url = new URL(path2, origin);
      url.searchParams.set("per_page", "100");
      for (const [key, value] of Object.entries(params)) {
        for (const item of Array.isArray(value) ? value : [value]) url.searchParams.append(key, item);
      }
      return url.href;
    };
    options.onProgress?.("Connecting to your Canvas account\u2026");
    const profile = (await get("/api/v1/users/self/profile")).data;
    if (!profile?.id) throw new CanvasAuthenticationError();
    const courseList = await all(query("/api/v1/courses", {
      enrollment_type: "student",
      enrollment_state: "active",
      "include[]": ["total_scores", "syllabus_body"]
    }));
    const studentCourses = courseList.filter((c3) => studentEnrollment(c3) && c3.workflow_state !== "deleted");
    studentCourses.sort((a4, b2) => Number(String(b2.id) === options.courseId) - Number(String(a4.id) === options.courseId));
    const issues = [];
    let loaded = 0;
    const loadCourse = async (raw) => {
      const id = String(raw.id);
      const courseIssues = [];
      const materialFailures = /* @__PURE__ */ new Map();
      const optional = async (section, path2) => {
        try {
          return await all(path2);
        } catch (error) {
          if (error instanceof CanvasAuthenticationError || isAbort(error)) throw error;
          courseIssues.push({ courseId: id, section, message: message(error) });
          return [];
        }
      };
      const materialIndex = async (section, path2) => {
        try {
          return await all(path2);
        } catch (error) {
          if (error instanceof CanvasAuthenticationError || isAbort(error)) throw error;
          const expected = error instanceof CanvasEndpointError && [403, 404].includes(error.status);
          materialFailures.set(section, expected ? `Canvas does not expose this course's ${section} index (HTTP ${error.status}).` : message(error));
          if (!expected) courseIssues.push({ courseId: id, section, message: message(error) });
          return [];
        }
      };
      try {
        const prefix = `/api/v1/courses/${encodeURIComponent(id)}`;
        const [groups, assignments, selfSubmissions] = await Promise.all([
          all(query(`${prefix}/assignment_groups`)),
          all(query(`${prefix}/assignments`, { "include[]": ["submission", "rubric"] })),
          optional("Submissions", query(`${prefix}/students/submissions`, { "student_ids[]": "self", "include[]": ["rubric_assessment", "submission_comments"] }))
        ]);
        const normalizedAssignments = adapter.parseAssignments(assignments);
        const byAssignment = new Map(assignments.filter((a4) => a4.submission).map((a4) => [String(a4.id), a4.submission]));
        for (const submission of selfSubmissions) byAssignment.set(String(submission.assignment_id), submission);
        const normalizedSubmissions = adapter.parseSubmissions([...byAssignment.values()]).map((submission) => {
          const source = byAssignment.get(submission.assignmentId);
          if (source?.rubric_assessment && typeof source.rubric_assessment === "object") {
            submission.rubricAssessment = Object.fromEntries(Object.entries(source.rubric_assessment).map(([key, value]) => [key, {
              points: Math.max(0, Number(value.points) || 0),
              ratingId: value.rating_id == null ? void 0 : String(value.rating_id),
              comments: typeof value.comments === "string" ? value.comments : void 0
            }]));
          }
          if (Array.isArray(source?.submission_comments)) {
            submission.submissionComments = source.submission_comments.map((c3) => ({ authorName: String(c3.author_name ?? "Instructor"), comment: String(c3.comment ?? ""), createdAt: c3.created_at }));
          }
          return submission;
        });
        const submissionMap = new Map(normalizedSubmissions.map((s3) => [s3.assignmentId, s3]));
        const [modules, pages, files, announcements, calendarEvents, enrollments, tabs] = await Promise.all([
          optional("Modules", query(`${prefix}/modules`, { "include[]": ["items"] })),
          materialIndex("Pages", query(`${prefix}/pages`)),
          materialIndex("Files", query(`${prefix}/files`)),
          optional("Announcements", query("/api/v1/announcements", { "context_codes[]": `course_${id}` })),
          optional("Calendar", query("/api/v1/calendar_events", { "context_codes[]": `course_${id}` })),
          optional("Grade totals", query(`${prefix}/enrollments`, { user_id: "self", "type[]": "StudentEnrollment" })),
          // Navigation visibility describes the index, not permissions on individual module items.
          all(query(`${prefix}/tabs`)).catch((error) => {
            if (error instanceof CanvasAuthenticationError || isAbort(error)) throw error;
            return [];
          })
        ]);
        await Promise.all(modules.filter(visibleToStudent).map(async (module) => {
          if (typeof module.items_count === "number" && module.items_count > (module.items?.length ?? 0)) {
            module.items = await optional("Module items", query(`${prefix}/modules/${module.id}/items`));
          }
        }));
        const enrollment = enrollments.find((e3) => String(e3.user_id) === String(profile.id) && (e3.type === "StudentEnrollment" || e3.role === "StudentEnrollment")) ?? studentEnrollment(raw) ?? {};
        const resourceMap = /* @__PURE__ */ new Map();
        const blockedResourceKeys = /* @__PURE__ */ new Set();
        const addResource = (key, resource) => {
          if (!blockedResourceKeys.has(key) && !resourceMap.has(key)) resourceMap.set(key, resource);
        };
        const pageKey = (slug, pageId) => `page:${String(slug ?? pageId)}`;
        const modulePageSlug = (item) => item.page_url ?? (typeof item.html_url === "string" ? new URL(sameOriginUrl(item.html_url, `/courses/${id}/modules/items/${item.id}`, origin)).pathname.match(/\/pages\/([^/]+)\/?$/)?.[1] : void 0);
        for (const file of files.filter((f4) => !visibleToStudent(f4))) blockedResourceKeys.add(`file:${file.id}`);
        for (const page of pages.filter((p3) => !visibleToStudent(p3))) blockedResourceKeys.add(pageKey(page.url, page.page_id));
        for (const module of modules) {
          for (const item of Array.isArray(module.items) ? module.items : []) {
            if (visibleToStudent(module) && visibleToStudent(item)) continue;
            if (item.type === "File" && item.content_id != null) blockedResourceKeys.add(`file:${item.content_id}`);
            if (item.type === "Page" && modulePageSlug(item)) blockedResourceKeys.add(pageKey(modulePageSlug(item), item.content_id));
          }
        }
        for (const page of pages.filter(visibleToStudent)) {
          addResource(pageKey(page.url, page.page_id), {
            id: String(page.page_id ?? page.url),
            type: "page",
            title: String(page.title ?? "Page"),
            url: sameOriginUrl(page.html_url, `/courses/${id}/pages/${encodeURIComponent(page.url ?? "")}`, origin),
            source: "index"
          });
        }
        for (const file of files.filter(visibleToStudent)) {
          addResource(`file:${file.id}`, {
            id: String(file.id),
            type: "file",
            title: String(file.display_name ?? file.filename ?? "File"),
            url: `${origin}/courses/${id}/files/${file.id}`,
            source: "index"
          });
        }
        for (const module of modules.filter(visibleToStudent)) {
          addResource(`module:${module.id}`, {
            id: String(module.id),
            type: "module",
            title: String(module.name ?? "Module"),
            url: `${origin}/courses/${id}/modules#module_${module.id}`,
            source: "module"
          });
          for (const item of Array.isArray(module.items) ? module.items : []) {
            if (!["Page", "File"].includes(item.type) || !visibleToStudent(item)) continue;
            const type = item.type === "File" ? "file" : "page";
            const slug = modulePageSlug(item);
            const key = type === "file" ? `file:${item.content_id ?? `module-item-${item.id}`}` : pageKey(slug, item.content_id ?? `module-item-${item.id}`);
            addResource(key, {
              id: `module-item-${item.id}`,
              type,
              title: String(item.title ?? "Course resource"),
              url: sameOriginUrl(item.html_url, `/courses/${id}/modules/items/${item.id}`, origin),
              source: "module"
            });
          }
        }
        const courseHtml = [raw.syllabus_body, ...assignments.map((a4) => a4.description), ...announcements.map((a4) => a4.message)];
        for (const html of courseHtml) {
          if (typeof html !== "string") continue;
          for (const resource of courseLinkedResources(html, id, origin)) addResource(`${resource.type}:${resource.id}`, resource);
        }
        const resources = [...resourceMap.values()];
        const materialAccess = ["Pages", "Files"].map((section) => {
          const type = section === "Pages" ? "page" : "file";
          const count = resources.filter((r3) => r3.type === type).length;
          const failure = materialFailures.get(section);
          const navigation = tabs.find((t3) => t3.id === section.toLowerCase());
          const reason = failure && navigation?.hidden === true ? `The ${section} navigation tab is hidden. ${failure}` : failure;
          return { section, status: failure ? count > 0 ? "module-links" : "unavailable" : "direct", count, reason };
        });
        let courseForAdapter = raw;
        if (Number(raw.grading_standard_id) > 0 && !Array.isArray(raw.grading_standard) && !Array.isArray(raw.grading_scheme)) {
          try {
            const standard = (await get(`${prefix}/grading_standards/${raw.grading_standard_id}`)).data;
            if (Array.isArray(standard?.grading_scheme)) courseForAdapter = { ...raw, grading_scheme: standard.grading_scheme };
          } catch (error) {
            if (error instanceof CanvasAuthenticationError || isAbort(error)) throw error;
            courseIssues.push({ courseId: id, section: "Grading scheme", message: message(error) });
          }
        }
        const input = {
          course: adapter.parseCourse(courseForAdapter, 3),
          groups: adapter.parseAssignmentGroups(groups),
          assignments: normalizedAssignments,
          submissions: normalizedSubmissions,
          priorityWeight: 1
        };
        return {
          id,
          name: String(raw.name),
          code: String(raw.course_code ?? raw.name),
          url: `${origin}/courses/${id}`,
          syllabusHtml: typeof raw.syllabus_body === "string" ? raw.syllabus_body : "",
          input,
          currentScore: numberOrNull(enrollment.grades?.current_score ?? enrollment.computed_current_score),
          finalScore: numberOrNull(enrollment.grades?.final_score ?? enrollment.computed_final_score),
          assignments: normalizedAssignments.map((assignment, i3) => ({
            ...assignment,
            htmlUrl: sameOriginUrl(assignments[i3]?.html_url, `/courses/${id}/assignments/${assignment.id}`, origin),
            descriptionHtml: typeof assignments[i3]?.description === "string" ? assignments[i3].description : "",
            submission: submissionMap.get(assignment.id) ?? null
          })),
          resources,
          materialAccess,
          announcements: announcements.map((a4) => ({ id: String(a4.id), title: String(a4.title ?? "Announcement"), bodyHtml: String(a4.message ?? ""), postedAt: a4.posted_at ?? null, url: sameOriginUrl(a4.html_url, `/courses/${id}/discussion_topics/${a4.id}`, origin) })),
          calendarEvents: calendarEvents.map((e3) => ({ id: String(e3.id), title: String(e3.title ?? "Calendar event"), startAt: e3.start_at ?? null, endAt: e3.end_at ?? null, url: sameOriginUrl(e3.html_url, `/courses/${id}`, origin) })),
          issues: courseIssues
        };
      } catch (error) {
        if (error instanceof CanvasAuthenticationError || isAbort(error)) throw error;
        issues.push({ courseId: id, section: String(raw.name ?? "Course"), message: message(error) });
        return null;
      } finally {
        loaded++;
        options.onProgress?.(`Synced ${loaded} of ${studentCourses.length} courses\u2026`);
      }
    };
    const courses = [];
    for (let offset = 0; offset < studentCourses.length; offset += 3) {
      const batch = await Promise.all(studentCourses.slice(offset, offset + 3).map(loadCourse));
      courses.push(...batch.filter((c3) => c3 !== null));
    }
    return {
      origin,
      syncedAt: (/* @__PURE__ */ new Date()).toISOString(),
      user: { id: String(profile.id), name: String(profile.name ?? "Canvas student"), shortName: String(profile.short_name ?? profile.name ?? "Student"), avatarUrl: typeof profile.avatar_url === "string" ? profile.avatar_url : void 0 },
      courses,
      issues
    };
  }

  // core/grade.ts
  function determineDroppedAssignments(items, rules) {
    if (items.length === 0) {
      return { dropped: [], kept: [] };
    }
    const neverDropSet = new Set(rules.neverDrop);
    const droppableCandidates = items.filter(
      (item) => !item.isNeverDrop && !neverDropSet.has(item.assignmentId)
    );
    const lockedItems = items.filter(
      (item) => item.isNeverDrop || neverDropSet.has(item.assignmentId)
    );
    if (droppableCandidates.length === 0 || rules.dropLowest === 0 && rules.dropHighest === 0) {
      return { dropped: [], kept: items };
    }
    let remainingCandidates = [...droppableCandidates];
    const droppedIds = [];
    const dropHighestCount = Math.min(rules.dropHighest, remainingCandidates.length);
    for (let d3 = 0; d3 < dropHighestCount; d3++) {
      if (remainingCandidates.length === 0) break;
      let bestIndex = 0;
      let worstResultingRatio = Infinity;
      for (let i3 = 0; i3 < remainingCandidates.length; i3++) {
        const testRemaining = [
          ...lockedItems,
          ...remainingCandidates.filter((_3, idx) => idx !== i3)
        ];
        const sumEarned = testRemaining.reduce((acc, it) => acc + it.score, 0);
        const sumPossible = testRemaining.reduce((acc, it) => acc + it.pointsPossible, 0);
        const ratio = sumPossible > 0 ? sumEarned / sumPossible : 0;
        if (ratio < worstResultingRatio) {
          worstResultingRatio = ratio;
          bestIndex = i3;
        }
      }
      const removed = remainingCandidates.splice(bestIndex, 1)[0];
      droppedIds.push(removed.assignmentId);
    }
    const dropLowestCount = Math.min(rules.dropLowest, remainingCandidates.length);
    for (let d3 = 0; d3 < dropLowestCount; d3++) {
      if (remainingCandidates.length === 0) break;
      let bestIndex = 0;
      let bestResultingRatio = -Infinity;
      for (let i3 = 0; i3 < remainingCandidates.length; i3++) {
        const candidate = remainingCandidates[i3];
        const testRemaining = [
          ...lockedItems,
          ...remainingCandidates.filter((_3, idx) => idx !== i3)
        ];
        const sumEarned = testRemaining.reduce((acc, it) => acc + it.score, 0);
        const sumPossible = testRemaining.reduce((acc, it) => acc + it.pointsPossible, 0);
        const ratio = sumPossible > 0 ? sumEarned / sumPossible : 1;
        if (ratio > bestResultingRatio) {
          bestResultingRatio = ratio;
          bestIndex = i3;
        } else if (ratio === bestResultingRatio) {
          const currentBest = remainingCandidates[bestIndex];
          if (candidate.pointsPossible > currentBest.pointsPossible) {
            bestIndex = i3;
          }
        }
      }
      const removed = remainingCandidates.splice(bestIndex, 1)[0];
      droppedIds.push(removed.assignmentId);
    }
    const kept = [...lockedItems, ...remainingCandidates];
    return { dropped: droppedIds, kept };
  }
  function getLetterGrade(percentage, scheme) {
    const sortedScheme = [...scheme].sort((a4, b2) => b2.minPct - a4.minPct);
    for (const item of sortedScheme) {
      if (percentage >= item.minPct) {
        return item.letter;
      }
    }
    return sortedScheme[sortedScheme.length - 1]?.letter ?? "F";
  }
  function getGradePoints(letter, scale) {
    return scale[letter] ?? 0;
  }
  function computeCanvasGrade(course, groups, assignments, submissions, options = {}) {
    const {
      includeUnposted = false,
      treatUnsubmittedAsZero = false,
      roundingDecimals = 2
    } = options;
    const submissionMap = /* @__PURE__ */ new Map();
    for (const sub2 of submissions) {
      submissionMap.set(sub2.assignmentId, sub2);
    }
    const assignmentMap = /* @__PURE__ */ new Map();
    for (const assign of assignments) {
      assignmentMap.set(assign.id, assign);
    }
    const groupBreakdowns = [];
    const allDroppedAssignmentIds = [];
    let grandTotalEarned = 0;
    let grandTotalPossible = 0;
    for (const group of groups) {
      const groupAssignments = assignments.filter((a4) => a4.groupId === group.id);
      const gradedItems = [];
      for (const assign of groupAssignments) {
        if (assign.omitFromFinalGrade) {
          continue;
        }
        const sub2 = submissionMap.get(assign.id);
        if (sub2?.excused) {
          continue;
        }
        let score2 = null;
        if (sub2 && !sub2.posted && !includeUnposted) {
          if (treatUnsubmittedAsZero) {
            score2 = 0;
          } else {
            continue;
          }
        }
        if (score2 === null) {
          if (sub2 && sub2.score !== null) {
            score2 = sub2.score;
          } else if (treatUnsubmittedAsZero) {
            score2 = 0;
          }
        }
        if (score2 !== null) {
          const isNeverDrop = group.rules.neverDrop.includes(assign.id);
          gradedItems.push({
            assignmentId: assign.id,
            name: assign.name,
            score: score2,
            pointsPossible: assign.pointsPossible,
            isNeverDrop
          });
        }
      }
      const { dropped, kept } = determineDroppedAssignments(gradedItems, group.rules);
      allDroppedAssignmentIds.push(...dropped);
      const pointsEarned = kept.reduce((acc, it) => acc + it.score, 0);
      const pointsPossible = kept.reduce((acc, it) => acc + it.pointsPossible, 0);
      const percentage = pointsPossible > 0 ? pointsEarned / pointsPossible * 100 : null;
      grandTotalEarned += pointsEarned;
      grandTotalPossible += pointsPossible;
      groupBreakdowns.push({
        groupId: group.id,
        groupName: group.name,
        weight: group.weight,
        pointsEarned,
        pointsPossible,
        percentage,
        droppedAssignmentIds: dropped,
        keptAssignmentIds: kept.map((it) => it.assignmentId),
        assignmentCount: groupAssignments.length,
        gradedCount: gradedItems.length
      });
    }
    let finalPercentage = null;
    if (course.applyGroupWeights) {
      let weightedEarnedSum = 0;
      let activeWeightTotal = 0;
      for (const bg of groupBreakdowns) {
        if (bg.percentage !== null) {
          weightedEarnedSum += bg.percentage * bg.weight / 100;
          activeWeightTotal += bg.weight;
        } else if (bg.pointsPossible === 0 && bg.pointsEarned > 0) {
          weightedEarnedSum += bg.pointsEarned;
        }
      }
      if (activeWeightTotal > 0) {
        finalPercentage = weightedEarnedSum / (activeWeightTotal / 100);
      }
    } else {
      if (grandTotalPossible > 0) {
        finalPercentage = grandTotalEarned / grandTotalPossible * 100;
      }
    }
    if (finalPercentage !== null) {
      const factor = Math.pow(10, roundingDecimals);
      finalPercentage = Math.round(finalPercentage * factor) / factor;
    }
    const letterGrade = finalPercentage !== null ? getLetterGrade(finalPercentage, course.gradingScheme) : null;
    const gradePoints = letterGrade !== null ? getGradePoints(letterGrade, course.gradePointScale) : null;
    return {
      percentage: finalPercentage,
      letterGrade,
      gradePoints,
      totalPointsEarned: Math.round(grandTotalEarned * 100) / 100,
      totalPointsPossible: Math.round(grandTotalPossible * 100) / 100,
      groups: groupBreakdowns,
      droppedAssignmentIds: allDroppedAssignmentIds,
      groupWeightsApplied: course.applyGroupWeights,
      creditHours: course.creditHours
    };
  }

  // core/gradeModel.ts
  function currentGrade(courseData, options) {
    return computeCanvasGrade(
      courseData.course,
      courseData.groups,
      courseData.assignments,
      courseData.submissions,
      {
        treatUnsubmittedAsZero: false,
        includeUnposted: false,
        roundingDecimals: 2,
        ...options
      }
    );
  }

  // core/optimiserPriors.ts
  var DEFAULT_TASK_PRIORS = {
    homework: {
      taskType: "homework",
      cap: 0.98,
      tau: 3,
      noiseSigma: 0.05,
      alphaLogged: 0.15
    },
    problem_set: {
      taskType: "problem_set",
      cap: 0.96,
      tau: 4,
      noiseSigma: 0.06,
      alphaLogged: 0.15
    },
    essay: {
      taskType: "essay",
      cap: 0.94,
      tau: 6,
      noiseSigma: 0.07,
      alphaLogged: 0.12
    },
    exam: {
      taskType: "exam",
      cap: 0.92,
      tau: 8,
      noiseSigma: 0.08,
      alphaLogged: 0.1
    },
    quiz: {
      taskType: "quiz",
      cap: 0.95,
      tau: 2,
      noiseSigma: 0.05,
      alphaLogged: 0.18
    },
    project: {
      taskType: "project",
      cap: 0.95,
      tau: 10,
      noiseSigma: 0.07,
      alphaLogged: 0.1
    },
    default: {
      taskType: "default",
      cap: 0.95,
      tau: 4,
      noiseSigma: 0.06,
      alphaLogged: 0.14
    }
  };
  function inferTaskType(assignmentName, submissionTypes, groupName) {
    const combined = `${assignmentName} ${groupName ?? ""}`.toLowerCase();
    if (combined.includes("quiz")) {
      return "quiz";
    }
    if (combined.includes("exam") || combined.includes("midterm") || combined.includes("final exam") || combined.includes("test")) {
      return "exam";
    }
    if (combined.includes("essay") || combined.includes("paper") || combined.includes("report") || combined.includes("critique")) {
      return "essay";
    }
    if (combined.includes("project") || combined.includes("proposal") || combined.includes("milestone") || combined.includes("presentation")) {
      return "project";
    }
    if (combined.includes("problem set") || combined.includes("pset") || combined.includes("problem-set")) {
      return "problem_set";
    }
    if (combined.includes("hw") || combined.includes("homework") || combined.includes("lab") || combined.includes("exercise")) {
      return "homework";
    }
    if (submissionTypes?.includes("online_quiz")) {
      return "quiz";
    }
    return "default";
  }
  function computeEffectiveTau(baseTau, loggedHours = 0, alphaLogged = 0.15, tauScale = 1) {
    const safeLogged = Math.max(0, loggedHours);
    const loggedMultiplier = Math.max(0.25, 1 / (1 + alphaLogged * safeLogged));
    return baseTau * tauScale * loggedMultiplier;
  }
  function expectedScoreFraction(hours, cap, tauEffective) {
    if (hours <= 0) return 0;
    if (tauEffective <= 0) return cap;
    return cap * (1 - Math.exp(-hours / tauEffective));
  }

  // core/optimiser.ts
  var SeededRandom = class {
    state;
    constructor(seed = 42) {
      this.state = seed >>> 0;
    }
    /** Uniform random float in [0, 1) */
    next() {
      let z4 = this.state += 1831565813;
      z4 = Math.imul(z4 ^ z4 >>> 15, z4 | 1);
      z4 ^= z4 + Math.imul(z4 ^ z4 >>> 7, z4 | 61);
      return ((z4 ^ z4 >>> 14) >>> 0) / 4294967296;
    }
    /** Standard Normal distribution N(0, 1) using Box-Muller transform */
    nextGaussian() {
      let u4 = 0;
      let v3 = 0;
      while (u4 === 0) u4 = this.next();
      while (v3 === 0) v3 = this.next();
      return Math.sqrt(-2 * Math.log(u4)) * Math.cos(2 * Math.PI * v3);
    }
  };
  function buildCourseEvalContext(input, options, tauScale = 1) {
    const { course, groups, assignments, submissions } = input;
    const loggedHoursMap = input.loggedHours ?? {};
    const studyEligibleIds = input.studyEligibleAssignmentIds === void 0 ? null : new Set(input.studyEligibleAssignmentIds);
    const creditHours = Math.max(0.5, course.creditHours ?? 3);
    const priorityWeight = Math.max(0.01, input.priorityWeight ?? 1);
    const subMap = new Map(submissions.map((s3) => [s3.assignmentId, s3]));
    const groupMap = new Map(groups.map((g3) => [g3.id, g3]));
    const fixedGroupItems = /* @__PURE__ */ new Map();
    const upcomingByGroup = /* @__PURE__ */ new Map();
    for (const g3 of groups) {
      fixedGroupItems.set(g3.id, []);
      upcomingByGroup.set(g3.id, []);
    }
    const allUpcoming = [];
    const nowTime = options.currentTime ? new Date(options.currentTime).getTime() : null;
    for (const assign of assignments) {
      if (assign.omitFromFinalGrade) continue;
      const sub2 = subMap.get(assign.id);
      if (sub2?.excused) continue;
      const group = groupMap.get(assign.groupId);
      if (!group) continue;
      const isNeverDrop = group.rules.neverDrop.includes(assign.id);
      if (sub2 && sub2.score !== null && sub2.posted) {
        fixedGroupItems.get(group.id).push({
          assignmentId: assign.id,
          name: assign.name,
          score: sub2.score,
          pointsPossible: assign.pointsPossible,
          isNeverDrop
        });
        continue;
      }
      const taskType = inferTaskType(assign.name, assign.submissionTypes, group.name);
      const basePrior = DEFAULT_TASK_PRIORS[taskType] ?? DEFAULT_TASK_PRIORS["default"];
      const customPrior = options.customPriors?.[taskType];
      const cap = customPrior?.cap ?? basePrior.cap;
      const baseTau = customPrior?.tau ?? basePrior.tau;
      const noiseSigma = customPrior?.noiseSigma ?? basePrior.noiseSigma;
      const alphaLogged = customPrior?.alphaLogged ?? basePrior.alphaLogged;
      const logged = loggedHoursMap[assign.id] ?? 0;
      const tauEff = computeEffectiveTau(baseTau, logged, alphaLogged, tauScale);
      let isPastDeadline = false;
      if (nowTime !== null && assign.dueAt) {
        const dueTime = new Date(assign.dueAt).getTime();
        if (dueTime <= nowTime) {
          isPastDeadline = true;
        }
      }
      const isStudyEligible = studyEligibleIds === null || studyEligibleIds.has(assign.id);
      const maxH = isPastDeadline || !isStudyEligible ? 0 : Math.min(options.maxHoursPerAssignment ?? 8, 24);
      const meta = {
        uniqueKey: `${course.id}::${assign.id}`,
        assignmentId: assign.id,
        assignmentName: assign.name,
        courseId: course.id,
        courseName: course.name,
        groupId: group.id,
        groupName: group.name,
        pointsPossible: assign.pointsPossible,
        taskType,
        cap,
        tauEffective: tauEff,
        noiseSigma,
        dueAt: assign.dueAt ?? null,
        isEligible: !isPastDeadline && maxH > 0,
        minHours: options.minHoursPerAssignment ?? 0,
        maxHours: maxH
      };
      upcomingByGroup.get(group.id).push(meta);
      allUpcoming.push(meta);
    }
    return {
      course,
      groups,
      creditHours,
      priorityWeight,
      fixedGroupItems,
      upcomingByGroup,
      allUpcoming
    };
  }
  function evaluateCourseMonteCarlo(ctx, hoursMap, noiseMatrix, numSamples) {
    const { course, groups, fixedGroupItems, upcomingByGroup } = ctx;
    const samplePercentages = new Float64Array(numSamples);
    const sampleGpas = new Float64Array(numSamples);
    let sumGpa = 0;
    let sumPct = 0;
    const fastGroups = groups.map((g3) => {
      const fixed = fixedGroupItems.get(g3.id) ?? [];
      const upcomingList = upcomingByGroup.get(g3.id) ?? [];
      const fixedEarned = fixed.reduce((acc, it) => acc + it.score, 0);
      const fixedPossible = fixed.reduce((acc, it) => acc + it.pointsPossible, 0);
      const hasDropRules = g3.rules.dropLowest > 0 || g3.rules.dropHighest > 0;
      let upcomingPossibleSum = 0;
      const fastUpcoming = [];
      for (const it of upcomingList) {
        const h3 = hoursMap.get(it.uniqueKey) ?? 0;
        const mu = expectedScoreFraction(h3, it.cap, it.tauEffective);
        const zArr = noiseMatrix.get(it.uniqueKey);
        const isNeverDrop = g3.rules.neverDrop.includes(it.assignmentId);
        upcomingPossibleSum += it.pointsPossible;
        fastUpcoming.push({
          meta: it,
          mu,
          sigma: it.noiseSigma,
          pts: it.pointsPossible,
          h: h3,
          zArray: zArr,
          isNeverDrop
        });
      }
      return {
        group: g3,
        hasDropRules,
        fixedEarned,
        fixedPossible,
        fixedItems: fixed,
        upcoming: fastUpcoming,
        upcomingPossibleSum
      };
    });
    const dropBuffer = [];
    for (let s3 = 0; s3 < numSamples; s3++) {
      let grandEarned = 0;
      let grandPossible = 0;
      let weightedEarnedSum = 0;
      let activeWeightSum = 0;
      for (let gIdx = 0; gIdx < fastGroups.length; gIdx++) {
        const fg = fastGroups[gIdx];
        let groupEarned = 0;
        let groupPossible = 0;
        if (!fg.hasDropRules) {
          groupEarned = fg.fixedEarned;
          for (let uIdx = 0; uIdx < fg.upcoming.length; uIdx++) {
            const up = fg.upcoming[uIdx];
            if (up.h > 0) {
              const z4 = up.zArray[s3];
              const frac = Math.min(1, Math.max(0, up.mu + up.sigma * z4));
              groupEarned += frac * up.pts;
            }
          }
          groupPossible = fg.fixedPossible + fg.upcomingPossibleSum;
        } else {
          dropBuffer.length = 0;
          for (let fIdx = 0; fIdx < fg.fixedItems.length; fIdx++) {
            dropBuffer.push(fg.fixedItems[fIdx]);
          }
          for (let uIdx = 0; uIdx < fg.upcoming.length; uIdx++) {
            const up = fg.upcoming[uIdx];
            let score2 = 0;
            if (up.h > 0) {
              const z4 = up.zArray[s3];
              const frac = Math.min(1, Math.max(0, up.mu + up.sigma * z4));
              score2 = frac * up.pts;
            }
            dropBuffer.push({
              assignmentId: up.meta.assignmentId,
              name: up.meta.assignmentName,
              score: score2,
              pointsPossible: up.pts,
              isNeverDrop: up.isNeverDrop
            });
          }
          const { kept } = determineDroppedAssignments(dropBuffer, fg.group.rules);
          for (let k3 = 0; k3 < kept.length; k3++) {
            groupEarned += kept[k3].score;
            groupPossible += kept[k3].pointsPossible;
          }
        }
        grandEarned += groupEarned;
        grandPossible += groupPossible;
        if (groupPossible > 0 && fg.group.weight > 0) {
          const groupPct = groupEarned / groupPossible * 100;
          weightedEarnedSum += groupPct * fg.group.weight;
          activeWeightSum += fg.group.weight;
        }
      }
      let finalPct = 0;
      if (course.applyGroupWeights) {
        finalPct = activeWeightSum > 0 ? weightedEarnedSum / activeWeightSum : 0;
      } else {
        finalPct = grandPossible > 0 ? grandEarned / grandPossible * 100 : 0;
      }
      samplePercentages[s3] = finalPct;
      const letter = getLetterGrade(finalPct, course.gradingScheme);
      const gpa = getGradePoints(letter, course.gradePointScale);
      sampleGpas[s3] = gpa;
      sumPct += finalPct;
      sumGpa += gpa;
    }
    return {
      expectedGpa: sumGpa / numSamples,
      expectedPct: sumPct / numSamples,
      samplePercentages,
      sampleGpas
    };
  }
  function optimizeEffort(courseInputs, options) {
    const startTime = performance.now();
    const capacity = Math.max(0, options.capacityHours);
    const stepSize = options.stepSizeHours ?? 0.5;
    const numSamples = options.numSamples ?? 1e3;
    const seed = options.seed ?? 42;
    const tauScale = options.tauScale ?? 1;
    const rng = new SeededRandom(seed);
    const courseContexts = courseInputs.map(
      (input) => buildCourseEvalContext(input, options, tauScale)
    );
    const noiseMatrix = /* @__PURE__ */ new Map();
    for (const ctx of courseContexts) {
      for (const assign of ctx.allUpcoming) {
        const arr = new Float64Array(numSamples);
        for (let s3 = 0; s3 < numSamples; s3++) {
          arr[s3] = rng.nextGaussian();
        }
        noiseMatrix.set(assign.uniqueKey, arr);
      }
    }
    const totalWeightDenominator = courseContexts.reduce(
      (acc, ctx) => acc + ctx.priorityWeight * ctx.creditHours,
      0
    );
    const courseWeights = courseContexts.map(
      (ctx) => ctx.priorityWeight * ctx.creditHours / (totalWeightDenominator || 1)
    );
    const assignmentToCourseIdx = /* @__PURE__ */ new Map();
    const allEligibleUpcoming = [];
    courseContexts.forEach((ctx, idx) => {
      for (const it of ctx.allUpcoming) {
        assignmentToCourseIdx.set(it.uniqueKey, idx);
        if (it.isEligible) {
          allEligibleUpcoming.push(it);
        }
      }
    });
    const currentHours = /* @__PURE__ */ new Map();
    for (const it of allEligibleUpcoming) {
      currentHours.set(it.uniqueKey, 0);
    }
    let remainingCapacity = capacity;
    if (options.protectMastery && allEligibleUpcoming.length > 0) {
      const floorH = options.masteryFloorHours ?? 0.5;
      for (const it of allEligibleUpcoming) {
        if (remainingCapacity < floorH) break;
        const initialH = Math.min(floorH, it.maxHours);
        currentHours.set(it.uniqueKey, initialH);
        remainingCapacity -= initialH;
      }
    }
    const courseEvals = courseContexts.map(
      (ctx) => evaluateCourseMonteCarlo(ctx, currentHours, noiseMatrix, numSamples)
    );
    const baselineGpa = courseEvals.reduce(
      (acc, ev, idx) => acc + (courseWeights[idx] ?? 0) * ev.expectedGpa,
      0
    );
    const computeOverallSemesterGpa = () => {
      return courseEvals.reduce(
        (acc, ev, idx) => acc + (courseWeights[idx] ?? 0) * ev.expectedGpa,
        0
      );
    };
    while (remainingCapacity >= stepSize - 1e-6) {
      let bestAssignment = null;
      let bestGpaGain = -Infinity;
      let bestPctGain = -Infinity;
      let bestNewCourseEval = null;
      for (const it of allEligibleUpcoming) {
        const hCurr = currentHours.get(it.uniqueKey) ?? 0;
        if (hCurr + stepSize > it.maxHours + 1e-6) continue;
        const cIdx2 = assignmentToCourseIdx.get(it.uniqueKey);
        const ctx = courseContexts[cIdx2];
        const prevEval = courseEvals[cIdx2];
        const cWeight = courseWeights[cIdx2] ?? 0;
        currentHours.set(it.uniqueKey, hCurr + stepSize);
        const testEval = evaluateCourseMonteCarlo(ctx, currentHours, noiseMatrix, numSamples);
        currentHours.set(it.uniqueKey, hCurr);
        const marginalGpaGain = cWeight * (testEval.expectedGpa - prevEval.expectedGpa);
        const marginalPctGain = cWeight * (testEval.expectedPct - prevEval.expectedPct);
        if (marginalGpaGain > bestGpaGain + 1e-6 || Math.abs(marginalGpaGain - bestGpaGain) <= 1e-6 && marginalPctGain > bestPctGain) {
          bestGpaGain = marginalGpaGain;
          bestPctGain = marginalPctGain;
          bestAssignment = it;
          bestNewCourseEval = testEval;
        }
      }
      if (!bestAssignment || !bestNewCourseEval || bestGpaGain <= 0 && bestPctGain <= 0) {
        break;
      }
      const currH = currentHours.get(bestAssignment.uniqueKey) ?? 0;
      currentHours.set(bestAssignment.uniqueKey, currH + stepSize);
      remainingCapacity -= stepSize;
      const cIdx = assignmentToCourseIdx.get(bestAssignment.uniqueKey);
      courseEvals[cIdx] = bestNewCourseEval;
    }
    let swapImproved = true;
    let swapIterations = 0;
    const maxSwapIterations = 40;
    while (swapImproved && swapIterations < maxSwapIterations) {
      swapImproved = false;
      swapIterations++;
      for (const donor of allEligibleUpcoming) {
        const hDonor = currentHours.get(donor.uniqueKey) ?? 0;
        if (hDonor < stepSize - 1e-6) continue;
        for (const recipient of allEligibleUpcoming) {
          if (donor.uniqueKey === recipient.uniqueKey) continue;
          const hRecip = currentHours.get(recipient.uniqueKey) ?? 0;
          if (hRecip + stepSize > recipient.maxHours + 1e-6) continue;
          const dIdx = assignmentToCourseIdx.get(donor.uniqueKey);
          const rIdx = assignmentToCourseIdx.get(recipient.uniqueKey);
          const curGpa = computeOverallSemesterGpa();
          currentHours.set(donor.uniqueKey, hDonor - stepSize);
          currentHours.set(recipient.uniqueKey, hRecip + stepSize);
          const dEvalNew = evaluateCourseMonteCarlo(
            courseContexts[dIdx],
            currentHours,
            noiseMatrix,
            numSamples
          );
          let rEvalNew = dEvalNew;
          if (dIdx !== rIdx) {
            rEvalNew = evaluateCourseMonteCarlo(
              courseContexts[rIdx],
              currentHours,
              noiseMatrix,
              numSamples
            );
          }
          let proposedGpa = 0;
          for (let i3 = 0; i3 < courseContexts.length; i3++) {
            const w3 = courseWeights[i3] ?? 0;
            if (i3 === dIdx) proposedGpa += w3 * dEvalNew.expectedGpa;
            else if (i3 === rIdx) proposedGpa += w3 * rEvalNew.expectedGpa;
            else proposedGpa += w3 * courseEvals[i3].expectedGpa;
          }
          if (proposedGpa > curGpa + 1e-5) {
            courseEvals[dIdx] = dEvalNew;
            courseEvals[rIdx] = rEvalNew;
            swapImproved = true;
            break;
          } else {
            currentHours.set(donor.uniqueKey, hDonor);
            currentHours.set(recipient.uniqueKey, hRecip);
          }
        }
        if (swapImproved) break;
      }
    }
    const finalGpa = computeOverallSemesterGpa();
    const totalAllocated = capacity - remainingCapacity;
    const recommendations = [];
    for (const it of allEligibleUpcoming) {
      const hours = currentHours.get(it.uniqueKey) ?? 0;
      if (hours <= 0) continue;
      const cIdx = assignmentToCourseIdx.get(it.uniqueKey);
      const ctx = courseContexts[cIdx];
      const scoreFrac = expectedScoreFraction(hours, it.cap, it.tauEffective);
      const scorePct = Math.round(scoreFrac * 1e3) / 10;
      const withoutItHours = new Map(currentHours);
      withoutItHours.set(it.uniqueKey, 0);
      const baseCEval = evaluateCourseMonteCarlo(
        ctx,
        withoutItHours,
        noiseMatrix,
        numSamples
      );
      const finalCEval = courseEvals[cIdx];
      const cGain = Math.max(0, finalCEval.expectedGpa - baseCEval.expectedGpa);
      const marginalGpa = hours > 0 ? cGain / hours : 0;
      const baseLetter = getLetterGrade(baseCEval.expectedPct, ctx.course.gradingScheme);
      const optLetter = getLetterGrade(finalCEval.expectedPct, ctx.course.gradingScheme);
      let reason = "";
      if (baseLetter !== optLetter && cGain > 0.01) {
        reason = `Allocating ${hours.toFixed(1)}h elevates ${ctx.course.name.split(":")[0]} from a ${baseLetter} (${baseCEval.expectedPct.toFixed(1)}%) to ${optLetter} (${finalCEval.expectedPct.toFixed(1)}%), achieving a +${cGain.toFixed(2)} course grade-point increase.`;
      } else if (it.groupName.toLowerCase().includes("homework") || it.groupName.toLowerCase().includes("quiz")) {
        reason = `Allocating ${hours.toFixed(1)}h secures ${it.assignmentName} at ~${scorePct}%, protecting your ${it.groupName} group against drop-rule score penalties.`;
      } else {
        reason = `Allocating ${hours.toFixed(1)}h targets ~${scorePct}% on ${it.assignmentName} to buffer ${ctx.course.name.split(":")[0]} against test-day variance.`;
      }
      recommendations.push({
        assignmentId: it.assignmentId,
        assignmentName: it.assignmentName,
        courseId: it.courseId,
        courseName: it.courseName,
        allocatedHours: hours,
        expectedScorePct: scorePct,
        expectedGradePointGain: Math.round(cGain * 100) / 100,
        marginalGainPerHour: Math.round(marginalGpa * 1e3) / 1e3,
        reason
      });
    }
    recommendations.sort((a4, b2) => b2.allocatedHours - a4.allocatedHours);
    const thresholdAlerts = [];
    for (let i3 = 0; i3 < courseContexts.length; i3++) {
      const ctx = courseContexts[i3];
      const ev = courseEvals[i3];
      const curPct = ev.expectedPct;
      const curLetter = getLetterGrade(curPct, ctx.course.gradingScheme);
      const sortedScheme = [...ctx.course.gradingScheme].sort((a4, b2) => b2.minPct - a4.minPct);
      const curIdx = sortedScheme.findIndex((s3) => s3.letter === curLetter);
      if (curIdx > 0) {
        const nextThreshold = sortedScheme[curIdx - 1];
        const targetPct = nextThreshold.minPct;
        const pointsNeeded = Math.max(0, targetPct - curPct);
        let crossingSamples = 0;
        for (let s3 = 0; s3 < numSamples; s3++) {
          if (ev.samplePercentages[s3] >= targetPct) {
            crossingSamples++;
          }
        }
        const prob = crossingSamples / numSamples;
        const courseUpcoming = ctx.allUpcoming.filter((a4) => a4.isEligible);
        const allocatedInCourse = courseUpcoming.reduce(
          (acc, a4) => acc + (currentHours.get(a4.uniqueKey) ?? 0),
          0
        );
        const shortCourseName = ctx.course.name.split(":")[0] ?? ctx.course.name;
        const alertMessage = `${shortCourseName} is ${pointsNeeded.toFixed(2)} points under a ${nextThreshold.letter} (${targetPct.toFixed(1)}%); ${allocatedInCourse.toFixed(1)} hours likely crosses it (${Math.round(prob * 100)}% probability).`;
        thresholdAlerts.push({
          courseId: ctx.course.id,
          courseName: ctx.course.name,
          currentGradePct: Math.round(curPct * 100) / 100,
          currentLetter: curLetter,
          nextLetter: nextThreshold.letter,
          targetPct,
          pointsNeeded: Math.round(pointsNeeded * 100) / 100,
          hoursToLikelyCross: allocatedInCourse,
          probabilityOfCrossing: Math.round(prob * 100) / 100,
          alertMessage
        });
      }
    }
    let robustness;
    if (!options.isRobustnessRun) {
      robustness = computeRobustnessCheck(courseInputs, options, recommendations);
    } else {
      robustness = {
        confidence: "high",
        topAssignmentsMatch: true,
        details: "Internal perturbation run",
        perturbationResults: {
          fasterPace: { tauScale: 0.7, topAssignmentIds: [], expectedGpa: finalGpa },
          slowerPace: { tauScale: 1.3, topAssignmentIds: [], expectedGpa: finalGpa }
        }
      };
    }
    const runtimeMs = Math.round(performance.now() - startTime);
    return {
      totalCapacityHours: capacity,
      allocatedHours: Math.round(totalAllocated * 10) / 10,
      baselineExpectedGpa: Math.round(baselineGpa * 100) / 100,
      optimizedExpectedGpa: Math.round(finalGpa * 100) / 100,
      expectedGpaGain: Math.round((finalGpa - baselineGpa) * 100) / 100,
      recommendations,
      thresholdAlerts,
      robustness,
      metadata: {
        seed,
        numSamples,
        stepSizeHours: stepSize,
        runtimeMs,
        assumptionsUsed: {
          priors: DEFAULT_TASK_PRIORS,
          loggedHoursMultiplier: "tau_effective = tau * max(0.25, 1 / (1 + 0.15 * loggedHours))",
          noiseDistribution: "Truncated Normal N(0, sigma^2) clamped to [0, 1] via Box-Muller CRN"
        }
      }
    };
  }
  function computeRobustnessCheck(courseInputs, baseOptions, baseRecommendations) {
    const baseTopIds = baseRecommendations.slice(0, 2).map((r3) => r3.assignmentId);
    const optFaster = optimizeEffort(courseInputs, {
      ...baseOptions,
      tauScale: 0.7,
      isRobustnessRun: true,
      // Use slightly fewer samples for perturbation speed
      numSamples: Math.min(baseOptions.numSamples ?? 1e3, 500)
    });
    const fastTopIds = optFaster.recommendations.slice(0, 2).map((r3) => r3.assignmentId);
    const optSlower = optimizeEffort(courseInputs, {
      ...baseOptions,
      tauScale: 1.3,
      isRobustnessRun: true,
      numSamples: Math.min(baseOptions.numSamples ?? 1e3, 500)
    });
    const slowTopIds = optSlower.recommendations.slice(0, 2).map((r3) => r3.assignmentId);
    const fastTopMatches = baseTopIds.length === 0 || baseTopIds[0] === fastTopIds[0];
    const slowTopMatches = baseTopIds.length === 0 || baseTopIds[0] === slowTopIds[0];
    let confidence;
    let details;
    if (fastTopMatches && slowTopMatches) {
      confidence = "high";
      details = "High confidence: Top priority assignments remain identical even if individual study pace is 30% faster or slower than assumed.";
    } else if (fastTopMatches || slowTopMatches) {
      confidence = "medium";
      details = "Medium confidence: Top assignment recommendation is moderately sensitive to study pace variations.";
    } else {
      confidence = "low";
      details = "Low confidence: Prioritized coursework shifts significantly under varying learning speed assumptions.";
    }
    return {
      confidence,
      topAssignmentsMatch: fastTopMatches && slowTopMatches,
      details,
      perturbationResults: {
        fasterPace: {
          tauScale: 0.7,
          topAssignmentIds: fastTopIds,
          expectedGpa: optFaster.optimizedExpectedGpa
        },
        slowerPace: {
          tauScale: 1.3,
          topAssignmentIds: slowTopIds,
          expectedGpa: optSlower.optimizedExpectedGpa
        }
      }
    };
  }

  // extension/ui/workspaceStyles.ts
  var WORKSPACE_STYLES = `
:host{all:initial;color-scheme:light;font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#182037;font-size:14px;line-height:1.5}
*,*::before,*::after{box-sizing:border-box}
button,input,select,textarea{font:inherit}
button,a,input,select{touch-action:manipulation}
button,a,select{cursor:pointer}
button{color:inherit}
button{transition:background .18s,border-color .18s,color .18s,box-shadow .18s}
a{color:inherit;text-decoration:none}
button:disabled{cursor:wait;opacity:.6}
button:focus-visible,a:focus-visible,input:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid #2855e8;outline-offset:3px}
svg{display:block;flex-shrink:0}
h1,h2,h3,p{margin:0}
button{border:0}
input,select{max-width:100%}
 .gw,.g-launcher{font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
.gw{position:fixed;right:14px;top:14px;bottom:14px;width:min(480px,calc(100vw - 28px));z-index:2147483646;display:flex;flex-direction:column;background:#f7f8fc;border:1px solid #fff;border-radius:24px;box-shadow:0 14px 80px #111c3e30,0 0 0 1px #1c2b4d10;overflow:hidden;color:#182037;font-size:14px;line-height:1.5;isolation:isolate}
.gw.wide{width:min(860px,calc(100vw - 28px))}
.g-header{display:flex;align-items:center;gap:10px;padding:21px 24px 18px;background:#fff;border-bottom:1px solid #e9edf5;flex-shrink:0}
.g-brand{display:flex;gap:10px;align-items:center;flex:1}
.g-logo{display:grid;place-items:center;width:35px;height:35px;background:#2855e8;color:white;border-radius:11px}
.g-wordmark{font-weight:850;letter-spacing:-1.2px;font-size:23px;line-height:1}
.g-brand-sub{font-size:9px;font-weight:700;letter-spacing:1.7px;color:#667085;margin-top:5px;text-transform:uppercase}
.g-icon-btn{width:32px;height:32px;display:grid;place-items:center;background:transparent;color:#657087;border-radius:8px}
.g-icon-btn:hover{background:#eef2fa;color:#2855e8}
.g-status{padding:12px 24px 0;background:#fff;display:flex;align-items:center;justify-content:space-between;gap:8px;color:#536079;font-size:11px}
.g-live{display:flex;gap:6px;align-items:center;font-size:10px;font-weight:750;letter-spacing:.6px;text-transform:uppercase}
.g-dot{height:6px;width:6px;border-radius:50%;background:#16825c;box-shadow:0 0 0 3px #d9f8e8}
.g-demo-dot{background:#a66a12;box-shadow:0 0 0 3px #fff0cb}
.g-nav{display:flex;gap:3px;padding:15px 16px 16px;background:#fff;border-bottom:1px solid #e5e9f1;flex-shrink:0}
.g-tab{flex:1;min-width:0;display:flex;justify-content:center;gap:6px;align-items:center;padding:9px 4px;border-radius:9px;background:transparent;color:#657087;font-size:11px;font-weight:700;white-space:nowrap}
.g-tab.active{color:#2855e8;background:#edf2ff}
.g-tab:hover{background:#f2f5fb}
.g-body{padding:24px;overflow:auto;overscroll-behavior:contain;flex:1;min-height:0;scrollbar-width:thin;scrollbar-color:#ccd5e6 transparent}
.g-stack{display:flex;flex-direction:column;gap:20px}
.g-eyebrow{color:#66738b;font-size:10px;font-weight:750;letter-spacing:1.5px;text-transform:uppercase}
.g-title{font-size:29px;letter-spacing:-1.3px;line-height:1.14;font-weight:800;margin-top:6px}
.g-title .g-accent{color:#2855e8}
.g-subtitle{font-size:12px;line-height:1.65;color:#647087;margin-top:9px}
.g-greeting{display:flex;justify-content:space-between;gap:8px;align-items:flex-start}
.g-date{font-size:10px;color:#58647b;background:#fff;border:1px solid #e4e9f3;border-radius:8px;padding:6px 8px;white-space:nowrap;margin-top:3px;font-weight:600}
.g-metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px}
.g-metric{background:#fff;padding:16px 12px;border-radius:13px;border:1px solid #e5e9f1}
.g-metric strong{display:block;font-size:27px;font-weight:800;letter-spacing:-1px;line-height:1.25;margin-bottom:5px}
.g-metric small{font-size:10px;color:#5c6880;font-weight:600}
.g-metric.blue{background:#2855e8;border-color:#2855e8;color:#fff}
.g-metric.blue small{color:#e5ebff}
.g-metric.peach{background:#ffede6;border-color:#ffe2d6}
.g-metric.peach strong{color:#a83f20}
.g-section-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}
.g-section-head h2{font-size:15px;letter-spacing:-.3px;font-weight:750}
.g-label-count{font-size:10px;color:#647087;background:#eaf0f7;border-radius:6px;padding:3px 6px;font-weight:700}
.g-link-btn{background:transparent;font-size:11px;font-weight:700;color:#2855e8;display:flex;align-items:center;gap:4px;padding:3px 0}
.g-course-list{display:grid;grid-template-columns:minmax(0,1fr);gap:9px;min-width:0}
.g-course{width:100%;min-width:0;text-align:left;display:flex;gap:12px;align-items:center;padding:15px;background:white;border:1px solid #e5e9f1;border-radius:13px}
.g-course:hover{border-color:#a5b9f7;background:#fcfdff}
.g-course-symbol{white-space:nowrap;height:37px;width:37px;border-radius:10px;display:grid;place-items:center;font-size:11px;font-weight:800;background:var(--tint);color:var(--ink);flex-shrink:0}
.g-course-info{min-width:0;flex:1}
.g-course-info strong{display:block;font-size:12px;font-weight:750;line-height:1.4;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.g-course-info small{font-size:10px;color:#647087}
.g-track{height:4px;background:#edf0f6;border-radius:99px;margin-top:8px;overflow:hidden}
.g-track span{display:block;height:100%;background:var(--ink,#2855e8);border-radius:99px}
.g-course-score{flex-shrink:0;font-weight:800;font-size:17px;letter-spacing:-.5px}
.g-course-score small{display:block;font-size:9px;font-weight:500;color:#647087;text-align:right;letter-spacing:0}
.g-task{display:flex;align-items:flex-start;gap:12px;padding:13px 0;border-bottom:1px solid #e9edf4}
.g-task:last-child{border-bottom:0;padding-bottom:0}
.g-task:first-child{padding-top:0}
.g-task-marker{height:30px;width:30px;display:grid;place-items:center;background:#edf2ff;color:#2855e8;border-radius:8px;flex-shrink:0;margin-top:2px}
.g-task-main{flex:1;min-width:0}
.g-task-main strong{display:block;font-size:12px;font-weight:650;line-height:1.5}
.g-task-main a:hover{color:#2855e8}
.g-task-meta{font-size:10px;color:#66738b;display:flex;flex-wrap:wrap;align-items:center;gap:5px;margin-top:4px}
.g-due{font-size:9px;font-weight:750;color:#9c411d;background:#ffecdf;padding:3px 6px;border-radius:5px;white-space:nowrap}
.g-due.normal{color:#426080;background:#edf2f7}
.g-card{background:#fff;border:1px solid #e5e9f1;border-radius:16px;padding:19px}
.g-plan{border:0;background:#edf3ff;position:relative;overflow:hidden}
.g-plan h2{font-size:20px;letter-spacing:-.7px;line-height:1.2;max-width:220px}
.g-plan .g-subtitle{max-width:270px;font-size:11px}
.g-plan-mark{position:absolute;right:20px;top:17px;height:52px;width:52px;border-radius:16px;background:#dbe6ff;color:#2855e8;display:grid;place-items:center;transform:rotate(-9deg)}
.g-plan-controls{display:flex;align-items:center;gap:10px;margin-top:18px}
.g-hours{display:flex;align-items:center;gap:7px;background:#fff;border:1px solid #dbe3f5;border-radius:9px;padding:7px 9px;font-size:11px;color:#5b6880}
.g-hours input{width:38px;border:0;background:transparent;color:#182037;font-weight:750;padding:0}
.g-primary{display:flex;align-items:center;justify-content:center;gap:7px;padding:10px 14px;background:#2855e8;border:1px solid #2855e8;color:#fff;border-radius:9px;font-size:11px;font-weight:700;min-height:37px}
.g-primary:hover{background:#1740c8;border-color:#1740c8}
.g-secondary{display:flex;align-items:center;justify-content:center;gap:7px;background:#fff;border:1px solid #dbe1ed;border-radius:9px;padding:9px 12px;font-size:11px;font-weight:700;min-height:36px}
.g-secondary:hover{background:#f0f4ff;border-color:#b7c8fa}
.g-notice{display:flex;align-items:flex-start;gap:8px;font-size:11px;line-height:1.6;padding:11px 12px;border-radius:9px;background:#fff4df;color:#7f5520}
.g-notice.info{background:#eaf2ff;color:#345276}
.g-notice.success{background:#e7f6ed;color:#276345}
.g-small{font-size:10px;color:#647087;line-height:1.7}
.g-select{width:100%;padding:11px 12px;background:#fff;border:1px solid #dce3ee;border-radius:10px;color:#182037;font-size:12px}
.g-field-label{font-size:11px;font-weight:700;margin-bottom:7px;display:block}
.g-toolbar{display:flex;gap:8px}
.g-search{display:flex;gap:8px;align-items:center;flex:1;background:#fff;border:1px solid #dce3ee;border-radius:10px;padding:10px 12px;color:#647087}
.g-search input{width:100%;min-width:0;border:0;outline:0;background:transparent;color:#182037;font-size:12px;padding:0}
.g-chips{display:flex;gap:6px;flex-wrap:wrap}
.g-chip{font-size:10px;font-weight:700;border-radius:7px;padding:6px 9px;background:#fff;border:1px solid #e2e7f0;color:#5e6c84}
.g-chip.active{background:#2855e8;border-color:#2855e8;color:white}
.g-grade-card{background:#2855e8;color:#fff;display:flex;align-items:center;gap:24px;padding:24px;border-radius:16px}
.g-grade-ring{height:98px;width:98px;border-radius:50%;padding:7px;background:conic-gradient(#c4f69c calc(var(--grade,0)*1%),#ffffff30 0);flex-shrink:0}
.g-grade-ring>div{height:100%;width:100%;border-radius:50%;background:#2855e8;display:flex;flex-direction:column;align-items:center;justify-content:center}
.g-grade-ring strong{font-size:20px;letter-spacing:-.7px;white-space:nowrap}
.g-grade-ring small{font-size:7px;white-space:nowrap;color:#e0e8ff;text-transform:uppercase;font-weight:700;letter-spacing:.5px}
.g-grade-info h2{font-size:15px;line-height:1.4;font-weight:700;letter-spacing:-.3px}
.g-grade-info p{font-size:10px;color:#dce5ff;margin-top:7px}
.g-grade-info span{font-size:9px;background:#ffffff20;display:inline-flex;gap:4px;align-items:center;padding:3px 6px;border-radius:5px;margin-top:9px}
.g-range{width:100%;accent-color:#2855e8;cursor:pointer;margin:17px 0 8px}
.g-whatif-result{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px}
.g-whatif-result>div{background:#f4f6fb;border-radius:9px;padding:12px}
.g-whatif-result strong{display:block;font-size:22px;font-weight:750;letter-spacing:-.8px}
.g-whatif-result small{font-size:10px;color:#647087}
.g-resource{display:flex;gap:11px;padding:14px 0;border-bottom:1px solid #e9edf4}
.g-resource:last-child{border:0;padding-bottom:0}
.g-resource:first-child{padding-top:0}
.g-resource:hover strong{color:#2855e8}
.g-resource-icon{height:34px;width:34px;background:#f0f3fa;color:#5b6c8d;border-radius:9px;display:grid;place-items:center;flex-shrink:0}
.g-resource>span:nth-child(2){flex:1;min-width:0}
.g-resource strong{font-size:12px;display:block;font-weight:650}
.g-resource small{font-size:10px;color:#647087;text-transform:capitalize}
.g-announcement{padding:13px 0;border-bottom:1px solid #e9edf4}
.g-announcement:first-child{padding-top:0}
.g-announcement:last-child{padding-bottom:0;border:0}
.g-announcement summary{font-size:12px;font-weight:650;cursor:pointer;line-height:1.5}
.g-announcement p{font-size:11px;color:#5e6b81;white-space:pre-line;margin-top:9px;max-height:220px;overflow:auto}
.g-announcement a{font-size:10px;color:#2855e8;display:inline-block;margin-top:8px;font-weight:700}
.g-empty{text-align:center;padding:32px 18px;color:#66738b;font-size:12px}
.g-empty-icon{display:grid;place-items:center;height:48px;width:48px;margin:0 auto 14px;background:#edf2ff;border-radius:14px;color:#2855e8}
.g-empty h2{font-size:16px;color:#182037;letter-spacing:-.4px;margin-bottom:6px}
.g-empty p{line-height:1.7;max-width:280px;margin:0 auto}
.g-footer{border-top:1px solid #e5e9f1;padding:11px 24px;background:#fff;display:flex;align-items:center;justify-content:space-between;color:#66738b;font-size:9px;flex-shrink:0}
.g-footer>span{display:flex;gap:5px;align-items:center}
.g-user{height:22px;width:22px;background:#f6e9dc;color:#785733;border-radius:50%;display:grid;place-items:center;font-size:9px;font-weight:750}
.g-launcher{position:fixed;right:20px;bottom:22px;z-index:2147483646;border-radius:18px;background:#2855e8;color:white;padding:14px 19px;display:flex;align-items:center;gap:10px;box-shadow:0 6px 32px #173bbc50;font-weight:750;font-size:14px;border:1px solid #ffffff45}
.g-launcher:hover{background:#1740c8}
.g-setting-row{display:flex;justify-content:space-between;align-items:center;gap:14px;padding:12px 0;border-bottom:1px solid #e9edf4;font-size:11px}
.g-setting-row:last-child{border:0}
.g-setting-row span{color:#647087}
.g-setting-row strong{font-weight:650;overflow-wrap:anywhere;text-align:right}
.g-credit{width:55px;border:1px solid #dce3ee;border-radius:7px;padding:5px 7px;font-size:11px}
.g-credits label{font-size:11px;display:flex;justify-content:space-between;align-items:center;gap:12px;padding:9px 0}
.g-plan-result{margin-top:14px}
.g-plan-result .g-task{border-color:#dce5f7}
.g-plan-result .g-task-marker{background:white}
.g-skeleton{height:92px;border-radius:13px;background:linear-gradient(100deg,#e9edf5 20%,#f8faff 45%,#e9edf5 70%);background-size:220% 100%;animation:g-shimmer 1.6s infinite}
.g-sync-loading{display:flex;gap:8px;align-items:center;color:#2855e8;font-size:11px;margin-bottom:12px}
.g-spinner{animation:g-spin 1.2s linear infinite}
.g-resource-count{font-size:29px;font-weight:800;letter-spacing:-1px;color:#2855e8}
.g-syllabus{font-size:12px;line-height:1.8;color:#536079;white-space:pre-line;max-height:330px;overflow:auto}
.g-title-row{display:flex;justify-content:space-between;align-items:flex-end;gap:14px}
.g-version{font-size:9px;color:#647087;letter-spacing:.5px}
.g-overview-grid>section{min-width:0;width:100%}.g-overview-grid{display:flex;flex-direction:column;gap:20px}
.wide .g-overview-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);align-items:start}
.wide .g-overview-grid>section:first-child{grid-row:span 2}
.wide .g-title{font-size:34px}
.wide .g-metric{padding:20px}
.wide .g-nav{gap:12px}
.wide .g-tab{font-size:12px}
.wide .g-course{padding:17px}
.wide .g-plan h2{max-width:210px}
.g-issue-details{font-size:11px;color:#7f5520;background:#fff4df;border-radius:10px;padding:11px 13px}
.g-issue-details summary{cursor:pointer;font-weight:650}
.g-issue-details ul{margin:9px 0 0;padding-left:16px;line-height:1.7}
.g-assignment-description{font-size:12px;color:#536079;line-height:1.8;white-space:pre-line;max-height:230px;overflow:auto;margin-top:13px}
.g-legend{display:flex;justify-content:space-between;font-size:10px;color:#647087}
.g-gradient-art{display:flex;align-items:flex-end;gap:4px;position:absolute;right:18px;bottom:23px;pointer-events:none;opacity:.3}
.g-gradient-art i{display:block;width:8px;border-radius:3px;background:#2855e8}
.g-gradient-art i:nth-child(1){height:14px}
.g-gradient-art i:nth-child(2){height:24px}
.g-gradient-art i:nth-child(3){height:36px}
.g-gradient-art i:nth-child(4){height:50px}
.g-gradient-art i:nth-child(5){height:63px}
.g-plan-controls{position:relative;z-index:1}
.g-bottom-note{font-size:10px;color:#647087;display:flex;gap:6px;align-items:center}
.g-loading-sub{font-size:11px;color:#647087;margin-top:9px}
.g-course-link{font-size:10px;font-weight:700;color:#2855e8;display:inline-flex;gap:4px;align-items:center}
.g-bold-number{font-variant-numeric:tabular-nums}
.g-course-menu{display:flex;gap:9px;align-items:center}
.g-course-menu .g-select{flex:1;min-width:0}

.g-feedback-summary{cursor:pointer;font-size:13px;font-weight:750;line-height:1.6}.g-feedback-summary>span:last-child{margin-left:10px;vertical-align:middle}.g-rubric-list{margin-top:14px}.g-rubric-criterion{padding:15px 0;border-top:1px solid #e9edf4}.g-rubric-criterion:last-child{padding-bottom:0}.g-rubric-criterion h3{font-size:12px;font-weight:700;line-height:1.6}.g-rubric-criterion .g-section-head{align-items:flex-start}.g-rubric-criterion .g-label-count{flex-shrink:0}.g-ratings-summary{font-size:11px;color:#2855e8;font-weight:650;cursor:pointer}.g-rubric-ratings{list-style:none;margin:9px 0 0;padding:0;background:#f7f8fc;border:1px solid #e9edf4;border-radius:9px;overflow:hidden}.g-rubric-ratings li{padding:10px 11px;border-bottom:1px solid #e9edf4;font-size:11px;line-height:1.65;display:flex;gap:12px;align-items:flex-start;color:#536079}.g-rubric-ratings li:last-child{border:0}.g-rubric-ratings li>span{flex:1;min-width:0}.g-rubric-ratings strong{white-space:nowrap;font-size:10px;font-weight:700;color:#34425d}.g-feedback-comments{margin-top:17px;padding-top:15px;border-top:1px solid #e9edf4}.g-feedback-comments h3{font-size:12px;font-weight:750}.g-instructor-comment{padding:12px 0;border-bottom:1px solid #e9edf4}.g-instructor-comment:last-child{border:0;padding-bottom:0}.g-comment-author{display:flex;gap:10px;justify-content:space-between;font-size:10px;color:#536079}.g-comment-author strong{font-weight:700;color:#34425d}.g-comment-author time{flex-shrink:0}.g-instructor-comment p{font-size:12px;line-height:1.75;color:#536079;white-space:pre-line;margin-top:6px}
@keyframes g-shimmer{to{background-position:-220% 0}
}
@keyframes g-spin{to{transform:rotate(360deg)}
}
@media(max-width:600px){.gw,.gw.wide{right:0;top:0;bottom:0;width:100vw;border-radius:0;border:0}
.g-header{padding:17px 18px}
.g-status{padding:11px 18px 0}
.g-nav{padding:13px 18px}
.g-body{padding:21px 18px}
.g-footer{padding:11px 18px}
.g-title{font-size:28px}
.g-date{display:none}
.wide .g-overview-grid{display:flex}
.g-tab{gap:4px;font-size:10px}
.g-tab svg{width:14px}
.g-grade-card{padding:20px;gap:17px}
.g-plan-mark{right:15px}
.g-metric{padding:14px 11px}
.g-wordmark{font-size:22px}
.g-launcher{right:14px;bottom:14px}
.g-hide-mobile{display:none}
}
@media(max-width:400px){.g-tab svg{display:none}.g-grade-card{gap:13px}.g-grade-ring{height:88px;width:88px}.g-grade-ring strong{font-size:20px}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}
}

`;
  var ASSISTANT_ENTRY_STYLES = `
.g-assistant-entry{display:flex;align-items:center;gap:12px;text-align:left;border-radius:14px;border:1px solid #dbe3f5;background:#edf3ff;color:#182037;padding:17px 16px;width:100%}
.g-assistant-entry:hover{background:#e5edff;border-color:#b7c8fa}.g-assistant-entry>span:nth-child(2){flex:1;min-width:0}
.g-assistant-entry strong{display:block;font-size:12px;line-height:1.5}.g-assistant-entry small{display:block;margin-top:4px;color:#647087;font-size:10px;line-height:1.6}
.g-assistant-entry-icon{display:grid;place-items:center;width:38px;height:38px;background:#2855e8;border:1px solid #2855e8;border-radius:12px;color:#fff;flex-shrink:0}
@media(max-width:420px){.g-nav{padding-left:10px;padding-right:10px;gap:1px}.g-tab{font-size:10px;gap:3px}.g-tab svg{width:13px;height:13px}}
`;

  // node_modules/preact/jsx-runtime/dist/jsxRuntime.mjs
  var f3 = Symbol.for("pv");
  var o3 = 0;
  var u3 = Array.isArray;
  function a3(t3, e3, n2, u4, a4, i3) {
    e3 || (e3 = {});
    var c3, l3, p3 = e3;
    if ("ref" in p3 && "function" != typeof t3) for (l3 in p3 = {}, e3) "ref" == l3 ? c3 = e3[l3] : p3[l3] = e3[l3];
    var s3 = { type: t3, props: p3, key: n2, ref: c3, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: f3, __v: --o3, __i: -1, __u: 0 };
    return (a4 || i3) && (s3.__source = a4, s3.__self = i3), n.vnode && n.vnode(s3), s3;
  }

  // extension/ui/Icons.tsx
  var paths = {
    grid: "M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z",
    book: "M4 4h6a3 3 0 0 1 3 3v14a4 4 0 0 0-4-3H4z M20 4h-4a3 3 0 0 0-3 3 M20 4v14h-3a4 4 0 0 0-4 3",
    folder: "M3 7V5a2 2 0 0 1 2-2h5l2 3h7a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
    settings: "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M9 3l-1 3-3 1-2 3 2 2v3l3 2 1 3h5l1-3 3-1 2-3-2-2v-3l-3-2-1-3z",
    arrow: "M5 12h14 M13 6l6 6-6 6",
    refresh: "M20 7v5h-5 M4 17v-5h5 M6 6a8 8 0 0 1 13 2 M18 18a8 8 0 0 1-13-2",
    close: "M6 6l12 12 M18 6L6 18",
    expand: "M9 3H3v6 M3 3l7 7 M15 21h6v-6 M21 21l-7-7",
    collapse: "M5 12h14",
    calendar: "M5 4h14a2 2 0 0 1 2 2v14H3V6a2 2 0 0 1 2-2z M7 2v5 M17 2v5 M3 10h18 M7 14h2 M12 14h2 M7 17h2",
    clock: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18 M12 7v5l3 2",
    check: "M5 12l4 4L19 6",
    shield: "M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6z M8 12l3 3 5-6",
    search: "M10.5 3a7.5 7.5 0 1 0 0 15 7.5 7.5 0 0 0 0-15 M16 16l5 5",
    file: "M5 3h9l5 5v13H5z M14 3v6h5 M9 13h6 M9 17h6",
    layers: "M12 3L2 8l10 5 10-5z M2 12l10 5 10-5 M2 16l10 5 10-5",
    bolt: "M13 2L4 14h7l-1 8 10-13h-8z",
    chart: "M4 20V4 M4 20h17 M8 15l4-5 4 2 5-7",
    alert: "M12 3L2 21h20z M12 9v5 M12 17v1",
    download: "M12 3v12 M7 10l5 5 5-5 M4 16v5h16v-5",
    chevron: "M9 5l7 7-7 7",
    external: "M14 3h7v7 M21 3L10 14 M10 3H3v18h18v-7",
    spark: "M12 2l2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5z",
    user: "M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M4 21v-3a6 6 0 0 1 6-6h4a6 6 0 0 1 6 6v3"
  };
  function Icon({ name, size = 18, className = "" }) {
    return /* @__PURE__ */ a3("svg", { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": "1.7", "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true", class: className, children: /* @__PURE__ */ a3("path", { d: paths[name] }) });
  }

  // extension/ui/MaterialAccess.tsx
  function MaterialAccess({ courses, compact = false }) {
    const sections = courses.flatMap((course) => (course.materialAccess ?? []).filter((access) => access.status !== "direct").map((access) => ({ course, access })));
    if (!sections.length) return null;
    return /* @__PURE__ */ a3("section", { class: "g-card", role: "region", "aria-label": "Material access", children: [
      /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
        /* @__PURE__ */ a3("h2", { children: compact ? "Material access" : "Course materials" }),
        /* @__PURE__ */ a3(Icon, { name: "folder", size: 17 })
      ] }),
      /* @__PURE__ */ a3("p", { class: "g-small", style: { marginBottom: "12px" }, children: "Some instructors hide the Pages or Files index. GRADIENT also finds material links in modules, the syllabus, and coursework." }),
      /* @__PURE__ */ a3("div", { style: { display: "grid", gap: "12px" }, children: sections.map(({ course, access }) => /* @__PURE__ */ a3("div", { style: { borderTop: "1px solid #e5e9f1", paddingTop: "11px" }, children: [
        !compact && /* @__PURE__ */ a3("div", { class: "g-small", style: { marginBottom: "4px" }, children: course.code }),
        /* @__PURE__ */ a3("strong", { style: { display: "block", fontSize: "12px", color: access.count ? "#187352" : "#536079" }, children: [
          access.section,
          " \xB7 ",
          access.count > 0 ? `${access.count} linked ${access.count === 1 ? "resource" : "resources"}` : "Not available in this course"
        ] }),
        /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "4px" }, children: access.reason }),
        access.count > 0 && /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "3px" }, children: "Linked materials are listed in the course library. Canvas checks access when you open each item." })
      ] }, `${course.id}-${access.section}`)) })
    ] });
  }

  // node_modules/katex/dist/katex.mjs
  var ParseError = class _ParseError extends Error {
    // The underlying error message without any context added.
    constructor(message2, token) {
      var error = "KaTeX parse error: " + message2;
      var start;
      var end;
      var loc = token && token.loc;
      if (loc && loc.start <= loc.end) {
        var input = loc.lexer.input;
        start = loc.start;
        end = loc.end;
        if (start === input.length) {
          error += " at end of input: ";
        } else {
          error += " at position " + (start + 1) + ": ";
        }
        var underlined = input.slice(start, end).replace(/[^]/g, "$&\u0332");
        var left;
        if (start > 15) {
          left = "\u2026" + input.slice(start - 15, start);
        } else {
          left = input.slice(0, start);
        }
        var right;
        if (end + 15 < input.length) {
          right = input.slice(end, end + 15) + "\u2026";
        } else {
          right = input.slice(end);
        }
        error += left + underlined + right;
      }
      super(error);
      this.name = "ParseError";
      this.position = void 0;
      this.length = void 0;
      this.rawMessage = void 0;
      Object.setPrototypeOf(this, _ParseError.prototype);
      this.position = start;
      if (start != null && end != null) {
        this.length = end - start;
      }
      this.rawMessage = message2;
    }
  };
  var uppercase = /([A-Z])/g;
  var hyphenate = (str) => str.replace(uppercase, "-$1").toLowerCase();
  var ESCAPE_LOOKUP = {
    "&": "&amp;",
    ">": "&gt;",
    "<": "&lt;",
    '"': "&quot;",
    "'": "&#x27;"
  };
  var ESCAPE_REGEX = /[&><"']/g;
  var escape = (text2) => String(text2).replace(ESCAPE_REGEX, (match) => ESCAPE_LOOKUP[match]);
  var getBaseElem = (group) => {
    if (group.type === "ordgroup") {
      if (group.body.length === 1) {
        return getBaseElem(group.body[0]);
      } else {
        return group;
      }
    } else if (group.type === "color") {
      if (group.body.length === 1) {
        return getBaseElem(group.body[0]);
      } else {
        return group;
      }
    } else if (group.type === "font") {
      return getBaseElem(group.body);
    } else {
      return group;
    }
  };
  var characterNodesTypes = /* @__PURE__ */ new Set(["mathord", "textord", "atom"]);
  var isCharacterBox = (group) => characterNodesTypes.has(getBaseElem(group).type);
  var protocolFromUrl = (url) => {
    var protocol = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(url);
    if (!protocol) {
      return "_relative";
    }
    if (protocol[2] !== ":") {
      return null;
    }
    if (!/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(protocol[1])) {
      return null;
    }
    return protocol[1].toLowerCase();
  };
  var SETTINGS_SCHEMA = {
    displayMode: {
      type: "boolean",
      description: "Render math in display mode, which puts the math in display style (so \\int and \\sum are large, for example), and centers the math on the page on its own line.",
      cli: "-d, --display-mode"
    },
    output: {
      type: {
        enum: ["htmlAndMathml", "html", "mathml"]
      },
      description: "Determines the markup language of the output.",
      cli: "-F, --format <type>"
    },
    leqno: {
      type: "boolean",
      description: "Render display math in leqno style (left-justified tags)."
    },
    fleqn: {
      type: "boolean",
      description: "Render display math flush left."
    },
    throwOnError: {
      type: "boolean",
      default: true,
      cli: "-t, --no-throw-on-error",
      cliDescription: "Render errors (in the color given by --error-color) instead of throwing a ParseError exception when encountering an error."
    },
    errorColor: {
      type: "string",
      default: "#cc0000",
      cli: "-c, --error-color <color>",
      cliDescription: "A color string given in the format 'rgb' or 'rrggbb' (no #). This option determines the color of errors rendered by the -t option.",
      cliProcessor: (color) => "#" + color
    },
    macros: {
      type: "object",
      cli: "-m, --macro <def>",
      cliDescription: "Define custom macro of the form '\\foo:expansion' (use multiple -m arguments for multiple macros).",
      cliDefault: [],
      cliProcessor: (def, defs) => {
        defs.push(def);
        return defs;
      }
    },
    minRuleThickness: {
      type: "number",
      description: "Specifies a minimum thickness, in ems, for fraction lines, `\\sqrt` top lines, `{array}` vertical lines, `\\hline`, `\\hdashline`, `\\underline`, `\\overline`, and the borders of `\\fbox`, `\\boxed`, and `\\fcolorbox`.",
      processor: (t3) => Math.max(0, t3),
      cli: "--min-rule-thickness <size>",
      cliProcessor: parseFloat
    },
    colorIsTextColor: {
      type: "boolean",
      description: "Makes \\color behave like LaTeX's 2-argument \\textcolor, instead of LaTeX's one-argument \\color mode change.",
      cli: "-b, --color-is-text-color"
    },
    strict: {
      type: [{
        enum: ["warn", "ignore", "error"]
      }, "boolean", "function"],
      description: "Turn on strict / LaTeX faithfulness mode, which throws an error if the input uses features that are not supported by LaTeX.",
      cli: "-S, --strict",
      cliDefault: false
    },
    trust: {
      type: ["boolean", "function"],
      description: "Trust the input, enabling all HTML features such as \\url.",
      cli: "-T, --trust"
    },
    maxSize: {
      type: "number",
      default: Infinity,
      description: "If non-zero, all user-specified sizes, e.g. in \\rule{500em}{500em}, will be capped to maxSize ems. Otherwise, elements and spaces can be arbitrarily large",
      processor: (s3) => Math.max(0, s3),
      cli: "-s, --max-size <n>",
      cliProcessor: parseInt
    },
    maxExpand: {
      type: "number",
      default: 1e3,
      description: "Limit the number of macro expansions to the specified number, to prevent e.g. infinite macro loops. If set to Infinity, the macro expander will try to fully expand as in LaTeX.",
      processor: (n2) => Math.max(0, n2),
      cli: "-e, --max-expand <n>",
      cliProcessor: (n2) => n2 === "Infinity" ? Infinity : parseInt(n2)
    },
    globalGroup: {
      type: "boolean",
      cli: false
    }
  };
  function getImplicitDefault(type) {
    if (typeof type !== "string") {
      return type.enum[0];
    }
    switch (type) {
      case "boolean":
        return false;
      case "string":
        return "";
      case "number":
        return 0;
      case "object":
        return {};
      default:
        throw new Error("Unexpected schema type; settings must declare an explicit default.");
    }
  }
  function getDefaultValue(schema) {
    if (Object.prototype.hasOwnProperty.call(schema, "default") && schema.default !== void 0) {
      return schema.default;
    }
    var type = Array.isArray(schema.type) ? schema.type[0] : schema.type;
    return getImplicitDefault(type);
  }
  function applySetting(target, prop, options, schema) {
    var optionValue = Object.prototype.hasOwnProperty.call(options, prop) ? options[prop] : void 0;
    var processor = Object.prototype.hasOwnProperty.call(schema, "processor") ? schema.processor : void 0;
    target[prop] = optionValue !== void 0 ? processor ? processor(optionValue) : optionValue : getDefaultValue(schema);
  }
  var Settings = class {
    constructor(options) {
      if (options === void 0) {
        options = {};
      }
      this.displayMode = void 0;
      this.output = void 0;
      this.leqno = void 0;
      this.fleqn = void 0;
      this.throwOnError = void 0;
      this.errorColor = void 0;
      this.macros = void 0;
      this.minRuleThickness = void 0;
      this.colorIsTextColor = void 0;
      this.strict = void 0;
      this.trust = void 0;
      this.maxSize = void 0;
      this.maxExpand = void 0;
      this.globalGroup = void 0;
      options = options || {};
      for (var prop of Object.keys(SETTINGS_SCHEMA)) {
        var schema = SETTINGS_SCHEMA[prop];
        if (schema) {
          applySetting(this, prop, options, schema);
        }
      }
    }
    /**
     * Check whether to test potentially dangerous input, and return
     * `true` (trusted) or `false` (untrusted).  The sole argument `context`
     * should be an object with `command` field specifying the relevant LaTeX
     * command (as a string starting with `\`), and any other arguments, etc.
     * If `context` has a `url` field, a `protocol` field will automatically
     * get added by this function (changing the specified object).
     */
    isTrusted(context) {
      if ("url" in context && context.url && !context.protocol) {
        var protocol = protocolFromUrl(context.url);
        if (protocol == null) {
          return false;
        }
        context.protocol = protocol;
      }
      var trust = typeof this.trust === "function" ? this.trust(context) : this.trust;
      return Boolean(trust);
    }
  };
  var Style = class {
    constructor(id, size, cramped) {
      this.id = void 0;
      this.size = void 0;
      this.cramped = void 0;
      this.id = id;
      this.size = size;
      this.cramped = cramped;
    }
    /**
     * Get the style of a superscript given a base in the current style.
     */
    sup() {
      return styles[sup[this.id]];
    }
    /**
     * Get the style of a subscript given a base in the current style.
     */
    sub() {
      return styles[sub[this.id]];
    }
    /**
     * Get the style of a fraction numerator given the fraction in the current
     * style.
     */
    fracNum() {
      return styles[fracNum[this.id]];
    }
    /**
     * Get the style of a fraction denominator given the fraction in the current
     * style.
     */
    fracDen() {
      return styles[fracDen[this.id]];
    }
    /**
     * Get the cramped version of a style (in particular, cramping a cramped style
     * doesn't change the style).
     */
    cramp() {
      return styles[cramp[this.id]];
    }
    /**
     * Get a text or display version of this style.
     */
    text() {
      return styles[text$1[this.id]];
    }
    /**
     * Return true if this style is tightly spaced (scriptstyle/scriptscriptstyle)
     */
    isTight() {
      return this.size >= 2;
    }
  };
  var D3 = 0;
  var Dc = 1;
  var T3 = 2;
  var Tc = 3;
  var S2 = 4;
  var Sc = 5;
  var SS = 6;
  var SSc = 7;
  var styles = [new Style(D3, 0, false), new Style(Dc, 0, true), new Style(T3, 1, false), new Style(Tc, 1, true), new Style(S2, 2, false), new Style(Sc, 2, true), new Style(SS, 3, false), new Style(SSc, 3, true)];
  var sup = [S2, Sc, S2, Sc, SS, SSc, SS, SSc];
  var sub = [Sc, Sc, Sc, Sc, SSc, SSc, SSc, SSc];
  var fracNum = [T3, Tc, S2, Sc, SS, SSc, SS, SSc];
  var fracDen = [Tc, Tc, Sc, Sc, SSc, SSc, SSc, SSc];
  var cramp = [Dc, Dc, Tc, Tc, Sc, Sc, SSc, SSc];
  var text$1 = [D3, Dc, T3, Tc, T3, Tc, T3, Tc];
  var Style$1 = {
    DISPLAY: styles[D3],
    TEXT: styles[T3],
    SCRIPT: styles[S2],
    SCRIPTSCRIPT: styles[SS]
  };
  var scriptData = [{
    // Latin characters beyond the Latin-1 characters we have metrics for.
    // Needed for Czech, Hungarian and Turkish text, for example.
    name: "latin",
    blocks: [
      [256, 591],
      // Latin Extended-A and Latin Extended-B
      [768, 879]
      // Combining Diacritical marks
    ]
  }, {
    // The Cyrillic script used by Russian and related languages.
    // A Cyrillic subset used to be supported as explicitly defined
    // symbols in symbols.js
    name: "cyrillic",
    blocks: [[1024, 1279]]
  }, {
    // Armenian
    name: "armenian",
    blocks: [[1328, 1423]]
  }, {
    // The Brahmic scripts of South and Southeast Asia
    // Devanagari (0900–097F)
    // Bengali (0980–09FF)
    // Gurmukhi (0A00–0A7F)
    // Gujarati (0A80–0AFF)
    // Oriya (0B00–0B7F)
    // Tamil (0B80–0BFF)
    // Telugu (0C00–0C7F)
    // Kannada (0C80–0CFF)
    // Malayalam (0D00–0D7F)
    // Sinhala (0D80–0DFF)
    // Thai (0E00–0E7F)
    // Lao (0E80–0EFF)
    // Tibetan (0F00–0FFF)
    // Myanmar (1000–109F)
    name: "brahmic",
    blocks: [[2304, 4255]]
  }, {
    name: "georgian",
    blocks: [[4256, 4351]]
  }, {
    // Chinese and Japanese.
    // The "k" in cjk is for Korean, but we've separated Korean out
    name: "cjk",
    blocks: [
      [12288, 12543],
      // CJK symbols and punctuation, Hiragana, Katakana
      [19968, 40879],
      // CJK ideograms
      [65280, 65376]
      // Fullwidth punctuation
      // TODO: add halfwidth Katakana and Romanji glyphs
    ]
  }, {
    // Korean
    name: "hangul",
    blocks: [[44032, 55215]]
  }];
  function scriptFromCodepoint(codepoint) {
    for (var i3 = 0; i3 < scriptData.length; i3++) {
      var script2 = scriptData[i3];
      for (var _i = 0; _i < script2.blocks.length; _i++) {
        var block = script2.blocks[_i];
        if (codepoint >= block[0] && codepoint <= block[1]) {
          return script2.name;
        }
      }
    }
    return null;
  }
  var allBlocks = [];
  scriptData.forEach((s3) => s3.blocks.forEach((b2) => allBlocks.push(...b2)));
  function supportedCodepoint(codepoint) {
    for (var i3 = 0; i3 < allBlocks.length; i3 += 2) {
      if (codepoint >= allBlocks[i3] && codepoint <= allBlocks[i3 + 1]) {
        return true;
      }
    }
    return false;
  }
  var doubleBrushStroke = (svgPath) => svgPath + " " + svgPath;
  var hLinePad = 80;
  var sqrtMain = function sqrtMain2(extraVinculum, hLinePad2) {
    return "M95," + (622 + extraVinculum + hLinePad2) + "\nc-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14\nc0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54\nc44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10\ns173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429\nc69,-144,104.5,-217.7,106.5,-221\nl" + extraVinculum / 2.075 + " -" + extraVinculum + "\nc5.3,-9.3,12,-14,20,-14\nH400000v" + (40 + extraVinculum) + "H845.2724\ns-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7\nc-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z\nM" + (834 + extraVinculum) + " " + hLinePad2 + "h400000v" + (40 + extraVinculum) + "h-400000z";
  };
  var sqrtSize1 = function sqrtSize12(extraVinculum, hLinePad2) {
    return "M263," + (601 + extraVinculum + hLinePad2) + "c0.7,0,18,39.7,52,119\nc34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120\nc340,-704.7,510.7,-1060.3,512,-1067\nl" + extraVinculum / 2.084 + " -" + extraVinculum + "\nc4.7,-7.3,11,-11,19,-11\nH40000v" + (40 + extraVinculum) + "H1012.3\ns-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232\nc-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1\ns-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26\nc-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z\nM" + (1001 + extraVinculum) + " " + hLinePad2 + "h400000v" + (40 + extraVinculum) + "h-400000z";
  };
  var sqrtSize2 = function sqrtSize22(extraVinculum, hLinePad2) {
    return "M983 " + (10 + extraVinculum + hLinePad2) + "\nl" + extraVinculum / 3.13 + " -" + extraVinculum + "\nc4,-6.7,10,-10,18,-10 H400000v" + (40 + extraVinculum) + "\nH1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7\ns-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744\nc-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30\nc26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722\nc56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5\nc53.7,-170.3,84.5,-266.8,92.5,-289.5z\nM" + (1001 + extraVinculum) + " " + hLinePad2 + "h400000v" + (40 + extraVinculum) + "h-400000z";
  };
  var sqrtSize3 = function sqrtSize32(extraVinculum, hLinePad2) {
    return "M424," + (2398 + extraVinculum + hLinePad2) + "\nc-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514\nc0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20\ns-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121\ns209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081\nl" + extraVinculum / 4.223 + " -" + extraVinculum + "c4,-6.7,10,-10,18,-10 H400000\nv" + (40 + extraVinculum) + "H1014.6\ns-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185\nc-2,6,-10,9,-24,9\nc-8,0,-12,-0.7,-12,-2z M" + (1001 + extraVinculum) + " " + hLinePad2 + "\nh400000v" + (40 + extraVinculum) + "h-400000z";
  };
  var sqrtSize4 = function sqrtSize42(extraVinculum, hLinePad2) {
    return "M473," + (2713 + extraVinculum + hLinePad2) + "\nc339.3,-1799.3,509.3,-2700,510,-2702 l" + extraVinculum / 5.298 + " -" + extraVinculum + "\nc3.3,-7.3,9.3,-11,18,-11 H400000v" + (40 + extraVinculum) + "H1017.7\ns-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9\nc-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200\nc0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26\ns76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,\n606zM" + (1001 + extraVinculum) + " " + hLinePad2 + "h400000v" + (40 + extraVinculum) + "H1017.7z";
  };
  var phasePath = function phasePath2(y3) {
    var x2 = y3 / 2;
    return "M400000 " + y3 + " H0 L" + x2 + " 0 l65 45 L145 " + (y3 - 80) + " H400000z";
  };
  var sqrtTall = function sqrtTall2(extraVinculum, hLinePad2, viewBoxHeight) {
    var vertSegment = viewBoxHeight - 54 - hLinePad2 - extraVinculum;
    return "M702 " + (extraVinculum + hLinePad2) + "H400000" + (40 + extraVinculum) + "\nH742v" + vertSegment + "l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1\nh-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170\nc-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667\n219 661 l218 661zM702 " + hLinePad2 + "H400000v" + (40 + extraVinculum) + "H742z";
  };
  var sqrtPath = function sqrtPath2(size, extraVinculum, viewBoxHeight) {
    extraVinculum = 1e3 * extraVinculum;
    var path2 = "";
    switch (size) {
      case "sqrtMain":
        path2 = sqrtMain(extraVinculum, hLinePad);
        break;
      case "sqrtSize1":
        path2 = sqrtSize1(extraVinculum, hLinePad);
        break;
      case "sqrtSize2":
        path2 = sqrtSize2(extraVinculum, hLinePad);
        break;
      case "sqrtSize3":
        path2 = sqrtSize3(extraVinculum, hLinePad);
        break;
      case "sqrtSize4":
        path2 = sqrtSize4(extraVinculum, hLinePad);
        break;
      case "sqrtTall":
        path2 = sqrtTall(extraVinculum, hLinePad, viewBoxHeight);
    }
    return path2;
  };
  var innerPath = function innerPath2(name, height) {
    switch (name) {
      case "\u239C":
        return doubleBrushStroke("M291 0 H417 V" + height + " H291z");
      case "\u2223":
        return doubleBrushStroke("M145 0 H188 V" + height + " H145z");
      case "\u2225":
        return doubleBrushStroke("M145 0 H188 V" + height + " H145z") + doubleBrushStroke("M367 0 H410 V" + height + " H367z");
      case "\u239F":
        return doubleBrushStroke("M457 0 H583 V" + height + " H457z");
      case "\u23A2":
        return doubleBrushStroke("M319 0 H403 V" + height + " H319z");
      case "\u23A5":
        return doubleBrushStroke("M263 0 H347 V" + height + " H263z");
      case "\u23AA":
        return doubleBrushStroke("M384 0 H504 V" + height + " H384z");
      case "\u23D0":
        return doubleBrushStroke("M312 0 H355 V" + height + " H312z");
      case "\u2016":
        return doubleBrushStroke("M257 0 H300 V" + height + " H257z") + doubleBrushStroke("M478 0 H521 V" + height + " H478z");
      default:
        return "";
    }
  };
  var path = {
    // The doubleleftarrow geometry is from glyph U+21D0 in the font KaTeX Main
    doubleleftarrow: "M262 157\nl10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3\n 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28\n 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5\nc2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5\n 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87\n-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7\n-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z\nm8 0v40h399730v-40zm0 194v40h399730v-40z",
    // doublerightarrow is from glyph U+21D2 in font KaTeX Main
    doublerightarrow: "M399738 392l\n-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5\n 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88\n-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68\n-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18\n-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782\nc-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3\n-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z",
    // leftarrow is from glyph U+2190 in font KaTeX Main
    leftarrow: "M400000 241H110l3-3c68.7-52.7 113.7-120\n 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8\n-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247\nc-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208\n 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3\n 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202\n l-3-3h399890zM100 241v40h399900v-40z",
    // overbrace is from glyphs U+23A9/23A8/23A7 in font KaTeX_Size4-Regular
    leftbrace: "M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117\n-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7\n 5-6 9-10 13-.7 1-7.3 1-20 1H6z",
    leftbraceunder: "M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13\n 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688\n 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7\n-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z",
    // overgroup is from the MnSymbol package (public domain)
    leftgroup: "M400000 80\nH435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0\n 435 0h399565z",
    leftgroupunder: "M400000 262\nH435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219\n 435 219h399565z",
    // Harpoons are from glyph U+21BD in font KaTeX Main
    leftharpoon: "M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3\n-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5\n-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7\n-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z",
    leftharpoonplus: "M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5\n 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3\n-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7\n-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z\nm0 0v40h400000v-40z",
    leftharpoondown: "M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333\n 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5\n 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667\n-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z",
    leftharpoondownplus: "M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12\n 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7\n-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0\nv40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z",
    // hook is from glyph U+21A9 in font KaTeX Main
    lefthook: "M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5\n-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3\n-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21\n 71.5 23h399859zM103 281v-40h399897v40z",
    leftlinesegment: doubleBrushStroke("M40 281 V428 H0 V94 H40 V241 H400000 v40z"),
    leftbracketunder: doubleBrushStroke("M0 0 h120 V290 H399995 v120 H0z"),
    leftbracketover: doubleBrushStroke("M0 440 h120 V150 H399995 v-120 H0z"),
    leftmapsto: doubleBrushStroke("M40 281 V448H0V74H40V241H400000v40z"),
    // tofrom is from glyph U+21C4 in font KaTeX AMS Regular
    leftToFrom: "M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23\n-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8\nc28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3\n 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z",
    longequal: doubleBrushStroke("M0 50 h400000 v40H0z m0 194h40000v40H0z"),
    midbrace: "M200428 334\nc-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14\n-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7\n 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11\n 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z",
    midbraceunder: "M199572 214\nc100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14\n 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3\n 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0\n-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z",
    oiintSize1: "M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6\n-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z\nm368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8\n60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z",
    oiintSize2: "M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8\n-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z\nm502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2\nc0 110 84 276 504 276s502.4-166 502.4-276z",
    oiiintSize1: "M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6\n-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z\nm525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0\n85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z",
    oiiintSize2: "M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8\n-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z\nm770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1\nc0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z",
    rightarrow: "M0 241v40h399891c-47.3 35.3-84 78-110 128\n-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20\n 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7\n 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85\n-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5\n-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67\n 151.7 139 205zm0 0v40h399900v-40z",
    rightbrace: "M400000 542l\n-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5\ns-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1\nc124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z",
    rightbraceunder: "M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3\n 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237\n-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z",
    rightgroup: "M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0\n 3-1 3-3v-38c-76-158-257-219-435-219H0z",
    rightgroupunder: "M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18\n 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z",
    rightharpoon: "M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3\n-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2\n-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58\n 69.2 92 94.5zm0 0v40h399900v-40z",
    rightharpoonplus: "M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11\n-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7\n 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z\nm0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z",
    rightharpoondown: "M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8\n 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5\n-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95\n-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z",
    rightharpoondownplus: "M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8\n 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3\n 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3\n-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z\nm0-194v40h400000v-40zm0 0v40h400000v-40z",
    righthook: "M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3\n 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0\n-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21\n 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z",
    rightlinesegment: doubleBrushStroke("M399960 241 V94 h40 V428 h-40 V281 H0 v-40z"),
    rightbracketunder: doubleBrushStroke("M399995 0 h-120 V290 H0 v120 H400000z"),
    rightbracketover: doubleBrushStroke("M399995 440 h-120 V150 H0 v-120 H399995z"),
    rightToFrom: "M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23\n 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32\n-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142\n-167z M100 147v40h399900v-40zM0 341v40h399900v-40z",
    // twoheadleftarrow is from glyph U+219E in font KaTeX AMS Regular
    twoheadleftarrow: "M0 167c68 40\n 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69\n-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3\n-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19\n-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101\n 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z",
    twoheadrightarrow: "M400000 167\nc-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3\n 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42\n 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333\n-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70\n 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z",
    // tilde1 is a modified version of a glyph from the MnSymbol package
    tilde1: "M200 55.538c-77 0-168 73.953-177 73.953-3 0-7\n-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0\n 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0\n 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128\n-68.267.847-113-73.952-191-73.952z",
    // ditto tilde2, tilde3, & tilde4
    tilde2: "M344 55.266c-142 0-300.638 81.316-311.5 86.418\n-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9\n 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114\nc1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751\n 181.476 676 181.476c-149 0-189-126.21-332-126.21z",
    tilde3: "M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457\n-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0\n 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697\n 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696\n -338 0-409-156.573-744-156.573z",
    tilde4: "M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345\n-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409\n 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9\n 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409\n -175.236-744-175.236z",
    // vec is from glyph U+20D7 in font KaTeX Main
    vec: "M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5\n3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11\n10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63\n-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1\n-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59\nH213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359\nc-16-25.333-24-45-24-59z",
    // widehat1 is a modified version of a glyph from the MnSymbol package
    widehat1: "M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22\nc-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z",
    // ditto widehat2, widehat3, & widehat4
    widehat2: "M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
    widehat3: "M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
    widehat4: "M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
    // widecheck paths are all inverted versions of widehat
    widecheck1: "M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,\n-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z",
    widecheck2: "M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
    widecheck3: "M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
    widecheck4: "M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
    // The next ten paths support reaction arrows from the mhchem package.
    // Arrows for \ce{<-->} are offset from xAxis by 0.22ex, per mhchem in LaTeX
    // baraboveleftarrow is mostly from glyph U+2190 in font KaTeX Main
    baraboveleftarrow: "M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202\nc4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5\nc-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130\ns-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47\n121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6\ns2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11\nc0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z\nM100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z",
    // rightarrowabovebar is mostly from glyph U+2192, KaTeX Main
    rightarrowabovebar: "M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32\n-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0\n13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39\n-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5\n-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5\n-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67\n151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z",
    // The short left harpoon has 0.5em (i.e. 500 units) kern on the left end.
    // Ref from mhchem.sty: \rlap{\raisebox{-.22ex}{$\kern0.5em
    baraboveshortleftharpoon: "M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11\nc1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17\nc2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21\nc-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40\nc-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z\nM0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z",
    rightharpoonaboveshortbar: "M0,241 l0,40c399126,0,399993,0,399993,0\nc4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,\n-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6\nc-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z\nM0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z",
    shortbaraboveleftharpoon: "M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11\nc1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,\n1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,\n-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z\nM93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z",
    shortrightharpoonabovebar: "M53,241l0,40c398570,0,399437,0,399437,0\nc4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,\n-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6\nc-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z\nM500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z"
  };
  var tallDelim = function tallDelim2(label, midHeight) {
    switch (label) {
      case "lbrack":
        return "M403 1759 V84 H666 V0 H319 V1759 v" + midHeight + " v1759 v84 h347 v-84\nH403z M403 1759 V0 H319 V1759 v" + midHeight + " v1759 v84 h84z";
      case "rbrack":
        return "M347 1759 V0 H0 V84 H263 V1759 v" + midHeight + " v1759 H0 v84 H347z\nM347 1759 V0 H263 V1759 v" + midHeight + " v1759 h84z";
      case "vert":
        return "M145 15 v585 v" + midHeight + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -midHeight + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M188 15 H145 v585 v" + midHeight + " v585 h43z";
      case "doublevert":
        return "M145 15 v585 v" + midHeight + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -midHeight + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M188 15 H145 v585 v" + midHeight + " v585 h43z\nM367 15 v585 v" + midHeight + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -midHeight + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M410 15 H367 v585 v" + midHeight + " v585 h43z";
      case "lfloor":
        return "M319 602 V0 H403 V602 v" + midHeight + " v1715 h263 v84 H319z\nMM319 602 V0 H403 V602 v" + midHeight + " v1715 H319z";
      case "rfloor":
        return "M319 602 V0 H403 V602 v" + midHeight + " v1799 H0 v-84 H319z\nMM319 602 V0 H403 V602 v" + midHeight + " v1715 H319z";
      case "lceil":
        return "M403 1759 V84 H666 V0 H319 V1759 v" + midHeight + " v602 h84z\nM403 1759 V0 H319 V1759 v" + midHeight + " v602 h84z";
      case "rceil":
        return "M347 1759 V0 H0 V84 H263 V1759 v" + midHeight + " v602 h84z\nM347 1759 V0 h-84 V1759 v" + midHeight + " v602 h84z";
      case "lparen":
        return "M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1\nc-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,\n-36,557 l0," + (midHeight + 84) + "c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,\n949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9\nc0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,\n-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189\nl0,-" + (midHeight + 92) + "c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,\n-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z";
      case "rparen":
        return "M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,\n63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5\nc11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0," + (midHeight + 9) + "\nc-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664\nc-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11\nc0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17\nc242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558\nl0,-" + (midHeight + 144) + "c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,\n-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z";
      default:
        throw new Error("Unknown stretchy delimiter.");
    }
  };
  function isMathDomNode(node) {
    return "toText" in node;
  }
  var DocumentFragment = class {
    // Never used; needed for satisfying interface.
    constructor(children) {
      this.children = void 0;
      this.classes = void 0;
      this.height = void 0;
      this.depth = void 0;
      this.maxFontSize = void 0;
      this.style = void 0;
      this.children = children;
      this.classes = [];
      this.height = 0;
      this.depth = 0;
      this.maxFontSize = 0;
      this.style = {};
    }
    hasClass(className) {
      return this.classes.includes(className);
    }
    /** Convert the fragment into a node. */
    toNode() {
      var frag = document.createDocumentFragment();
      for (var i3 = 0; i3 < this.children.length; i3++) {
        frag.appendChild(this.children[i3].toNode());
      }
      return frag;
    }
    /** Convert the fragment into HTML markup. */
    toMarkup() {
      var markup = "";
      for (var i3 = 0; i3 < this.children.length; i3++) {
        markup += this.children[i3].toMarkup();
      }
      return markup;
    }
    /**
     * Converts the math node into a string, similar to innerText. Applies to
     * MathDomNode's only.
     */
    toText() {
      return this.children.map((child) => {
        if (isMathDomNode(child)) {
          return child.toText();
        }
        throw new Error("Expected MathDomNode with toText, got " + child.constructor.name);
      }).join("");
    }
  };
  var ptPerUnit = {
    // https://en.wikibooks.org/wiki/LaTeX/Lengths and
    // https://tex.stackexchange.com/a/8263
    "pt": 1,
    // TeX point
    "mm": 7227 / 2540,
    // millimeter
    "cm": 7227 / 254,
    // centimeter
    "in": 72.27,
    // inch
    "bp": 803 / 800,
    // big (PostScript) points
    "pc": 12,
    // pica
    "dd": 1238 / 1157,
    // didot
    "cc": 14856 / 1157,
    // cicero (12 didot)
    "nd": 685 / 642,
    // new didot
    "nc": 1370 / 107,
    // new cicero (12 new didot)
    "sp": 1 / 65536,
    // scaled point (TeX's internal smallest unit)
    // https://tex.stackexchange.com/a/41371
    "px": 803 / 800
    // \pdfpxdimen defaults to 1 bp in pdfTeX and LuaTeX
  };
  var relativeUnit = {
    "ex": true,
    "em": true,
    "mu": true
  };
  var validUnit = function validUnit2(unit) {
    if (typeof unit !== "string") {
      unit = unit.unit;
    }
    return unit in ptPerUnit || unit in relativeUnit || unit === "ex";
  };
  var calculateSize = function calculateSize2(sizeValue, options) {
    var scale;
    if (sizeValue.unit in ptPerUnit) {
      scale = ptPerUnit[sizeValue.unit] / options.fontMetrics().ptPerEm / options.sizeMultiplier;
    } else if (sizeValue.unit === "mu") {
      scale = options.fontMetrics().cssEmPerMu;
    } else {
      var unitOptions;
      if (options.style.isTight()) {
        unitOptions = options.havingStyle(options.style.text());
      } else {
        unitOptions = options;
      }
      if (sizeValue.unit === "ex") {
        scale = unitOptions.fontMetrics().xHeight;
      } else if (sizeValue.unit === "em") {
        scale = unitOptions.fontMetrics().quad;
      } else {
        throw new ParseError("Invalid unit: '" + sizeValue.unit + "'");
      }
      if (unitOptions !== options) {
        scale *= unitOptions.sizeMultiplier / options.sizeMultiplier;
      }
    }
    return Math.min(sizeValue.number * scale, options.maxSize);
  };
  var makeEm = function makeEm2(n2) {
    return +n2.toFixed(4) + "em";
  };
  var createClass = function createClass2(classes) {
    return classes.filter((cls) => cls).join(" ");
  };
  var cssStyleToString = function cssStyleToString2(style) {
    var styles2 = "";
    for (var key of Object.keys(style)) {
      var value = style[key];
      if (value !== void 0) {
        styles2 += hyphenate(key) + ":" + value + ";";
      }
    }
    return styles2;
  };
  var initNode = function initNode2(classes, options, style) {
    this.classes = classes || [];
    this.attributes = {};
    this.height = 0;
    this.depth = 0;
    this.maxFontSize = 0;
    this.style = style || {};
    if (options) {
      if (options.style.isTight()) {
        this.classes.push("mtight");
      }
      var color = options.getColor();
      if (color) {
        this.style.color = color;
      }
    }
  };
  var toNode = function toNode2(tagName) {
    var node = document.createElement(tagName);
    node.className = createClass(this.classes);
    Object.assign(node.style, this.style);
    for (var attr of Object.keys(this.attributes)) {
      node.setAttribute(attr, this.attributes[attr]);
    }
    for (var i3 = 0; i3 < this.children.length; i3++) {
      node.appendChild(this.children[i3].toNode());
    }
    return node;
  };
  var invalidAttributeNameRegex = /[\s"'>/=\x00-\x1f]/;
  var toMarkup = function toMarkup2(tagName) {
    var markup = "<" + tagName;
    if (this.classes.length) {
      markup += ' class="' + escape(createClass(this.classes)) + '"';
    }
    var styles2 = cssStyleToString(this.style);
    if (styles2) {
      markup += ' style="' + escape(styles2) + '"';
    }
    for (var attr of Object.keys(this.attributes)) {
      if (invalidAttributeNameRegex.test(attr)) {
        throw new ParseError("Invalid attribute name '" + attr + "'");
      }
      markup += " " + attr + '="' + escape(this.attributes[attr]) + '"';
    }
    markup += ">";
    for (var i3 = 0; i3 < this.children.length; i3++) {
      markup += this.children[i3].toMarkup();
    }
    markup += "</" + tagName + ">";
    return markup;
  };
  var Span = class {
    constructor(classes, children, options, style) {
      this.children = void 0;
      this.attributes = void 0;
      this.classes = void 0;
      this.height = void 0;
      this.depth = void 0;
      this.width = void 0;
      this.maxFontSize = void 0;
      this.style = void 0;
      this.italic = void 0;
      initNode.call(this, classes, options, style);
      this.children = children || [];
    }
    /**
     * Sets an arbitrary attribute on the span. Warning: use this wisely. Not
     * all browsers support attributes the same, and having too many custom
     * attributes is probably bad.
     */
    setAttribute(attribute, value) {
      this.attributes[attribute] = value;
    }
    hasClass(className) {
      return this.classes.includes(className);
    }
    toNode() {
      return toNode.call(this, "span");
    }
    toMarkup() {
      return toMarkup.call(this, "span");
    }
  };
  var Anchor = class {
    constructor(href, classes, children, options) {
      this.children = void 0;
      this.attributes = void 0;
      this.classes = void 0;
      this.height = void 0;
      this.depth = void 0;
      this.maxFontSize = void 0;
      this.style = void 0;
      initNode.call(this, classes, options);
      this.children = children || [];
      this.setAttribute("href", href);
    }
    setAttribute(attribute, value) {
      this.attributes[attribute] = value;
    }
    hasClass(className) {
      return this.classes.includes(className);
    }
    toNode() {
      return toNode.call(this, "a");
    }
    toMarkup() {
      return toMarkup.call(this, "a");
    }
  };
  var Img = class {
    constructor(src, alt, style) {
      this.src = void 0;
      this.alt = void 0;
      this.classes = void 0;
      this.height = void 0;
      this.depth = void 0;
      this.maxFontSize = void 0;
      this.style = void 0;
      this.alt = alt;
      this.src = src;
      this.classes = ["mord"];
      this.height = 0;
      this.depth = 0;
      this.maxFontSize = 0;
      this.style = style;
    }
    hasClass(className) {
      return this.classes.includes(className);
    }
    toNode() {
      var node = document.createElement("img");
      node.src = this.src;
      node.alt = this.alt;
      node.className = "mord";
      Object.assign(node.style, this.style);
      return node;
    }
    toMarkup() {
      var markup = '<img src="' + escape(this.src) + '"' + (' alt="' + escape(this.alt) + '"');
      var styles2 = cssStyleToString(this.style);
      if (styles2) {
        markup += ' style="' + escape(styles2) + '"';
      }
      markup += "'/>";
      return markup;
    }
  };
  var iCombinations = {
    "\xEE": "\u0131\u0302",
    "\xEF": "\u0131\u0308",
    "\xED": "\u0131\u0301",
    // 'ī': '\u0131\u0304', // enable when we add Extended Latin
    "\xEC": "\u0131\u0300"
  };
  var SymbolNode = class {
    constructor(text2, height, depth, italic2, skew, width, classes, style) {
      this.text = void 0;
      this.height = void 0;
      this.depth = void 0;
      this.italic = void 0;
      this.skew = void 0;
      this.width = void 0;
      this.maxFontSize = void 0;
      this.classes = void 0;
      this.style = void 0;
      this.text = text2;
      this.height = height || 0;
      this.depth = depth || 0;
      this.italic = italic2 || 0;
      this.skew = skew || 0;
      this.width = width || 0;
      this.classes = classes || [];
      this.style = style || {};
      this.maxFontSize = 0;
      var script2 = scriptFromCodepoint(this.text.charCodeAt(0));
      if (script2) {
        this.classes.push(script2 + "_fallback");
      }
      if (/[îïíì]/.test(this.text)) {
        this.text = iCombinations[this.text];
      }
    }
    hasClass(className) {
      return this.classes.includes(className);
    }
    /**
     * Creates a text node or span from a symbol node. Note that a span is only
     * created if it is needed.
     */
    toNode() {
      var node = document.createTextNode(this.text);
      var span = null;
      if (this.italic > 0) {
        span = document.createElement("span");
        span.style.marginRight = makeEm(this.italic);
      }
      if (this.classes.length > 0) {
        span = span || document.createElement("span");
        span.className = createClass(this.classes);
      }
      if (Object.keys(this.style).length > 0) {
        span = span || document.createElement("span");
        Object.assign(span.style, this.style);
      }
      if (span) {
        span.appendChild(node);
        return span;
      } else {
        return node;
      }
    }
    /**
     * Creates markup for a symbol node.
     */
    toMarkup() {
      var needsSpan = false;
      var markup = "<span";
      if (this.classes.length) {
        needsSpan = true;
        markup += ' class="';
        markup += escape(createClass(this.classes));
        markup += '"';
      }
      var styles2 = "";
      if (this.italic > 0) {
        styles2 += "margin-right:" + makeEm(this.italic) + ";";
      }
      styles2 += cssStyleToString(this.style);
      if (styles2) {
        needsSpan = true;
        markup += ' style="' + escape(styles2) + '"';
      }
      var escaped = escape(this.text);
      if (needsSpan) {
        markup += ">";
        markup += escaped;
        markup += "</span>";
        return markup;
      } else {
        return escaped;
      }
    }
  };
  var SvgNode = class {
    constructor(children, attributes) {
      this.children = void 0;
      this.attributes = void 0;
      this.children = children || [];
      this.attributes = attributes || {};
    }
    toNode() {
      var svgNS = "http://www.w3.org/2000/svg";
      var node = document.createElementNS(svgNS, "svg");
      for (var attr of Object.keys(this.attributes)) {
        node.setAttribute(attr, this.attributes[attr]);
      }
      for (var i3 = 0; i3 < this.children.length; i3++) {
        node.appendChild(this.children[i3].toNode());
      }
      return node;
    }
    toMarkup() {
      var markup = '<svg xmlns="http://www.w3.org/2000/svg"';
      for (var attr of Object.keys(this.attributes)) {
        markup += " " + attr + '="' + escape(this.attributes[attr]) + '"';
      }
      markup += ">";
      for (var i3 = 0; i3 < this.children.length; i3++) {
        markup += this.children[i3].toMarkup();
      }
      markup += "</svg>";
      return markup;
    }
  };
  var PathNode = class {
    constructor(pathName, alternate) {
      this.pathName = void 0;
      this.alternate = void 0;
      this.pathName = pathName;
      this.alternate = alternate;
    }
    toNode() {
      var svgNS = "http://www.w3.org/2000/svg";
      var node = document.createElementNS(svgNS, "path");
      if (this.alternate) {
        node.setAttribute("d", this.alternate);
      } else {
        node.setAttribute("d", path[this.pathName]);
      }
      return node;
    }
    toMarkup() {
      if (this.alternate) {
        return '<path d="' + escape(this.alternate) + '"/>';
      } else {
        return '<path d="' + escape(path[this.pathName]) + '"/>';
      }
    }
  };
  var LineNode = class {
    constructor(attributes) {
      this.attributes = void 0;
      this.attributes = attributes || {};
    }
    toNode() {
      var svgNS = "http://www.w3.org/2000/svg";
      var node = document.createElementNS(svgNS, "line");
      for (var attr of Object.keys(this.attributes)) {
        node.setAttribute(attr, this.attributes[attr]);
      }
      return node;
    }
    toMarkup() {
      var markup = "<line";
      for (var attr of Object.keys(this.attributes)) {
        markup += " " + attr + '="' + escape(this.attributes[attr]) + '"';
      }
      markup += "/>";
      return markup;
    }
  };
  function assertSymbolDomNode(group) {
    if (group instanceof SymbolNode) {
      return group;
    } else {
      throw new Error("Expected symbolNode but got " + String(group) + ".");
    }
  }
  function assertSpan(group) {
    if (group instanceof Span) {
      return group;
    } else {
      throw new Error("Expected span<HtmlDomNode> but got " + String(group) + ".");
    }
  }
  var hasHtmlDomChildren = (node) => node instanceof Span || node instanceof Anchor || node instanceof DocumentFragment;
  var fontMetricsData = {
    "AMS-Regular": {
      "32": [0, 0, 0, 0, 0.25],
      "65": [0, 0.68889, 0, 0, 0.72222],
      "66": [0, 0.68889, 0, 0, 0.66667],
      "67": [0, 0.68889, 0, 0, 0.72222],
      "68": [0, 0.68889, 0, 0, 0.72222],
      "69": [0, 0.68889, 0, 0, 0.66667],
      "70": [0, 0.68889, 0, 0, 0.61111],
      "71": [0, 0.68889, 0, 0, 0.77778],
      "72": [0, 0.68889, 0, 0, 0.77778],
      "73": [0, 0.68889, 0, 0, 0.38889],
      "74": [0.16667, 0.68889, 0, 0, 0.5],
      "75": [0, 0.68889, 0, 0, 0.77778],
      "76": [0, 0.68889, 0, 0, 0.66667],
      "77": [0, 0.68889, 0, 0, 0.94445],
      "78": [0, 0.68889, 0, 0, 0.72222],
      "79": [0.16667, 0.68889, 0, 0, 0.77778],
      "80": [0, 0.68889, 0, 0, 0.61111],
      "81": [0.16667, 0.68889, 0, 0, 0.77778],
      "82": [0, 0.68889, 0, 0, 0.72222],
      "83": [0, 0.68889, 0, 0, 0.55556],
      "84": [0, 0.68889, 0, 0, 0.66667],
      "85": [0, 0.68889, 0, 0, 0.72222],
      "86": [0, 0.68889, 0, 0, 0.72222],
      "87": [0, 0.68889, 0, 0, 1],
      "88": [0, 0.68889, 0, 0, 0.72222],
      "89": [0, 0.68889, 0, 0, 0.72222],
      "90": [0, 0.68889, 0, 0, 0.66667],
      "107": [0, 0.68889, 0, 0, 0.55556],
      "160": [0, 0, 0, 0, 0.25],
      "165": [0, 0.675, 0.025, 0, 0.75],
      "174": [0.15559, 0.69224, 0, 0, 0.94666],
      "240": [0, 0.68889, 0, 0, 0.55556],
      "295": [0, 0.68889, 0, 0, 0.54028],
      "710": [0, 0.825, 0, 0, 2.33334],
      "732": [0, 0.9, 0, 0, 2.33334],
      "770": [0, 0.825, 0, 0, 2.33334],
      "771": [0, 0.9, 0, 0, 2.33334],
      "989": [0.08167, 0.58167, 0, 0, 0.77778],
      "1008": [0, 0.43056, 0.04028, 0, 0.66667],
      "8245": [0, 0.54986, 0, 0, 0.275],
      "8463": [0, 0.68889, 0, 0, 0.54028],
      "8487": [0, 0.68889, 0, 0, 0.72222],
      "8498": [0, 0.68889, 0, 0, 0.55556],
      "8502": [0, 0.68889, 0, 0, 0.66667],
      "8503": [0, 0.68889, 0, 0, 0.44445],
      "8504": [0, 0.68889, 0, 0, 0.66667],
      "8513": [0, 0.68889, 0, 0, 0.63889],
      "8592": [-0.03598, 0.46402, 0, 0, 0.5],
      "8594": [-0.03598, 0.46402, 0, 0, 0.5],
      "8602": [-0.13313, 0.36687, 0, 0, 1],
      "8603": [-0.13313, 0.36687, 0, 0, 1],
      "8606": [0.01354, 0.52239, 0, 0, 1],
      "8608": [0.01354, 0.52239, 0, 0, 1],
      "8610": [0.01354, 0.52239, 0, 0, 1.11111],
      "8611": [0.01354, 0.52239, 0, 0, 1.11111],
      "8619": [0, 0.54986, 0, 0, 1],
      "8620": [0, 0.54986, 0, 0, 1],
      "8621": [-0.13313, 0.37788, 0, 0, 1.38889],
      "8622": [-0.13313, 0.36687, 0, 0, 1],
      "8624": [0, 0.69224, 0, 0, 0.5],
      "8625": [0, 0.69224, 0, 0, 0.5],
      "8630": [0, 0.43056, 0, 0, 1],
      "8631": [0, 0.43056, 0, 0, 1],
      "8634": [0.08198, 0.58198, 0, 0, 0.77778],
      "8635": [0.08198, 0.58198, 0, 0, 0.77778],
      "8638": [0.19444, 0.69224, 0, 0, 0.41667],
      "8639": [0.19444, 0.69224, 0, 0, 0.41667],
      "8642": [0.19444, 0.69224, 0, 0, 0.41667],
      "8643": [0.19444, 0.69224, 0, 0, 0.41667],
      "8644": [0.1808, 0.675, 0, 0, 1],
      "8646": [0.1808, 0.675, 0, 0, 1],
      "8647": [0.1808, 0.675, 0, 0, 1],
      "8648": [0.19444, 0.69224, 0, 0, 0.83334],
      "8649": [0.1808, 0.675, 0, 0, 1],
      "8650": [0.19444, 0.69224, 0, 0, 0.83334],
      "8651": [0.01354, 0.52239, 0, 0, 1],
      "8652": [0.01354, 0.52239, 0, 0, 1],
      "8653": [-0.13313, 0.36687, 0, 0, 1],
      "8654": [-0.13313, 0.36687, 0, 0, 1],
      "8655": [-0.13313, 0.36687, 0, 0, 1],
      "8666": [0.13667, 0.63667, 0, 0, 1],
      "8667": [0.13667, 0.63667, 0, 0, 1],
      "8669": [-0.13313, 0.37788, 0, 0, 1],
      "8672": [-0.064, 0.437, 0, 0, 1.334],
      "8674": [-0.064, 0.437, 0, 0, 1.334],
      "8705": [0, 0.825, 0, 0, 0.5],
      "8708": [0, 0.68889, 0, 0, 0.55556],
      "8709": [0.08167, 0.58167, 0, 0, 0.77778],
      "8717": [0, 0.43056, 0, 0, 0.42917],
      "8722": [-0.03598, 0.46402, 0, 0, 0.5],
      "8724": [0.08198, 0.69224, 0, 0, 0.77778],
      "8726": [0.08167, 0.58167, 0, 0, 0.77778],
      "8733": [0, 0.69224, 0, 0, 0.77778],
      "8736": [0, 0.69224, 0, 0, 0.72222],
      "8737": [0, 0.69224, 0, 0, 0.72222],
      "8738": [0.03517, 0.52239, 0, 0, 0.72222],
      "8739": [0.08167, 0.58167, 0, 0, 0.22222],
      "8740": [0.25142, 0.74111, 0, 0, 0.27778],
      "8741": [0.08167, 0.58167, 0, 0, 0.38889],
      "8742": [0.25142, 0.74111, 0, 0, 0.5],
      "8756": [0, 0.69224, 0, 0, 0.66667],
      "8757": [0, 0.69224, 0, 0, 0.66667],
      "8764": [-0.13313, 0.36687, 0, 0, 0.77778],
      "8765": [-0.13313, 0.37788, 0, 0, 0.77778],
      "8769": [-0.13313, 0.36687, 0, 0, 0.77778],
      "8770": [-0.03625, 0.46375, 0, 0, 0.77778],
      "8774": [0.30274, 0.79383, 0, 0, 0.77778],
      "8776": [-0.01688, 0.48312, 0, 0, 0.77778],
      "8778": [0.08167, 0.58167, 0, 0, 0.77778],
      "8782": [0.06062, 0.54986, 0, 0, 0.77778],
      "8783": [0.06062, 0.54986, 0, 0, 0.77778],
      "8785": [0.08198, 0.58198, 0, 0, 0.77778],
      "8786": [0.08198, 0.58198, 0, 0, 0.77778],
      "8787": [0.08198, 0.58198, 0, 0, 0.77778],
      "8790": [0, 0.69224, 0, 0, 0.77778],
      "8791": [0.22958, 0.72958, 0, 0, 0.77778],
      "8796": [0.08198, 0.91667, 0, 0, 0.77778],
      "8806": [0.25583, 0.75583, 0, 0, 0.77778],
      "8807": [0.25583, 0.75583, 0, 0, 0.77778],
      "8808": [0.25142, 0.75726, 0, 0, 0.77778],
      "8809": [0.25142, 0.75726, 0, 0, 0.77778],
      "8812": [0.25583, 0.75583, 0, 0, 0.5],
      "8814": [0.20576, 0.70576, 0, 0, 0.77778],
      "8815": [0.20576, 0.70576, 0, 0, 0.77778],
      "8816": [0.30274, 0.79383, 0, 0, 0.77778],
      "8817": [0.30274, 0.79383, 0, 0, 0.77778],
      "8818": [0.22958, 0.72958, 0, 0, 0.77778],
      "8819": [0.22958, 0.72958, 0, 0, 0.77778],
      "8822": [0.1808, 0.675, 0, 0, 0.77778],
      "8823": [0.1808, 0.675, 0, 0, 0.77778],
      "8828": [0.13667, 0.63667, 0, 0, 0.77778],
      "8829": [0.13667, 0.63667, 0, 0, 0.77778],
      "8830": [0.22958, 0.72958, 0, 0, 0.77778],
      "8831": [0.22958, 0.72958, 0, 0, 0.77778],
      "8832": [0.20576, 0.70576, 0, 0, 0.77778],
      "8833": [0.20576, 0.70576, 0, 0, 0.77778],
      "8840": [0.30274, 0.79383, 0, 0, 0.77778],
      "8841": [0.30274, 0.79383, 0, 0, 0.77778],
      "8842": [0.13597, 0.63597, 0, 0, 0.77778],
      "8843": [0.13597, 0.63597, 0, 0, 0.77778],
      "8847": [0.03517, 0.54986, 0, 0, 0.77778],
      "8848": [0.03517, 0.54986, 0, 0, 0.77778],
      "8858": [0.08198, 0.58198, 0, 0, 0.77778],
      "8859": [0.08198, 0.58198, 0, 0, 0.77778],
      "8861": [0.08198, 0.58198, 0, 0, 0.77778],
      "8862": [0, 0.675, 0, 0, 0.77778],
      "8863": [0, 0.675, 0, 0, 0.77778],
      "8864": [0, 0.675, 0, 0, 0.77778],
      "8865": [0, 0.675, 0, 0, 0.77778],
      "8872": [0, 0.69224, 0, 0, 0.61111],
      "8873": [0, 0.69224, 0, 0, 0.72222],
      "8874": [0, 0.69224, 0, 0, 0.88889],
      "8876": [0, 0.68889, 0, 0, 0.61111],
      "8877": [0, 0.68889, 0, 0, 0.61111],
      "8878": [0, 0.68889, 0, 0, 0.72222],
      "8879": [0, 0.68889, 0, 0, 0.72222],
      "8882": [0.03517, 0.54986, 0, 0, 0.77778],
      "8883": [0.03517, 0.54986, 0, 0, 0.77778],
      "8884": [0.13667, 0.63667, 0, 0, 0.77778],
      "8885": [0.13667, 0.63667, 0, 0, 0.77778],
      "8888": [0, 0.54986, 0, 0, 1.11111],
      "8890": [0.19444, 0.43056, 0, 0, 0.55556],
      "8891": [0.19444, 0.69224, 0, 0, 0.61111],
      "8892": [0.19444, 0.69224, 0, 0, 0.61111],
      "8901": [0, 0.54986, 0, 0, 0.27778],
      "8903": [0.08167, 0.58167, 0, 0, 0.77778],
      "8905": [0.08167, 0.58167, 0, 0, 0.77778],
      "8906": [0.08167, 0.58167, 0, 0, 0.77778],
      "8907": [0, 0.69224, 0, 0, 0.77778],
      "8908": [0, 0.69224, 0, 0, 0.77778],
      "8909": [-0.03598, 0.46402, 0, 0, 0.77778],
      "8910": [0, 0.54986, 0, 0, 0.76042],
      "8911": [0, 0.54986, 0, 0, 0.76042],
      "8912": [0.03517, 0.54986, 0, 0, 0.77778],
      "8913": [0.03517, 0.54986, 0, 0, 0.77778],
      "8914": [0, 0.54986, 0, 0, 0.66667],
      "8915": [0, 0.54986, 0, 0, 0.66667],
      "8916": [0, 0.69224, 0, 0, 0.66667],
      "8918": [0.0391, 0.5391, 0, 0, 0.77778],
      "8919": [0.0391, 0.5391, 0, 0, 0.77778],
      "8920": [0.03517, 0.54986, 0, 0, 1.33334],
      "8921": [0.03517, 0.54986, 0, 0, 1.33334],
      "8922": [0.38569, 0.88569, 0, 0, 0.77778],
      "8923": [0.38569, 0.88569, 0, 0, 0.77778],
      "8926": [0.13667, 0.63667, 0, 0, 0.77778],
      "8927": [0.13667, 0.63667, 0, 0, 0.77778],
      "8928": [0.30274, 0.79383, 0, 0, 0.77778],
      "8929": [0.30274, 0.79383, 0, 0, 0.77778],
      "8934": [0.23222, 0.74111, 0, 0, 0.77778],
      "8935": [0.23222, 0.74111, 0, 0, 0.77778],
      "8936": [0.23222, 0.74111, 0, 0, 0.77778],
      "8937": [0.23222, 0.74111, 0, 0, 0.77778],
      "8938": [0.20576, 0.70576, 0, 0, 0.77778],
      "8939": [0.20576, 0.70576, 0, 0, 0.77778],
      "8940": [0.30274, 0.79383, 0, 0, 0.77778],
      "8941": [0.30274, 0.79383, 0, 0, 0.77778],
      "8994": [0.19444, 0.69224, 0, 0, 0.77778],
      "8995": [0.19444, 0.69224, 0, 0, 0.77778],
      "9416": [0.15559, 0.69224, 0, 0, 0.90222],
      "9484": [0, 0.69224, 0, 0, 0.5],
      "9488": [0, 0.69224, 0, 0, 0.5],
      "9492": [0, 0.37788, 0, 0, 0.5],
      "9496": [0, 0.37788, 0, 0, 0.5],
      "9585": [0.19444, 0.68889, 0, 0, 0.88889],
      "9586": [0.19444, 0.74111, 0, 0, 0.88889],
      "9632": [0, 0.675, 0, 0, 0.77778],
      "9633": [0, 0.675, 0, 0, 0.77778],
      "9650": [0, 0.54986, 0, 0, 0.72222],
      "9651": [0, 0.54986, 0, 0, 0.72222],
      "9654": [0.03517, 0.54986, 0, 0, 0.77778],
      "9660": [0, 0.54986, 0, 0, 0.72222],
      "9661": [0, 0.54986, 0, 0, 0.72222],
      "9664": [0.03517, 0.54986, 0, 0, 0.77778],
      "9674": [0.11111, 0.69224, 0, 0, 0.66667],
      "9733": [0.19444, 0.69224, 0, 0, 0.94445],
      "10003": [0, 0.69224, 0, 0, 0.83334],
      "10016": [0, 0.69224, 0, 0, 0.83334],
      "10731": [0.11111, 0.69224, 0, 0, 0.66667],
      "10846": [0.19444, 0.75583, 0, 0, 0.61111],
      "10877": [0.13667, 0.63667, 0, 0, 0.77778],
      "10878": [0.13667, 0.63667, 0, 0, 0.77778],
      "10885": [0.25583, 0.75583, 0, 0, 0.77778],
      "10886": [0.25583, 0.75583, 0, 0, 0.77778],
      "10887": [0.13597, 0.63597, 0, 0, 0.77778],
      "10888": [0.13597, 0.63597, 0, 0, 0.77778],
      "10889": [0.26167, 0.75726, 0, 0, 0.77778],
      "10890": [0.26167, 0.75726, 0, 0, 0.77778],
      "10891": [0.48256, 0.98256, 0, 0, 0.77778],
      "10892": [0.48256, 0.98256, 0, 0, 0.77778],
      "10901": [0.13667, 0.63667, 0, 0, 0.77778],
      "10902": [0.13667, 0.63667, 0, 0, 0.77778],
      "10933": [0.25142, 0.75726, 0, 0, 0.77778],
      "10934": [0.25142, 0.75726, 0, 0, 0.77778],
      "10935": [0.26167, 0.75726, 0, 0, 0.77778],
      "10936": [0.26167, 0.75726, 0, 0, 0.77778],
      "10937": [0.26167, 0.75726, 0, 0, 0.77778],
      "10938": [0.26167, 0.75726, 0, 0, 0.77778],
      "10949": [0.25583, 0.75583, 0, 0, 0.77778],
      "10950": [0.25583, 0.75583, 0, 0, 0.77778],
      "10955": [0.28481, 0.79383, 0, 0, 0.77778],
      "10956": [0.28481, 0.79383, 0, 0, 0.77778],
      "57350": [0.08167, 0.58167, 0, 0, 0.22222],
      "57351": [0.08167, 0.58167, 0, 0, 0.38889],
      "57352": [0.08167, 0.58167, 0, 0, 0.77778],
      "57353": [0, 0.43056, 0.04028, 0, 0.66667],
      "57356": [0.25142, 0.75726, 0, 0, 0.77778],
      "57357": [0.25142, 0.75726, 0, 0, 0.77778],
      "57358": [0.41951, 0.91951, 0, 0, 0.77778],
      "57359": [0.30274, 0.79383, 0, 0, 0.77778],
      "57360": [0.30274, 0.79383, 0, 0, 0.77778],
      "57361": [0.41951, 0.91951, 0, 0, 0.77778],
      "57366": [0.25142, 0.75726, 0, 0, 0.77778],
      "57367": [0.25142, 0.75726, 0, 0, 0.77778],
      "57368": [0.25142, 0.75726, 0, 0, 0.77778],
      "57369": [0.25142, 0.75726, 0, 0, 0.77778],
      "57370": [0.13597, 0.63597, 0, 0, 0.77778],
      "57371": [0.13597, 0.63597, 0, 0, 0.77778]
    },
    "Caligraphic-Regular": {
      "32": [0, 0, 0, 0, 0.25],
      "65": [0, 0.68333, 0, 0.19445, 0.79847],
      "66": [0, 0.68333, 0.03041, 0.13889, 0.65681],
      "67": [0, 0.68333, 0.05834, 0.13889, 0.52653],
      "68": [0, 0.68333, 0.02778, 0.08334, 0.77139],
      "69": [0, 0.68333, 0.08944, 0.11111, 0.52778],
      "70": [0, 0.68333, 0.09931, 0.11111, 0.71875],
      "71": [0.09722, 0.68333, 0.0593, 0.11111, 0.59487],
      "72": [0, 0.68333, 965e-5, 0.11111, 0.84452],
      "73": [0, 0.68333, 0.07382, 0, 0.54452],
      "74": [0.09722, 0.68333, 0.18472, 0.16667, 0.67778],
      "75": [0, 0.68333, 0.01445, 0.05556, 0.76195],
      "76": [0, 0.68333, 0, 0.13889, 0.68972],
      "77": [0, 0.68333, 0, 0.13889, 1.2009],
      "78": [0, 0.68333, 0.14736, 0.08334, 0.82049],
      "79": [0, 0.68333, 0.02778, 0.11111, 0.79611],
      "80": [0, 0.68333, 0.08222, 0.08334, 0.69556],
      "81": [0.09722, 0.68333, 0, 0.11111, 0.81667],
      "82": [0, 0.68333, 0, 0.08334, 0.8475],
      "83": [0, 0.68333, 0.075, 0.13889, 0.60556],
      "84": [0, 0.68333, 0.25417, 0, 0.54464],
      "85": [0, 0.68333, 0.09931, 0.08334, 0.62583],
      "86": [0, 0.68333, 0.08222, 0, 0.61278],
      "87": [0, 0.68333, 0.08222, 0.08334, 0.98778],
      "88": [0, 0.68333, 0.14643, 0.13889, 0.7133],
      "89": [0.09722, 0.68333, 0.08222, 0.08334, 0.66834],
      "90": [0, 0.68333, 0.07944, 0.13889, 0.72473],
      "160": [0, 0, 0, 0, 0.25]
    },
    "Fraktur-Regular": {
      "32": [0, 0, 0, 0, 0.25],
      "33": [0, 0.69141, 0, 0, 0.29574],
      "34": [0, 0.69141, 0, 0, 0.21471],
      "38": [0, 0.69141, 0, 0, 0.73786],
      "39": [0, 0.69141, 0, 0, 0.21201],
      "40": [0.24982, 0.74947, 0, 0, 0.38865],
      "41": [0.24982, 0.74947, 0, 0, 0.38865],
      "42": [0, 0.62119, 0, 0, 0.27764],
      "43": [0.08319, 0.58283, 0, 0, 0.75623],
      "44": [0, 0.10803, 0, 0, 0.27764],
      "45": [0.08319, 0.58283, 0, 0, 0.75623],
      "46": [0, 0.10803, 0, 0, 0.27764],
      "47": [0.24982, 0.74947, 0, 0, 0.50181],
      "48": [0, 0.47534, 0, 0, 0.50181],
      "49": [0, 0.47534, 0, 0, 0.50181],
      "50": [0, 0.47534, 0, 0, 0.50181],
      "51": [0.18906, 0.47534, 0, 0, 0.50181],
      "52": [0.18906, 0.47534, 0, 0, 0.50181],
      "53": [0.18906, 0.47534, 0, 0, 0.50181],
      "54": [0, 0.69141, 0, 0, 0.50181],
      "55": [0.18906, 0.47534, 0, 0, 0.50181],
      "56": [0, 0.69141, 0, 0, 0.50181],
      "57": [0.18906, 0.47534, 0, 0, 0.50181],
      "58": [0, 0.47534, 0, 0, 0.21606],
      "59": [0.12604, 0.47534, 0, 0, 0.21606],
      "61": [-0.13099, 0.36866, 0, 0, 0.75623],
      "63": [0, 0.69141, 0, 0, 0.36245],
      "65": [0, 0.69141, 0, 0, 0.7176],
      "66": [0, 0.69141, 0, 0, 0.88397],
      "67": [0, 0.69141, 0, 0, 0.61254],
      "68": [0, 0.69141, 0, 0, 0.83158],
      "69": [0, 0.69141, 0, 0, 0.66278],
      "70": [0.12604, 0.69141, 0, 0, 0.61119],
      "71": [0, 0.69141, 0, 0, 0.78539],
      "72": [0.06302, 0.69141, 0, 0, 0.7203],
      "73": [0, 0.69141, 0, 0, 0.55448],
      "74": [0.12604, 0.69141, 0, 0, 0.55231],
      "75": [0, 0.69141, 0, 0, 0.66845],
      "76": [0, 0.69141, 0, 0, 0.66602],
      "77": [0, 0.69141, 0, 0, 1.04953],
      "78": [0, 0.69141, 0, 0, 0.83212],
      "79": [0, 0.69141, 0, 0, 0.82699],
      "80": [0.18906, 0.69141, 0, 0, 0.82753],
      "81": [0.03781, 0.69141, 0, 0, 0.82699],
      "82": [0, 0.69141, 0, 0, 0.82807],
      "83": [0, 0.69141, 0, 0, 0.82861],
      "84": [0, 0.69141, 0, 0, 0.66899],
      "85": [0, 0.69141, 0, 0, 0.64576],
      "86": [0, 0.69141, 0, 0, 0.83131],
      "87": [0, 0.69141, 0, 0, 1.04602],
      "88": [0, 0.69141, 0, 0, 0.71922],
      "89": [0.18906, 0.69141, 0, 0, 0.83293],
      "90": [0.12604, 0.69141, 0, 0, 0.60201],
      "91": [0.24982, 0.74947, 0, 0, 0.27764],
      "93": [0.24982, 0.74947, 0, 0, 0.27764],
      "94": [0, 0.69141, 0, 0, 0.49965],
      "97": [0, 0.47534, 0, 0, 0.50046],
      "98": [0, 0.69141, 0, 0, 0.51315],
      "99": [0, 0.47534, 0, 0, 0.38946],
      "100": [0, 0.62119, 0, 0, 0.49857],
      "101": [0, 0.47534, 0, 0, 0.40053],
      "102": [0.18906, 0.69141, 0, 0, 0.32626],
      "103": [0.18906, 0.47534, 0, 0, 0.5037],
      "104": [0.18906, 0.69141, 0, 0, 0.52126],
      "105": [0, 0.69141, 0, 0, 0.27899],
      "106": [0, 0.69141, 0, 0, 0.28088],
      "107": [0, 0.69141, 0, 0, 0.38946],
      "108": [0, 0.69141, 0, 0, 0.27953],
      "109": [0, 0.47534, 0, 0, 0.76676],
      "110": [0, 0.47534, 0, 0, 0.52666],
      "111": [0, 0.47534, 0, 0, 0.48885],
      "112": [0.18906, 0.52396, 0, 0, 0.50046],
      "113": [0.18906, 0.47534, 0, 0, 0.48912],
      "114": [0, 0.47534, 0, 0, 0.38919],
      "115": [0, 0.47534, 0, 0, 0.44266],
      "116": [0, 0.62119, 0, 0, 0.33301],
      "117": [0, 0.47534, 0, 0, 0.5172],
      "118": [0, 0.52396, 0, 0, 0.5118],
      "119": [0, 0.52396, 0, 0, 0.77351],
      "120": [0.18906, 0.47534, 0, 0, 0.38865],
      "121": [0.18906, 0.47534, 0, 0, 0.49884],
      "122": [0.18906, 0.47534, 0, 0, 0.39054],
      "160": [0, 0, 0, 0, 0.25],
      "8216": [0, 0.69141, 0, 0, 0.21471],
      "8217": [0, 0.69141, 0, 0, 0.21471],
      "58112": [0, 0.62119, 0, 0, 0.49749],
      "58113": [0, 0.62119, 0, 0, 0.4983],
      "58114": [0.18906, 0.69141, 0, 0, 0.33328],
      "58115": [0.18906, 0.69141, 0, 0, 0.32923],
      "58116": [0.18906, 0.47534, 0, 0, 0.50343],
      "58117": [0, 0.69141, 0, 0, 0.33301],
      "58118": [0, 0.62119, 0, 0, 0.33409],
      "58119": [0, 0.47534, 0, 0, 0.50073]
    },
    "Main-Bold": {
      "32": [0, 0, 0, 0, 0.25],
      "33": [0, 0.69444, 0, 0, 0.35],
      "34": [0, 0.69444, 0, 0, 0.60278],
      "35": [0.19444, 0.69444, 0, 0, 0.95833],
      "36": [0.05556, 0.75, 0, 0, 0.575],
      "37": [0.05556, 0.75, 0, 0, 0.95833],
      "38": [0, 0.69444, 0, 0, 0.89444],
      "39": [0, 0.69444, 0, 0, 0.31944],
      "40": [0.25, 0.75, 0, 0, 0.44722],
      "41": [0.25, 0.75, 0, 0, 0.44722],
      "42": [0, 0.75, 0, 0, 0.575],
      "43": [0.13333, 0.63333, 0, 0, 0.89444],
      "44": [0.19444, 0.15556, 0, 0, 0.31944],
      "45": [0, 0.44444, 0, 0, 0.38333],
      "46": [0, 0.15556, 0, 0, 0.31944],
      "47": [0.25, 0.75, 0, 0, 0.575],
      "48": [0, 0.64444, 0, 0, 0.575],
      "49": [0, 0.64444, 0, 0, 0.575],
      "50": [0, 0.64444, 0, 0, 0.575],
      "51": [0, 0.64444, 0, 0, 0.575],
      "52": [0, 0.64444, 0, 0, 0.575],
      "53": [0, 0.64444, 0, 0, 0.575],
      "54": [0, 0.64444, 0, 0, 0.575],
      "55": [0, 0.64444, 0, 0, 0.575],
      "56": [0, 0.64444, 0, 0, 0.575],
      "57": [0, 0.64444, 0, 0, 0.575],
      "58": [0, 0.44444, 0, 0, 0.31944],
      "59": [0.19444, 0.44444, 0, 0, 0.31944],
      "60": [0.08556, 0.58556, 0, 0, 0.89444],
      "61": [-0.10889, 0.39111, 0, 0, 0.89444],
      "62": [0.08556, 0.58556, 0, 0, 0.89444],
      "63": [0, 0.69444, 0, 0, 0.54305],
      "64": [0, 0.69444, 0, 0, 0.89444],
      "65": [0, 0.68611, 0, 0, 0.86944],
      "66": [0, 0.68611, 0, 0, 0.81805],
      "67": [0, 0.68611, 0, 0, 0.83055],
      "68": [0, 0.68611, 0, 0, 0.88194],
      "69": [0, 0.68611, 0, 0, 0.75555],
      "70": [0, 0.68611, 0, 0, 0.72361],
      "71": [0, 0.68611, 0, 0, 0.90416],
      "72": [0, 0.68611, 0, 0, 0.9],
      "73": [0, 0.68611, 0, 0, 0.43611],
      "74": [0, 0.68611, 0, 0, 0.59444],
      "75": [0, 0.68611, 0, 0, 0.90138],
      "76": [0, 0.68611, 0, 0, 0.69166],
      "77": [0, 0.68611, 0, 0, 1.09166],
      "78": [0, 0.68611, 0, 0, 0.9],
      "79": [0, 0.68611, 0, 0, 0.86388],
      "80": [0, 0.68611, 0, 0, 0.78611],
      "81": [0.19444, 0.68611, 0, 0, 0.86388],
      "82": [0, 0.68611, 0, 0, 0.8625],
      "83": [0, 0.68611, 0, 0, 0.63889],
      "84": [0, 0.68611, 0, 0, 0.8],
      "85": [0, 0.68611, 0, 0, 0.88472],
      "86": [0, 0.68611, 0.01597, 0, 0.86944],
      "87": [0, 0.68611, 0.01597, 0, 1.18888],
      "88": [0, 0.68611, 0, 0, 0.86944],
      "89": [0, 0.68611, 0.02875, 0, 0.86944],
      "90": [0, 0.68611, 0, 0, 0.70277],
      "91": [0.25, 0.75, 0, 0, 0.31944],
      "92": [0.25, 0.75, 0, 0, 0.575],
      "93": [0.25, 0.75, 0, 0, 0.31944],
      "94": [0, 0.69444, 0, 0, 0.575],
      "95": [0.31, 0.13444, 0.03194, 0, 0.575],
      "97": [0, 0.44444, 0, 0, 0.55902],
      "98": [0, 0.69444, 0, 0, 0.63889],
      "99": [0, 0.44444, 0, 0, 0.51111],
      "100": [0, 0.69444, 0, 0, 0.63889],
      "101": [0, 0.44444, 0, 0, 0.52708],
      "102": [0, 0.69444, 0.10903, 0, 0.35139],
      "103": [0.19444, 0.44444, 0.01597, 0, 0.575],
      "104": [0, 0.69444, 0, 0, 0.63889],
      "105": [0, 0.69444, 0, 0, 0.31944],
      "106": [0.19444, 0.69444, 0, 0, 0.35139],
      "107": [0, 0.69444, 0, 0, 0.60694],
      "108": [0, 0.69444, 0, 0, 0.31944],
      "109": [0, 0.44444, 0, 0, 0.95833],
      "110": [0, 0.44444, 0, 0, 0.63889],
      "111": [0, 0.44444, 0, 0, 0.575],
      "112": [0.19444, 0.44444, 0, 0, 0.63889],
      "113": [0.19444, 0.44444, 0, 0, 0.60694],
      "114": [0, 0.44444, 0, 0, 0.47361],
      "115": [0, 0.44444, 0, 0, 0.45361],
      "116": [0, 0.63492, 0, 0, 0.44722],
      "117": [0, 0.44444, 0, 0, 0.63889],
      "118": [0, 0.44444, 0.01597, 0, 0.60694],
      "119": [0, 0.44444, 0.01597, 0, 0.83055],
      "120": [0, 0.44444, 0, 0, 0.60694],
      "121": [0.19444, 0.44444, 0.01597, 0, 0.60694],
      "122": [0, 0.44444, 0, 0, 0.51111],
      "123": [0.25, 0.75, 0, 0, 0.575],
      "124": [0.25, 0.75, 0, 0, 0.31944],
      "125": [0.25, 0.75, 0, 0, 0.575],
      "126": [0.35, 0.34444, 0, 0, 0.575],
      "160": [0, 0, 0, 0, 0.25],
      "163": [0, 0.69444, 0, 0, 0.86853],
      "168": [0, 0.69444, 0, 0, 0.575],
      "172": [0, 0.44444, 0, 0, 0.76666],
      "176": [0, 0.69444, 0, 0, 0.86944],
      "177": [0.13333, 0.63333, 0, 0, 0.89444],
      "184": [0.17014, 0, 0, 0, 0.51111],
      "198": [0, 0.68611, 0, 0, 1.04166],
      "215": [0.13333, 0.63333, 0, 0, 0.89444],
      "216": [0.04861, 0.73472, 0, 0, 0.89444],
      "223": [0, 0.69444, 0, 0, 0.59722],
      "230": [0, 0.44444, 0, 0, 0.83055],
      "247": [0.13333, 0.63333, 0, 0, 0.89444],
      "248": [0.09722, 0.54167, 0, 0, 0.575],
      "305": [0, 0.44444, 0, 0, 0.31944],
      "338": [0, 0.68611, 0, 0, 1.16944],
      "339": [0, 0.44444, 0, 0, 0.89444],
      "567": [0.19444, 0.44444, 0, 0, 0.35139],
      "710": [0, 0.69444, 0, 0, 0.575],
      "711": [0, 0.63194, 0, 0, 0.575],
      "713": [0, 0.59611, 0, 0, 0.575],
      "714": [0, 0.69444, 0, 0, 0.575],
      "715": [0, 0.69444, 0, 0, 0.575],
      "728": [0, 0.69444, 0, 0, 0.575],
      "729": [0, 0.69444, 0, 0, 0.31944],
      "730": [0, 0.69444, 0, 0, 0.86944],
      "732": [0, 0.69444, 0, 0, 0.575],
      "733": [0, 0.69444, 0, 0, 0.575],
      "915": [0, 0.68611, 0, 0, 0.69166],
      "916": [0, 0.68611, 0, 0, 0.95833],
      "920": [0, 0.68611, 0, 0, 0.89444],
      "923": [0, 0.68611, 0, 0, 0.80555],
      "926": [0, 0.68611, 0, 0, 0.76666],
      "928": [0, 0.68611, 0, 0, 0.9],
      "931": [0, 0.68611, 0, 0, 0.83055],
      "933": [0, 0.68611, 0, 0, 0.89444],
      "934": [0, 0.68611, 0, 0, 0.83055],
      "936": [0, 0.68611, 0, 0, 0.89444],
      "937": [0, 0.68611, 0, 0, 0.83055],
      "8211": [0, 0.44444, 0.03194, 0, 0.575],
      "8212": [0, 0.44444, 0.03194, 0, 1.14999],
      "8216": [0, 0.69444, 0, 0, 0.31944],
      "8217": [0, 0.69444, 0, 0, 0.31944],
      "8220": [0, 0.69444, 0, 0, 0.60278],
      "8221": [0, 0.69444, 0, 0, 0.60278],
      "8224": [0.19444, 0.69444, 0, 0, 0.51111],
      "8225": [0.19444, 0.69444, 0, 0, 0.51111],
      "8242": [0, 0.55556, 0, 0, 0.34444],
      "8407": [0, 0.72444, 0.15486, 0, 0.575],
      "8463": [0, 0.69444, 0, 0, 0.66759],
      "8465": [0, 0.69444, 0, 0, 0.83055],
      "8467": [0, 0.69444, 0, 0, 0.47361],
      "8472": [0.19444, 0.44444, 0, 0, 0.74027],
      "8476": [0, 0.69444, 0, 0, 0.83055],
      "8501": [0, 0.69444, 0, 0, 0.70277],
      "8592": [-0.10889, 0.39111, 0, 0, 1.14999],
      "8593": [0.19444, 0.69444, 0, 0, 0.575],
      "8594": [-0.10889, 0.39111, 0, 0, 1.14999],
      "8595": [0.19444, 0.69444, 0, 0, 0.575],
      "8596": [-0.10889, 0.39111, 0, 0, 1.14999],
      "8597": [0.25, 0.75, 0, 0, 0.575],
      "8598": [0.19444, 0.69444, 0, 0, 1.14999],
      "8599": [0.19444, 0.69444, 0, 0, 1.14999],
      "8600": [0.19444, 0.69444, 0, 0, 1.14999],
      "8601": [0.19444, 0.69444, 0, 0, 1.14999],
      "8636": [-0.10889, 0.39111, 0, 0, 1.14999],
      "8637": [-0.10889, 0.39111, 0, 0, 1.14999],
      "8640": [-0.10889, 0.39111, 0, 0, 1.14999],
      "8641": [-0.10889, 0.39111, 0, 0, 1.14999],
      "8656": [-0.10889, 0.39111, 0, 0, 1.14999],
      "8657": [0.19444, 0.69444, 0, 0, 0.70277],
      "8658": [-0.10889, 0.39111, 0, 0, 1.14999],
      "8659": [0.19444, 0.69444, 0, 0, 0.70277],
      "8660": [-0.10889, 0.39111, 0, 0, 1.14999],
      "8661": [0.25, 0.75, 0, 0, 0.70277],
      "8704": [0, 0.69444, 0, 0, 0.63889],
      "8706": [0, 0.69444, 0.06389, 0, 0.62847],
      "8707": [0, 0.69444, 0, 0, 0.63889],
      "8709": [0.05556, 0.75, 0, 0, 0.575],
      "8711": [0, 0.68611, 0, 0, 0.95833],
      "8712": [0.08556, 0.58556, 0, 0, 0.76666],
      "8715": [0.08556, 0.58556, 0, 0, 0.76666],
      "8722": [0.13333, 0.63333, 0, 0, 0.89444],
      "8723": [0.13333, 0.63333, 0, 0, 0.89444],
      "8725": [0.25, 0.75, 0, 0, 0.575],
      "8726": [0.25, 0.75, 0, 0, 0.575],
      "8727": [-0.02778, 0.47222, 0, 0, 0.575],
      "8728": [-0.02639, 0.47361, 0, 0, 0.575],
      "8729": [-0.02639, 0.47361, 0, 0, 0.575],
      "8730": [0.18, 0.82, 0, 0, 0.95833],
      "8733": [0, 0.44444, 0, 0, 0.89444],
      "8734": [0, 0.44444, 0, 0, 1.14999],
      "8736": [0, 0.69224, 0, 0, 0.72222],
      "8739": [0.25, 0.75, 0, 0, 0.31944],
      "8741": [0.25, 0.75, 0, 0, 0.575],
      "8743": [0, 0.55556, 0, 0, 0.76666],
      "8744": [0, 0.55556, 0, 0, 0.76666],
      "8745": [0, 0.55556, 0, 0, 0.76666],
      "8746": [0, 0.55556, 0, 0, 0.76666],
      "8747": [0.19444, 0.69444, 0.12778, 0, 0.56875],
      "8764": [-0.10889, 0.39111, 0, 0, 0.89444],
      "8768": [0.19444, 0.69444, 0, 0, 0.31944],
      "8771": [222e-5, 0.50222, 0, 0, 0.89444],
      "8773": [0.027, 0.638, 0, 0, 0.894],
      "8776": [0.02444, 0.52444, 0, 0, 0.89444],
      "8781": [222e-5, 0.50222, 0, 0, 0.89444],
      "8801": [222e-5, 0.50222, 0, 0, 0.89444],
      "8804": [0.19667, 0.69667, 0, 0, 0.89444],
      "8805": [0.19667, 0.69667, 0, 0, 0.89444],
      "8810": [0.08556, 0.58556, 0, 0, 1.14999],
      "8811": [0.08556, 0.58556, 0, 0, 1.14999],
      "8826": [0.08556, 0.58556, 0, 0, 0.89444],
      "8827": [0.08556, 0.58556, 0, 0, 0.89444],
      "8834": [0.08556, 0.58556, 0, 0, 0.89444],
      "8835": [0.08556, 0.58556, 0, 0, 0.89444],
      "8838": [0.19667, 0.69667, 0, 0, 0.89444],
      "8839": [0.19667, 0.69667, 0, 0, 0.89444],
      "8846": [0, 0.55556, 0, 0, 0.76666],
      "8849": [0.19667, 0.69667, 0, 0, 0.89444],
      "8850": [0.19667, 0.69667, 0, 0, 0.89444],
      "8851": [0, 0.55556, 0, 0, 0.76666],
      "8852": [0, 0.55556, 0, 0, 0.76666],
      "8853": [0.13333, 0.63333, 0, 0, 0.89444],
      "8854": [0.13333, 0.63333, 0, 0, 0.89444],
      "8855": [0.13333, 0.63333, 0, 0, 0.89444],
      "8856": [0.13333, 0.63333, 0, 0, 0.89444],
      "8857": [0.13333, 0.63333, 0, 0, 0.89444],
      "8866": [0, 0.69444, 0, 0, 0.70277],
      "8867": [0, 0.69444, 0, 0, 0.70277],
      "8868": [0, 0.69444, 0, 0, 0.89444],
      "8869": [0, 0.69444, 0, 0, 0.89444],
      "8900": [-0.02639, 0.47361, 0, 0, 0.575],
      "8901": [-0.02639, 0.47361, 0, 0, 0.31944],
      "8902": [-0.02778, 0.47222, 0, 0, 0.575],
      "8968": [0.25, 0.75, 0, 0, 0.51111],
      "8969": [0.25, 0.75, 0, 0, 0.51111],
      "8970": [0.25, 0.75, 0, 0, 0.51111],
      "8971": [0.25, 0.75, 0, 0, 0.51111],
      "8994": [-0.13889, 0.36111, 0, 0, 1.14999],
      "8995": [-0.13889, 0.36111, 0, 0, 1.14999],
      "9651": [0.19444, 0.69444, 0, 0, 1.02222],
      "9657": [-0.02778, 0.47222, 0, 0, 0.575],
      "9661": [0.19444, 0.69444, 0, 0, 1.02222],
      "9667": [-0.02778, 0.47222, 0, 0, 0.575],
      "9711": [0.19444, 0.69444, 0, 0, 1.14999],
      "9824": [0.12963, 0.69444, 0, 0, 0.89444],
      "9825": [0.12963, 0.69444, 0, 0, 0.89444],
      "9826": [0.12963, 0.69444, 0, 0, 0.89444],
      "9827": [0.12963, 0.69444, 0, 0, 0.89444],
      "9837": [0, 0.75, 0, 0, 0.44722],
      "9838": [0.19444, 0.69444, 0, 0, 0.44722],
      "9839": [0.19444, 0.69444, 0, 0, 0.44722],
      "10216": [0.25, 0.75, 0, 0, 0.44722],
      "10217": [0.25, 0.75, 0, 0, 0.44722],
      "10815": [0, 0.68611, 0, 0, 0.9],
      "10927": [0.19667, 0.69667, 0, 0, 0.89444],
      "10928": [0.19667, 0.69667, 0, 0, 0.89444],
      "57376": [0.19444, 0.69444, 0, 0, 0]
    },
    "Main-BoldItalic": {
      "32": [0, 0, 0, 0, 0.25],
      "33": [0, 0.69444, 0.11417, 0, 0.38611],
      "34": [0, 0.69444, 0.07939, 0, 0.62055],
      "35": [0.19444, 0.69444, 0.06833, 0, 0.94444],
      "37": [0.05556, 0.75, 0.12861, 0, 0.94444],
      "38": [0, 0.69444, 0.08528, 0, 0.88555],
      "39": [0, 0.69444, 0.12945, 0, 0.35555],
      "40": [0.25, 0.75, 0.15806, 0, 0.47333],
      "41": [0.25, 0.75, 0.03306, 0, 0.47333],
      "42": [0, 0.75, 0.14333, 0, 0.59111],
      "43": [0.10333, 0.60333, 0.03306, 0, 0.88555],
      "44": [0.19444, 0.14722, 0, 0, 0.35555],
      "45": [0, 0.44444, 0.02611, 0, 0.41444],
      "46": [0, 0.14722, 0, 0, 0.35555],
      "47": [0.25, 0.75, 0.15806, 0, 0.59111],
      "48": [0, 0.64444, 0.13167, 0, 0.59111],
      "49": [0, 0.64444, 0.13167, 0, 0.59111],
      "50": [0, 0.64444, 0.13167, 0, 0.59111],
      "51": [0, 0.64444, 0.13167, 0, 0.59111],
      "52": [0.19444, 0.64444, 0.13167, 0, 0.59111],
      "53": [0, 0.64444, 0.13167, 0, 0.59111],
      "54": [0, 0.64444, 0.13167, 0, 0.59111],
      "55": [0.19444, 0.64444, 0.13167, 0, 0.59111],
      "56": [0, 0.64444, 0.13167, 0, 0.59111],
      "57": [0, 0.64444, 0.13167, 0, 0.59111],
      "58": [0, 0.44444, 0.06695, 0, 0.35555],
      "59": [0.19444, 0.44444, 0.06695, 0, 0.35555],
      "61": [-0.10889, 0.39111, 0.06833, 0, 0.88555],
      "63": [0, 0.69444, 0.11472, 0, 0.59111],
      "64": [0, 0.69444, 0.09208, 0, 0.88555],
      "65": [0, 0.68611, 0, 0, 0.86555],
      "66": [0, 0.68611, 0.0992, 0, 0.81666],
      "67": [0, 0.68611, 0.14208, 0, 0.82666],
      "68": [0, 0.68611, 0.09062, 0, 0.87555],
      "69": [0, 0.68611, 0.11431, 0, 0.75666],
      "70": [0, 0.68611, 0.12903, 0, 0.72722],
      "71": [0, 0.68611, 0.07347, 0, 0.89527],
      "72": [0, 0.68611, 0.17208, 0, 0.8961],
      "73": [0, 0.68611, 0.15681, 0, 0.47166],
      "74": [0, 0.68611, 0.145, 0, 0.61055],
      "75": [0, 0.68611, 0.14208, 0, 0.89499],
      "76": [0, 0.68611, 0, 0, 0.69777],
      "77": [0, 0.68611, 0.17208, 0, 1.07277],
      "78": [0, 0.68611, 0.17208, 0, 0.8961],
      "79": [0, 0.68611, 0.09062, 0, 0.85499],
      "80": [0, 0.68611, 0.0992, 0, 0.78721],
      "81": [0.19444, 0.68611, 0.09062, 0, 0.85499],
      "82": [0, 0.68611, 0.02559, 0, 0.85944],
      "83": [0, 0.68611, 0.11264, 0, 0.64999],
      "84": [0, 0.68611, 0.12903, 0, 0.7961],
      "85": [0, 0.68611, 0.17208, 0, 0.88083],
      "86": [0, 0.68611, 0.18625, 0, 0.86555],
      "87": [0, 0.68611, 0.18625, 0, 1.15999],
      "88": [0, 0.68611, 0.15681, 0, 0.86555],
      "89": [0, 0.68611, 0.19803, 0, 0.86555],
      "90": [0, 0.68611, 0.14208, 0, 0.70888],
      "91": [0.25, 0.75, 0.1875, 0, 0.35611],
      "93": [0.25, 0.75, 0.09972, 0, 0.35611],
      "94": [0, 0.69444, 0.06709, 0, 0.59111],
      "95": [0.31, 0.13444, 0.09811, 0, 0.59111],
      "97": [0, 0.44444, 0.09426, 0, 0.59111],
      "98": [0, 0.69444, 0.07861, 0, 0.53222],
      "99": [0, 0.44444, 0.05222, 0, 0.53222],
      "100": [0, 0.69444, 0.10861, 0, 0.59111],
      "101": [0, 0.44444, 0.085, 0, 0.53222],
      "102": [0.19444, 0.69444, 0.21778, 0, 0.4],
      "103": [0.19444, 0.44444, 0.105, 0, 0.53222],
      "104": [0, 0.69444, 0.09426, 0, 0.59111],
      "105": [0, 0.69326, 0.11387, 0, 0.35555],
      "106": [0.19444, 0.69326, 0.1672, 0, 0.35555],
      "107": [0, 0.69444, 0.11111, 0, 0.53222],
      "108": [0, 0.69444, 0.10861, 0, 0.29666],
      "109": [0, 0.44444, 0.09426, 0, 0.94444],
      "110": [0, 0.44444, 0.09426, 0, 0.64999],
      "111": [0, 0.44444, 0.07861, 0, 0.59111],
      "112": [0.19444, 0.44444, 0.07861, 0, 0.59111],
      "113": [0.19444, 0.44444, 0.105, 0, 0.53222],
      "114": [0, 0.44444, 0.11111, 0, 0.50167],
      "115": [0, 0.44444, 0.08167, 0, 0.48694],
      "116": [0, 0.63492, 0.09639, 0, 0.385],
      "117": [0, 0.44444, 0.09426, 0, 0.62055],
      "118": [0, 0.44444, 0.11111, 0, 0.53222],
      "119": [0, 0.44444, 0.11111, 0, 0.76777],
      "120": [0, 0.44444, 0.12583, 0, 0.56055],
      "121": [0.19444, 0.44444, 0.105, 0, 0.56166],
      "122": [0, 0.44444, 0.13889, 0, 0.49055],
      "126": [0.35, 0.34444, 0.11472, 0, 0.59111],
      "160": [0, 0, 0, 0, 0.25],
      "168": [0, 0.69444, 0.11473, 0, 0.59111],
      "176": [0, 0.69444, 0, 0, 0.94888],
      "184": [0.17014, 0, 0, 0, 0.53222],
      "198": [0, 0.68611, 0.11431, 0, 1.02277],
      "216": [0.04861, 0.73472, 0.09062, 0, 0.88555],
      "223": [0.19444, 0.69444, 0.09736, 0, 0.665],
      "230": [0, 0.44444, 0.085, 0, 0.82666],
      "248": [0.09722, 0.54167, 0.09458, 0, 0.59111],
      "305": [0, 0.44444, 0.09426, 0, 0.35555],
      "338": [0, 0.68611, 0.11431, 0, 1.14054],
      "339": [0, 0.44444, 0.085, 0, 0.82666],
      "567": [0.19444, 0.44444, 0.04611, 0, 0.385],
      "710": [0, 0.69444, 0.06709, 0, 0.59111],
      "711": [0, 0.63194, 0.08271, 0, 0.59111],
      "713": [0, 0.59444, 0.10444, 0, 0.59111],
      "714": [0, 0.69444, 0.08528, 0, 0.59111],
      "715": [0, 0.69444, 0, 0, 0.59111],
      "728": [0, 0.69444, 0.10333, 0, 0.59111],
      "729": [0, 0.69444, 0.12945, 0, 0.35555],
      "730": [0, 0.69444, 0, 0, 0.94888],
      "732": [0, 0.69444, 0.11472, 0, 0.59111],
      "733": [0, 0.69444, 0.11472, 0, 0.59111],
      "915": [0, 0.68611, 0.12903, 0, 0.69777],
      "916": [0, 0.68611, 0, 0, 0.94444],
      "920": [0, 0.68611, 0.09062, 0, 0.88555],
      "923": [0, 0.68611, 0, 0, 0.80666],
      "926": [0, 0.68611, 0.15092, 0, 0.76777],
      "928": [0, 0.68611, 0.17208, 0, 0.8961],
      "931": [0, 0.68611, 0.11431, 0, 0.82666],
      "933": [0, 0.68611, 0.10778, 0, 0.88555],
      "934": [0, 0.68611, 0.05632, 0, 0.82666],
      "936": [0, 0.68611, 0.10778, 0, 0.88555],
      "937": [0, 0.68611, 0.0992, 0, 0.82666],
      "8211": [0, 0.44444, 0.09811, 0, 0.59111],
      "8212": [0, 0.44444, 0.09811, 0, 1.18221],
      "8216": [0, 0.69444, 0.12945, 0, 0.35555],
      "8217": [0, 0.69444, 0.12945, 0, 0.35555],
      "8220": [0, 0.69444, 0.16772, 0, 0.62055],
      "8221": [0, 0.69444, 0.07939, 0, 0.62055]
    },
    "Main-Italic": {
      "32": [0, 0, 0, 0, 0.25],
      "33": [0, 0.69444, 0.12417, 0, 0.30667],
      "34": [0, 0.69444, 0.06961, 0, 0.51444],
      "35": [0.19444, 0.69444, 0.06616, 0, 0.81777],
      "37": [0.05556, 0.75, 0.13639, 0, 0.81777],
      "38": [0, 0.69444, 0.09694, 0, 0.76666],
      "39": [0, 0.69444, 0.12417, 0, 0.30667],
      "40": [0.25, 0.75, 0.16194, 0, 0.40889],
      "41": [0.25, 0.75, 0.03694, 0, 0.40889],
      "42": [0, 0.75, 0.14917, 0, 0.51111],
      "43": [0.05667, 0.56167, 0.03694, 0, 0.76666],
      "44": [0.19444, 0.10556, 0, 0, 0.30667],
      "45": [0, 0.43056, 0.02826, 0, 0.35778],
      "46": [0, 0.10556, 0, 0, 0.30667],
      "47": [0.25, 0.75, 0.16194, 0, 0.51111],
      "48": [0, 0.64444, 0.13556, 0, 0.51111],
      "49": [0, 0.64444, 0.13556, 0, 0.51111],
      "50": [0, 0.64444, 0.13556, 0, 0.51111],
      "51": [0, 0.64444, 0.13556, 0, 0.51111],
      "52": [0.19444, 0.64444, 0.13556, 0, 0.51111],
      "53": [0, 0.64444, 0.13556, 0, 0.51111],
      "54": [0, 0.64444, 0.13556, 0, 0.51111],
      "55": [0.19444, 0.64444, 0.13556, 0, 0.51111],
      "56": [0, 0.64444, 0.13556, 0, 0.51111],
      "57": [0, 0.64444, 0.13556, 0, 0.51111],
      "58": [0, 0.43056, 0.0582, 0, 0.30667],
      "59": [0.19444, 0.43056, 0.0582, 0, 0.30667],
      "61": [-0.13313, 0.36687, 0.06616, 0, 0.76666],
      "63": [0, 0.69444, 0.1225, 0, 0.51111],
      "64": [0, 0.69444, 0.09597, 0, 0.76666],
      "65": [0, 0.68333, 0, 0, 0.74333],
      "66": [0, 0.68333, 0.10257, 0, 0.70389],
      "67": [0, 0.68333, 0.14528, 0, 0.71555],
      "68": [0, 0.68333, 0.09403, 0, 0.755],
      "69": [0, 0.68333, 0.12028, 0, 0.67833],
      "70": [0, 0.68333, 0.13305, 0, 0.65277],
      "71": [0, 0.68333, 0.08722, 0, 0.77361],
      "72": [0, 0.68333, 0.16389, 0, 0.74333],
      "73": [0, 0.68333, 0.15806, 0, 0.38555],
      "74": [0, 0.68333, 0.14028, 0, 0.525],
      "75": [0, 0.68333, 0.14528, 0, 0.76888],
      "76": [0, 0.68333, 0, 0, 0.62722],
      "77": [0, 0.68333, 0.16389, 0, 0.89666],
      "78": [0, 0.68333, 0.16389, 0, 0.74333],
      "79": [0, 0.68333, 0.09403, 0, 0.76666],
      "80": [0, 0.68333, 0.10257, 0, 0.67833],
      "81": [0.19444, 0.68333, 0.09403, 0, 0.76666],
      "82": [0, 0.68333, 0.03868, 0, 0.72944],
      "83": [0, 0.68333, 0.11972, 0, 0.56222],
      "84": [0, 0.68333, 0.13305, 0, 0.71555],
      "85": [0, 0.68333, 0.16389, 0, 0.74333],
      "86": [0, 0.68333, 0.18361, 0, 0.74333],
      "87": [0, 0.68333, 0.18361, 0, 0.99888],
      "88": [0, 0.68333, 0.15806, 0, 0.74333],
      "89": [0, 0.68333, 0.19383, 0, 0.74333],
      "90": [0, 0.68333, 0.14528, 0, 0.61333],
      "91": [0.25, 0.75, 0.1875, 0, 0.30667],
      "93": [0.25, 0.75, 0.10528, 0, 0.30667],
      "94": [0, 0.69444, 0.06646, 0, 0.51111],
      "95": [0.31, 0.12056, 0.09208, 0, 0.51111],
      "97": [0, 0.43056, 0.07671, 0, 0.51111],
      "98": [0, 0.69444, 0.06312, 0, 0.46],
      "99": [0, 0.43056, 0.05653, 0, 0.46],
      "100": [0, 0.69444, 0.10333, 0, 0.51111],
      "101": [0, 0.43056, 0.07514, 0, 0.46],
      "102": [0.19444, 0.69444, 0.21194, 0, 0.30667],
      "103": [0.19444, 0.43056, 0.08847, 0, 0.46],
      "104": [0, 0.69444, 0.07671, 0, 0.51111],
      "105": [0, 0.65536, 0.1019, 0, 0.30667],
      "106": [0.19444, 0.65536, 0.14467, 0, 0.30667],
      "107": [0, 0.69444, 0.10764, 0, 0.46],
      "108": [0, 0.69444, 0.10333, 0, 0.25555],
      "109": [0, 0.43056, 0.07671, 0, 0.81777],
      "110": [0, 0.43056, 0.07671, 0, 0.56222],
      "111": [0, 0.43056, 0.06312, 0, 0.51111],
      "112": [0.19444, 0.43056, 0.06312, 0, 0.51111],
      "113": [0.19444, 0.43056, 0.08847, 0, 0.46],
      "114": [0, 0.43056, 0.10764, 0, 0.42166],
      "115": [0, 0.43056, 0.08208, 0, 0.40889],
      "116": [0, 0.61508, 0.09486, 0, 0.33222],
      "117": [0, 0.43056, 0.07671, 0, 0.53666],
      "118": [0, 0.43056, 0.10764, 0, 0.46],
      "119": [0, 0.43056, 0.10764, 0, 0.66444],
      "120": [0, 0.43056, 0.12042, 0, 0.46389],
      "121": [0.19444, 0.43056, 0.08847, 0, 0.48555],
      "122": [0, 0.43056, 0.12292, 0, 0.40889],
      "126": [0.35, 0.31786, 0.11585, 0, 0.51111],
      "160": [0, 0, 0, 0, 0.25],
      "168": [0, 0.66786, 0.10474, 0, 0.51111],
      "176": [0, 0.69444, 0, 0, 0.83129],
      "184": [0.17014, 0, 0, 0, 0.46],
      "198": [0, 0.68333, 0.12028, 0, 0.88277],
      "216": [0.04861, 0.73194, 0.09403, 0, 0.76666],
      "223": [0.19444, 0.69444, 0.10514, 0, 0.53666],
      "230": [0, 0.43056, 0.07514, 0, 0.71555],
      "248": [0.09722, 0.52778, 0.09194, 0, 0.51111],
      "338": [0, 0.68333, 0.12028, 0, 0.98499],
      "339": [0, 0.43056, 0.07514, 0, 0.71555],
      "710": [0, 0.69444, 0.06646, 0, 0.51111],
      "711": [0, 0.62847, 0.08295, 0, 0.51111],
      "713": [0, 0.56167, 0.10333, 0, 0.51111],
      "714": [0, 0.69444, 0.09694, 0, 0.51111],
      "715": [0, 0.69444, 0, 0, 0.51111],
      "728": [0, 0.69444, 0.10806, 0, 0.51111],
      "729": [0, 0.66786, 0.11752, 0, 0.30667],
      "730": [0, 0.69444, 0, 0, 0.83129],
      "732": [0, 0.66786, 0.11585, 0, 0.51111],
      "733": [0, 0.69444, 0.1225, 0, 0.51111],
      "915": [0, 0.68333, 0.13305, 0, 0.62722],
      "916": [0, 0.68333, 0, 0, 0.81777],
      "920": [0, 0.68333, 0.09403, 0, 0.76666],
      "923": [0, 0.68333, 0, 0, 0.69222],
      "926": [0, 0.68333, 0.15294, 0, 0.66444],
      "928": [0, 0.68333, 0.16389, 0, 0.74333],
      "931": [0, 0.68333, 0.12028, 0, 0.71555],
      "933": [0, 0.68333, 0.11111, 0, 0.76666],
      "934": [0, 0.68333, 0.05986, 0, 0.71555],
      "936": [0, 0.68333, 0.11111, 0, 0.76666],
      "937": [0, 0.68333, 0.10257, 0, 0.71555],
      "8211": [0, 0.43056, 0.09208, 0, 0.51111],
      "8212": [0, 0.43056, 0.09208, 0, 1.02222],
      "8216": [0, 0.69444, 0.12417, 0, 0.30667],
      "8217": [0, 0.69444, 0.12417, 0, 0.30667],
      "8220": [0, 0.69444, 0.1685, 0, 0.51444],
      "8221": [0, 0.69444, 0.06961, 0, 0.51444],
      "8463": [0, 0.68889, 0, 0, 0.54028]
    },
    "Main-Regular": {
      "32": [0, 0, 0, 0, 0.25],
      "33": [0, 0.69444, 0, 0, 0.27778],
      "34": [0, 0.69444, 0, 0, 0.5],
      "35": [0.19444, 0.69444, 0, 0, 0.83334],
      "36": [0.05556, 0.75, 0, 0, 0.5],
      "37": [0.05556, 0.75, 0, 0, 0.83334],
      "38": [0, 0.69444, 0, 0, 0.77778],
      "39": [0, 0.69444, 0, 0, 0.27778],
      "40": [0.25, 0.75, 0, 0, 0.38889],
      "41": [0.25, 0.75, 0, 0, 0.38889],
      "42": [0, 0.75, 0, 0, 0.5],
      "43": [0.08333, 0.58333, 0, 0, 0.77778],
      "44": [0.19444, 0.10556, 0, 0, 0.27778],
      "45": [0, 0.43056, 0, 0, 0.33333],
      "46": [0, 0.10556, 0, 0, 0.27778],
      "47": [0.25, 0.75, 0, 0, 0.5],
      "48": [0, 0.64444, 0, 0, 0.5],
      "49": [0, 0.64444, 0, 0, 0.5],
      "50": [0, 0.64444, 0, 0, 0.5],
      "51": [0, 0.64444, 0, 0, 0.5],
      "52": [0, 0.64444, 0, 0, 0.5],
      "53": [0, 0.64444, 0, 0, 0.5],
      "54": [0, 0.64444, 0, 0, 0.5],
      "55": [0, 0.64444, 0, 0, 0.5],
      "56": [0, 0.64444, 0, 0, 0.5],
      "57": [0, 0.64444, 0, 0, 0.5],
      "58": [0, 0.43056, 0, 0, 0.27778],
      "59": [0.19444, 0.43056, 0, 0, 0.27778],
      "60": [0.0391, 0.5391, 0, 0, 0.77778],
      "61": [-0.13313, 0.36687, 0, 0, 0.77778],
      "62": [0.0391, 0.5391, 0, 0, 0.77778],
      "63": [0, 0.69444, 0, 0, 0.47222],
      "64": [0, 0.69444, 0, 0, 0.77778],
      "65": [0, 0.68333, 0, 0, 0.75],
      "66": [0, 0.68333, 0, 0, 0.70834],
      "67": [0, 0.68333, 0, 0, 0.72222],
      "68": [0, 0.68333, 0, 0, 0.76389],
      "69": [0, 0.68333, 0, 0, 0.68056],
      "70": [0, 0.68333, 0, 0, 0.65278],
      "71": [0, 0.68333, 0, 0, 0.78472],
      "72": [0, 0.68333, 0, 0, 0.75],
      "73": [0, 0.68333, 0, 0, 0.36111],
      "74": [0, 0.68333, 0, 0, 0.51389],
      "75": [0, 0.68333, 0, 0, 0.77778],
      "76": [0, 0.68333, 0, 0, 0.625],
      "77": [0, 0.68333, 0, 0, 0.91667],
      "78": [0, 0.68333, 0, 0, 0.75],
      "79": [0, 0.68333, 0, 0, 0.77778],
      "80": [0, 0.68333, 0, 0, 0.68056],
      "81": [0.19444, 0.68333, 0, 0, 0.77778],
      "82": [0, 0.68333, 0, 0, 0.73611],
      "83": [0, 0.68333, 0, 0, 0.55556],
      "84": [0, 0.68333, 0, 0, 0.72222],
      "85": [0, 0.68333, 0, 0, 0.75],
      "86": [0, 0.68333, 0.01389, 0, 0.75],
      "87": [0, 0.68333, 0.01389, 0, 1.02778],
      "88": [0, 0.68333, 0, 0, 0.75],
      "89": [0, 0.68333, 0.025, 0, 0.75],
      "90": [0, 0.68333, 0, 0, 0.61111],
      "91": [0.25, 0.75, 0, 0, 0.27778],
      "92": [0.25, 0.75, 0, 0, 0.5],
      "93": [0.25, 0.75, 0, 0, 0.27778],
      "94": [0, 0.69444, 0, 0, 0.5],
      "95": [0.31, 0.12056, 0.02778, 0, 0.5],
      "97": [0, 0.43056, 0, 0, 0.5],
      "98": [0, 0.69444, 0, 0, 0.55556],
      "99": [0, 0.43056, 0, 0, 0.44445],
      "100": [0, 0.69444, 0, 0, 0.55556],
      "101": [0, 0.43056, 0, 0, 0.44445],
      "102": [0, 0.69444, 0.07778, 0, 0.30556],
      "103": [0.19444, 0.43056, 0.01389, 0, 0.5],
      "104": [0, 0.69444, 0, 0, 0.55556],
      "105": [0, 0.66786, 0, 0, 0.27778],
      "106": [0.19444, 0.66786, 0, 0, 0.30556],
      "107": [0, 0.69444, 0, 0, 0.52778],
      "108": [0, 0.69444, 0, 0, 0.27778],
      "109": [0, 0.43056, 0, 0, 0.83334],
      "110": [0, 0.43056, 0, 0, 0.55556],
      "111": [0, 0.43056, 0, 0, 0.5],
      "112": [0.19444, 0.43056, 0, 0, 0.55556],
      "113": [0.19444, 0.43056, 0, 0, 0.52778],
      "114": [0, 0.43056, 0, 0, 0.39167],
      "115": [0, 0.43056, 0, 0, 0.39445],
      "116": [0, 0.61508, 0, 0, 0.38889],
      "117": [0, 0.43056, 0, 0, 0.55556],
      "118": [0, 0.43056, 0.01389, 0, 0.52778],
      "119": [0, 0.43056, 0.01389, 0, 0.72222],
      "120": [0, 0.43056, 0, 0, 0.52778],
      "121": [0.19444, 0.43056, 0.01389, 0, 0.52778],
      "122": [0, 0.43056, 0, 0, 0.44445],
      "123": [0.25, 0.75, 0, 0, 0.5],
      "124": [0.25, 0.75, 0, 0, 0.27778],
      "125": [0.25, 0.75, 0, 0, 0.5],
      "126": [0.35, 0.31786, 0, 0, 0.5],
      "160": [0, 0, 0, 0, 0.25],
      "163": [0, 0.69444, 0, 0, 0.76909],
      "167": [0.19444, 0.69444, 0, 0, 0.44445],
      "168": [0, 0.66786, 0, 0, 0.5],
      "172": [0, 0.43056, 0, 0, 0.66667],
      "176": [0, 0.69444, 0, 0, 0.75],
      "177": [0.08333, 0.58333, 0, 0, 0.77778],
      "182": [0.19444, 0.69444, 0, 0, 0.61111],
      "184": [0.17014, 0, 0, 0, 0.44445],
      "198": [0, 0.68333, 0, 0, 0.90278],
      "215": [0.08333, 0.58333, 0, 0, 0.77778],
      "216": [0.04861, 0.73194, 0, 0, 0.77778],
      "223": [0, 0.69444, 0, 0, 0.5],
      "230": [0, 0.43056, 0, 0, 0.72222],
      "247": [0.08333, 0.58333, 0, 0, 0.77778],
      "248": [0.09722, 0.52778, 0, 0, 0.5],
      "305": [0, 0.43056, 0, 0, 0.27778],
      "338": [0, 0.68333, 0, 0, 1.01389],
      "339": [0, 0.43056, 0, 0, 0.77778],
      "567": [0.19444, 0.43056, 0, 0, 0.30556],
      "710": [0, 0.69444, 0, 0, 0.5],
      "711": [0, 0.62847, 0, 0, 0.5],
      "713": [0, 0.56778, 0, 0, 0.5],
      "714": [0, 0.69444, 0, 0, 0.5],
      "715": [0, 0.69444, 0, 0, 0.5],
      "728": [0, 0.69444, 0, 0, 0.5],
      "729": [0, 0.66786, 0, 0, 0.27778],
      "730": [0, 0.69444, 0, 0, 0.75],
      "732": [0, 0.66786, 0, 0, 0.5],
      "733": [0, 0.69444, 0, 0, 0.5],
      "915": [0, 0.68333, 0, 0, 0.625],
      "916": [0, 0.68333, 0, 0, 0.83334],
      "920": [0, 0.68333, 0, 0, 0.77778],
      "923": [0, 0.68333, 0, 0, 0.69445],
      "926": [0, 0.68333, 0, 0, 0.66667],
      "928": [0, 0.68333, 0, 0, 0.75],
      "931": [0, 0.68333, 0, 0, 0.72222],
      "933": [0, 0.68333, 0, 0, 0.77778],
      "934": [0, 0.68333, 0, 0, 0.72222],
      "936": [0, 0.68333, 0, 0, 0.77778],
      "937": [0, 0.68333, 0, 0, 0.72222],
      "8211": [0, 0.43056, 0.02778, 0, 0.5],
      "8212": [0, 0.43056, 0.02778, 0, 1],
      "8216": [0, 0.69444, 0, 0, 0.27778],
      "8217": [0, 0.69444, 0, 0, 0.27778],
      "8220": [0, 0.69444, 0, 0, 0.5],
      "8221": [0, 0.69444, 0, 0, 0.5],
      "8224": [0.19444, 0.69444, 0, 0, 0.44445],
      "8225": [0.19444, 0.69444, 0, 0, 0.44445],
      "8230": [0, 0.123, 0, 0, 1.172],
      "8242": [0, 0.55556, 0, 0, 0.275],
      "8407": [0, 0.71444, 0.15382, 0, 0.5],
      "8463": [0, 0.68889, 0, 0, 0.54028],
      "8465": [0, 0.69444, 0, 0, 0.72222],
      "8467": [0, 0.69444, 0, 0.11111, 0.41667],
      "8472": [0.19444, 0.43056, 0, 0.11111, 0.63646],
      "8476": [0, 0.69444, 0, 0, 0.72222],
      "8501": [0, 0.69444, 0, 0, 0.61111],
      "8592": [-0.13313, 0.36687, 0, 0, 1],
      "8593": [0.19444, 0.69444, 0, 0, 0.5],
      "8594": [-0.13313, 0.36687, 0, 0, 1],
      "8595": [0.19444, 0.69444, 0, 0, 0.5],
      "8596": [-0.13313, 0.36687, 0, 0, 1],
      "8597": [0.25, 0.75, 0, 0, 0.5],
      "8598": [0.19444, 0.69444, 0, 0, 1],
      "8599": [0.19444, 0.69444, 0, 0, 1],
      "8600": [0.19444, 0.69444, 0, 0, 1],
      "8601": [0.19444, 0.69444, 0, 0, 1],
      "8614": [0.011, 0.511, 0, 0, 1],
      "8617": [0.011, 0.511, 0, 0, 1.126],
      "8618": [0.011, 0.511, 0, 0, 1.126],
      "8636": [-0.13313, 0.36687, 0, 0, 1],
      "8637": [-0.13313, 0.36687, 0, 0, 1],
      "8640": [-0.13313, 0.36687, 0, 0, 1],
      "8641": [-0.13313, 0.36687, 0, 0, 1],
      "8652": [0.011, 0.671, 0, 0, 1],
      "8656": [-0.13313, 0.36687, 0, 0, 1],
      "8657": [0.19444, 0.69444, 0, 0, 0.61111],
      "8658": [-0.13313, 0.36687, 0, 0, 1],
      "8659": [0.19444, 0.69444, 0, 0, 0.61111],
      "8660": [-0.13313, 0.36687, 0, 0, 1],
      "8661": [0.25, 0.75, 0, 0, 0.61111],
      "8704": [0, 0.69444, 0, 0, 0.55556],
      "8706": [0, 0.69444, 0.05556, 0.08334, 0.5309],
      "8707": [0, 0.69444, 0, 0, 0.55556],
      "8709": [0.05556, 0.75, 0, 0, 0.5],
      "8711": [0, 0.68333, 0, 0, 0.83334],
      "8712": [0.0391, 0.5391, 0, 0, 0.66667],
      "8715": [0.0391, 0.5391, 0, 0, 0.66667],
      "8722": [0.08333, 0.58333, 0, 0, 0.77778],
      "8723": [0.08333, 0.58333, 0, 0, 0.77778],
      "8725": [0.25, 0.75, 0, 0, 0.5],
      "8726": [0.25, 0.75, 0, 0, 0.5],
      "8727": [-0.03472, 0.46528, 0, 0, 0.5],
      "8728": [-0.05555, 0.44445, 0, 0, 0.5],
      "8729": [-0.05555, 0.44445, 0, 0, 0.5],
      "8730": [0.2, 0.8, 0, 0, 0.83334],
      "8733": [0, 0.43056, 0, 0, 0.77778],
      "8734": [0, 0.43056, 0, 0, 1],
      "8736": [0, 0.69224, 0, 0, 0.72222],
      "8739": [0.25, 0.75, 0, 0, 0.27778],
      "8741": [0.25, 0.75, 0, 0, 0.5],
      "8743": [0, 0.55556, 0, 0, 0.66667],
      "8744": [0, 0.55556, 0, 0, 0.66667],
      "8745": [0, 0.55556, 0, 0, 0.66667],
      "8746": [0, 0.55556, 0, 0, 0.66667],
      "8747": [0.19444, 0.69444, 0.11111, 0, 0.41667],
      "8764": [-0.13313, 0.36687, 0, 0, 0.77778],
      "8768": [0.19444, 0.69444, 0, 0, 0.27778],
      "8771": [-0.03625, 0.46375, 0, 0, 0.77778],
      "8773": [-0.022, 0.589, 0, 0, 0.778],
      "8776": [-0.01688, 0.48312, 0, 0, 0.77778],
      "8781": [-0.03625, 0.46375, 0, 0, 0.77778],
      "8784": [-0.133, 0.673, 0, 0, 0.778],
      "8801": [-0.03625, 0.46375, 0, 0, 0.77778],
      "8804": [0.13597, 0.63597, 0, 0, 0.77778],
      "8805": [0.13597, 0.63597, 0, 0, 0.77778],
      "8810": [0.0391, 0.5391, 0, 0, 1],
      "8811": [0.0391, 0.5391, 0, 0, 1],
      "8826": [0.0391, 0.5391, 0, 0, 0.77778],
      "8827": [0.0391, 0.5391, 0, 0, 0.77778],
      "8834": [0.0391, 0.5391, 0, 0, 0.77778],
      "8835": [0.0391, 0.5391, 0, 0, 0.77778],
      "8838": [0.13597, 0.63597, 0, 0, 0.77778],
      "8839": [0.13597, 0.63597, 0, 0, 0.77778],
      "8846": [0, 0.55556, 0, 0, 0.66667],
      "8849": [0.13597, 0.63597, 0, 0, 0.77778],
      "8850": [0.13597, 0.63597, 0, 0, 0.77778],
      "8851": [0, 0.55556, 0, 0, 0.66667],
      "8852": [0, 0.55556, 0, 0, 0.66667],
      "8853": [0.08333, 0.58333, 0, 0, 0.77778],
      "8854": [0.08333, 0.58333, 0, 0, 0.77778],
      "8855": [0.08333, 0.58333, 0, 0, 0.77778],
      "8856": [0.08333, 0.58333, 0, 0, 0.77778],
      "8857": [0.08333, 0.58333, 0, 0, 0.77778],
      "8866": [0, 0.69444, 0, 0, 0.61111],
      "8867": [0, 0.69444, 0, 0, 0.61111],
      "8868": [0, 0.69444, 0, 0, 0.77778],
      "8869": [0, 0.69444, 0, 0, 0.77778],
      "8872": [0.249, 0.75, 0, 0, 0.867],
      "8900": [-0.05555, 0.44445, 0, 0, 0.5],
      "8901": [-0.05555, 0.44445, 0, 0, 0.27778],
      "8902": [-0.03472, 0.46528, 0, 0, 0.5],
      "8904": [5e-3, 0.505, 0, 0, 0.9],
      "8942": [0.03, 0.903, 0, 0, 0.278],
      "8943": [-0.19, 0.313, 0, 0, 1.172],
      "8945": [-0.1, 0.823, 0, 0, 1.282],
      "8968": [0.25, 0.75, 0, 0, 0.44445],
      "8969": [0.25, 0.75, 0, 0, 0.44445],
      "8970": [0.25, 0.75, 0, 0, 0.44445],
      "8971": [0.25, 0.75, 0, 0, 0.44445],
      "8994": [-0.14236, 0.35764, 0, 0, 1],
      "8995": [-0.14236, 0.35764, 0, 0, 1],
      "9136": [0.244, 0.744, 0, 0, 0.412],
      "9137": [0.244, 0.745, 0, 0, 0.412],
      "9651": [0.19444, 0.69444, 0, 0, 0.88889],
      "9657": [-0.03472, 0.46528, 0, 0, 0.5],
      "9661": [0.19444, 0.69444, 0, 0, 0.88889],
      "9667": [-0.03472, 0.46528, 0, 0, 0.5],
      "9711": [0.19444, 0.69444, 0, 0, 1],
      "9824": [0.12963, 0.69444, 0, 0, 0.77778],
      "9825": [0.12963, 0.69444, 0, 0, 0.77778],
      "9826": [0.12963, 0.69444, 0, 0, 0.77778],
      "9827": [0.12963, 0.69444, 0, 0, 0.77778],
      "9837": [0, 0.75, 0, 0, 0.38889],
      "9838": [0.19444, 0.69444, 0, 0, 0.38889],
      "9839": [0.19444, 0.69444, 0, 0, 0.38889],
      "10216": [0.25, 0.75, 0, 0, 0.38889],
      "10217": [0.25, 0.75, 0, 0, 0.38889],
      "10222": [0.244, 0.744, 0, 0, 0.412],
      "10223": [0.244, 0.745, 0, 0, 0.412],
      "10229": [0.011, 0.511, 0, 0, 1.609],
      "10230": [0.011, 0.511, 0, 0, 1.638],
      "10231": [0.011, 0.511, 0, 0, 1.859],
      "10232": [0.024, 0.525, 0, 0, 1.609],
      "10233": [0.024, 0.525, 0, 0, 1.638],
      "10234": [0.024, 0.525, 0, 0, 1.858],
      "10236": [0.011, 0.511, 0, 0, 1.638],
      "10815": [0, 0.68333, 0, 0, 0.75],
      "10927": [0.13597, 0.63597, 0, 0, 0.77778],
      "10928": [0.13597, 0.63597, 0, 0, 0.77778],
      "57376": [0.19444, 0.69444, 0, 0, 0]
    },
    "Math-BoldItalic": {
      "32": [0, 0, 0, 0, 0.25],
      "48": [0, 0.44444, 0, 0, 0.575],
      "49": [0, 0.44444, 0, 0, 0.575],
      "50": [0, 0.44444, 0, 0, 0.575],
      "51": [0.19444, 0.44444, 0, 0, 0.575],
      "52": [0.19444, 0.44444, 0, 0, 0.575],
      "53": [0.19444, 0.44444, 0, 0, 0.575],
      "54": [0, 0.64444, 0, 0, 0.575],
      "55": [0.19444, 0.44444, 0, 0, 0.575],
      "56": [0, 0.64444, 0, 0, 0.575],
      "57": [0.19444, 0.44444, 0, 0, 0.575],
      "65": [0, 0.68611, 0, 0, 0.86944],
      "66": [0, 0.68611, 0.04835, 0, 0.8664],
      "67": [0, 0.68611, 0.06979, 0, 0.81694],
      "68": [0, 0.68611, 0.03194, 0, 0.93812],
      "69": [0, 0.68611, 0.05451, 0, 0.81007],
      "70": [0, 0.68611, 0.15972, 0, 0.68889],
      "71": [0, 0.68611, 0, 0, 0.88673],
      "72": [0, 0.68611, 0.08229, 0, 0.98229],
      "73": [0, 0.68611, 0.07778, 0, 0.51111],
      "74": [0, 0.68611, 0.10069, 0, 0.63125],
      "75": [0, 0.68611, 0.06979, 0, 0.97118],
      "76": [0, 0.68611, 0, 0, 0.75555],
      "77": [0, 0.68611, 0.11424, 0, 1.14201],
      "78": [0, 0.68611, 0.11424, 0, 0.95034],
      "79": [0, 0.68611, 0.03194, 0, 0.83666],
      "80": [0, 0.68611, 0.15972, 0, 0.72309],
      "81": [0.19444, 0.68611, 0, 0, 0.86861],
      "82": [0, 0.68611, 421e-5, 0, 0.87235],
      "83": [0, 0.68611, 0.05382, 0, 0.69271],
      "84": [0, 0.68611, 0.15972, 0, 0.63663],
      "85": [0, 0.68611, 0.11424, 0, 0.80027],
      "86": [0, 0.68611, 0.25555, 0, 0.67778],
      "87": [0, 0.68611, 0.15972, 0, 1.09305],
      "88": [0, 0.68611, 0.07778, 0, 0.94722],
      "89": [0, 0.68611, 0.25555, 0, 0.67458],
      "90": [0, 0.68611, 0.06979, 0, 0.77257],
      "97": [0, 0.44444, 0, 0, 0.63287],
      "98": [0, 0.69444, 0, 0, 0.52083],
      "99": [0, 0.44444, 0, 0, 0.51342],
      "100": [0, 0.69444, 0, 0, 0.60972],
      "101": [0, 0.44444, 0, 0, 0.55361],
      "102": [0.19444, 0.69444, 0.11042, 0, 0.56806],
      "103": [0.19444, 0.44444, 0.03704, 0, 0.5449],
      "104": [0, 0.69444, 0, 0, 0.66759],
      "105": [0, 0.69326, 0, 0, 0.4048],
      "106": [0.19444, 0.69326, 0.0622, 0, 0.47083],
      "107": [0, 0.69444, 0.01852, 0, 0.6037],
      "108": [0, 0.69444, 88e-4, 0, 0.34815],
      "109": [0, 0.44444, 0, 0, 1.0324],
      "110": [0, 0.44444, 0, 0, 0.71296],
      "111": [0, 0.44444, 0, 0, 0.58472],
      "112": [0.19444, 0.44444, 0, 0, 0.60092],
      "113": [0.19444, 0.44444, 0.03704, 0, 0.54213],
      "114": [0, 0.44444, 0.03194, 0, 0.5287],
      "115": [0, 0.44444, 0, 0, 0.53125],
      "116": [0, 0.63492, 0, 0, 0.41528],
      "117": [0, 0.44444, 0, 0, 0.68102],
      "118": [0, 0.44444, 0.03704, 0, 0.56666],
      "119": [0, 0.44444, 0.02778, 0, 0.83148],
      "120": [0, 0.44444, 0, 0, 0.65903],
      "121": [0.19444, 0.44444, 0.03704, 0, 0.59028],
      "122": [0, 0.44444, 0.04213, 0, 0.55509],
      "160": [0, 0, 0, 0, 0.25],
      "915": [0, 0.68611, 0.15972, 0, 0.65694],
      "916": [0, 0.68611, 0, 0, 0.95833],
      "920": [0, 0.68611, 0.03194, 0, 0.86722],
      "923": [0, 0.68611, 0, 0, 0.80555],
      "926": [0, 0.68611, 0.07458, 0, 0.84125],
      "928": [0, 0.68611, 0.08229, 0, 0.98229],
      "931": [0, 0.68611, 0.05451, 0, 0.88507],
      "933": [0, 0.68611, 0.15972, 0, 0.67083],
      "934": [0, 0.68611, 0, 0, 0.76666],
      "936": [0, 0.68611, 0.11653, 0, 0.71402],
      "937": [0, 0.68611, 0.04835, 0, 0.8789],
      "945": [0, 0.44444, 0, 0, 0.76064],
      "946": [0.19444, 0.69444, 0.03403, 0, 0.65972],
      "947": [0.19444, 0.44444, 0.06389, 0, 0.59003],
      "948": [0, 0.69444, 0.03819, 0, 0.52222],
      "949": [0, 0.44444, 0, 0, 0.52882],
      "950": [0.19444, 0.69444, 0.06215, 0, 0.50833],
      "951": [0.19444, 0.44444, 0.03704, 0, 0.6],
      "952": [0, 0.69444, 0.03194, 0, 0.5618],
      "953": [0, 0.44444, 0, 0, 0.41204],
      "954": [0, 0.44444, 0, 0, 0.66759],
      "955": [0, 0.69444, 0, 0, 0.67083],
      "956": [0.19444, 0.44444, 0, 0, 0.70787],
      "957": [0, 0.44444, 0.06898, 0, 0.57685],
      "958": [0.19444, 0.69444, 0.03021, 0, 0.50833],
      "959": [0, 0.44444, 0, 0, 0.58472],
      "960": [0, 0.44444, 0.03704, 0, 0.68241],
      "961": [0.19444, 0.44444, 0, 0, 0.6118],
      "962": [0.09722, 0.44444, 0.07917, 0, 0.42361],
      "963": [0, 0.44444, 0.03704, 0, 0.68588],
      "964": [0, 0.44444, 0.13472, 0, 0.52083],
      "965": [0, 0.44444, 0.03704, 0, 0.63055],
      "966": [0.19444, 0.44444, 0, 0, 0.74722],
      "967": [0.19444, 0.44444, 0, 0, 0.71805],
      "968": [0.19444, 0.69444, 0.03704, 0, 0.75833],
      "969": [0, 0.44444, 0.03704, 0, 0.71782],
      "977": [0, 0.69444, 0, 0, 0.69155],
      "981": [0.19444, 0.69444, 0, 0, 0.7125],
      "982": [0, 0.44444, 0.03194, 0, 0.975],
      "1009": [0.19444, 0.44444, 0, 0, 0.6118],
      "1013": [0, 0.44444, 0, 0, 0.48333],
      "57649": [0, 0.44444, 0, 0, 0.39352],
      "57911": [0.19444, 0.44444, 0, 0, 0.43889]
    },
    "Math-Italic": {
      "32": [0, 0, 0, 0, 0.25],
      "48": [0, 0.43056, 0, 0, 0.5],
      "49": [0, 0.43056, 0, 0, 0.5],
      "50": [0, 0.43056, 0, 0, 0.5],
      "51": [0.19444, 0.43056, 0, 0, 0.5],
      "52": [0.19444, 0.43056, 0, 0, 0.5],
      "53": [0.19444, 0.43056, 0, 0, 0.5],
      "54": [0, 0.64444, 0, 0, 0.5],
      "55": [0.19444, 0.43056, 0, 0, 0.5],
      "56": [0, 0.64444, 0, 0, 0.5],
      "57": [0.19444, 0.43056, 0, 0, 0.5],
      "65": [0, 0.68333, 0, 0.13889, 0.75],
      "66": [0, 0.68333, 0.05017, 0.08334, 0.75851],
      "67": [0, 0.68333, 0.07153, 0.08334, 0.71472],
      "68": [0, 0.68333, 0.02778, 0.05556, 0.82792],
      "69": [0, 0.68333, 0.05764, 0.08334, 0.7382],
      "70": [0, 0.68333, 0.13889, 0.08334, 0.64306],
      "71": [0, 0.68333, 0, 0.08334, 0.78625],
      "72": [0, 0.68333, 0.08125, 0.05556, 0.83125],
      "73": [0, 0.68333, 0.07847, 0.11111, 0.43958],
      "74": [0, 0.68333, 0.09618, 0.16667, 0.55451],
      "75": [0, 0.68333, 0.07153, 0.05556, 0.84931],
      "76": [0, 0.68333, 0, 0.02778, 0.68056],
      "77": [0, 0.68333, 0.10903, 0.08334, 0.97014],
      "78": [0, 0.68333, 0.10903, 0.08334, 0.80347],
      "79": [0, 0.68333, 0.02778, 0.08334, 0.76278],
      "80": [0, 0.68333, 0.13889, 0.08334, 0.64201],
      "81": [0.19444, 0.68333, 0, 0.08334, 0.79056],
      "82": [0, 0.68333, 773e-5, 0.08334, 0.75929],
      "83": [0, 0.68333, 0.05764, 0.08334, 0.6132],
      "84": [0, 0.68333, 0.13889, 0.08334, 0.58438],
      "85": [0, 0.68333, 0.10903, 0.02778, 0.68278],
      "86": [0, 0.68333, 0.22222, 0, 0.58333],
      "87": [0, 0.68333, 0.13889, 0, 0.94445],
      "88": [0, 0.68333, 0.07847, 0.08334, 0.82847],
      "89": [0, 0.68333, 0.22222, 0, 0.58056],
      "90": [0, 0.68333, 0.07153, 0.08334, 0.68264],
      "97": [0, 0.43056, 0, 0, 0.52859],
      "98": [0, 0.69444, 0, 0, 0.42917],
      "99": [0, 0.43056, 0, 0.05556, 0.43276],
      "100": [0, 0.69444, 0, 0.16667, 0.52049],
      "101": [0, 0.43056, 0, 0.05556, 0.46563],
      "102": [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
      "103": [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
      "104": [0, 0.69444, 0, 0, 0.57616],
      "105": [0, 0.65952, 0, 0, 0.34451],
      "106": [0.19444, 0.65952, 0.05724, 0, 0.41181],
      "107": [0, 0.69444, 0.03148, 0, 0.5206],
      "108": [0, 0.69444, 0.01968, 0.08334, 0.29838],
      "109": [0, 0.43056, 0, 0, 0.87801],
      "110": [0, 0.43056, 0, 0, 0.60023],
      "111": [0, 0.43056, 0, 0.05556, 0.48472],
      "112": [0.19444, 0.43056, 0, 0.08334, 0.50313],
      "113": [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
      "114": [0, 0.43056, 0.02778, 0.05556, 0.45116],
      "115": [0, 0.43056, 0, 0.05556, 0.46875],
      "116": [0, 0.61508, 0, 0.08334, 0.36111],
      "117": [0, 0.43056, 0, 0.02778, 0.57246],
      "118": [0, 0.43056, 0.03588, 0.02778, 0.48472],
      "119": [0, 0.43056, 0.02691, 0.08334, 0.71592],
      "120": [0, 0.43056, 0, 0.02778, 0.57153],
      "121": [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
      "122": [0, 0.43056, 0.04398, 0.05556, 0.46505],
      "160": [0, 0, 0, 0, 0.25],
      "915": [0, 0.68333, 0.13889, 0.08334, 0.61528],
      "916": [0, 0.68333, 0, 0.16667, 0.83334],
      "920": [0, 0.68333, 0.02778, 0.08334, 0.76278],
      "923": [0, 0.68333, 0, 0.16667, 0.69445],
      "926": [0, 0.68333, 0.07569, 0.08334, 0.74236],
      "928": [0, 0.68333, 0.08125, 0.05556, 0.83125],
      "931": [0, 0.68333, 0.05764, 0.08334, 0.77986],
      "933": [0, 0.68333, 0.13889, 0.05556, 0.58333],
      "934": [0, 0.68333, 0, 0.08334, 0.66667],
      "936": [0, 0.68333, 0.11, 0.05556, 0.61222],
      "937": [0, 0.68333, 0.05017, 0.08334, 0.7724],
      "945": [0, 0.43056, 37e-4, 0.02778, 0.6397],
      "946": [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
      "947": [0.19444, 0.43056, 0.05556, 0, 0.51773],
      "948": [0, 0.69444, 0.03785, 0.05556, 0.44444],
      "949": [0, 0.43056, 0, 0.08334, 0.46632],
      "950": [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
      "951": [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
      "952": [0, 0.69444, 0.02778, 0.08334, 0.46944],
      "953": [0, 0.43056, 0, 0.05556, 0.35394],
      "954": [0, 0.43056, 0, 0, 0.57616],
      "955": [0, 0.69444, 0, 0, 0.58334],
      "956": [0.19444, 0.43056, 0, 0.02778, 0.60255],
      "957": [0, 0.43056, 0.06366, 0.02778, 0.49398],
      "958": [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
      "959": [0, 0.43056, 0, 0.05556, 0.48472],
      "960": [0, 0.43056, 0.03588, 0, 0.57003],
      "961": [0.19444, 0.43056, 0, 0.08334, 0.51702],
      "962": [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
      "963": [0, 0.43056, 0.03588, 0, 0.57141],
      "964": [0, 0.43056, 0.1132, 0.02778, 0.43715],
      "965": [0, 0.43056, 0.03588, 0.02778, 0.54028],
      "966": [0.19444, 0.43056, 0, 0.08334, 0.65417],
      "967": [0.19444, 0.43056, 0, 0.05556, 0.62569],
      "968": [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
      "969": [0, 0.43056, 0.03588, 0, 0.62245],
      "977": [0, 0.69444, 0, 0.08334, 0.59144],
      "981": [0.19444, 0.69444, 0, 0.08334, 0.59583],
      "982": [0, 0.43056, 0.02778, 0, 0.82813],
      "1009": [0.19444, 0.43056, 0, 0.08334, 0.51702],
      "1013": [0, 0.43056, 0, 0.05556, 0.4059],
      "57649": [0, 0.43056, 0, 0.02778, 0.32246],
      "57911": [0.19444, 0.43056, 0, 0.08334, 0.38403]
    },
    "SansSerif-Bold": {
      "32": [0, 0, 0, 0, 0.25],
      "33": [0, 0.69444, 0, 0, 0.36667],
      "34": [0, 0.69444, 0, 0, 0.55834],
      "35": [0.19444, 0.69444, 0, 0, 0.91667],
      "36": [0.05556, 0.75, 0, 0, 0.55],
      "37": [0.05556, 0.75, 0, 0, 1.02912],
      "38": [0, 0.69444, 0, 0, 0.83056],
      "39": [0, 0.69444, 0, 0, 0.30556],
      "40": [0.25, 0.75, 0, 0, 0.42778],
      "41": [0.25, 0.75, 0, 0, 0.42778],
      "42": [0, 0.75, 0, 0, 0.55],
      "43": [0.11667, 0.61667, 0, 0, 0.85556],
      "44": [0.10556, 0.13056, 0, 0, 0.30556],
      "45": [0, 0.45833, 0, 0, 0.36667],
      "46": [0, 0.13056, 0, 0, 0.30556],
      "47": [0.25, 0.75, 0, 0, 0.55],
      "48": [0, 0.69444, 0, 0, 0.55],
      "49": [0, 0.69444, 0, 0, 0.55],
      "50": [0, 0.69444, 0, 0, 0.55],
      "51": [0, 0.69444, 0, 0, 0.55],
      "52": [0, 0.69444, 0, 0, 0.55],
      "53": [0, 0.69444, 0, 0, 0.55],
      "54": [0, 0.69444, 0, 0, 0.55],
      "55": [0, 0.69444, 0, 0, 0.55],
      "56": [0, 0.69444, 0, 0, 0.55],
      "57": [0, 0.69444, 0, 0, 0.55],
      "58": [0, 0.45833, 0, 0, 0.30556],
      "59": [0.10556, 0.45833, 0, 0, 0.30556],
      "61": [-0.09375, 0.40625, 0, 0, 0.85556],
      "63": [0, 0.69444, 0, 0, 0.51945],
      "64": [0, 0.69444, 0, 0, 0.73334],
      "65": [0, 0.69444, 0, 0, 0.73334],
      "66": [0, 0.69444, 0, 0, 0.73334],
      "67": [0, 0.69444, 0, 0, 0.70278],
      "68": [0, 0.69444, 0, 0, 0.79445],
      "69": [0, 0.69444, 0, 0, 0.64167],
      "70": [0, 0.69444, 0, 0, 0.61111],
      "71": [0, 0.69444, 0, 0, 0.73334],
      "72": [0, 0.69444, 0, 0, 0.79445],
      "73": [0, 0.69444, 0, 0, 0.33056],
      "74": [0, 0.69444, 0, 0, 0.51945],
      "75": [0, 0.69444, 0, 0, 0.76389],
      "76": [0, 0.69444, 0, 0, 0.58056],
      "77": [0, 0.69444, 0, 0, 0.97778],
      "78": [0, 0.69444, 0, 0, 0.79445],
      "79": [0, 0.69444, 0, 0, 0.79445],
      "80": [0, 0.69444, 0, 0, 0.70278],
      "81": [0.10556, 0.69444, 0, 0, 0.79445],
      "82": [0, 0.69444, 0, 0, 0.70278],
      "83": [0, 0.69444, 0, 0, 0.61111],
      "84": [0, 0.69444, 0, 0, 0.73334],
      "85": [0, 0.69444, 0, 0, 0.76389],
      "86": [0, 0.69444, 0.01528, 0, 0.73334],
      "87": [0, 0.69444, 0.01528, 0, 1.03889],
      "88": [0, 0.69444, 0, 0, 0.73334],
      "89": [0, 0.69444, 0.0275, 0, 0.73334],
      "90": [0, 0.69444, 0, 0, 0.67223],
      "91": [0.25, 0.75, 0, 0, 0.34306],
      "93": [0.25, 0.75, 0, 0, 0.34306],
      "94": [0, 0.69444, 0, 0, 0.55],
      "95": [0.35, 0.10833, 0.03056, 0, 0.55],
      "97": [0, 0.45833, 0, 0, 0.525],
      "98": [0, 0.69444, 0, 0, 0.56111],
      "99": [0, 0.45833, 0, 0, 0.48889],
      "100": [0, 0.69444, 0, 0, 0.56111],
      "101": [0, 0.45833, 0, 0, 0.51111],
      "102": [0, 0.69444, 0.07639, 0, 0.33611],
      "103": [0.19444, 0.45833, 0.01528, 0, 0.55],
      "104": [0, 0.69444, 0, 0, 0.56111],
      "105": [0, 0.69444, 0, 0, 0.25556],
      "106": [0.19444, 0.69444, 0, 0, 0.28611],
      "107": [0, 0.69444, 0, 0, 0.53056],
      "108": [0, 0.69444, 0, 0, 0.25556],
      "109": [0, 0.45833, 0, 0, 0.86667],
      "110": [0, 0.45833, 0, 0, 0.56111],
      "111": [0, 0.45833, 0, 0, 0.55],
      "112": [0.19444, 0.45833, 0, 0, 0.56111],
      "113": [0.19444, 0.45833, 0, 0, 0.56111],
      "114": [0, 0.45833, 0.01528, 0, 0.37222],
      "115": [0, 0.45833, 0, 0, 0.42167],
      "116": [0, 0.58929, 0, 0, 0.40417],
      "117": [0, 0.45833, 0, 0, 0.56111],
      "118": [0, 0.45833, 0.01528, 0, 0.5],
      "119": [0, 0.45833, 0.01528, 0, 0.74445],
      "120": [0, 0.45833, 0, 0, 0.5],
      "121": [0.19444, 0.45833, 0.01528, 0, 0.5],
      "122": [0, 0.45833, 0, 0, 0.47639],
      "126": [0.35, 0.34444, 0, 0, 0.55],
      "160": [0, 0, 0, 0, 0.25],
      "168": [0, 0.69444, 0, 0, 0.55],
      "176": [0, 0.69444, 0, 0, 0.73334],
      "180": [0, 0.69444, 0, 0, 0.55],
      "184": [0.17014, 0, 0, 0, 0.48889],
      "305": [0, 0.45833, 0, 0, 0.25556],
      "567": [0.19444, 0.45833, 0, 0, 0.28611],
      "710": [0, 0.69444, 0, 0, 0.55],
      "711": [0, 0.63542, 0, 0, 0.55],
      "713": [0, 0.63778, 0, 0, 0.55],
      "728": [0, 0.69444, 0, 0, 0.55],
      "729": [0, 0.69444, 0, 0, 0.30556],
      "730": [0, 0.69444, 0, 0, 0.73334],
      "732": [0, 0.69444, 0, 0, 0.55],
      "733": [0, 0.69444, 0, 0, 0.55],
      "915": [0, 0.69444, 0, 0, 0.58056],
      "916": [0, 0.69444, 0, 0, 0.91667],
      "920": [0, 0.69444, 0, 0, 0.85556],
      "923": [0, 0.69444, 0, 0, 0.67223],
      "926": [0, 0.69444, 0, 0, 0.73334],
      "928": [0, 0.69444, 0, 0, 0.79445],
      "931": [0, 0.69444, 0, 0, 0.79445],
      "933": [0, 0.69444, 0, 0, 0.85556],
      "934": [0, 0.69444, 0, 0, 0.79445],
      "936": [0, 0.69444, 0, 0, 0.85556],
      "937": [0, 0.69444, 0, 0, 0.79445],
      "8211": [0, 0.45833, 0.03056, 0, 0.55],
      "8212": [0, 0.45833, 0.03056, 0, 1.10001],
      "8216": [0, 0.69444, 0, 0, 0.30556],
      "8217": [0, 0.69444, 0, 0, 0.30556],
      "8220": [0, 0.69444, 0, 0, 0.55834],
      "8221": [0, 0.69444, 0, 0, 0.55834]
    },
    "SansSerif-Italic": {
      "32": [0, 0, 0, 0, 0.25],
      "33": [0, 0.69444, 0.05733, 0, 0.31945],
      "34": [0, 0.69444, 316e-5, 0, 0.5],
      "35": [0.19444, 0.69444, 0.05087, 0, 0.83334],
      "36": [0.05556, 0.75, 0.11156, 0, 0.5],
      "37": [0.05556, 0.75, 0.03126, 0, 0.83334],
      "38": [0, 0.69444, 0.03058, 0, 0.75834],
      "39": [0, 0.69444, 0.07816, 0, 0.27778],
      "40": [0.25, 0.75, 0.13164, 0, 0.38889],
      "41": [0.25, 0.75, 0.02536, 0, 0.38889],
      "42": [0, 0.75, 0.11775, 0, 0.5],
      "43": [0.08333, 0.58333, 0.02536, 0, 0.77778],
      "44": [0.125, 0.08333, 0, 0, 0.27778],
      "45": [0, 0.44444, 0.01946, 0, 0.33333],
      "46": [0, 0.08333, 0, 0, 0.27778],
      "47": [0.25, 0.75, 0.13164, 0, 0.5],
      "48": [0, 0.65556, 0.11156, 0, 0.5],
      "49": [0, 0.65556, 0.11156, 0, 0.5],
      "50": [0, 0.65556, 0.11156, 0, 0.5],
      "51": [0, 0.65556, 0.11156, 0, 0.5],
      "52": [0, 0.65556, 0.11156, 0, 0.5],
      "53": [0, 0.65556, 0.11156, 0, 0.5],
      "54": [0, 0.65556, 0.11156, 0, 0.5],
      "55": [0, 0.65556, 0.11156, 0, 0.5],
      "56": [0, 0.65556, 0.11156, 0, 0.5],
      "57": [0, 0.65556, 0.11156, 0, 0.5],
      "58": [0, 0.44444, 0.02502, 0, 0.27778],
      "59": [0.125, 0.44444, 0.02502, 0, 0.27778],
      "61": [-0.13, 0.37, 0.05087, 0, 0.77778],
      "63": [0, 0.69444, 0.11809, 0, 0.47222],
      "64": [0, 0.69444, 0.07555, 0, 0.66667],
      "65": [0, 0.69444, 0, 0, 0.66667],
      "66": [0, 0.69444, 0.08293, 0, 0.66667],
      "67": [0, 0.69444, 0.11983, 0, 0.63889],
      "68": [0, 0.69444, 0.07555, 0, 0.72223],
      "69": [0, 0.69444, 0.11983, 0, 0.59722],
      "70": [0, 0.69444, 0.13372, 0, 0.56945],
      "71": [0, 0.69444, 0.11983, 0, 0.66667],
      "72": [0, 0.69444, 0.08094, 0, 0.70834],
      "73": [0, 0.69444, 0.13372, 0, 0.27778],
      "74": [0, 0.69444, 0.08094, 0, 0.47222],
      "75": [0, 0.69444, 0.11983, 0, 0.69445],
      "76": [0, 0.69444, 0, 0, 0.54167],
      "77": [0, 0.69444, 0.08094, 0, 0.875],
      "78": [0, 0.69444, 0.08094, 0, 0.70834],
      "79": [0, 0.69444, 0.07555, 0, 0.73611],
      "80": [0, 0.69444, 0.08293, 0, 0.63889],
      "81": [0.125, 0.69444, 0.07555, 0, 0.73611],
      "82": [0, 0.69444, 0.08293, 0, 0.64584],
      "83": [0, 0.69444, 0.09205, 0, 0.55556],
      "84": [0, 0.69444, 0.13372, 0, 0.68056],
      "85": [0, 0.69444, 0.08094, 0, 0.6875],
      "86": [0, 0.69444, 0.1615, 0, 0.66667],
      "87": [0, 0.69444, 0.1615, 0, 0.94445],
      "88": [0, 0.69444, 0.13372, 0, 0.66667],
      "89": [0, 0.69444, 0.17261, 0, 0.66667],
      "90": [0, 0.69444, 0.11983, 0, 0.61111],
      "91": [0.25, 0.75, 0.15942, 0, 0.28889],
      "93": [0.25, 0.75, 0.08719, 0, 0.28889],
      "94": [0, 0.69444, 0.0799, 0, 0.5],
      "95": [0.35, 0.09444, 0.08616, 0, 0.5],
      "97": [0, 0.44444, 981e-5, 0, 0.48056],
      "98": [0, 0.69444, 0.03057, 0, 0.51667],
      "99": [0, 0.44444, 0.08336, 0, 0.44445],
      "100": [0, 0.69444, 0.09483, 0, 0.51667],
      "101": [0, 0.44444, 0.06778, 0, 0.44445],
      "102": [0, 0.69444, 0.21705, 0, 0.30556],
      "103": [0.19444, 0.44444, 0.10836, 0, 0.5],
      "104": [0, 0.69444, 0.01778, 0, 0.51667],
      "105": [0, 0.67937, 0.09718, 0, 0.23889],
      "106": [0.19444, 0.67937, 0.09162, 0, 0.26667],
      "107": [0, 0.69444, 0.08336, 0, 0.48889],
      "108": [0, 0.69444, 0.09483, 0, 0.23889],
      "109": [0, 0.44444, 0.01778, 0, 0.79445],
      "110": [0, 0.44444, 0.01778, 0, 0.51667],
      "111": [0, 0.44444, 0.06613, 0, 0.5],
      "112": [0.19444, 0.44444, 0.0389, 0, 0.51667],
      "113": [0.19444, 0.44444, 0.04169, 0, 0.51667],
      "114": [0, 0.44444, 0.10836, 0, 0.34167],
      "115": [0, 0.44444, 0.0778, 0, 0.38333],
      "116": [0, 0.57143, 0.07225, 0, 0.36111],
      "117": [0, 0.44444, 0.04169, 0, 0.51667],
      "118": [0, 0.44444, 0.10836, 0, 0.46111],
      "119": [0, 0.44444, 0.10836, 0, 0.68334],
      "120": [0, 0.44444, 0.09169, 0, 0.46111],
      "121": [0.19444, 0.44444, 0.10836, 0, 0.46111],
      "122": [0, 0.44444, 0.08752, 0, 0.43472],
      "126": [0.35, 0.32659, 0.08826, 0, 0.5],
      "160": [0, 0, 0, 0, 0.25],
      "168": [0, 0.67937, 0.06385, 0, 0.5],
      "176": [0, 0.69444, 0, 0, 0.73752],
      "184": [0.17014, 0, 0, 0, 0.44445],
      "305": [0, 0.44444, 0.04169, 0, 0.23889],
      "567": [0.19444, 0.44444, 0.04169, 0, 0.26667],
      "710": [0, 0.69444, 0.0799, 0, 0.5],
      "711": [0, 0.63194, 0.08432, 0, 0.5],
      "713": [0, 0.60889, 0.08776, 0, 0.5],
      "714": [0, 0.69444, 0.09205, 0, 0.5],
      "715": [0, 0.69444, 0, 0, 0.5],
      "728": [0, 0.69444, 0.09483, 0, 0.5],
      "729": [0, 0.67937, 0.07774, 0, 0.27778],
      "730": [0, 0.69444, 0, 0, 0.73752],
      "732": [0, 0.67659, 0.08826, 0, 0.5],
      "733": [0, 0.69444, 0.09205, 0, 0.5],
      "915": [0, 0.69444, 0.13372, 0, 0.54167],
      "916": [0, 0.69444, 0, 0, 0.83334],
      "920": [0, 0.69444, 0.07555, 0, 0.77778],
      "923": [0, 0.69444, 0, 0, 0.61111],
      "926": [0, 0.69444, 0.12816, 0, 0.66667],
      "928": [0, 0.69444, 0.08094, 0, 0.70834],
      "931": [0, 0.69444, 0.11983, 0, 0.72222],
      "933": [0, 0.69444, 0.09031, 0, 0.77778],
      "934": [0, 0.69444, 0.04603, 0, 0.72222],
      "936": [0, 0.69444, 0.09031, 0, 0.77778],
      "937": [0, 0.69444, 0.08293, 0, 0.72222],
      "8211": [0, 0.44444, 0.08616, 0, 0.5],
      "8212": [0, 0.44444, 0.08616, 0, 1],
      "8216": [0, 0.69444, 0.07816, 0, 0.27778],
      "8217": [0, 0.69444, 0.07816, 0, 0.27778],
      "8220": [0, 0.69444, 0.14205, 0, 0.5],
      "8221": [0, 0.69444, 316e-5, 0, 0.5]
    },
    "SansSerif-Regular": {
      "32": [0, 0, 0, 0, 0.25],
      "33": [0, 0.69444, 0, 0, 0.31945],
      "34": [0, 0.69444, 0, 0, 0.5],
      "35": [0.19444, 0.69444, 0, 0, 0.83334],
      "36": [0.05556, 0.75, 0, 0, 0.5],
      "37": [0.05556, 0.75, 0, 0, 0.83334],
      "38": [0, 0.69444, 0, 0, 0.75834],
      "39": [0, 0.69444, 0, 0, 0.27778],
      "40": [0.25, 0.75, 0, 0, 0.38889],
      "41": [0.25, 0.75, 0, 0, 0.38889],
      "42": [0, 0.75, 0, 0, 0.5],
      "43": [0.08333, 0.58333, 0, 0, 0.77778],
      "44": [0.125, 0.08333, 0, 0, 0.27778],
      "45": [0, 0.44444, 0, 0, 0.33333],
      "46": [0, 0.08333, 0, 0, 0.27778],
      "47": [0.25, 0.75, 0, 0, 0.5],
      "48": [0, 0.65556, 0, 0, 0.5],
      "49": [0, 0.65556, 0, 0, 0.5],
      "50": [0, 0.65556, 0, 0, 0.5],
      "51": [0, 0.65556, 0, 0, 0.5],
      "52": [0, 0.65556, 0, 0, 0.5],
      "53": [0, 0.65556, 0, 0, 0.5],
      "54": [0, 0.65556, 0, 0, 0.5],
      "55": [0, 0.65556, 0, 0, 0.5],
      "56": [0, 0.65556, 0, 0, 0.5],
      "57": [0, 0.65556, 0, 0, 0.5],
      "58": [0, 0.44444, 0, 0, 0.27778],
      "59": [0.125, 0.44444, 0, 0, 0.27778],
      "61": [-0.13, 0.37, 0, 0, 0.77778],
      "63": [0, 0.69444, 0, 0, 0.47222],
      "64": [0, 0.69444, 0, 0, 0.66667],
      "65": [0, 0.69444, 0, 0, 0.66667],
      "66": [0, 0.69444, 0, 0, 0.66667],
      "67": [0, 0.69444, 0, 0, 0.63889],
      "68": [0, 0.69444, 0, 0, 0.72223],
      "69": [0, 0.69444, 0, 0, 0.59722],
      "70": [0, 0.69444, 0, 0, 0.56945],
      "71": [0, 0.69444, 0, 0, 0.66667],
      "72": [0, 0.69444, 0, 0, 0.70834],
      "73": [0, 0.69444, 0, 0, 0.27778],
      "74": [0, 0.69444, 0, 0, 0.47222],
      "75": [0, 0.69444, 0, 0, 0.69445],
      "76": [0, 0.69444, 0, 0, 0.54167],
      "77": [0, 0.69444, 0, 0, 0.875],
      "78": [0, 0.69444, 0, 0, 0.70834],
      "79": [0, 0.69444, 0, 0, 0.73611],
      "80": [0, 0.69444, 0, 0, 0.63889],
      "81": [0.125, 0.69444, 0, 0, 0.73611],
      "82": [0, 0.69444, 0, 0, 0.64584],
      "83": [0, 0.69444, 0, 0, 0.55556],
      "84": [0, 0.69444, 0, 0, 0.68056],
      "85": [0, 0.69444, 0, 0, 0.6875],
      "86": [0, 0.69444, 0.01389, 0, 0.66667],
      "87": [0, 0.69444, 0.01389, 0, 0.94445],
      "88": [0, 0.69444, 0, 0, 0.66667],
      "89": [0, 0.69444, 0.025, 0, 0.66667],
      "90": [0, 0.69444, 0, 0, 0.61111],
      "91": [0.25, 0.75, 0, 0, 0.28889],
      "93": [0.25, 0.75, 0, 0, 0.28889],
      "94": [0, 0.69444, 0, 0, 0.5],
      "95": [0.35, 0.09444, 0.02778, 0, 0.5],
      "97": [0, 0.44444, 0, 0, 0.48056],
      "98": [0, 0.69444, 0, 0, 0.51667],
      "99": [0, 0.44444, 0, 0, 0.44445],
      "100": [0, 0.69444, 0, 0, 0.51667],
      "101": [0, 0.44444, 0, 0, 0.44445],
      "102": [0, 0.69444, 0.06944, 0, 0.30556],
      "103": [0.19444, 0.44444, 0.01389, 0, 0.5],
      "104": [0, 0.69444, 0, 0, 0.51667],
      "105": [0, 0.67937, 0, 0, 0.23889],
      "106": [0.19444, 0.67937, 0, 0, 0.26667],
      "107": [0, 0.69444, 0, 0, 0.48889],
      "108": [0, 0.69444, 0, 0, 0.23889],
      "109": [0, 0.44444, 0, 0, 0.79445],
      "110": [0, 0.44444, 0, 0, 0.51667],
      "111": [0, 0.44444, 0, 0, 0.5],
      "112": [0.19444, 0.44444, 0, 0, 0.51667],
      "113": [0.19444, 0.44444, 0, 0, 0.51667],
      "114": [0, 0.44444, 0.01389, 0, 0.34167],
      "115": [0, 0.44444, 0, 0, 0.38333],
      "116": [0, 0.57143, 0, 0, 0.36111],
      "117": [0, 0.44444, 0, 0, 0.51667],
      "118": [0, 0.44444, 0.01389, 0, 0.46111],
      "119": [0, 0.44444, 0.01389, 0, 0.68334],
      "120": [0, 0.44444, 0, 0, 0.46111],
      "121": [0.19444, 0.44444, 0.01389, 0, 0.46111],
      "122": [0, 0.44444, 0, 0, 0.43472],
      "126": [0.35, 0.32659, 0, 0, 0.5],
      "160": [0, 0, 0, 0, 0.25],
      "168": [0, 0.67937, 0, 0, 0.5],
      "176": [0, 0.69444, 0, 0, 0.66667],
      "184": [0.17014, 0, 0, 0, 0.44445],
      "305": [0, 0.44444, 0, 0, 0.23889],
      "567": [0.19444, 0.44444, 0, 0, 0.26667],
      "710": [0, 0.69444, 0, 0, 0.5],
      "711": [0, 0.63194, 0, 0, 0.5],
      "713": [0, 0.60889, 0, 0, 0.5],
      "714": [0, 0.69444, 0, 0, 0.5],
      "715": [0, 0.69444, 0, 0, 0.5],
      "728": [0, 0.69444, 0, 0, 0.5],
      "729": [0, 0.67937, 0, 0, 0.27778],
      "730": [0, 0.69444, 0, 0, 0.66667],
      "732": [0, 0.67659, 0, 0, 0.5],
      "733": [0, 0.69444, 0, 0, 0.5],
      "915": [0, 0.69444, 0, 0, 0.54167],
      "916": [0, 0.69444, 0, 0, 0.83334],
      "920": [0, 0.69444, 0, 0, 0.77778],
      "923": [0, 0.69444, 0, 0, 0.61111],
      "926": [0, 0.69444, 0, 0, 0.66667],
      "928": [0, 0.69444, 0, 0, 0.70834],
      "931": [0, 0.69444, 0, 0, 0.72222],
      "933": [0, 0.69444, 0, 0, 0.77778],
      "934": [0, 0.69444, 0, 0, 0.72222],
      "936": [0, 0.69444, 0, 0, 0.77778],
      "937": [0, 0.69444, 0, 0, 0.72222],
      "8211": [0, 0.44444, 0.02778, 0, 0.5],
      "8212": [0, 0.44444, 0.02778, 0, 1],
      "8216": [0, 0.69444, 0, 0, 0.27778],
      "8217": [0, 0.69444, 0, 0, 0.27778],
      "8220": [0, 0.69444, 0, 0, 0.5],
      "8221": [0, 0.69444, 0, 0, 0.5]
    },
    "Script-Regular": {
      "32": [0, 0, 0, 0, 0.25],
      "65": [0, 0.7, 0.22925, 0, 0.80253],
      "66": [0, 0.7, 0.04087, 0, 0.90757],
      "67": [0, 0.7, 0.1689, 0, 0.66619],
      "68": [0, 0.7, 0.09371, 0, 0.77443],
      "69": [0, 0.7, 0.18583, 0, 0.56162],
      "70": [0, 0.7, 0.13634, 0, 0.89544],
      "71": [0, 0.7, 0.17322, 0, 0.60961],
      "72": [0, 0.7, 0.29694, 0, 0.96919],
      "73": [0, 0.7, 0.19189, 0, 0.80907],
      "74": [0.27778, 0.7, 0.19189, 0, 1.05159],
      "75": [0, 0.7, 0.31259, 0, 0.91364],
      "76": [0, 0.7, 0.19189, 0, 0.87373],
      "77": [0, 0.7, 0.15981, 0, 1.08031],
      "78": [0, 0.7, 0.3525, 0, 0.9015],
      "79": [0, 0.7, 0.08078, 0, 0.73787],
      "80": [0, 0.7, 0.08078, 0, 1.01262],
      "81": [0, 0.7, 0.03305, 0, 0.88282],
      "82": [0, 0.7, 0.06259, 0, 0.85],
      "83": [0, 0.7, 0.19189, 0, 0.86767],
      "84": [0, 0.7, 0.29087, 0, 0.74697],
      "85": [0, 0.7, 0.25815, 0, 0.79996],
      "86": [0, 0.7, 0.27523, 0, 0.62204],
      "87": [0, 0.7, 0.27523, 0, 0.80532],
      "88": [0, 0.7, 0.26006, 0, 0.94445],
      "89": [0, 0.7, 0.2939, 0, 0.70961],
      "90": [0, 0.7, 0.24037, 0, 0.8212],
      "160": [0, 0, 0, 0, 0.25]
    },
    "Size1-Regular": {
      "32": [0, 0, 0, 0, 0.25],
      "40": [0.35001, 0.85, 0, 0, 0.45834],
      "41": [0.35001, 0.85, 0, 0, 0.45834],
      "47": [0.35001, 0.85, 0, 0, 0.57778],
      "91": [0.35001, 0.85, 0, 0, 0.41667],
      "92": [0.35001, 0.85, 0, 0, 0.57778],
      "93": [0.35001, 0.85, 0, 0, 0.41667],
      "123": [0.35001, 0.85, 0, 0, 0.58334],
      "125": [0.35001, 0.85, 0, 0, 0.58334],
      "160": [0, 0, 0, 0, 0.25],
      "710": [0, 0.72222, 0, 0, 0.55556],
      "732": [0, 0.72222, 0, 0, 0.55556],
      "770": [0, 0.72222, 0, 0, 0.55556],
      "771": [0, 0.72222, 0, 0, 0.55556],
      "8214": [-99e-5, 0.601, 0, 0, 0.77778],
      "8593": [1e-5, 0.6, 0, 0, 0.66667],
      "8595": [1e-5, 0.6, 0, 0, 0.66667],
      "8657": [1e-5, 0.6, 0, 0, 0.77778],
      "8659": [1e-5, 0.6, 0, 0, 0.77778],
      "8719": [0.25001, 0.75, 0, 0, 0.94445],
      "8720": [0.25001, 0.75, 0, 0, 0.94445],
      "8721": [0.25001, 0.75, 0, 0, 1.05556],
      "8730": [0.35001, 0.85, 0, 0, 1],
      "8739": [-599e-5, 0.606, 0, 0, 0.33333],
      "8741": [-599e-5, 0.606, 0, 0, 0.55556],
      "8747": [0.30612, 0.805, 0.19445, 0, 0.47222],
      "8748": [0.306, 0.805, 0.19445, 0, 0.47222],
      "8749": [0.306, 0.805, 0.19445, 0, 0.47222],
      "8750": [0.30612, 0.805, 0.19445, 0, 0.47222],
      "8896": [0.25001, 0.75, 0, 0, 0.83334],
      "8897": [0.25001, 0.75, 0, 0, 0.83334],
      "8898": [0.25001, 0.75, 0, 0, 0.83334],
      "8899": [0.25001, 0.75, 0, 0, 0.83334],
      "8968": [0.35001, 0.85, 0, 0, 0.47222],
      "8969": [0.35001, 0.85, 0, 0, 0.47222],
      "8970": [0.35001, 0.85, 0, 0, 0.47222],
      "8971": [0.35001, 0.85, 0, 0, 0.47222],
      "9168": [-99e-5, 0.601, 0, 0, 0.66667],
      "10216": [0.35001, 0.85, 0, 0, 0.47222],
      "10217": [0.35001, 0.85, 0, 0, 0.47222],
      "10752": [0.25001, 0.75, 0, 0, 1.11111],
      "10753": [0.25001, 0.75, 0, 0, 1.11111],
      "10754": [0.25001, 0.75, 0, 0, 1.11111],
      "10756": [0.25001, 0.75, 0, 0, 0.83334],
      "10758": [0.25001, 0.75, 0, 0, 0.83334]
    },
    "Size2-Regular": {
      "32": [0, 0, 0, 0, 0.25],
      "40": [0.65002, 1.15, 0, 0, 0.59722],
      "41": [0.65002, 1.15, 0, 0, 0.59722],
      "47": [0.65002, 1.15, 0, 0, 0.81111],
      "91": [0.65002, 1.15, 0, 0, 0.47222],
      "92": [0.65002, 1.15, 0, 0, 0.81111],
      "93": [0.65002, 1.15, 0, 0, 0.47222],
      "123": [0.65002, 1.15, 0, 0, 0.66667],
      "125": [0.65002, 1.15, 0, 0, 0.66667],
      "160": [0, 0, 0, 0, 0.25],
      "710": [0, 0.75, 0, 0, 1],
      "732": [0, 0.75, 0, 0, 1],
      "770": [0, 0.75, 0, 0, 1],
      "771": [0, 0.75, 0, 0, 1],
      "8719": [0.55001, 1.05, 0, 0, 1.27778],
      "8720": [0.55001, 1.05, 0, 0, 1.27778],
      "8721": [0.55001, 1.05, 0, 0, 1.44445],
      "8730": [0.65002, 1.15, 0, 0, 1],
      "8747": [0.86225, 1.36, 0.44445, 0, 0.55556],
      "8748": [0.862, 1.36, 0.44445, 0, 0.55556],
      "8749": [0.862, 1.36, 0.44445, 0, 0.55556],
      "8750": [0.86225, 1.36, 0.44445, 0, 0.55556],
      "8896": [0.55001, 1.05, 0, 0, 1.11111],
      "8897": [0.55001, 1.05, 0, 0, 1.11111],
      "8898": [0.55001, 1.05, 0, 0, 1.11111],
      "8899": [0.55001, 1.05, 0, 0, 1.11111],
      "8968": [0.65002, 1.15, 0, 0, 0.52778],
      "8969": [0.65002, 1.15, 0, 0, 0.52778],
      "8970": [0.65002, 1.15, 0, 0, 0.52778],
      "8971": [0.65002, 1.15, 0, 0, 0.52778],
      "10216": [0.65002, 1.15, 0, 0, 0.61111],
      "10217": [0.65002, 1.15, 0, 0, 0.61111],
      "10752": [0.55001, 1.05, 0, 0, 1.51112],
      "10753": [0.55001, 1.05, 0, 0, 1.51112],
      "10754": [0.55001, 1.05, 0, 0, 1.51112],
      "10756": [0.55001, 1.05, 0, 0, 1.11111],
      "10758": [0.55001, 1.05, 0, 0, 1.11111]
    },
    "Size3-Regular": {
      "32": [0, 0, 0, 0, 0.25],
      "40": [0.95003, 1.45, 0, 0, 0.73611],
      "41": [0.95003, 1.45, 0, 0, 0.73611],
      "47": [0.95003, 1.45, 0, 0, 1.04445],
      "91": [0.95003, 1.45, 0, 0, 0.52778],
      "92": [0.95003, 1.45, 0, 0, 1.04445],
      "93": [0.95003, 1.45, 0, 0, 0.52778],
      "123": [0.95003, 1.45, 0, 0, 0.75],
      "125": [0.95003, 1.45, 0, 0, 0.75],
      "160": [0, 0, 0, 0, 0.25],
      "710": [0, 0.75, 0, 0, 1.44445],
      "732": [0, 0.75, 0, 0, 1.44445],
      "770": [0, 0.75, 0, 0, 1.44445],
      "771": [0, 0.75, 0, 0, 1.44445],
      "8730": [0.95003, 1.45, 0, 0, 1],
      "8968": [0.95003, 1.45, 0, 0, 0.58334],
      "8969": [0.95003, 1.45, 0, 0, 0.58334],
      "8970": [0.95003, 1.45, 0, 0, 0.58334],
      "8971": [0.95003, 1.45, 0, 0, 0.58334],
      "10216": [0.95003, 1.45, 0, 0, 0.75],
      "10217": [0.95003, 1.45, 0, 0, 0.75]
    },
    "Size4-Regular": {
      "32": [0, 0, 0, 0, 0.25],
      "40": [1.25003, 1.75, 0, 0, 0.79167],
      "41": [1.25003, 1.75, 0, 0, 0.79167],
      "47": [1.25003, 1.75, 0, 0, 1.27778],
      "91": [1.25003, 1.75, 0, 0, 0.58334],
      "92": [1.25003, 1.75, 0, 0, 1.27778],
      "93": [1.25003, 1.75, 0, 0, 0.58334],
      "123": [1.25003, 1.75, 0, 0, 0.80556],
      "125": [1.25003, 1.75, 0, 0, 0.80556],
      "160": [0, 0, 0, 0, 0.25],
      "710": [0, 0.825, 0, 0, 1.8889],
      "732": [0, 0.825, 0, 0, 1.8889],
      "770": [0, 0.825, 0, 0, 1.8889],
      "771": [0, 0.825, 0, 0, 1.8889],
      "8730": [1.25003, 1.75, 0, 0, 1],
      "8968": [1.25003, 1.75, 0, 0, 0.63889],
      "8969": [1.25003, 1.75, 0, 0, 0.63889],
      "8970": [1.25003, 1.75, 0, 0, 0.63889],
      "8971": [1.25003, 1.75, 0, 0, 0.63889],
      "9115": [0.64502, 1.155, 0, 0, 0.875],
      "9116": [1e-5, 0.6, 0, 0, 0.875],
      "9117": [0.64502, 1.155, 0, 0, 0.875],
      "9118": [0.64502, 1.155, 0, 0, 0.875],
      "9119": [1e-5, 0.6, 0, 0, 0.875],
      "9120": [0.64502, 1.155, 0, 0, 0.875],
      "9121": [0.64502, 1.155, 0, 0, 0.66667],
      "9122": [-99e-5, 0.601, 0, 0, 0.66667],
      "9123": [0.64502, 1.155, 0, 0, 0.66667],
      "9124": [0.64502, 1.155, 0, 0, 0.66667],
      "9125": [-99e-5, 0.601, 0, 0, 0.66667],
      "9126": [0.64502, 1.155, 0, 0, 0.66667],
      "9127": [1e-5, 0.9, 0, 0, 0.88889],
      "9128": [0.65002, 1.15, 0, 0, 0.88889],
      "9129": [0.90001, 0, 0, 0, 0.88889],
      "9130": [0, 0.3, 0, 0, 0.88889],
      "9131": [1e-5, 0.9, 0, 0, 0.88889],
      "9132": [0.65002, 1.15, 0, 0, 0.88889],
      "9133": [0.90001, 0, 0, 0, 0.88889],
      "9143": [0.88502, 0.915, 0, 0, 1.05556],
      "10216": [1.25003, 1.75, 0, 0, 0.80556],
      "10217": [1.25003, 1.75, 0, 0, 0.80556],
      "57344": [-499e-5, 0.605, 0, 0, 1.05556],
      "57345": [-499e-5, 0.605, 0, 0, 1.05556],
      "57680": [0, 0.12, 0, 0, 0.45],
      "57681": [0, 0.12, 0, 0, 0.45],
      "57682": [0, 0.12, 0, 0, 0.45],
      "57683": [0, 0.12, 0, 0, 0.45]
    },
    "Typewriter-Regular": {
      "32": [0, 0, 0, 0, 0.525],
      "33": [0, 0.61111, 0, 0, 0.525],
      "34": [0, 0.61111, 0, 0, 0.525],
      "35": [0, 0.61111, 0, 0, 0.525],
      "36": [0.08333, 0.69444, 0, 0, 0.525],
      "37": [0.08333, 0.69444, 0, 0, 0.525],
      "38": [0, 0.61111, 0, 0, 0.525],
      "39": [0, 0.61111, 0, 0, 0.525],
      "40": [0.08333, 0.69444, 0, 0, 0.525],
      "41": [0.08333, 0.69444, 0, 0, 0.525],
      "42": [0, 0.52083, 0, 0, 0.525],
      "43": [-0.08056, 0.53055, 0, 0, 0.525],
      "44": [0.13889, 0.125, 0, 0, 0.525],
      "45": [-0.08056, 0.53055, 0, 0, 0.525],
      "46": [0, 0.125, 0, 0, 0.525],
      "47": [0.08333, 0.69444, 0, 0, 0.525],
      "48": [0, 0.61111, 0, 0, 0.525],
      "49": [0, 0.61111, 0, 0, 0.525],
      "50": [0, 0.61111, 0, 0, 0.525],
      "51": [0, 0.61111, 0, 0, 0.525],
      "52": [0, 0.61111, 0, 0, 0.525],
      "53": [0, 0.61111, 0, 0, 0.525],
      "54": [0, 0.61111, 0, 0, 0.525],
      "55": [0, 0.61111, 0, 0, 0.525],
      "56": [0, 0.61111, 0, 0, 0.525],
      "57": [0, 0.61111, 0, 0, 0.525],
      "58": [0, 0.43056, 0, 0, 0.525],
      "59": [0.13889, 0.43056, 0, 0, 0.525],
      "60": [-0.05556, 0.55556, 0, 0, 0.525],
      "61": [-0.19549, 0.41562, 0, 0, 0.525],
      "62": [-0.05556, 0.55556, 0, 0, 0.525],
      "63": [0, 0.61111, 0, 0, 0.525],
      "64": [0, 0.61111, 0, 0, 0.525],
      "65": [0, 0.61111, 0, 0, 0.525],
      "66": [0, 0.61111, 0, 0, 0.525],
      "67": [0, 0.61111, 0, 0, 0.525],
      "68": [0, 0.61111, 0, 0, 0.525],
      "69": [0, 0.61111, 0, 0, 0.525],
      "70": [0, 0.61111, 0, 0, 0.525],
      "71": [0, 0.61111, 0, 0, 0.525],
      "72": [0, 0.61111, 0, 0, 0.525],
      "73": [0, 0.61111, 0, 0, 0.525],
      "74": [0, 0.61111, 0, 0, 0.525],
      "75": [0, 0.61111, 0, 0, 0.525],
      "76": [0, 0.61111, 0, 0, 0.525],
      "77": [0, 0.61111, 0, 0, 0.525],
      "78": [0, 0.61111, 0, 0, 0.525],
      "79": [0, 0.61111, 0, 0, 0.525],
      "80": [0, 0.61111, 0, 0, 0.525],
      "81": [0.13889, 0.61111, 0, 0, 0.525],
      "82": [0, 0.61111, 0, 0, 0.525],
      "83": [0, 0.61111, 0, 0, 0.525],
      "84": [0, 0.61111, 0, 0, 0.525],
      "85": [0, 0.61111, 0, 0, 0.525],
      "86": [0, 0.61111, 0, 0, 0.525],
      "87": [0, 0.61111, 0, 0, 0.525],
      "88": [0, 0.61111, 0, 0, 0.525],
      "89": [0, 0.61111, 0, 0, 0.525],
      "90": [0, 0.61111, 0, 0, 0.525],
      "91": [0.08333, 0.69444, 0, 0, 0.525],
      "92": [0.08333, 0.69444, 0, 0, 0.525],
      "93": [0.08333, 0.69444, 0, 0, 0.525],
      "94": [0, 0.61111, 0, 0, 0.525],
      "95": [0.09514, 0, 0, 0, 0.525],
      "96": [0, 0.61111, 0, 0, 0.525],
      "97": [0, 0.43056, 0, 0, 0.525],
      "98": [0, 0.61111, 0, 0, 0.525],
      "99": [0, 0.43056, 0, 0, 0.525],
      "100": [0, 0.61111, 0, 0, 0.525],
      "101": [0, 0.43056, 0, 0, 0.525],
      "102": [0, 0.61111, 0, 0, 0.525],
      "103": [0.22222, 0.43056, 0, 0, 0.525],
      "104": [0, 0.61111, 0, 0, 0.525],
      "105": [0, 0.61111, 0, 0, 0.525],
      "106": [0.22222, 0.61111, 0, 0, 0.525],
      "107": [0, 0.61111, 0, 0, 0.525],
      "108": [0, 0.61111, 0, 0, 0.525],
      "109": [0, 0.43056, 0, 0, 0.525],
      "110": [0, 0.43056, 0, 0, 0.525],
      "111": [0, 0.43056, 0, 0, 0.525],
      "112": [0.22222, 0.43056, 0, 0, 0.525],
      "113": [0.22222, 0.43056, 0, 0, 0.525],
      "114": [0, 0.43056, 0, 0, 0.525],
      "115": [0, 0.43056, 0, 0, 0.525],
      "116": [0, 0.55358, 0, 0, 0.525],
      "117": [0, 0.43056, 0, 0, 0.525],
      "118": [0, 0.43056, 0, 0, 0.525],
      "119": [0, 0.43056, 0, 0, 0.525],
      "120": [0, 0.43056, 0, 0, 0.525],
      "121": [0.22222, 0.43056, 0, 0, 0.525],
      "122": [0, 0.43056, 0, 0, 0.525],
      "123": [0.08333, 0.69444, 0, 0, 0.525],
      "124": [0.08333, 0.69444, 0, 0, 0.525],
      "125": [0.08333, 0.69444, 0, 0, 0.525],
      "126": [0, 0.61111, 0, 0, 0.525],
      "127": [0, 0.61111, 0, 0, 0.525],
      "160": [0, 0, 0, 0, 0.525],
      "176": [0, 0.61111, 0, 0, 0.525],
      "184": [0.19445, 0, 0, 0, 0.525],
      "305": [0, 0.43056, 0, 0, 0.525],
      "567": [0.22222, 0.43056, 0, 0, 0.525],
      "711": [0, 0.56597, 0, 0, 0.525],
      "713": [0, 0.56555, 0, 0, 0.525],
      "714": [0, 0.61111, 0, 0, 0.525],
      "715": [0, 0.61111, 0, 0, 0.525],
      "728": [0, 0.61111, 0, 0, 0.525],
      "730": [0, 0.61111, 0, 0, 0.525],
      "770": [0, 0.61111, 0, 0, 0.525],
      "771": [0, 0.61111, 0, 0, 0.525],
      "776": [0, 0.61111, 0, 0, 0.525],
      "915": [0, 0.61111, 0, 0, 0.525],
      "916": [0, 0.61111, 0, 0, 0.525],
      "920": [0, 0.61111, 0, 0, 0.525],
      "923": [0, 0.61111, 0, 0, 0.525],
      "926": [0, 0.61111, 0, 0, 0.525],
      "928": [0, 0.61111, 0, 0, 0.525],
      "931": [0, 0.61111, 0, 0, 0.525],
      "933": [0, 0.61111, 0, 0, 0.525],
      "934": [0, 0.61111, 0, 0, 0.525],
      "936": [0, 0.61111, 0, 0, 0.525],
      "937": [0, 0.61111, 0, 0, 0.525],
      "8216": [0, 0.61111, 0, 0, 0.525],
      "8217": [0, 0.61111, 0, 0, 0.525],
      "8242": [0, 0.61111, 0, 0, 0.525],
      "9251": [0.11111, 0.21944, 0, 0, 0.525]
    }
  };
  var sigmasAndXis = {
    slant: [0.25, 0.25, 0.25],
    // sigma1
    space: [0, 0, 0],
    // sigma2
    stretch: [0, 0, 0],
    // sigma3
    shrink: [0, 0, 0],
    // sigma4
    xHeight: [0.431, 0.431, 0.431],
    // sigma5
    quad: [1, 1.171, 1.472],
    // sigma6
    extraSpace: [0, 0, 0],
    // sigma7
    num1: [0.677, 0.732, 0.925],
    // sigma8
    num2: [0.394, 0.384, 0.387],
    // sigma9
    num3: [0.444, 0.471, 0.504],
    // sigma10
    denom1: [0.686, 0.752, 1.025],
    // sigma11
    denom2: [0.345, 0.344, 0.532],
    // sigma12
    sup1: [0.413, 0.503, 0.504],
    // sigma13
    sup2: [0.363, 0.431, 0.404],
    // sigma14
    sup3: [0.289, 0.286, 0.294],
    // sigma15
    sub1: [0.15, 0.143, 0.2],
    // sigma16
    sub2: [0.247, 0.286, 0.4],
    // sigma17
    supDrop: [0.386, 0.353, 0.494],
    // sigma18
    subDrop: [0.05, 0.071, 0.1],
    // sigma19
    delim1: [2.39, 1.7, 1.98],
    // sigma20
    delim2: [1.01, 1.157, 1.42],
    // sigma21
    axisHeight: [0.25, 0.25, 0.25],
    // sigma22
    // These font metrics are extracted from TeX by using tftopl on cmex10.tfm;
    // they correspond to the font parameters of the extension fonts (family 3).
    // See the TeXbook, page 441. In AMSTeX, the extension fonts scale; to
    // match cmex7, we'd use cmex7.tfm values for script and scriptscript
    // values.
    defaultRuleThickness: [0.04, 0.049, 0.049],
    // xi8; cmex7: 0.049
    bigOpSpacing1: [0.111, 0.111, 0.111],
    // xi9
    bigOpSpacing2: [0.166, 0.166, 0.166],
    // xi10
    bigOpSpacing3: [0.2, 0.2, 0.2],
    // xi11
    bigOpSpacing4: [0.6, 0.611, 0.611],
    // xi12; cmex7: 0.611
    bigOpSpacing5: [0.1, 0.143, 0.143],
    // xi13; cmex7: 0.143
    // The \sqrt rule width is taken from the height of the surd character.
    // Since we use the same font at all sizes, this thickness doesn't scale.
    sqrtRuleThickness: [0.04, 0.04, 0.04],
    // This value determines how large a pt is, for metrics which are defined
    // in terms of pts.
    // This value is also used in katex.scss; if you change it make sure the
    // values match.
    ptPerEm: [10, 10, 10],
    // The space between adjacent `|` columns in an array definition. From
    // `\showthe\doublerulesep` in LaTeX. Equals 2.0 / ptPerEm.
    doubleRuleSep: [0.2, 0.2, 0.2],
    // The width of separator lines in {array} environments. From
    // `\showthe\arrayrulewidth` in LaTeX. Equals 0.4 / ptPerEm.
    arrayRuleWidth: [0.04, 0.04, 0.04],
    // Two values from LaTeX source2e:
    fboxsep: [0.3, 0.3, 0.3],
    //        3 pt / ptPerEm
    fboxrule: [0.04, 0.04, 0.04]
    // 0.4 pt / ptPerEm
  };
  var extraCharacterMap = {
    // Latin-1
    "\xC5": "A",
    "\xD0": "D",
    "\xDE": "o",
    "\xE5": "a",
    "\xF0": "d",
    "\xFE": "o",
    // Cyrillic
    "\u0410": "A",
    "\u0411": "B",
    "\u0412": "B",
    "\u0413": "F",
    "\u0414": "A",
    "\u0415": "E",
    "\u0416": "K",
    "\u0417": "3",
    "\u0418": "N",
    "\u0419": "N",
    "\u041A": "K",
    "\u041B": "N",
    "\u041C": "M",
    "\u041D": "H",
    "\u041E": "O",
    "\u041F": "N",
    "\u0420": "P",
    "\u0421": "C",
    "\u0422": "T",
    "\u0423": "y",
    "\u0424": "O",
    "\u0425": "X",
    "\u0426": "U",
    "\u0427": "h",
    "\u0428": "W",
    "\u0429": "W",
    "\u042A": "B",
    "\u042B": "X",
    "\u042C": "B",
    "\u042D": "3",
    "\u042E": "X",
    "\u042F": "R",
    "\u0430": "a",
    "\u0431": "b",
    "\u0432": "a",
    "\u0433": "r",
    "\u0434": "y",
    "\u0435": "e",
    "\u0436": "m",
    "\u0437": "e",
    "\u0438": "n",
    "\u0439": "n",
    "\u043A": "n",
    "\u043B": "n",
    "\u043C": "m",
    "\u043D": "n",
    "\u043E": "o",
    "\u043F": "n",
    "\u0440": "p",
    "\u0441": "c",
    "\u0442": "o",
    "\u0443": "y",
    "\u0444": "b",
    "\u0445": "x",
    "\u0446": "n",
    "\u0447": "n",
    "\u0448": "w",
    "\u0449": "w",
    "\u044A": "a",
    "\u044B": "m",
    "\u044C": "a",
    "\u044D": "e",
    "\u044E": "m",
    "\u044F": "r"
  };
  function getCharacterMetrics(character, font, mode) {
    if (!fontMetricsData[font]) {
      throw new Error("Font metrics not found for font: " + font + ".");
    }
    var ch = character.charCodeAt(0);
    var metrics = fontMetricsData[font][ch];
    if (!metrics && character[0] in extraCharacterMap) {
      ch = extraCharacterMap[character[0]].charCodeAt(0);
      metrics = fontMetricsData[font][ch];
    }
    if (!metrics && mode === "text") {
      if (supportedCodepoint(ch)) {
        metrics = fontMetricsData[font][77];
      }
    }
    if (metrics) {
      return {
        depth: metrics[0],
        height: metrics[1],
        italic: metrics[2],
        skew: metrics[3],
        width: metrics[4]
      };
    }
  }
  var fontMetricsBySizeIndex = {};
  function getGlobalMetrics(size) {
    var sizeIndex;
    if (size >= 5) {
      sizeIndex = 0;
    } else if (size >= 3) {
      sizeIndex = 1;
    } else {
      sizeIndex = 2;
    }
    if (!fontMetricsBySizeIndex[sizeIndex]) {
      var metrics = fontMetricsBySizeIndex[sizeIndex] = {
        cssEmPerMu: sigmasAndXis.quad[sizeIndex] / 18
      };
      for (var key of Object.keys(sigmasAndXis)) {
        metrics[key] = sigmasAndXis[key][sizeIndex];
      }
    }
    return fontMetricsBySizeIndex[sizeIndex];
  }
  var symbols = {
    "math": {},
    "text": {}
  };
  function defineSymbol(mode, font, group, replace, name, acceptUnicodeChar) {
    symbols[mode][name] = {
      font,
      group,
      replace
    };
    if (acceptUnicodeChar && replace) {
      symbols[mode][replace] = symbols[mode][name];
    }
  }
  var math = "math";
  var text = "text";
  var main = "main";
  var ams = "ams";
  var accent = "accent-token";
  var bin = "bin";
  var close = "close";
  var inner = "inner";
  var mathord = "mathord";
  var op = "op-token";
  var open = "open";
  var punct = "punct";
  var rel = "rel";
  var spacing = "spacing";
  var textord = "textord";
  defineSymbol(math, main, rel, "\u2261", "\\equiv", true);
  defineSymbol(math, main, rel, "\u227A", "\\prec", true);
  defineSymbol(math, main, rel, "\u227B", "\\succ", true);
  defineSymbol(math, main, rel, "\u223C", "\\sim", true);
  defineSymbol(math, main, rel, "\u22A5", "\\perp");
  defineSymbol(math, main, rel, "\u2AAF", "\\preceq", true);
  defineSymbol(math, main, rel, "\u2AB0", "\\succeq", true);
  defineSymbol(math, main, rel, "\u2243", "\\simeq", true);
  defineSymbol(math, main, rel, "\u2223", "\\mid", true);
  defineSymbol(math, main, rel, "\u226A", "\\ll", true);
  defineSymbol(math, main, rel, "\u226B", "\\gg", true);
  defineSymbol(math, main, rel, "\u224D", "\\asymp", true);
  defineSymbol(math, main, rel, "\u2225", "\\parallel");
  defineSymbol(math, main, rel, "\u22C8", "\\bowtie", true);
  defineSymbol(math, main, rel, "\u2323", "\\smile", true);
  defineSymbol(math, main, rel, "\u2291", "\\sqsubseteq", true);
  defineSymbol(math, main, rel, "\u2292", "\\sqsupseteq", true);
  defineSymbol(math, main, rel, "\u2250", "\\doteq", true);
  defineSymbol(math, main, rel, "\u2322", "\\frown", true);
  defineSymbol(math, main, rel, "\u220B", "\\ni", true);
  defineSymbol(math, main, rel, "\u221D", "\\propto", true);
  defineSymbol(math, main, rel, "\u22A2", "\\vdash", true);
  defineSymbol(math, main, rel, "\u22A3", "\\dashv", true);
  defineSymbol(math, main, rel, "\u220B", "\\owns");
  defineSymbol(math, main, punct, ".", "\\ldotp");
  defineSymbol(math, main, punct, "\u22C5", "\\cdotp");
  defineSymbol(math, main, punct, "\u22C5", "\xB7");
  defineSymbol(text, main, textord, "\u22C5", "\xB7");
  defineSymbol(math, main, textord, "#", "\\#");
  defineSymbol(text, main, textord, "#", "\\#");
  defineSymbol(math, main, textord, "&", "\\&");
  defineSymbol(text, main, textord, "&", "\\&");
  defineSymbol(math, main, textord, "\u2135", "\\aleph", true);
  defineSymbol(math, main, textord, "\u2200", "\\forall", true);
  defineSymbol(math, main, textord, "\u210F", "\\hbar", true);
  defineSymbol(math, main, textord, "\u2203", "\\exists", true);
  defineSymbol(math, main, textord, "\u2207", "\\nabla", true);
  defineSymbol(math, main, textord, "\u266D", "\\flat", true);
  defineSymbol(math, main, textord, "\u2113", "\\ell", true);
  defineSymbol(math, main, textord, "\u266E", "\\natural", true);
  defineSymbol(math, main, textord, "\u2663", "\\clubsuit", true);
  defineSymbol(math, main, textord, "\u2118", "\\wp", true);
  defineSymbol(math, main, textord, "\u266F", "\\sharp", true);
  defineSymbol(math, main, textord, "\u2662", "\\diamondsuit", true);
  defineSymbol(math, main, textord, "\u211C", "\\Re", true);
  defineSymbol(math, main, textord, "\u2661", "\\heartsuit", true);
  defineSymbol(math, main, textord, "\u2111", "\\Im", true);
  defineSymbol(math, main, textord, "\u2660", "\\spadesuit", true);
  defineSymbol(math, main, textord, "\xA7", "\\S", true);
  defineSymbol(text, main, textord, "\xA7", "\\S");
  defineSymbol(math, main, textord, "\xB6", "\\P", true);
  defineSymbol(text, main, textord, "\xB6", "\\P");
  defineSymbol(math, main, textord, "\u2020", "\\dag");
  defineSymbol(text, main, textord, "\u2020", "\\dag");
  defineSymbol(text, main, textord, "\u2020", "\\textdagger");
  defineSymbol(math, main, textord, "\u2021", "\\ddag");
  defineSymbol(text, main, textord, "\u2021", "\\ddag");
  defineSymbol(text, main, textord, "\u2021", "\\textdaggerdbl");
  defineSymbol(math, main, close, "\u23B1", "\\rmoustache", true);
  defineSymbol(math, main, open, "\u23B0", "\\lmoustache", true);
  defineSymbol(math, main, close, "\u27EF", "\\rgroup", true);
  defineSymbol(math, main, open, "\u27EE", "\\lgroup", true);
  defineSymbol(math, main, bin, "\u2213", "\\mp", true);
  defineSymbol(math, main, bin, "\u2296", "\\ominus", true);
  defineSymbol(math, main, bin, "\u228E", "\\uplus", true);
  defineSymbol(math, main, bin, "\u2293", "\\sqcap", true);
  defineSymbol(math, main, bin, "\u2217", "\\ast");
  defineSymbol(math, main, bin, "\u2294", "\\sqcup", true);
  defineSymbol(math, main, bin, "\u25EF", "\\bigcirc", true);
  defineSymbol(math, main, bin, "\u2219", "\\bullet", true);
  defineSymbol(math, main, bin, "\u2021", "\\ddagger");
  defineSymbol(math, main, bin, "\u2240", "\\wr", true);
  defineSymbol(math, main, bin, "\u2A3F", "\\amalg");
  defineSymbol(math, main, bin, "&", "\\And");
  defineSymbol(math, main, rel, "\u27F5", "\\longleftarrow", true);
  defineSymbol(math, main, rel, "\u21D0", "\\Leftarrow", true);
  defineSymbol(math, main, rel, "\u27F8", "\\Longleftarrow", true);
  defineSymbol(math, main, rel, "\u27F6", "\\longrightarrow", true);
  defineSymbol(math, main, rel, "\u21D2", "\\Rightarrow", true);
  defineSymbol(math, main, rel, "\u27F9", "\\Longrightarrow", true);
  defineSymbol(math, main, rel, "\u2194", "\\leftrightarrow", true);
  defineSymbol(math, main, rel, "\u27F7", "\\longleftrightarrow", true);
  defineSymbol(math, main, rel, "\u21D4", "\\Leftrightarrow", true);
  defineSymbol(math, main, rel, "\u27FA", "\\Longleftrightarrow", true);
  defineSymbol(math, main, rel, "\u21A6", "\\mapsto", true);
  defineSymbol(math, main, rel, "\u27FC", "\\longmapsto", true);
  defineSymbol(math, main, rel, "\u2197", "\\nearrow", true);
  defineSymbol(math, main, rel, "\u21A9", "\\hookleftarrow", true);
  defineSymbol(math, main, rel, "\u21AA", "\\hookrightarrow", true);
  defineSymbol(math, main, rel, "\u2198", "\\searrow", true);
  defineSymbol(math, main, rel, "\u21BC", "\\leftharpoonup", true);
  defineSymbol(math, main, rel, "\u21C0", "\\rightharpoonup", true);
  defineSymbol(math, main, rel, "\u2199", "\\swarrow", true);
  defineSymbol(math, main, rel, "\u21BD", "\\leftharpoondown", true);
  defineSymbol(math, main, rel, "\u21C1", "\\rightharpoondown", true);
  defineSymbol(math, main, rel, "\u2196", "\\nwarrow", true);
  defineSymbol(math, main, rel, "\u21CC", "\\rightleftharpoons", true);
  defineSymbol(math, ams, rel, "\u226E", "\\nless", true);
  defineSymbol(math, ams, rel, "\uE010", "\\@nleqslant");
  defineSymbol(math, ams, rel, "\uE011", "\\@nleqq");
  defineSymbol(math, ams, rel, "\u2A87", "\\lneq", true);
  defineSymbol(math, ams, rel, "\u2268", "\\lneqq", true);
  defineSymbol(math, ams, rel, "\uE00C", "\\@lvertneqq");
  defineSymbol(math, ams, rel, "\u22E6", "\\lnsim", true);
  defineSymbol(math, ams, rel, "\u2A89", "\\lnapprox", true);
  defineSymbol(math, ams, rel, "\u2280", "\\nprec", true);
  defineSymbol(math, ams, rel, "\u22E0", "\\npreceq", true);
  defineSymbol(math, ams, rel, "\u22E8", "\\precnsim", true);
  defineSymbol(math, ams, rel, "\u2AB9", "\\precnapprox", true);
  defineSymbol(math, ams, rel, "\u2241", "\\nsim", true);
  defineSymbol(math, ams, rel, "\uE006", "\\@nshortmid");
  defineSymbol(math, ams, rel, "\u2224", "\\nmid", true);
  defineSymbol(math, ams, rel, "\u22AC", "\\nvdash", true);
  defineSymbol(math, ams, rel, "\u22AD", "\\nvDash", true);
  defineSymbol(math, ams, rel, "\u22EA", "\\ntriangleleft");
  defineSymbol(math, ams, rel, "\u22EC", "\\ntrianglelefteq", true);
  defineSymbol(math, ams, rel, "\u228A", "\\subsetneq", true);
  defineSymbol(math, ams, rel, "\uE01A", "\\@varsubsetneq");
  defineSymbol(math, ams, rel, "\u2ACB", "\\subsetneqq", true);
  defineSymbol(math, ams, rel, "\uE017", "\\@varsubsetneqq");
  defineSymbol(math, ams, rel, "\u226F", "\\ngtr", true);
  defineSymbol(math, ams, rel, "\uE00F", "\\@ngeqslant");
  defineSymbol(math, ams, rel, "\uE00E", "\\@ngeqq");
  defineSymbol(math, ams, rel, "\u2A88", "\\gneq", true);
  defineSymbol(math, ams, rel, "\u2269", "\\gneqq", true);
  defineSymbol(math, ams, rel, "\uE00D", "\\@gvertneqq");
  defineSymbol(math, ams, rel, "\u22E7", "\\gnsim", true);
  defineSymbol(math, ams, rel, "\u2A8A", "\\gnapprox", true);
  defineSymbol(math, ams, rel, "\u2281", "\\nsucc", true);
  defineSymbol(math, ams, rel, "\u22E1", "\\nsucceq", true);
  defineSymbol(math, ams, rel, "\u22E9", "\\succnsim", true);
  defineSymbol(math, ams, rel, "\u2ABA", "\\succnapprox", true);
  defineSymbol(math, ams, rel, "\u2246", "\\ncong", true);
  defineSymbol(math, ams, rel, "\uE007", "\\@nshortparallel");
  defineSymbol(math, ams, rel, "\u2226", "\\nparallel", true);
  defineSymbol(math, ams, rel, "\u22AF", "\\nVDash", true);
  defineSymbol(math, ams, rel, "\u22EB", "\\ntriangleright");
  defineSymbol(math, ams, rel, "\u22ED", "\\ntrianglerighteq", true);
  defineSymbol(math, ams, rel, "\uE018", "\\@nsupseteqq");
  defineSymbol(math, ams, rel, "\u228B", "\\supsetneq", true);
  defineSymbol(math, ams, rel, "\uE01B", "\\@varsupsetneq");
  defineSymbol(math, ams, rel, "\u2ACC", "\\supsetneqq", true);
  defineSymbol(math, ams, rel, "\uE019", "\\@varsupsetneqq");
  defineSymbol(math, ams, rel, "\u22AE", "\\nVdash", true);
  defineSymbol(math, ams, rel, "\u2AB5", "\\precneqq", true);
  defineSymbol(math, ams, rel, "\u2AB6", "\\succneqq", true);
  defineSymbol(math, ams, rel, "\uE016", "\\@nsubseteqq");
  defineSymbol(math, ams, bin, "\u22B4", "\\unlhd");
  defineSymbol(math, ams, bin, "\u22B5", "\\unrhd");
  defineSymbol(math, ams, rel, "\u219A", "\\nleftarrow", true);
  defineSymbol(math, ams, rel, "\u219B", "\\nrightarrow", true);
  defineSymbol(math, ams, rel, "\u21CD", "\\nLeftarrow", true);
  defineSymbol(math, ams, rel, "\u21CF", "\\nRightarrow", true);
  defineSymbol(math, ams, rel, "\u21AE", "\\nleftrightarrow", true);
  defineSymbol(math, ams, rel, "\u21CE", "\\nLeftrightarrow", true);
  defineSymbol(math, ams, rel, "\u25B3", "\\vartriangle");
  defineSymbol(math, ams, textord, "\u210F", "\\hslash");
  defineSymbol(math, ams, textord, "\u25BD", "\\triangledown");
  defineSymbol(math, ams, textord, "\u25CA", "\\lozenge");
  defineSymbol(math, ams, textord, "\u24C8", "\\circledS");
  defineSymbol(math, ams, textord, "\xAE", "\\circledR");
  defineSymbol(text, ams, textord, "\xAE", "\\circledR");
  defineSymbol(math, ams, textord, "\u2221", "\\measuredangle", true);
  defineSymbol(math, ams, textord, "\u2204", "\\nexists");
  defineSymbol(math, ams, textord, "\u2127", "\\mho");
  defineSymbol(math, ams, textord, "\u2132", "\\Finv", true);
  defineSymbol(math, ams, textord, "\u2141", "\\Game", true);
  defineSymbol(math, ams, textord, "\u2035", "\\backprime");
  defineSymbol(math, ams, textord, "\u25B2", "\\blacktriangle");
  defineSymbol(math, ams, textord, "\u25BC", "\\blacktriangledown");
  defineSymbol(math, ams, textord, "\u25A0", "\\blacksquare");
  defineSymbol(math, ams, textord, "\u29EB", "\\blacklozenge");
  defineSymbol(math, ams, textord, "\u2605", "\\bigstar");
  defineSymbol(math, ams, textord, "\u2222", "\\sphericalangle", true);
  defineSymbol(math, ams, textord, "\u2201", "\\complement", true);
  defineSymbol(math, ams, textord, "\xF0", "\\eth", true);
  defineSymbol(text, main, textord, "\xF0", "\xF0");
  defineSymbol(math, ams, textord, "\u2571", "\\diagup");
  defineSymbol(math, ams, textord, "\u2572", "\\diagdown");
  defineSymbol(math, ams, textord, "\u25A1", "\\square");
  defineSymbol(math, ams, textord, "\u25A1", "\\Box");
  defineSymbol(math, ams, textord, "\u25CA", "\\Diamond");
  defineSymbol(math, ams, textord, "\xA5", "\\yen", true);
  defineSymbol(text, ams, textord, "\xA5", "\\yen", true);
  defineSymbol(math, ams, textord, "\u2713", "\\checkmark", true);
  defineSymbol(text, ams, textord, "\u2713", "\\checkmark");
  defineSymbol(math, ams, textord, "\u2136", "\\beth", true);
  defineSymbol(math, ams, textord, "\u2138", "\\daleth", true);
  defineSymbol(math, ams, textord, "\u2137", "\\gimel", true);
  defineSymbol(math, ams, textord, "\u03DD", "\\digamma", true);
  defineSymbol(math, ams, textord, "\u03F0", "\\varkappa");
  defineSymbol(math, ams, open, "\u250C", "\\@ulcorner", true);
  defineSymbol(math, ams, close, "\u2510", "\\@urcorner", true);
  defineSymbol(math, ams, open, "\u2514", "\\@llcorner", true);
  defineSymbol(math, ams, close, "\u2518", "\\@lrcorner", true);
  defineSymbol(math, ams, rel, "\u2266", "\\leqq", true);
  defineSymbol(math, ams, rel, "\u2A7D", "\\leqslant", true);
  defineSymbol(math, ams, rel, "\u2A95", "\\eqslantless", true);
  defineSymbol(math, ams, rel, "\u2272", "\\lesssim", true);
  defineSymbol(math, ams, rel, "\u2A85", "\\lessapprox", true);
  defineSymbol(math, ams, rel, "\u224A", "\\approxeq", true);
  defineSymbol(math, ams, bin, "\u22D6", "\\lessdot");
  defineSymbol(math, ams, rel, "\u22D8", "\\lll", true);
  defineSymbol(math, ams, rel, "\u2276", "\\lessgtr", true);
  defineSymbol(math, ams, rel, "\u22DA", "\\lesseqgtr", true);
  defineSymbol(math, ams, rel, "\u2A8B", "\\lesseqqgtr", true);
  defineSymbol(math, ams, rel, "\u2251", "\\doteqdot");
  defineSymbol(math, ams, rel, "\u2253", "\\risingdotseq", true);
  defineSymbol(math, ams, rel, "\u2252", "\\fallingdotseq", true);
  defineSymbol(math, ams, rel, "\u223D", "\\backsim", true);
  defineSymbol(math, ams, rel, "\u22CD", "\\backsimeq", true);
  defineSymbol(math, ams, rel, "\u2AC5", "\\subseteqq", true);
  defineSymbol(math, ams, rel, "\u22D0", "\\Subset", true);
  defineSymbol(math, ams, rel, "\u228F", "\\sqsubset", true);
  defineSymbol(math, ams, rel, "\u227C", "\\preccurlyeq", true);
  defineSymbol(math, ams, rel, "\u22DE", "\\curlyeqprec", true);
  defineSymbol(math, ams, rel, "\u227E", "\\precsim", true);
  defineSymbol(math, ams, rel, "\u2AB7", "\\precapprox", true);
  defineSymbol(math, ams, rel, "\u22B2", "\\vartriangleleft");
  defineSymbol(math, ams, rel, "\u22B4", "\\trianglelefteq");
  defineSymbol(math, ams, rel, "\u22A8", "\\vDash", true);
  defineSymbol(math, ams, rel, "\u22AA", "\\Vvdash", true);
  defineSymbol(math, ams, rel, "\u2323", "\\smallsmile");
  defineSymbol(math, ams, rel, "\u2322", "\\smallfrown");
  defineSymbol(math, ams, rel, "\u224F", "\\bumpeq", true);
  defineSymbol(math, ams, rel, "\u224E", "\\Bumpeq", true);
  defineSymbol(math, ams, rel, "\u2267", "\\geqq", true);
  defineSymbol(math, ams, rel, "\u2A7E", "\\geqslant", true);
  defineSymbol(math, ams, rel, "\u2A96", "\\eqslantgtr", true);
  defineSymbol(math, ams, rel, "\u2273", "\\gtrsim", true);
  defineSymbol(math, ams, rel, "\u2A86", "\\gtrapprox", true);
  defineSymbol(math, ams, bin, "\u22D7", "\\gtrdot");
  defineSymbol(math, ams, rel, "\u22D9", "\\ggg", true);
  defineSymbol(math, ams, rel, "\u2277", "\\gtrless", true);
  defineSymbol(math, ams, rel, "\u22DB", "\\gtreqless", true);
  defineSymbol(math, ams, rel, "\u2A8C", "\\gtreqqless", true);
  defineSymbol(math, ams, rel, "\u2256", "\\eqcirc", true);
  defineSymbol(math, ams, rel, "\u2257", "\\circeq", true);
  defineSymbol(math, ams, rel, "\u225C", "\\triangleq", true);
  defineSymbol(math, ams, rel, "\u223C", "\\thicksim");
  defineSymbol(math, ams, rel, "\u2248", "\\thickapprox");
  defineSymbol(math, ams, rel, "\u2AC6", "\\supseteqq", true);
  defineSymbol(math, ams, rel, "\u22D1", "\\Supset", true);
  defineSymbol(math, ams, rel, "\u2290", "\\sqsupset", true);
  defineSymbol(math, ams, rel, "\u227D", "\\succcurlyeq", true);
  defineSymbol(math, ams, rel, "\u22DF", "\\curlyeqsucc", true);
  defineSymbol(math, ams, rel, "\u227F", "\\succsim", true);
  defineSymbol(math, ams, rel, "\u2AB8", "\\succapprox", true);
  defineSymbol(math, ams, rel, "\u22B3", "\\vartriangleright");
  defineSymbol(math, ams, rel, "\u22B5", "\\trianglerighteq");
  defineSymbol(math, ams, rel, "\u22A9", "\\Vdash", true);
  defineSymbol(math, ams, rel, "\u2223", "\\shortmid");
  defineSymbol(math, ams, rel, "\u2225", "\\shortparallel");
  defineSymbol(math, ams, rel, "\u226C", "\\between", true);
  defineSymbol(math, ams, rel, "\u22D4", "\\pitchfork", true);
  defineSymbol(math, ams, rel, "\u221D", "\\varpropto");
  defineSymbol(math, ams, rel, "\u25C0", "\\blacktriangleleft");
  defineSymbol(math, ams, rel, "\u2234", "\\therefore", true);
  defineSymbol(math, ams, rel, "\u220D", "\\backepsilon");
  defineSymbol(math, ams, rel, "\u25B6", "\\blacktriangleright");
  defineSymbol(math, ams, rel, "\u2235", "\\because", true);
  defineSymbol(math, ams, rel, "\u22D8", "\\llless");
  defineSymbol(math, ams, rel, "\u22D9", "\\gggtr");
  defineSymbol(math, ams, bin, "\u22B2", "\\lhd");
  defineSymbol(math, ams, bin, "\u22B3", "\\rhd");
  defineSymbol(math, ams, rel, "\u2242", "\\eqsim", true);
  defineSymbol(math, main, rel, "\u22C8", "\\Join");
  defineSymbol(math, ams, rel, "\u2251", "\\Doteq", true);
  defineSymbol(math, ams, bin, "\u2214", "\\dotplus", true);
  defineSymbol(math, ams, bin, "\u2216", "\\smallsetminus");
  defineSymbol(math, ams, bin, "\u22D2", "\\Cap", true);
  defineSymbol(math, ams, bin, "\u22D3", "\\Cup", true);
  defineSymbol(math, ams, bin, "\u2A5E", "\\doublebarwedge", true);
  defineSymbol(math, ams, bin, "\u229F", "\\boxminus", true);
  defineSymbol(math, ams, bin, "\u229E", "\\boxplus", true);
  defineSymbol(math, ams, bin, "\u22C7", "\\divideontimes", true);
  defineSymbol(math, ams, bin, "\u22C9", "\\ltimes", true);
  defineSymbol(math, ams, bin, "\u22CA", "\\rtimes", true);
  defineSymbol(math, ams, bin, "\u22CB", "\\leftthreetimes", true);
  defineSymbol(math, ams, bin, "\u22CC", "\\rightthreetimes", true);
  defineSymbol(math, ams, bin, "\u22CF", "\\curlywedge", true);
  defineSymbol(math, ams, bin, "\u22CE", "\\curlyvee", true);
  defineSymbol(math, ams, bin, "\u229D", "\\circleddash", true);
  defineSymbol(math, ams, bin, "\u229B", "\\circledast", true);
  defineSymbol(math, ams, bin, "\u22C5", "\\centerdot");
  defineSymbol(math, ams, bin, "\u22BA", "\\intercal", true);
  defineSymbol(math, ams, bin, "\u22D2", "\\doublecap");
  defineSymbol(math, ams, bin, "\u22D3", "\\doublecup");
  defineSymbol(math, ams, bin, "\u22A0", "\\boxtimes", true);
  defineSymbol(math, ams, rel, "\u21E2", "\\dashrightarrow", true);
  defineSymbol(math, ams, rel, "\u21E0", "\\dashleftarrow", true);
  defineSymbol(math, ams, rel, "\u21C7", "\\leftleftarrows", true);
  defineSymbol(math, ams, rel, "\u21C6", "\\leftrightarrows", true);
  defineSymbol(math, ams, rel, "\u21DA", "\\Lleftarrow", true);
  defineSymbol(math, ams, rel, "\u219E", "\\twoheadleftarrow", true);
  defineSymbol(math, ams, rel, "\u21A2", "\\leftarrowtail", true);
  defineSymbol(math, ams, rel, "\u21AB", "\\looparrowleft", true);
  defineSymbol(math, ams, rel, "\u21CB", "\\leftrightharpoons", true);
  defineSymbol(math, ams, rel, "\u21B6", "\\curvearrowleft", true);
  defineSymbol(math, ams, rel, "\u21BA", "\\circlearrowleft", true);
  defineSymbol(math, ams, rel, "\u21B0", "\\Lsh", true);
  defineSymbol(math, ams, rel, "\u21C8", "\\upuparrows", true);
  defineSymbol(math, ams, rel, "\u21BF", "\\upharpoonleft", true);
  defineSymbol(math, ams, rel, "\u21C3", "\\downharpoonleft", true);
  defineSymbol(math, main, rel, "\u22B6", "\\origof", true);
  defineSymbol(math, main, rel, "\u22B7", "\\imageof", true);
  defineSymbol(math, ams, rel, "\u22B8", "\\multimap", true);
  defineSymbol(math, ams, rel, "\u21AD", "\\leftrightsquigarrow", true);
  defineSymbol(math, ams, rel, "\u21C9", "\\rightrightarrows", true);
  defineSymbol(math, ams, rel, "\u21C4", "\\rightleftarrows", true);
  defineSymbol(math, ams, rel, "\u21A0", "\\twoheadrightarrow", true);
  defineSymbol(math, ams, rel, "\u21A3", "\\rightarrowtail", true);
  defineSymbol(math, ams, rel, "\u21AC", "\\looparrowright", true);
  defineSymbol(math, ams, rel, "\u21B7", "\\curvearrowright", true);
  defineSymbol(math, ams, rel, "\u21BB", "\\circlearrowright", true);
  defineSymbol(math, ams, rel, "\u21B1", "\\Rsh", true);
  defineSymbol(math, ams, rel, "\u21CA", "\\downdownarrows", true);
  defineSymbol(math, ams, rel, "\u21BE", "\\upharpoonright", true);
  defineSymbol(math, ams, rel, "\u21C2", "\\downharpoonright", true);
  defineSymbol(math, ams, rel, "\u21DD", "\\rightsquigarrow", true);
  defineSymbol(math, ams, rel, "\u21DD", "\\leadsto");
  defineSymbol(math, ams, rel, "\u21DB", "\\Rrightarrow", true);
  defineSymbol(math, ams, rel, "\u21BE", "\\restriction");
  defineSymbol(math, main, textord, "\u2018", "`");
  defineSymbol(math, main, textord, "$", "\\$");
  defineSymbol(text, main, textord, "$", "\\$");
  defineSymbol(text, main, textord, "$", "\\textdollar");
  defineSymbol(math, main, textord, "%", "\\%");
  defineSymbol(text, main, textord, "%", "\\%");
  defineSymbol(math, main, textord, "_", "\\_");
  defineSymbol(text, main, textord, "_", "\\_");
  defineSymbol(text, main, textord, "_", "\\textunderscore");
  defineSymbol(math, main, textord, "\u2220", "\\angle", true);
  defineSymbol(math, main, textord, "\u221E", "\\infty", true);
  defineSymbol(math, main, textord, "\u2032", "\\prime");
  defineSymbol(math, main, textord, "\u25B3", "\\triangle");
  defineSymbol(math, main, textord, "\u0393", "\\Gamma", true);
  defineSymbol(math, main, textord, "\u0394", "\\Delta", true);
  defineSymbol(math, main, textord, "\u0398", "\\Theta", true);
  defineSymbol(math, main, textord, "\u039B", "\\Lambda", true);
  defineSymbol(math, main, textord, "\u039E", "\\Xi", true);
  defineSymbol(math, main, textord, "\u03A0", "\\Pi", true);
  defineSymbol(math, main, textord, "\u03A3", "\\Sigma", true);
  defineSymbol(math, main, textord, "\u03A5", "\\Upsilon", true);
  defineSymbol(math, main, textord, "\u03A6", "\\Phi", true);
  defineSymbol(math, main, textord, "\u03A8", "\\Psi", true);
  defineSymbol(math, main, textord, "\u03A9", "\\Omega", true);
  defineSymbol(math, main, textord, "A", "\u0391");
  defineSymbol(math, main, textord, "B", "\u0392");
  defineSymbol(math, main, textord, "E", "\u0395");
  defineSymbol(math, main, textord, "Z", "\u0396");
  defineSymbol(math, main, textord, "H", "\u0397");
  defineSymbol(math, main, textord, "I", "\u0399");
  defineSymbol(math, main, textord, "K", "\u039A");
  defineSymbol(math, main, textord, "M", "\u039C");
  defineSymbol(math, main, textord, "N", "\u039D");
  defineSymbol(math, main, textord, "O", "\u039F");
  defineSymbol(math, main, textord, "P", "\u03A1");
  defineSymbol(math, main, textord, "T", "\u03A4");
  defineSymbol(math, main, textord, "X", "\u03A7");
  defineSymbol(math, main, textord, "\xAC", "\\neg", true);
  defineSymbol(math, main, textord, "\xAC", "\\lnot");
  defineSymbol(math, main, textord, "\u22A4", "\\top");
  defineSymbol(math, main, textord, "\u22A5", "\\bot");
  defineSymbol(math, main, textord, "\u2205", "\\emptyset");
  defineSymbol(math, ams, textord, "\u2205", "\\varnothing");
  defineSymbol(math, main, mathord, "\u03B1", "\\alpha", true);
  defineSymbol(math, main, mathord, "\u03B2", "\\beta", true);
  defineSymbol(math, main, mathord, "\u03B3", "\\gamma", true);
  defineSymbol(math, main, mathord, "\u03B4", "\\delta", true);
  defineSymbol(math, main, mathord, "\u03F5", "\\epsilon", true);
  defineSymbol(math, main, mathord, "\u03B6", "\\zeta", true);
  defineSymbol(math, main, mathord, "\u03B7", "\\eta", true);
  defineSymbol(math, main, mathord, "\u03B8", "\\theta", true);
  defineSymbol(math, main, mathord, "\u03B9", "\\iota", true);
  defineSymbol(math, main, mathord, "\u03BA", "\\kappa", true);
  defineSymbol(math, main, mathord, "\u03BB", "\\lambda", true);
  defineSymbol(math, main, mathord, "\u03BC", "\\mu", true);
  defineSymbol(math, main, mathord, "\u03BD", "\\nu", true);
  defineSymbol(math, main, mathord, "\u03BE", "\\xi", true);
  defineSymbol(math, main, mathord, "\u03BF", "\\omicron", true);
  defineSymbol(math, main, mathord, "\u03C0", "\\pi", true);
  defineSymbol(math, main, mathord, "\u03C1", "\\rho", true);
  defineSymbol(math, main, mathord, "\u03C3", "\\sigma", true);
  defineSymbol(math, main, mathord, "\u03C4", "\\tau", true);
  defineSymbol(math, main, mathord, "\u03C5", "\\upsilon", true);
  defineSymbol(math, main, mathord, "\u03D5", "\\phi", true);
  defineSymbol(math, main, mathord, "\u03C7", "\\chi", true);
  defineSymbol(math, main, mathord, "\u03C8", "\\psi", true);
  defineSymbol(math, main, mathord, "\u03C9", "\\omega", true);
  defineSymbol(math, main, mathord, "\u03B5", "\\varepsilon", true);
  defineSymbol(math, main, mathord, "\u03D1", "\\vartheta", true);
  defineSymbol(math, main, mathord, "\u03D6", "\\varpi", true);
  defineSymbol(math, main, mathord, "\u03F1", "\\varrho", true);
  defineSymbol(math, main, mathord, "\u03C2", "\\varsigma", true);
  defineSymbol(math, main, mathord, "\u03C6", "\\varphi", true);
  defineSymbol(math, main, bin, "\u2217", "*", true);
  defineSymbol(math, main, bin, "+", "+");
  defineSymbol(math, main, bin, "\u2212", "-", true);
  defineSymbol(math, main, bin, "\u22C5", "\\cdot", true);
  defineSymbol(math, main, bin, "\u2218", "\\circ", true);
  defineSymbol(math, main, bin, "\xF7", "\\div", true);
  defineSymbol(math, main, bin, "\xB1", "\\pm", true);
  defineSymbol(math, main, bin, "\xD7", "\\times", true);
  defineSymbol(math, main, bin, "\u2229", "\\cap", true);
  defineSymbol(math, main, bin, "\u222A", "\\cup", true);
  defineSymbol(math, main, bin, "\u2216", "\\setminus", true);
  defineSymbol(math, main, bin, "\u2227", "\\land");
  defineSymbol(math, main, bin, "\u2228", "\\lor");
  defineSymbol(math, main, bin, "\u2227", "\\wedge", true);
  defineSymbol(math, main, bin, "\u2228", "\\vee", true);
  defineSymbol(math, main, textord, "\u221A", "\\surd");
  defineSymbol(math, main, open, "\u27E8", "\\langle", true);
  defineSymbol(math, main, open, "\u2223", "\\lvert");
  defineSymbol(math, main, open, "\u2225", "\\lVert");
  defineSymbol(math, main, close, "?", "?");
  defineSymbol(math, main, close, "!", "!");
  defineSymbol(math, main, close, "\u27E9", "\\rangle", true);
  defineSymbol(math, main, close, "\u2223", "\\rvert");
  defineSymbol(math, main, close, "\u2225", "\\rVert");
  defineSymbol(math, main, rel, "=", "=");
  defineSymbol(math, main, rel, ":", ":");
  defineSymbol(math, main, rel, "\u2248", "\\approx", true);
  defineSymbol(math, main, rel, "\u2245", "\\cong", true);
  defineSymbol(math, main, rel, "\u2265", "\\ge");
  defineSymbol(math, main, rel, "\u2265", "\\geq", true);
  defineSymbol(math, main, rel, "\u2190", "\\gets");
  defineSymbol(math, main, rel, ">", "\\gt", true);
  defineSymbol(math, main, rel, "\u2208", "\\in", true);
  defineSymbol(math, main, rel, "\uE020", "\\@not");
  defineSymbol(math, main, rel, "\u2282", "\\subset", true);
  defineSymbol(math, main, rel, "\u2283", "\\supset", true);
  defineSymbol(math, main, rel, "\u2286", "\\subseteq", true);
  defineSymbol(math, main, rel, "\u2287", "\\supseteq", true);
  defineSymbol(math, ams, rel, "\u2288", "\\nsubseteq", true);
  defineSymbol(math, ams, rel, "\u2289", "\\nsupseteq", true);
  defineSymbol(math, main, rel, "\u22A8", "\\models");
  defineSymbol(math, main, rel, "\u2190", "\\leftarrow", true);
  defineSymbol(math, main, rel, "\u2264", "\\le");
  defineSymbol(math, main, rel, "\u2264", "\\leq", true);
  defineSymbol(math, main, rel, "<", "\\lt", true);
  defineSymbol(math, main, rel, "\u2192", "\\rightarrow", true);
  defineSymbol(math, main, rel, "\u2192", "\\to");
  defineSymbol(math, ams, rel, "\u2271", "\\ngeq", true);
  defineSymbol(math, ams, rel, "\u2270", "\\nleq", true);
  defineSymbol(math, main, spacing, "\xA0", "\\ ");
  defineSymbol(math, main, spacing, "\xA0", "\\space");
  defineSymbol(math, main, spacing, "\xA0", "\\nobreakspace");
  defineSymbol(text, main, spacing, "\xA0", "\\ ");
  defineSymbol(text, main, spacing, "\xA0", " ");
  defineSymbol(text, main, spacing, "\xA0", "\\space");
  defineSymbol(text, main, spacing, "\xA0", "\\nobreakspace");
  defineSymbol(math, main, spacing, "", "\\nobreak");
  defineSymbol(math, main, spacing, "", "\\allowbreak");
  defineSymbol(math, main, punct, ",", ",");
  defineSymbol(math, main, punct, ";", ";");
  defineSymbol(math, ams, bin, "\u22BC", "\\barwedge", true);
  defineSymbol(math, ams, bin, "\u22BB", "\\veebar", true);
  defineSymbol(math, main, bin, "\u2299", "\\odot", true);
  defineSymbol(math, main, bin, "\u2295", "\\oplus", true);
  defineSymbol(math, main, bin, "\u2297", "\\otimes", true);
  defineSymbol(math, main, textord, "\u2202", "\\partial", true);
  defineSymbol(math, main, bin, "\u2298", "\\oslash", true);
  defineSymbol(math, ams, bin, "\u229A", "\\circledcirc", true);
  defineSymbol(math, ams, bin, "\u22A1", "\\boxdot", true);
  defineSymbol(math, main, bin, "\u25B3", "\\bigtriangleup");
  defineSymbol(math, main, bin, "\u25BD", "\\bigtriangledown");
  defineSymbol(math, main, bin, "\u2020", "\\dagger");
  defineSymbol(math, main, bin, "\u22C4", "\\diamond");
  defineSymbol(math, main, bin, "\u22C6", "\\star");
  defineSymbol(math, main, bin, "\u25C3", "\\triangleleft");
  defineSymbol(math, main, bin, "\u25B9", "\\triangleright");
  defineSymbol(math, main, open, "{", "\\{");
  defineSymbol(text, main, textord, "{", "\\{");
  defineSymbol(text, main, textord, "{", "\\textbraceleft");
  defineSymbol(math, main, close, "}", "\\}");
  defineSymbol(text, main, textord, "}", "\\}");
  defineSymbol(text, main, textord, "}", "\\textbraceright");
  defineSymbol(math, main, open, "{", "\\lbrace");
  defineSymbol(math, main, close, "}", "\\rbrace");
  defineSymbol(math, main, open, "[", "\\lbrack", true);
  defineSymbol(text, main, textord, "[", "\\lbrack", true);
  defineSymbol(math, main, close, "]", "\\rbrack", true);
  defineSymbol(text, main, textord, "]", "\\rbrack", true);
  defineSymbol(math, main, open, "(", "\\lparen", true);
  defineSymbol(math, main, close, ")", "\\rparen", true);
  defineSymbol(text, main, textord, "<", "\\textless", true);
  defineSymbol(text, main, textord, ">", "\\textgreater", true);
  defineSymbol(math, main, open, "\u230A", "\\lfloor", true);
  defineSymbol(math, main, close, "\u230B", "\\rfloor", true);
  defineSymbol(math, main, open, "\u2308", "\\lceil", true);
  defineSymbol(math, main, close, "\u2309", "\\rceil", true);
  defineSymbol(math, main, textord, "\\", "\\backslash");
  defineSymbol(math, main, textord, "\u2223", "|");
  defineSymbol(math, main, textord, "\u2223", "\\vert");
  defineSymbol(text, main, textord, "|", "\\textbar", true);
  defineSymbol(math, main, textord, "\u2225", "\\|");
  defineSymbol(math, main, textord, "\u2225", "\\Vert");
  defineSymbol(text, main, textord, "\u2225", "\\textbardbl");
  defineSymbol(text, main, textord, "~", "\\textasciitilde");
  defineSymbol(text, main, textord, "\\", "\\textbackslash");
  defineSymbol(text, main, textord, "^", "\\textasciicircum");
  defineSymbol(math, main, rel, "\u2191", "\\uparrow", true);
  defineSymbol(math, main, rel, "\u21D1", "\\Uparrow", true);
  defineSymbol(math, main, rel, "\u2193", "\\downarrow", true);
  defineSymbol(math, main, rel, "\u21D3", "\\Downarrow", true);
  defineSymbol(math, main, rel, "\u2195", "\\updownarrow", true);
  defineSymbol(math, main, rel, "\u21D5", "\\Updownarrow", true);
  defineSymbol(math, main, op, "\u2210", "\\coprod");
  defineSymbol(math, main, op, "\u22C1", "\\bigvee");
  defineSymbol(math, main, op, "\u22C0", "\\bigwedge");
  defineSymbol(math, main, op, "\u2A04", "\\biguplus");
  defineSymbol(math, main, op, "\u22C2", "\\bigcap");
  defineSymbol(math, main, op, "\u22C3", "\\bigcup");
  defineSymbol(math, main, op, "\u222B", "\\int");
  defineSymbol(math, main, op, "\u222B", "\\intop");
  defineSymbol(math, main, op, "\u222C", "\\iint");
  defineSymbol(math, main, op, "\u222D", "\\iiint");
  defineSymbol(math, main, op, "\u220F", "\\prod");
  defineSymbol(math, main, op, "\u2211", "\\sum");
  defineSymbol(math, main, op, "\u2A02", "\\bigotimes");
  defineSymbol(math, main, op, "\u2A01", "\\bigoplus");
  defineSymbol(math, main, op, "\u2A00", "\\bigodot");
  defineSymbol(math, main, op, "\u222E", "\\oint");
  defineSymbol(math, main, op, "\u222F", "\\oiint");
  defineSymbol(math, main, op, "\u2230", "\\oiiint");
  defineSymbol(math, main, op, "\u2A06", "\\bigsqcup");
  defineSymbol(math, main, op, "\u222B", "\\smallint");
  defineSymbol(text, main, inner, "\u2026", "\\textellipsis");
  defineSymbol(math, main, inner, "\u2026", "\\mathellipsis");
  defineSymbol(text, main, inner, "\u2026", "\\ldots", true);
  defineSymbol(math, main, inner, "\u2026", "\\ldots", true);
  defineSymbol(math, main, inner, "\u22EF", "\\@cdots", true);
  defineSymbol(math, main, inner, "\u22F1", "\\ddots", true);
  defineSymbol(math, main, textord, "\u22EE", "\\varvdots");
  defineSymbol(text, main, textord, "\u22EE", "\\varvdots");
  defineSymbol(math, main, accent, "\u02CA", "\\acute");
  defineSymbol(math, main, accent, "\u02CB", "\\grave");
  defineSymbol(math, main, accent, "\xA8", "\\ddot");
  defineSymbol(math, main, accent, "~", "\\tilde");
  defineSymbol(math, main, accent, "\u02C9", "\\bar");
  defineSymbol(math, main, accent, "\u02D8", "\\breve");
  defineSymbol(math, main, accent, "\u02C7", "\\check");
  defineSymbol(math, main, accent, "^", "\\hat");
  defineSymbol(math, main, accent, "\u20D7", "\\vec");
  defineSymbol(math, main, accent, "\u02D9", "\\dot");
  defineSymbol(math, main, accent, "\u02DA", "\\mathring");
  defineSymbol(math, main, mathord, "\uE131", "\\@imath");
  defineSymbol(math, main, mathord, "\uE237", "\\@jmath");
  defineSymbol(math, main, textord, "\u0131", "\u0131");
  defineSymbol(math, main, textord, "\u0237", "\u0237");
  defineSymbol(text, main, textord, "\u0131", "\\i", true);
  defineSymbol(text, main, textord, "\u0237", "\\j", true);
  defineSymbol(text, main, textord, "\xDF", "\\ss", true);
  defineSymbol(text, main, textord, "\xE6", "\\ae", true);
  defineSymbol(text, main, textord, "\u0153", "\\oe", true);
  defineSymbol(text, main, textord, "\xF8", "\\o", true);
  defineSymbol(text, main, textord, "\xC6", "\\AE", true);
  defineSymbol(text, main, textord, "\u0152", "\\OE", true);
  defineSymbol(text, main, textord, "\xD8", "\\O", true);
  defineSymbol(text, main, accent, "\u02CA", "\\'");
  defineSymbol(text, main, accent, "\u02CB", "\\`");
  defineSymbol(text, main, accent, "\u02C6", "\\^");
  defineSymbol(text, main, accent, "\u02DC", "\\~");
  defineSymbol(text, main, accent, "\u02C9", "\\=");
  defineSymbol(text, main, accent, "\u02D8", "\\u");
  defineSymbol(text, main, accent, "\u02D9", "\\.");
  defineSymbol(text, main, accent, "\xB8", "\\c");
  defineSymbol(text, main, accent, "\u02DA", "\\r");
  defineSymbol(text, main, accent, "\u02C7", "\\v");
  defineSymbol(text, main, accent, "\xA8", '\\"');
  defineSymbol(text, main, accent, "\u02DD", "\\H");
  defineSymbol(text, main, accent, "\u25EF", "\\textcircled");
  var ligatures = {
    "--": true,
    "---": true,
    "``": true,
    "''": true
  };
  defineSymbol(text, main, textord, "\u2013", "--", true);
  defineSymbol(text, main, textord, "\u2013", "\\textendash");
  defineSymbol(text, main, textord, "\u2014", "---", true);
  defineSymbol(text, main, textord, "\u2014", "\\textemdash");
  defineSymbol(text, main, textord, "\u2018", "`", true);
  defineSymbol(text, main, textord, "\u2018", "\\textquoteleft");
  defineSymbol(text, main, textord, "\u2019", "'", true);
  defineSymbol(text, main, textord, "\u2019", "\\textquoteright");
  defineSymbol(text, main, textord, "\u201C", "``", true);
  defineSymbol(text, main, textord, "\u201C", "\\textquotedblleft");
  defineSymbol(text, main, textord, "\u201D", "''", true);
  defineSymbol(text, main, textord, "\u201D", "\\textquotedblright");
  defineSymbol(math, main, textord, "\xB0", "\\degree", true);
  defineSymbol(text, main, textord, "\xB0", "\\degree");
  defineSymbol(text, main, textord, "\xB0", "\\textdegree", true);
  defineSymbol(math, main, textord, "\xA3", "\\pounds");
  defineSymbol(math, main, textord, "\xA3", "\\mathsterling", true);
  defineSymbol(text, main, textord, "\xA3", "\\pounds");
  defineSymbol(text, main, textord, "\xA3", "\\textsterling", true);
  defineSymbol(math, ams, textord, "\u2720", "\\maltese");
  defineSymbol(text, ams, textord, "\u2720", "\\maltese");
  var mathTextSymbols = '0123456789/@."';
  for (i3 = 0; i3 < mathTextSymbols.length; i3++) {
    ch = mathTextSymbols.charAt(i3);
    defineSymbol(math, main, textord, ch, ch);
  }
  var ch;
  var i3;
  var textSymbols = '0123456789!@*()-=+";:?/.,';
  for (_i = 0; _i < textSymbols.length; _i++) {
    _ch = textSymbols.charAt(_i);
    defineSymbol(text, main, textord, _ch, _ch);
  }
  var _ch;
  var _i;
  var letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
  for (_i2 = 0; _i2 < letters.length; _i2++) {
    _ch2 = letters.charAt(_i2);
    defineSymbol(math, main, mathord, _ch2, _ch2);
    defineSymbol(text, main, textord, _ch2, _ch2);
  }
  var _ch2;
  var _i2;
  defineSymbol(math, ams, textord, "C", "\u2102");
  defineSymbol(text, ams, textord, "C", "\u2102");
  defineSymbol(math, ams, textord, "H", "\u210D");
  defineSymbol(text, ams, textord, "H", "\u210D");
  defineSymbol(math, ams, textord, "N", "\u2115");
  defineSymbol(text, ams, textord, "N", "\u2115");
  defineSymbol(math, ams, textord, "P", "\u2119");
  defineSymbol(text, ams, textord, "P", "\u2119");
  defineSymbol(math, ams, textord, "Q", "\u211A");
  defineSymbol(text, ams, textord, "Q", "\u211A");
  defineSymbol(math, ams, textord, "R", "\u211D");
  defineSymbol(text, ams, textord, "R", "\u211D");
  defineSymbol(math, ams, textord, "Z", "\u2124");
  defineSymbol(text, ams, textord, "Z", "\u2124");
  defineSymbol(math, main, mathord, "h", "\u210E");
  defineSymbol(text, main, mathord, "h", "\u210E");
  var wideChar;
  for (_i3 = 0; _i3 < letters.length; _i3++) {
    _ch3 = letters.charAt(_i3);
    wideChar = String.fromCharCode(55349, 56320 + _i3);
    defineSymbol(math, main, mathord, _ch3, wideChar);
    defineSymbol(text, main, textord, _ch3, wideChar);
    wideChar = String.fromCharCode(55349, 56372 + _i3);
    defineSymbol(math, main, mathord, _ch3, wideChar);
    defineSymbol(text, main, textord, _ch3, wideChar);
    wideChar = String.fromCharCode(55349, 56424 + _i3);
    defineSymbol(math, main, mathord, _ch3, wideChar);
    defineSymbol(text, main, textord, _ch3, wideChar);
    wideChar = String.fromCharCode(55349, 56580 + _i3);
    defineSymbol(math, main, mathord, _ch3, wideChar);
    defineSymbol(text, main, textord, _ch3, wideChar);
    wideChar = String.fromCharCode(55349, 56684 + _i3);
    defineSymbol(math, main, mathord, _ch3, wideChar);
    defineSymbol(text, main, textord, _ch3, wideChar);
    wideChar = String.fromCharCode(55349, 56736 + _i3);
    defineSymbol(math, main, mathord, _ch3, wideChar);
    defineSymbol(text, main, textord, _ch3, wideChar);
    wideChar = String.fromCharCode(55349, 56788 + _i3);
    defineSymbol(math, main, mathord, _ch3, wideChar);
    defineSymbol(text, main, textord, _ch3, wideChar);
    wideChar = String.fromCharCode(55349, 56840 + _i3);
    defineSymbol(math, main, mathord, _ch3, wideChar);
    defineSymbol(text, main, textord, _ch3, wideChar);
    wideChar = String.fromCharCode(55349, 56944 + _i3);
    defineSymbol(math, main, mathord, _ch3, wideChar);
    defineSymbol(text, main, textord, _ch3, wideChar);
    if (_i3 < 26) {
      wideChar = String.fromCharCode(55349, 56632 + _i3);
      defineSymbol(math, main, mathord, _ch3, wideChar);
      defineSymbol(text, main, textord, _ch3, wideChar);
      wideChar = String.fromCharCode(55349, 56476 + _i3);
      defineSymbol(math, main, mathord, _ch3, wideChar);
      defineSymbol(text, main, textord, _ch3, wideChar);
    }
  }
  var _ch3;
  var _i3;
  wideChar = String.fromCharCode(55349, 56668);
  defineSymbol(math, main, mathord, "k", wideChar);
  defineSymbol(text, main, textord, "k", wideChar);
  for (_i4 = 0; _i4 < 10; _i4++) {
    _ch4 = _i4.toString();
    wideChar = String.fromCharCode(55349, 57294 + _i4);
    defineSymbol(math, main, mathord, _ch4, wideChar);
    defineSymbol(text, main, textord, _ch4, wideChar);
    wideChar = String.fromCharCode(55349, 57314 + _i4);
    defineSymbol(math, main, mathord, _ch4, wideChar);
    defineSymbol(text, main, textord, _ch4, wideChar);
    wideChar = String.fromCharCode(55349, 57324 + _i4);
    defineSymbol(math, main, mathord, _ch4, wideChar);
    defineSymbol(text, main, textord, _ch4, wideChar);
    wideChar = String.fromCharCode(55349, 57334 + _i4);
    defineSymbol(math, main, mathord, _ch4, wideChar);
    defineSymbol(text, main, textord, _ch4, wideChar);
  }
  var _ch4;
  var _i4;
  var extraLatin = "\xD0\xDE\xFE";
  for (_i5 = 0; _i5 < extraLatin.length; _i5++) {
    _ch5 = extraLatin.charAt(_i5);
    defineSymbol(math, main, mathord, _ch5, _ch5);
    defineSymbol(text, main, textord, _ch5, _ch5);
  }
  var _ch5;
  var _i5;
  var boldUpright = {
    mathClass: "mathbf",
    textClass: "textbf",
    font: "Main-Bold"
  };
  var italic = {
    mathClass: "mathnormal",
    textClass: "textit",
    font: "Math-Italic"
  };
  var boldItalic = {
    mathClass: "boldsymbol",
    textClass: "boldsymbol",
    font: "Main-BoldItalic"
  };
  var script = {
    mathClass: "mathscr",
    textClass: "textscr",
    font: "Script-Regular"
  };
  var noFont = {
    mathClass: "",
    textClass: "",
    font: ""
  };
  var fraktur = {
    mathClass: "mathfrak",
    textClass: "textfrak",
    font: "Fraktur-Regular"
  };
  var doubleStruck = {
    mathClass: "mathbb",
    textClass: "textbb",
    font: "AMS-Regular"
  };
  var boldFraktur = {
    mathClass: "mathboldfrak",
    textClass: "textboldfrak",
    font: "Fraktur-Regular"
  };
  var sansSerif = {
    mathClass: "mathsf",
    textClass: "textsf",
    font: "SansSerif-Regular"
  };
  var boldSansSerif = {
    mathClass: "mathboldsf",
    textClass: "textboldsf",
    font: "SansSerif-Bold"
  };
  var italicSansSerif = {
    mathClass: "mathitsf",
    textClass: "textitsf",
    font: "SansSerif-Italic"
  };
  var monospace = {
    mathClass: "mathtt",
    textClass: "texttt",
    font: "Typewriter-Regular"
  };
  var wideLatinLetterData = [
    boldUpright,
    boldUpright,
    // A-Z, a-z
    italic,
    italic,
    // A-Z, a-z
    boldItalic,
    boldItalic,
    // A-Z, a-z
    // Map fancy A-Z letters to script, not calligraphic.
    // This aligns with unicode-math and math fonts (except Cambria Math).
    script,
    noFont,
    // A-Z script, a-z — no font
    noFont,
    noFont,
    // A-Z bold script, a-z bold script — no font
    fraktur,
    fraktur,
    // A-Z, a-z
    doubleStruck,
    doubleStruck,
    // A-Z double-struck, k double-struck
    // Note that we are using a bold font, but font metrics for regular Fraktur.
    boldFraktur,
    boldFraktur,
    // A-Z, a-z
    sansSerif,
    sansSerif,
    // A-Z, a-z
    boldSansSerif,
    boldSansSerif,
    // A-Z, a-z
    italicSansSerif,
    italicSansSerif,
    // A-Z, a-z
    noFont,
    noFont,
    // A-Z bold italic sans, a-z bold italic sans - no font
    monospace,
    monospace
    // A-Z, a-z
  ];
  var wideNumeralData = [
    boldUpright,
    // 0-9
    noFont,
    // 0-9 double-struck. No KaTeX font.
    sansSerif,
    // 0-9
    boldSansSerif,
    // 0-9
    monospace
    // 0-9
  ];
  var wideCharacterFont = (wideChar2) => {
    var H2 = wideChar2.charCodeAt(0);
    var L2 = wideChar2.charCodeAt(1);
    var codePoint = (H2 - 55296) * 1024 + (L2 - 56320) + 65536;
    if (119808 <= codePoint && codePoint < 120484) {
      var i3 = Math.floor((codePoint - 119808) / 26);
      return wideLatinLetterData[i3];
    } else if (120782 <= codePoint && codePoint <= 120831) {
      var _i = Math.floor((codePoint - 120782) / 10);
      return wideNumeralData[_i];
    } else if (codePoint === 120485 || codePoint === 120486) {
      return wideLatinLetterData[0];
    } else if (120486 < codePoint && codePoint < 120782) {
      return noFont;
    } else {
      throw new ParseError("Unsupported character: " + wideChar2);
    }
  };
  function handleStrict(params) {
    var strict = params.strict, errorCode = params.errorCode, errorMsg = params.errorMsg, token = params.token, report = params.report;
    var behavior = strict;
    if (typeof strict === "function") {
      if (report) {
        behavior = strict(errorCode, errorMsg, token);
      } else {
        try {
          behavior = strict(errorCode, errorMsg, token);
        } catch (error) {
          behavior = "error";
        }
      }
    }
    switch (behavior) {
      case true:
      case "error":
        if (report) {
          throw new ParseError("LaTeX-incompatible input and strict mode is set to 'error': " + (errorMsg + " [" + errorCode + "]"), token);
        } else {
          return true;
        }
      case false:
      case "ignore":
        if (!report) {
          return false;
        }
        break;
      case "warn":
      default:
        typeof console !== "undefined" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (errorMsg + " [" + errorCode + "]"));
        if (!report) {
          return false;
        }
        break;
    }
  }
  var lookupSymbol = function lookupSymbol2(value, fontName, mode) {
    if (symbols[mode][value]) {
      var replacement = symbols[mode][value].replace;
      if (replacement) {
        value = replacement;
      }
    }
    return {
      value,
      metrics: getCharacterMetrics(value, fontName, mode)
    };
  };
  var makeSymbol = function makeSymbol2(value, fontName, mode, options, classes) {
    var lookup = lookupSymbol(value, fontName, mode);
    var metrics = lookup.metrics;
    value = lookup.value;
    var symbolNode;
    if (metrics) {
      var italic2 = metrics.italic;
      if (mode === "text" || options && options.font === "mathit") {
        italic2 = 0;
      }
      symbolNode = new SymbolNode(value, metrics.height, metrics.depth, italic2, metrics.skew, metrics.width, classes);
    } else {
      handleStrict({
        strict: options.strict,
        errorCode: "symbolNotInFont",
        errorMsg: "No character metrics for '" + value + "' in style '" + fontName + "' and mode '" + mode + "'",
        report: true
      });
      symbolNode = new SymbolNode(value, 0, 0, 0, 0, 0, classes);
    }
    symbolNode.maxFontSize = options.sizeMultiplier;
    if (options.style.isTight()) {
      symbolNode.classes.push("mtight");
    }
    var color = options.getColor();
    if (color) {
      symbolNode.style.color = color;
    }
    return symbolNode;
  };
  var mathsym = function mathsym2(value, mode, options, classes) {
    if (classes === void 0) {
      classes = [];
    }
    if (options.font === "boldsymbol" && lookupSymbol(value, "Main-Bold", mode).metrics) {
      return makeSymbol(value, "Main-Bold", mode, options, classes.concat(["mathbf"]));
    } else if (value === "\\" || symbols[mode][value].font === "main") {
      return makeSymbol(value, "Main-Regular", mode, options, classes);
    } else {
      return makeSymbol(value, "AMS-Regular", mode, options, classes.concat(["amsrm"]));
    }
  };
  var boldSymbol = function boldSymbol2(value, mode, type) {
    if (type !== "textord" && lookupSymbol(value, "Math-BoldItalic", mode).metrics) {
      return {
        fontName: "Math-BoldItalic",
        fontClass: "boldsymbol"
      };
    } else {
      return {
        fontName: "Main-Bold",
        fontClass: "mathbf"
      };
    }
  };
  var makeOrd = function makeOrd2(group, options) {
    var type = group.type === "mathord" ? "mathord" : "textord";
    var mode = group.mode;
    var text2 = group.text;
    var classes = ["mord"];
    var font = options.font, fontFamily = options.fontFamily, fontWeight = options.fontWeight, fontShape = options.fontShape;
    var useFont = mode === "math" || mode === "text" && !!font;
    var fontOrFamily = useFont ? font : fontFamily;
    var wideFontName = "";
    var wideFontClass = "";
    if (text2.charCodeAt(0) === 55349) {
      var wideCharData = wideCharacterFont(text2);
      wideFontName = wideCharData.font;
      wideFontClass = wideCharData[mode + "Class"];
    }
    if (wideFontName) {
      return makeSymbol(text2, wideFontName, mode, options, classes.concat(wideFontClass));
    } else if (fontOrFamily) {
      var fontName;
      var fontClasses;
      if (fontOrFamily === "boldsymbol") {
        var fontData = boldSymbol(text2, mode, type);
        fontName = fontData.fontName;
        fontClasses = [fontData.fontClass];
      } else if (useFont) {
        fontName = fontMap[font].fontName;
        fontClasses = [font];
      } else {
        fontName = retrieveTextFontName(fontFamily, fontWeight, fontShape);
        fontClasses = [fontFamily, fontWeight, fontShape];
      }
      if (lookupSymbol(text2, fontName, mode).metrics) {
        return makeSymbol(text2, fontName, mode, options, classes.concat(fontClasses));
      } else if (Object.prototype.hasOwnProperty.call(ligatures, text2) && fontName.slice(0, 10) === "Typewriter") {
        var parts = [];
        for (var i3 = 0; i3 < text2.length; i3++) {
          parts.push(makeSymbol(text2[i3], fontName, mode, options, classes.concat(fontClasses)));
        }
        return makeFragment(parts);
      }
    }
    if (type === "mathord") {
      return makeSymbol(text2, "Math-Italic", mode, options, classes.concat(["mathnormal"]));
    } else if (type === "textord") {
      var _font = symbols[mode][text2] && symbols[mode][text2].font;
      if (_font === "ams") {
        var _fontName = retrieveTextFontName("amsrm", fontWeight, fontShape);
        return makeSymbol(text2, _fontName, mode, options, classes.concat("amsrm", fontWeight, fontShape));
      } else if (_font === "main" || !_font) {
        var _fontName2 = retrieveTextFontName("textrm", fontWeight, fontShape);
        return makeSymbol(text2, _fontName2, mode, options, classes.concat(fontWeight, fontShape));
      } else {
        var _fontName3 = retrieveTextFontName(_font, fontWeight, fontShape);
        return makeSymbol(text2, _fontName3, mode, options, classes.concat(_fontName3, fontWeight, fontShape));
      }
    } else {
      throw new Error("unexpected type: " + type + " in makeOrd");
    }
  };
  var canCombine = (prev, next) => {
    if (createClass(prev.classes) !== createClass(next.classes) || prev.skew !== next.skew || prev.maxFontSize !== next.maxFontSize || prev.italic !== 0 && prev.hasClass("mathnormal")) {
      return false;
    }
    if (prev.classes.length === 1) {
      var cls = prev.classes[0];
      if (cls === "mbin" || cls === "mord") {
        return false;
      }
    }
    for (var key of Object.keys(prev.style)) {
      if (prev.style[key] !== next.style[key]) {
        return false;
      }
    }
    for (var _key of Object.keys(next.style)) {
      if (prev.style[_key] !== next.style[_key]) {
        return false;
      }
    }
    return true;
  };
  var tryCombineChars = (chars) => {
    for (var i3 = 0; i3 < chars.length - 1; i3++) {
      var prev = chars[i3];
      var next = chars[i3 + 1];
      if (prev instanceof SymbolNode && next instanceof SymbolNode && canCombine(prev, next)) {
        prev.text += next.text;
        prev.height = Math.max(prev.height, next.height);
        prev.depth = Math.max(prev.depth, next.depth);
        prev.italic = next.italic;
        chars.splice(i3 + 1, 1);
        i3--;
      }
    }
    return chars;
  };
  var sizeElementFromChildren = function sizeElementFromChildren2(elem) {
    var height = 0;
    var depth = 0;
    var maxFontSize = 0;
    for (var i3 = 0; i3 < elem.children.length; i3++) {
      var child = elem.children[i3];
      if (child.height > height) {
        height = child.height;
      }
      if (child.depth > depth) {
        depth = child.depth;
      }
      if (child.maxFontSize > maxFontSize) {
        maxFontSize = child.maxFontSize;
      }
    }
    elem.height = height;
    elem.depth = depth;
    elem.maxFontSize = maxFontSize;
  };
  var makeSpan = function makeSpan2(classes, children, options, style) {
    var span = new Span(classes, children, options, style);
    sizeElementFromChildren(span);
    return span;
  };
  var makeSvgSpan = (classes, children, options, style) => new Span(classes, children, options, style);
  var makeLineSpan = function makeLineSpan2(className, options, thickness) {
    var line = makeSpan([className], [], options);
    line.height = Math.max(thickness || options.fontMetrics().defaultRuleThickness, options.minRuleThickness);
    line.style.borderBottomWidth = makeEm(line.height);
    line.maxFontSize = 1;
    return line;
  };
  var makeAnchor = function makeAnchor2(href, classes, children, options) {
    var anchor = new Anchor(href, classes, children, options);
    sizeElementFromChildren(anchor);
    return anchor;
  };
  var makeFragment = function makeFragment2(children) {
    var fragment = new DocumentFragment(children);
    sizeElementFromChildren(fragment);
    return fragment;
  };
  var wrapFragment = function wrapFragment2(group, options) {
    if (group instanceof DocumentFragment) {
      return makeSpan([], [group], options);
    }
    return group;
  };
  var getVListChildrenAndDepth = function getVListChildrenAndDepth2(params) {
    if (params.positionType === "individualShift") {
      var oldChildren = params.children;
      var children = [oldChildren[0]];
      var _depth = -oldChildren[0].shift - oldChildren[0].elem.depth;
      var currPos = _depth;
      for (var i3 = 1; i3 < oldChildren.length; i3++) {
        var diff = -oldChildren[i3].shift - currPos - oldChildren[i3].elem.depth;
        var size = diff - (oldChildren[i3 - 1].elem.height + oldChildren[i3 - 1].elem.depth);
        currPos = currPos + diff;
        children.push({
          type: "kern",
          size
        });
        children.push(oldChildren[i3]);
      }
      return {
        children,
        depth: _depth
      };
    }
    var depth;
    if (params.positionType === "top") {
      var bottom = params.positionData;
      for (var _i = 0; _i < params.children.length; _i++) {
        var child = params.children[_i];
        bottom -= child.type === "kern" ? child.size : child.elem.height + child.elem.depth;
      }
      depth = bottom;
    } else if (params.positionType === "bottom") {
      depth = -params.positionData;
    } else {
      var firstChild = params.children[0];
      if (firstChild.type !== "elem") {
        throw new Error('First child must have type "elem".');
      }
      if (params.positionType === "shift") {
        depth = -firstChild.elem.depth - params.positionData;
      } else if (params.positionType === "firstBaseline") {
        depth = -firstChild.elem.depth;
      } else {
        throw new Error("Invalid positionType " + params.positionType + ".");
      }
    }
    return {
      children: params.children,
      depth
    };
  };
  var makeVList = function makeVList2(params, options) {
    var _getVListChildrenAndD = getVListChildrenAndDepth(params), children = _getVListChildrenAndD.children, depth = _getVListChildrenAndD.depth;
    var pstrutSize = 0;
    for (var i3 = 0; i3 < children.length; i3++) {
      var child = children[i3];
      if (child.type === "elem") {
        var elem = child.elem;
        pstrutSize = Math.max(pstrutSize, elem.maxFontSize, elem.height);
      }
    }
    pstrutSize += 2;
    var pstrut = makeSpan(["pstrut"], []);
    pstrut.style.height = makeEm(pstrutSize);
    var realChildren = [];
    var minPos = depth;
    var maxPos = depth;
    var currPos = depth;
    for (var _i2 = 0; _i2 < children.length; _i2++) {
      var _child = children[_i2];
      if (_child.type === "kern") {
        currPos += _child.size;
      } else {
        var _elem = _child.elem;
        var classes = _child.wrapperClasses || [];
        var style = _child.wrapperStyle || {};
        var childWrap = makeSpan(classes, [pstrut, _elem], void 0, style);
        childWrap.style.top = makeEm(-pstrutSize - currPos - _elem.depth);
        if (_child.marginLeft) {
          childWrap.style.marginLeft = _child.marginLeft;
        }
        if (_child.marginRight) {
          childWrap.style.marginRight = _child.marginRight;
        }
        realChildren.push(childWrap);
        currPos += _elem.height + _elem.depth;
      }
      minPos = Math.min(minPos, currPos);
      maxPos = Math.max(maxPos, currPos);
    }
    var vlist = makeSpan(["vlist"], realChildren);
    vlist.style.height = makeEm(maxPos);
    var rows;
    if (minPos < 0) {
      var emptySpan = makeSpan([], []);
      var depthStrut = makeSpan(["vlist"], [emptySpan]);
      depthStrut.style.height = makeEm(-minPos);
      var topStrut = makeSpan(["vlist-s"], [new SymbolNode("\u200B")]);
      rows = [makeSpan(["vlist-r"], [vlist, topStrut]), makeSpan(["vlist-r"], [depthStrut])];
    } else {
      rows = [makeSpan(["vlist-r"], [vlist])];
    }
    var vtable = makeSpan(["vlist-t"], rows);
    if (rows.length === 2) {
      vtable.classes.push("vlist-t2");
    }
    vtable.height = maxPos;
    vtable.depth = -minPos;
    return vtable;
  };
  var makeGlue = (measurement, options) => {
    var rule = makeSpan(["mspace"], [], options);
    var size = calculateSize(measurement, options);
    rule.style.marginRight = makeEm(size);
    return rule;
  };
  var retrieveTextFontName = (fontFamily, fontWeight, fontShape) => {
    var baseFontName;
    var fontStylesName;
    switch (fontFamily) {
      case "amsrm":
        baseFontName = "AMS";
        break;
      case "textrm":
        baseFontName = "Main";
        break;
      case "textsf":
        baseFontName = "SansSerif";
        break;
      case "texttt":
        baseFontName = "Typewriter";
        break;
      default:
        baseFontName = fontFamily;
    }
    if (fontWeight === "textbf" && fontShape === "textit") {
      fontStylesName = "BoldItalic";
    } else if (fontWeight === "textbf") {
      fontStylesName = "Bold";
    } else if (fontShape === "textit") {
      fontStylesName = "Italic";
    } else {
      fontStylesName = "Regular";
    }
    return baseFontName + "-" + fontStylesName;
  };
  var fontMap = {
    // styles
    "mathbf": {
      variant: "bold",
      fontName: "Main-Bold"
    },
    "mathrm": {
      variant: "normal",
      fontName: "Main-Regular"
    },
    "textit": {
      variant: "italic",
      fontName: "Main-Italic"
    },
    "mathit": {
      variant: "italic",
      fontName: "Main-Italic"
    },
    "mathnormal": {
      variant: "italic",
      fontName: "Math-Italic"
    },
    "mathsfit": {
      variant: "sans-serif-italic",
      fontName: "SansSerif-Italic"
    },
    // "boldsymbol" is missing because they require the use of multiple fonts:
    // Math-BoldItalic and Main-Bold.  This is handled by a special case in
    // makeOrd which ends up calling boldsymbol.
    // families
    "mathbb": {
      variant: "double-struck",
      fontName: "AMS-Regular"
    },
    "mathcal": {
      variant: "script",
      fontName: "Caligraphic-Regular"
    },
    "mathfrak": {
      variant: "fraktur",
      fontName: "Fraktur-Regular"
    },
    "mathscr": {
      variant: "script",
      fontName: "Script-Regular"
    },
    "mathsf": {
      variant: "sans-serif",
      fontName: "SansSerif-Regular"
    },
    "mathtt": {
      variant: "monospace",
      fontName: "Typewriter-Regular"
    }
  };
  var svgData = {
    //   path, width, height
    vec: ["vec", 0.471, 0.714],
    // values from the font glyph
    oiintSize1: ["oiintSize1", 0.957, 0.499],
    // oval to overlay the integrand
    oiintSize2: ["oiintSize2", 1.472, 0.659],
    oiiintSize1: ["oiiintSize1", 1.304, 0.499],
    oiiintSize2: ["oiiintSize2", 1.98, 0.659]
  };
  var staticSvg = function staticSvg2(value, options) {
    var _svgData$value = svgData[value], pathName = _svgData$value[0], width = _svgData$value[1], height = _svgData$value[2];
    var path2 = new PathNode(pathName);
    var svgNode = new SvgNode([path2], {
      "width": makeEm(width),
      "height": makeEm(height),
      // Override CSS rule `.katex svg { width: 100% }`
      "style": "width:" + makeEm(width),
      "viewBox": "0 0 " + 1e3 * width + " " + 1e3 * height,
      "preserveAspectRatio": "xMinYMin"
    });
    var span = makeSvgSpan(["katex-overlay"], [svgNode], options);
    span.height = height;
    span.style.height = makeEm(height);
    span.style.width = makeEm(width);
    return span;
  };
  var thinspace = {
    number: 3,
    unit: "mu"
  };
  var mediumspace = {
    number: 4,
    unit: "mu"
  };
  var thickspace = {
    number: 5,
    unit: "mu"
  };
  var spacings = {
    mord: {
      mop: thinspace,
      mbin: mediumspace,
      mrel: thickspace,
      minner: thinspace
    },
    mop: {
      mord: thinspace,
      mop: thinspace,
      mrel: thickspace,
      minner: thinspace
    },
    mbin: {
      mord: mediumspace,
      mop: mediumspace,
      mopen: mediumspace,
      minner: mediumspace
    },
    mrel: {
      mord: thickspace,
      mop: thickspace,
      mopen: thickspace,
      minner: thickspace
    },
    mopen: {},
    mclose: {
      mop: thinspace,
      mbin: mediumspace,
      mrel: thickspace,
      minner: thinspace
    },
    mpunct: {
      mord: thinspace,
      mop: thinspace,
      mrel: thickspace,
      mopen: thinspace,
      mclose: thinspace,
      mpunct: thinspace,
      minner: thinspace
    },
    minner: {
      mord: thinspace,
      mop: thinspace,
      mbin: mediumspace,
      mrel: thickspace,
      mopen: thinspace,
      mpunct: thinspace,
      minner: thinspace
    }
  };
  var tightSpacings = {
    mord: {
      mop: thinspace
    },
    mop: {
      mord: thinspace,
      mop: thinspace
    },
    mbin: {},
    mrel: {},
    mopen: {},
    mclose: {
      mop: thinspace
    },
    mpunct: {},
    minner: {
      mop: thinspace
    }
  };
  var _functions = {};
  var _htmlGroupBuilders = {};
  var _mathmlGroupBuilders = {};
  function defineFunction(data) {
    var type = data.type, names = data.names, htmlBuilder3 = data.htmlBuilder, mathmlBuilder3 = data.mathmlBuilder;
    for (var i3 = 0; i3 < names.length; ++i3) {
      _functions[names[i3]] = data;
    }
    if (type) {
      if (htmlBuilder3) {
        _htmlGroupBuilders[type] = htmlBuilder3;
      }
      if (mathmlBuilder3) {
        _mathmlGroupBuilders[type] = mathmlBuilder3;
      }
    }
  }
  function defineFunctionBuilders(_ref) {
    var type = _ref.type, htmlBuilder3 = _ref.htmlBuilder, mathmlBuilder3 = _ref.mathmlBuilder;
    if (htmlBuilder3) {
      _htmlGroupBuilders[type] = htmlBuilder3;
    }
    if (mathmlBuilder3) {
      _mathmlGroupBuilders[type] = mathmlBuilder3;
    }
  }
  var normalizeArgument = function normalizeArgument2(arg) {
    return arg.type === "ordgroup" && arg.body.length === 1 ? arg.body[0] : arg;
  };
  var ordargument = function ordargument2(arg) {
    return arg.type === "ordgroup" ? arg.body : [arg];
  };
  var binLeftCanceller = /* @__PURE__ */ new Set(["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"]);
  var binRightCanceller = /* @__PURE__ */ new Set(["rightmost", "mrel", "mclose", "mpunct"]);
  var styleMap$1 = {
    "display": Style$1.DISPLAY,
    "text": Style$1.TEXT,
    "script": Style$1.SCRIPT,
    "scriptscript": Style$1.SCRIPTSCRIPT
  };
  var DomEnum = {
    mord: "mord",
    mop: "mop",
    mbin: "mbin",
    mrel: "mrel",
    mopen: "mopen",
    mclose: "mclose",
    mpunct: "mpunct",
    minner: "minner"
  };
  var buildExpression$1 = function buildExpression(expression, options, isRealGroup, surrounding) {
    if (surrounding === void 0) {
      surrounding = [null, null];
    }
    var groups = [];
    for (var i3 = 0; i3 < expression.length; i3++) {
      var output = buildGroup$1(expression[i3], options);
      if (output instanceof DocumentFragment) {
        var children = output.children;
        groups.push(...children);
      } else {
        groups.push(output);
      }
    }
    tryCombineChars(groups);
    if (!isRealGroup) {
      return groups;
    }
    var glueOptions = options;
    if (expression.length === 1) {
      var node = expression[0];
      if (node.type === "sizing") {
        glueOptions = options.havingSize(node.size);
      } else if (node.type === "styling") {
        glueOptions = options.havingStyle(styleMap$1[node.style]);
      }
    }
    var dummyPrev = makeSpan([surrounding[0] || "leftmost"], [], options);
    var dummyNext = makeSpan([surrounding[1] || "rightmost"], [], options);
    var isRoot = isRealGroup === "root";
    _traverseNonSpaceNodes(groups, (node2, prev) => {
      var prevType = prev.classes[0];
      var type = node2.classes[0];
      if (prevType === "mbin" && binRightCanceller.has(type)) {
        prev.classes[0] = "mord";
      } else if (type === "mbin" && binLeftCanceller.has(prevType)) {
        node2.classes[0] = "mord";
      }
    }, {
      node: dummyPrev
    }, dummyNext, isRoot);
    _traverseNonSpaceNodes(groups, (node2, prev) => {
      var _tightSpacings$prevTy, _spacings$prevType;
      var prevType = getTypeOfDomTree(prev);
      var type = getTypeOfDomTree(node2);
      var space = prevType && type ? node2.hasClass("mtight") ? (_tightSpacings$prevTy = tightSpacings[prevType]) == null ? void 0 : _tightSpacings$prevTy[type] : (_spacings$prevType = spacings[prevType]) == null ? void 0 : _spacings$prevType[type] : null;
      if (space) {
        return makeGlue(space, glueOptions);
      }
    }, {
      node: dummyPrev
    }, dummyNext, isRoot);
    return groups;
  };
  var _traverseNonSpaceNodes = function traverseNonSpaceNodes(nodes, callback, prev, next, isRoot) {
    if (next) {
      nodes.push(next);
    }
    var i3 = 0;
    for (; i3 < nodes.length; i3++) {
      var node = nodes[i3];
      var partialGroup = checkPartialGroup(node);
      if (partialGroup) {
        _traverseNonSpaceNodes(partialGroup.children, callback, prev, null, isRoot);
        continue;
      }
      var nonspace = !node.hasClass("mspace");
      if (nonspace) {
        var result = callback(node, prev.node);
        if (result) {
          if (prev.insertAfter) {
            prev.insertAfter(result);
          } else {
            nodes.unshift(result);
            i3++;
          }
        }
      }
      if (nonspace) {
        prev.node = node;
      } else if (isRoot && node.hasClass("katex-newline")) {
        prev.node = makeSpan(["leftmost"]);
      }
      prev.insertAfter = /* @__PURE__ */ ((index) => (n2) => {
        nodes.splice(index + 1, 0, n2);
        i3++;
      })(i3);
    }
    if (next) {
      nodes.pop();
    }
  };
  var checkPartialGroup = function checkPartialGroup2(node) {
    if (node instanceof DocumentFragment || node instanceof Anchor || node instanceof Span && node.hasClass("enclosing")) {
      return node;
    }
    return null;
  };
  var _getOutermostNode = function getOutermostNode(node, side) {
    var partialGroup = checkPartialGroup(node);
    if (partialGroup) {
      var children = partialGroup.children;
      if (children.length) {
        if (side === "right") {
          return _getOutermostNode(children[children.length - 1], "right");
        } else if (side === "left") {
          return _getOutermostNode(children[0], "left");
        }
      }
    }
    return node;
  };
  var getTypeOfDomTree = function getTypeOfDomTree2(node, side) {
    if (!node) {
      return null;
    }
    if (side) {
      node = _getOutermostNode(node, side);
    }
    var className = node.classes[0];
    return DomEnum[className] || null;
  };
  var makeNullDelimiter = function makeNullDelimiter2(options, classes) {
    var moreClasses = ["nulldelimiter"].concat(options.baseSizingClasses());
    return makeSpan(classes.concat(moreClasses));
  };
  var buildGroup$1 = function buildGroup(group, options, baseOptions) {
    if (!group) {
      return makeSpan();
    }
    if (_htmlGroupBuilders[group.type]) {
      var groupNode = _htmlGroupBuilders[group.type](group, options);
      if (baseOptions && options.size !== baseOptions.size) {
        groupNode = makeSpan(options.sizingClasses(baseOptions), [groupNode], options);
        var multiplier = options.sizeMultiplier / baseOptions.sizeMultiplier;
        groupNode.height *= multiplier;
        groupNode.depth *= multiplier;
      }
      return groupNode;
    } else {
      throw new ParseError("Got group of unknown type: '" + group.type + "'");
    }
  };
  function buildHTMLUnbreakable(children, options) {
    var body = makeSpan(["katex-base"], children, options);
    var strut = makeSpan(["katex-strut"]);
    strut.style.height = makeEm(body.height + body.depth);
    if (body.depth) {
      strut.style.verticalAlign = makeEm(-body.depth);
    }
    body.children.unshift(strut);
    return body;
  }
  function buildHTML(tree, options) {
    var tag = null;
    if (tree.length === 1 && tree[0].type === "tag") {
      tag = tree[0].tag;
      tree = tree[0].body;
    }
    var expression = buildExpression$1(tree, options, "root");
    var eqnNum;
    if (expression.length === 2 && expression[1].hasClass("katex-tag")) {
      eqnNum = expression.pop();
    }
    var children = [];
    var parts = [];
    for (var i3 = 0; i3 < expression.length; i3++) {
      parts.push(expression[i3]);
      if (expression[i3].hasClass("mbin") || expression[i3].hasClass("mrel") || expression[i3].hasClass("allowbreak")) {
        var nobreak = false;
        while (i3 < expression.length - 1 && expression[i3 + 1].hasClass("mspace") && !expression[i3 + 1].hasClass("katex-newline")) {
          i3++;
          parts.push(expression[i3]);
          if (expression[i3].hasClass("nobreak")) {
            nobreak = true;
          }
        }
        if (!nobreak) {
          children.push(buildHTMLUnbreakable(parts, options));
          parts = [];
        }
      } else if (expression[i3].hasClass("katex-newline")) {
        parts.pop();
        if (parts.length > 0) {
          children.push(buildHTMLUnbreakable(parts, options));
          parts = [];
        }
        children.push(expression[i3]);
      }
    }
    if (parts.length > 0) {
      children.push(buildHTMLUnbreakable(parts, options));
    }
    var tagChild;
    if (tag) {
      tagChild = buildHTMLUnbreakable(buildExpression$1(tag, options, true), options);
      tagChild.classes = ["katex-tag"];
      children.push(tagChild);
    } else if (eqnNum) {
      children.push(eqnNum);
    }
    var htmlNode = makeSpan(["katex-html"], children);
    htmlNode.setAttribute("aria-hidden", "true");
    if (tagChild) {
      var strut = tagChild.children[0];
      strut.style.height = makeEm(htmlNode.height + htmlNode.depth);
      if (htmlNode.depth) {
        strut.style.verticalAlign = makeEm(-htmlNode.depth);
      }
    }
    return htmlNode;
  }
  function newDocumentFragment(children) {
    return new DocumentFragment(children);
  }
  var MathNode = class {
    constructor(type, children, classes) {
      this.type = void 0;
      this.attributes = void 0;
      this.children = void 0;
      this.classes = void 0;
      this.type = type;
      this.attributes = {};
      this.children = children || [];
      this.classes = classes || [];
    }
    /**
     * Sets an attribute on a MathML node. MathML depends on attributes to convey a
     * semantic content, so this is used heavily.
     */
    setAttribute(name, value) {
      this.attributes[name] = value;
    }
    /**
     * Gets an attribute on a MathML node.
     */
    getAttribute(name) {
      return this.attributes[name];
    }
    /**
     * Converts the math node into a MathML-namespaced DOM element.
     */
    toNode() {
      var node = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
      for (var _ref2 of Object.entries(this.attributes)) {
        var attr = _ref2[0];
        var value = _ref2[1];
        node.setAttribute(attr, value);
      }
      if (this.classes.length > 0) {
        node.className = createClass(this.classes);
      }
      for (var i3 = 0; i3 < this.children.length; i3++) {
        if (this.children[i3] instanceof TextNode && this.children[i3 + 1] instanceof TextNode) {
          var text2 = this.children[i3].toText() + this.children[++i3].toText();
          while (this.children[i3 + 1] instanceof TextNode) {
            text2 += this.children[++i3].toText();
          }
          node.appendChild(new TextNode(text2).toNode());
        } else {
          node.appendChild(this.children[i3].toNode());
        }
      }
      return node;
    }
    /**
     * Converts the math node into an HTML markup string.
     */
    toMarkup() {
      var markup = "<" + this.type;
      for (var _ref4 of Object.entries(this.attributes)) {
        var attr = _ref4[0];
        var value = _ref4[1];
        markup += " " + attr + '="';
        markup += escape(value);
        markup += '"';
      }
      if (this.classes.length > 0) {
        markup += ' class ="' + escape(createClass(this.classes)) + '"';
      }
      markup += ">";
      for (var i3 = 0; i3 < this.children.length; i3++) {
        markup += this.children[i3].toMarkup();
      }
      markup += "</" + this.type + ">";
      return markup;
    }
    /**
     * Converts the math node into a string, similar to innerText, but escaped.
     */
    toText() {
      return this.children.map((child) => child.toText()).join("");
    }
  };
  var TextNode = class {
    constructor(text2) {
      this.text = void 0;
      this.text = text2;
    }
    /**
     * Converts the text node into a DOM text node.
     */
    toNode() {
      return document.createTextNode(this.text);
    }
    /**
     * Converts the text node into escaped HTML markup
     * (representing the text itself).
     */
    toMarkup() {
      return escape(this.toText());
    }
    /**
     * Converts the text node into a string
     * (representing the text itself).
     */
    toText() {
      return this.text;
    }
  };
  var SpaceNode = class {
    /**
     * Create a Space node with width given in CSS ems.
     */
    constructor(width) {
      this.width = void 0;
      this.character = void 0;
      this.width = width;
      if (width >= 0.05555 && width <= 0.05556) {
        this.character = "\u200A";
      } else if (width >= 0.1666 && width <= 0.1667) {
        this.character = "\u2009";
      } else if (width >= 0.2222 && width <= 0.2223) {
        this.character = "\u2005";
      } else if (width >= 0.2777 && width <= 0.2778) {
        this.character = "\u2005\u200A";
      } else if (width >= -0.05556 && width <= -0.05555) {
        this.character = "\u200A\u2063";
      } else if (width >= -0.1667 && width <= -0.1666) {
        this.character = "\u2009\u2063";
      } else if (width >= -0.2223 && width <= -0.2222) {
        this.character = "\u205F\u2063";
      } else if (width >= -0.2778 && width <= -0.2777) {
        this.character = "\u2005\u2063";
      } else {
        this.character = null;
      }
    }
    /**
     * Converts the math node into a MathML-namespaced DOM element.
     */
    toNode() {
      if (this.character) {
        return document.createTextNode(this.character);
      } else {
        var node = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
        node.setAttribute("width", makeEm(this.width));
        return node;
      }
    }
    /**
     * Converts the math node into an HTML markup string.
     */
    toMarkup() {
      if (this.character) {
        return "<mtext>" + this.character + "</mtext>";
      } else {
        return '<mspace width="' + makeEm(this.width) + '"/>';
      }
    }
    /**
     * Converts the math node into a string, similar to innerText.
     */
    toText() {
      if (this.character) {
        return this.character;
      } else {
        return " ";
      }
    }
  };
  var noVariantSymbols = /* @__PURE__ */ new Set(["\\imath", "\\jmath"]);
  var rowLikeTypes = /* @__PURE__ */ new Set(["mrow", "mtable"]);
  var makeText = function makeText2(text2, mode, options) {
    var _options$fontFamily, _options$font;
    if (symbols[mode][text2] && symbols[mode][text2].replace && text2.charCodeAt(0) !== 55349 && !(Object.prototype.hasOwnProperty.call(ligatures, text2) && ((options == null || (_options$fontFamily = options.fontFamily) == null ? void 0 : _options$fontFamily.slice(4, 6)) === "tt" || (options == null || (_options$font = options.font) == null ? void 0 : _options$font.slice(4, 6)) === "tt"))) {
      text2 = symbols[mode][text2].replace;
    }
    return new TextNode(text2);
  };
  var makeRow = function makeRow2(body) {
    if (body.length === 1) {
      return body[0];
    } else {
      return new MathNode("mrow", body);
    }
  };
  var mathFontVariants = {
    mathit: "italic",
    boldsymbol: (group) => group.type === "textord" ? "bold" : "bold-italic",
    mathbf: "bold",
    mathbb: "double-struck",
    mathsfit: "sans-serif-italic",
    mathfrak: "fraktur",
    mathscr: "script",
    mathcal: "script",
    mathsf: "sans-serif",
    mathtt: "monospace"
  };
  var getVariant = (group, options) => {
    if (group.mode === "text") {
      if (options.fontFamily === "texttt") {
        return "monospace";
      } else if (options.fontFamily === "textsf") {
        if (options.fontShape === "textit" && options.fontWeight === "textbf") {
          return "sans-serif-bold-italic";
        } else if (options.fontShape === "textit") {
          return "sans-serif-italic";
        } else if (options.fontWeight === "textbf") {
          return "bold-sans-serif";
        } else {
          return "sans-serif";
        }
      } else if (options.fontShape === "textit" && options.fontWeight === "textbf") {
        return "bold-italic";
      } else if (options.fontShape === "textit") {
        return "italic";
      } else if (options.fontWeight === "textbf") {
        return "bold";
      }
    }
    var font = options.font;
    if (!font || font === "mathnormal") {
      return null;
    }
    var mode = group.mode;
    var mathVariant = mathFontVariants[font];
    if (mathVariant) {
      return typeof mathVariant === "function" ? mathVariant(group) : mathVariant;
    }
    var text2 = group.text;
    if (noVariantSymbols.has(text2)) {
      return null;
    }
    if (symbols[mode][text2]) {
      var replacement = symbols[mode][text2].replace;
      if (replacement) {
        text2 = replacement;
      }
    }
    var fontName = fontMap[font].fontName;
    if (getCharacterMetrics(text2, fontName, mode)) {
      return fontMap[font].variant;
    }
    return null;
  };
  function isNumberPunctuation(group) {
    if (!group) {
      return false;
    }
    if (group.type === "mi" && group.children.length === 1) {
      var child = group.children[0];
      return child instanceof TextNode && child.text === ".";
    } else if (group.type === "mo" && group.children.length === 1 && group.getAttribute("separator") === "true" && group.getAttribute("lspace") === "0em" && group.getAttribute("rspace") === "0em") {
      var _child = group.children[0];
      return _child instanceof TextNode && _child.text === ",";
    } else {
      return false;
    }
  }
  var buildExpression2 = function buildExpression3(expression, options, isOrdgroup) {
    if (expression.length === 1) {
      var group = buildGroup2(expression[0], options);
      if (isOrdgroup && group instanceof MathNode && group.type === "mo") {
        group.setAttribute("lspace", "0em");
        group.setAttribute("rspace", "0em");
      }
      return [group];
    }
    var groups = [];
    var lastGroup;
    for (var i3 = 0; i3 < expression.length; i3++) {
      var _group = buildGroup2(expression[i3], options);
      if (_group instanceof MathNode && lastGroup instanceof MathNode) {
        if (_group.type === "mtext" && lastGroup.type === "mtext" && _group.getAttribute("mathvariant") === lastGroup.getAttribute("mathvariant")) {
          lastGroup.children.push(..._group.children);
          continue;
        } else if (_group.type === "mn" && lastGroup.type === "mn") {
          lastGroup.children.push(..._group.children);
          continue;
        } else if (isNumberPunctuation(_group) && lastGroup.type === "mn") {
          lastGroup.children.push(..._group.children);
          continue;
        } else if (_group.type === "mn" && isNumberPunctuation(lastGroup)) {
          _group.children = [...lastGroup.children, ..._group.children];
          groups.pop();
        } else if ((_group.type === "msup" || _group.type === "msub") && _group.children.length >= 1 && (lastGroup.type === "mn" || isNumberPunctuation(lastGroup))) {
          var base = _group.children[0];
          if (base instanceof MathNode && base.type === "mn") {
            base.children = [...lastGroup.children, ...base.children];
            groups.pop();
          }
        } else if (lastGroup.type === "mi" && lastGroup.children.length === 1) {
          var lastChild = lastGroup.children[0];
          if (lastChild instanceof TextNode && lastChild.text === "\u0338" && (_group.type === "mo" || _group.type === "mi" || _group.type === "mn")) {
            var child = _group.children[0];
            if (child instanceof TextNode && child.text.length > 0) {
              child.text = child.text.slice(0, 1) + "\u0338" + child.text.slice(1);
              groups.pop();
            }
          }
        }
      }
      groups.push(_group);
      lastGroup = _group;
    }
    return groups;
  };
  var buildExpressionRow = function buildExpressionRow2(expression, options, isOrdgroup) {
    return makeRow(buildExpression2(expression, options, isOrdgroup));
  };
  var buildGroup2 = function buildGroup3(group, options) {
    if (!group) {
      return new MathNode("mrow");
    }
    if (_mathmlGroupBuilders[group.type]) {
      return _mathmlGroupBuilders[group.type](group, options);
    } else {
      throw new ParseError("Got group of unknown type: '" + group.type + "'");
    }
  };
  function buildMathML(tree, texExpression, options, isDisplayMode, forMathmlOnly) {
    var expression = buildExpression2(tree, options);
    var wrapper;
    if (expression.length === 1 && expression[0] instanceof MathNode && rowLikeTypes.has(expression[0].type)) {
      wrapper = expression[0];
    } else {
      wrapper = new MathNode("mrow", expression);
    }
    var annotation = new MathNode("annotation", [new TextNode(texExpression)]);
    annotation.setAttribute("encoding", "application/x-tex");
    var semantics = new MathNode("semantics", [wrapper, annotation]);
    var math2 = new MathNode("math", [semantics]);
    math2.setAttribute("xmlns", "http://www.w3.org/1998/Math/MathML");
    if (isDisplayMode) {
      math2.setAttribute("display", "block");
    }
    var wrapperClass = forMathmlOnly ? "katex" : "katex-mathml";
    return makeSpan([wrapperClass], [math2]);
  }
  var sizeStyleMap = [
    // Each element contains [textsize, scriptsize, scriptscriptsize].
    // The size mappings are taken from TeX with \normalsize=10pt.
    [1, 1, 1],
    // size1: [5, 5, 5]              \tiny
    [2, 1, 1],
    // size2: [6, 5, 5]
    [3, 1, 1],
    // size3: [7, 5, 5]              \scriptsize
    [4, 2, 1],
    // size4: [8, 6, 5]              \footnotesize
    [5, 2, 1],
    // size5: [9, 6, 5]              \small
    [6, 3, 1],
    // size6: [10, 7, 5]             \normalsize
    [7, 4, 2],
    // size7: [12, 8, 6]             \large
    [8, 6, 3],
    // size8: [14.4, 10, 7]          \Large
    [9, 7, 6],
    // size9: [17.28, 12, 10]        \LARGE
    [10, 8, 7],
    // size10: [20.74, 14.4, 12]     \huge
    [11, 10, 9]
    // size11: [24.88, 20.74, 17.28] \HUGE
  ];
  var sizeMultipliers = [
    // fontMetrics.js:getGlobalMetrics also uses size indexes, so if
    // you change size indexes, change that function.
    0.5,
    0.6,
    0.7,
    0.8,
    0.9,
    1,
    1.2,
    1.44,
    1.728,
    2.074,
    2.488
  ];
  var sizeAtStyle = function sizeAtStyle2(size, style) {
    return style.size < 2 ? size : sizeStyleMap[size - 1][style.size - 1];
  };
  var Options = class _Options {
    constructor(data) {
      this.style = void 0;
      this.color = void 0;
      this.size = void 0;
      this.textSize = void 0;
      this.phantom = void 0;
      this.font = void 0;
      this.fontFamily = void 0;
      this.fontWeight = void 0;
      this.fontShape = void 0;
      this.sizeMultiplier = void 0;
      this.maxSize = void 0;
      this.minRuleThickness = void 0;
      this._fontMetrics = void 0;
      this.strict = void 0;
      this.style = data.style;
      this.color = data.color;
      this.size = data.size || _Options.BASESIZE;
      this.textSize = data.textSize || this.size;
      this.phantom = !!data.phantom;
      this.font = data.font || "";
      this.fontFamily = data.fontFamily || "";
      this.fontWeight = data.fontWeight || "";
      this.fontShape = data.fontShape || "";
      this.sizeMultiplier = sizeMultipliers[this.size - 1];
      this.maxSize = data.maxSize;
      this.minRuleThickness = data.minRuleThickness;
      this.strict = data.strict;
      this._fontMetrics = void 0;
    }
    /**
     * Returns a new options object with the same properties as "this".  Properties
     * from "extension" will be copied to the new options object.
     */
    extend(extension) {
      var data = {
        style: this.style,
        size: this.size,
        textSize: this.textSize,
        color: this.color,
        phantom: this.phantom,
        font: this.font,
        fontFamily: this.fontFamily,
        fontWeight: this.fontWeight,
        fontShape: this.fontShape,
        maxSize: this.maxSize,
        minRuleThickness: this.minRuleThickness,
        strict: this.strict
      };
      Object.assign(data, extension);
      return new _Options(data);
    }
    /**
     * Return an options object with the given style. If `this.style === style`,
     * returns `this`.
     */
    havingStyle(style) {
      if (this.style === style) {
        return this;
      } else {
        return this.extend({
          style,
          size: sizeAtStyle(this.textSize, style)
        });
      }
    }
    /**
     * Return an options object with a cramped version of the current style. If
     * the current style is cramped, returns `this`.
     */
    havingCrampedStyle() {
      return this.havingStyle(this.style.cramp());
    }
    /**
     * Return an options object with the given size and in at least `\textstyle`.
     * Returns `this` if appropriate.
     */
    havingSize(size) {
      if (this.size === size && this.textSize === size) {
        return this;
      } else {
        return this.extend({
          style: this.style.text(),
          size,
          textSize: size,
          sizeMultiplier: sizeMultipliers[size - 1]
        });
      }
    }
    /**
     * Like `this.havingSize(BASESIZE).havingStyle(style)`. If `style` is omitted,
     * changes to at least `\textstyle`.
     */
    havingBaseStyle(style) {
      style = style || this.style.text();
      var wantSize = sizeAtStyle(_Options.BASESIZE, style);
      if (this.size === wantSize && this.textSize === _Options.BASESIZE && this.style === style) {
        return this;
      } else {
        return this.extend({
          style,
          size: wantSize
        });
      }
    }
    /**
     * Remove the effect of sizing changes such as \Huge.
     * Keep the effect of the current style, such as \scriptstyle.
     */
    havingBaseSizing() {
      var size;
      switch (this.style.id) {
        case 4:
        case 5:
          size = 3;
          break;
        case 6:
        case 7:
          size = 1;
          break;
        default:
          size = 6;
      }
      return this.extend({
        style: this.style.text(),
        size
      });
    }
    /**
     * Create a new options object with the given color.
     */
    withColor(color) {
      return this.extend({
        color
      });
    }
    /**
     * Create a new options object with "phantom" set to true.
     */
    withPhantom() {
      return this.extend({
        phantom: true
      });
    }
    /**
     * Creates a new options object with the given math font or old text font.
     * @type {[type]}
     */
    withFont(font) {
      return this.extend({
        font
      });
    }
    /**
     * Create a new options objects with the given fontFamily.
     */
    withTextFontFamily(fontFamily) {
      return this.extend({
        fontFamily,
        font: ""
      });
    }
    /**
     * Creates a new options object with the given font weight
     */
    withTextFontWeight(fontWeight) {
      return this.extend({
        fontWeight,
        font: ""
      });
    }
    /**
     * Creates a new options object with the given font weight
     */
    withTextFontShape(fontShape) {
      return this.extend({
        fontShape,
        font: ""
      });
    }
    /**
     * Return the CSS sizing classes required to switch from enclosing options
     * `oldOptions` to `this`. Returns an array of classes.
     */
    sizingClasses(oldOptions) {
      if (oldOptions.size !== this.size) {
        return ["katex-sizing", "reset-size" + oldOptions.size, "size" + this.size];
      } else {
        return [];
      }
    }
    /**
     * Return the CSS sizing classes required to switch to the base size. Like
     * `this.havingSize(BASESIZE).sizingClasses(this)`.
     */
    baseSizingClasses() {
      if (this.size !== _Options.BASESIZE) {
        return ["katex-sizing", "reset-size" + this.size, "size" + _Options.BASESIZE];
      } else {
        return [];
      }
    }
    /**
     * Return the font metrics for this size.
     */
    fontMetrics() {
      if (!this._fontMetrics) {
        this._fontMetrics = getGlobalMetrics(this.size);
      }
      return this._fontMetrics;
    }
    /**
     * Gets the CSS color of the current options object
     */
    getColor() {
      if (this.phantom) {
        return "transparent";
      } else {
        return this.color;
      }
    }
  };
  Options.BASESIZE = 6;
  var optionsFromSettings = (settings) => new Options({
    style: settings.displayMode ? Style$1.DISPLAY : Style$1.TEXT,
    maxSize: settings.maxSize,
    minRuleThickness: settings.minRuleThickness,
    strict: settings.strict
  });
  var displayWrap = function displayWrap2(node, settings) {
    if (settings.displayMode) {
      var classes = ["katex-display"];
      if (settings.leqno) {
        classes.push("leqno");
      }
      if (settings.fleqn) {
        classes.push("fleqn");
      }
      node = makeSpan(classes, [node]);
    }
    return node;
  };
  var buildTree = function buildTree2(tree, expression, settings) {
    var options = optionsFromSettings(settings);
    var katexNode;
    if (settings.output === "mathml") {
      return buildMathML(tree, expression, options, settings.displayMode, true);
    } else if (settings.output === "html") {
      var htmlNode = buildHTML(tree, options);
      katexNode = makeSpan(["katex"], [htmlNode]);
    } else {
      var mathMLNode = buildMathML(tree, expression, options, settings.displayMode, false);
      var _htmlNode = buildHTML(tree, options);
      katexNode = makeSpan(["katex"], [mathMLNode, _htmlNode]);
    }
    return displayWrap(katexNode, settings);
  };
  var stretchyCodePoint = {
    widehat: "^",
    widecheck: "\u02C7",
    widetilde: "~",
    utilde: "~",
    overleftarrow: "\u2190",
    underleftarrow: "\u2190",
    xleftarrow: "\u2190",
    overrightarrow: "\u2192",
    underrightarrow: "\u2192",
    xrightarrow: "\u2192",
    underbrace: "\u23DF",
    overbrace: "\u23DE",
    underbracket: "\u23B5",
    overbracket: "\u23B4",
    overgroup: "\u23E0",
    undergroup: "\u23E1",
    overleftrightarrow: "\u2194",
    underleftrightarrow: "\u2194",
    xleftrightarrow: "\u2194",
    Overrightarrow: "\u21D2",
    xRightarrow: "\u21D2",
    overleftharpoon: "\u21BC",
    xleftharpoonup: "\u21BC",
    overrightharpoon: "\u21C0",
    xrightharpoonup: "\u21C0",
    xLeftarrow: "\u21D0",
    xLeftrightarrow: "\u21D4",
    xhookleftarrow: "\u21A9",
    xhookrightarrow: "\u21AA",
    xmapsto: "\u21A6",
    xrightharpoondown: "\u21C1",
    xleftharpoondown: "\u21BD",
    xrightleftharpoons: "\u21CC",
    xleftrightharpoons: "\u21CB",
    xtwoheadleftarrow: "\u219E",
    xtwoheadrightarrow: "\u21A0",
    xlongequal: "=",
    xtofrom: "\u21C4",
    xrightleftarrows: "\u21C4",
    xrightequilibrium: "\u21CC",
    // Not a perfect match.
    xleftequilibrium: "\u21CB",
    // None better available.
    "\\cdrightarrow": "\u2192",
    "\\cdleftarrow": "\u2190",
    "\\cdlongequal": "="
  };
  var stretchyMathML = function stretchyMathML2(label) {
    var node = new MathNode("mo", [new TextNode(stretchyCodePoint[label.replace(/^\\/, "")])]);
    node.setAttribute("stretchy", "true");
    return node;
  };
  var katexImagesData = {
    //   path(s), minWidth, height, align
    overrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
    overleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
    underrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
    underleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
    xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
    "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"],
    // CD minwwidth2.5pc
    xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
    "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"],
    Overrightarrow: [["doublerightarrow"], 0.888, 560, "xMaxYMin"],
    xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
    xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
    overleftharpoon: [["leftharpoon"], 0.888, 522, "xMinYMin"],
    xleftharpoonup: [["leftharpoon"], 0.888, 522, "xMinYMin"],
    xleftharpoondown: [["leftharpoondown"], 0.888, 522, "xMinYMin"],
    overrightharpoon: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
    xrightharpoonup: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
    xrightharpoondown: [["rightharpoondown"], 0.888, 522, "xMaxYMin"],
    xlongequal: [["longequal"], 0.888, 334, "xMinYMin"],
    "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"],
    xtwoheadleftarrow: [["twoheadleftarrow"], 0.888, 334, "xMinYMin"],
    xtwoheadrightarrow: [["twoheadrightarrow"], 0.888, 334, "xMaxYMin"],
    overleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
    overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
    underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
    underleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
    xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
    xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
    xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
    xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
    xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
    xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
    overlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
    underlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
    overbracket: [["leftbracketover", "rightbracketover"], 1.6, 440],
    underbracket: [["leftbracketunder", "rightbracketunder"], 1.6, 410],
    overgroup: [["leftgroup", "rightgroup"], 0.888, 342],
    undergroup: [["leftgroupunder", "rightgroupunder"], 0.888, 342],
    xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
    xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
    // The next three arrows are from the mhchem package.
    // In mhchem.sty, min-length is 2.0em. But these arrows might appear in the
    // document as \xrightarrow or \xrightleftharpoons. Those have
    // min-length = 1.75em, so we set min-length on these next three to match.
    xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
    xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
    xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
  };
  var wideAccentLabels = /* @__PURE__ */ new Set(["widehat", "widecheck", "widetilde", "utilde"]);
  var stretchySvg = function stretchySvg2(group, options) {
    function buildSvgSpan_() {
      var viewBoxWidth = 4e5;
      var label = group.label.slice(1);
      if (wideAccentLabels.has(label) && "base" in group) {
        var numChars = group.base.type === "ordgroup" ? group.base.body.length : 1;
        var viewBoxHeight;
        var pathName;
        var _height;
        if (numChars > 5) {
          if (label === "widehat" || label === "widecheck") {
            viewBoxHeight = 420;
            viewBoxWidth = 2364;
            _height = 0.42;
            pathName = label + "4";
          } else {
            viewBoxHeight = 312;
            viewBoxWidth = 2340;
            _height = 0.34;
            pathName = "tilde4";
          }
        } else {
          var imgIndex = [1, 1, 2, 2, 3, 3][numChars];
          if (label === "widehat" || label === "widecheck") {
            viewBoxWidth = [0, 1062, 2364, 2364, 2364][imgIndex];
            viewBoxHeight = [0, 239, 300, 360, 420][imgIndex];
            _height = [0, 0.24, 0.3, 0.3, 0.36, 0.42][imgIndex];
            pathName = label + imgIndex;
          } else {
            viewBoxWidth = [0, 600, 1033, 2339, 2340][imgIndex];
            viewBoxHeight = [0, 260, 286, 306, 312][imgIndex];
            _height = [0, 0.26, 0.286, 0.3, 0.306, 0.34][imgIndex];
            pathName = "tilde" + imgIndex;
          }
        }
        var path2 = new PathNode(pathName);
        var svgNode = new SvgNode([path2], {
          "width": "100%",
          "height": makeEm(_height),
          "viewBox": "0 0 " + viewBoxWidth + " " + viewBoxHeight,
          "preserveAspectRatio": "none"
        });
        return {
          span: makeSvgSpan([], [svgNode], options),
          minWidth: 0,
          height: _height
        };
      } else {
        var spans = [];
        var data = katexImagesData[label];
        if (!data) {
          throw new Error('No SVG data for "' + label + '".');
        }
        var paths2 = data[0], _minWidth = data[1], _viewBoxHeight = data[2];
        var _height2 = _viewBoxHeight / 1e3;
        var numSvgChildren = paths2.length;
        var widthClasses;
        var aligns;
        if (numSvgChildren === 1) {
          if (data.length !== 4) {
            throw new Error('Expected 4-tuple for single-path SVG data "' + label + '".');
          }
          widthClasses = ["hide-tail"];
          aligns = [data[3]];
        } else if (numSvgChildren === 2) {
          widthClasses = ["halfarrow-left", "halfarrow-right"];
          aligns = ["xMinYMin", "xMaxYMin"];
        } else if (numSvgChildren === 3) {
          widthClasses = ["brace-left", "brace-center", "brace-right"];
          aligns = ["xMinYMin", "xMidYMin", "xMaxYMin"];
        } else {
          throw new Error("Correct katexImagesData or update code here to support\n                    " + numSvgChildren + " children.");
        }
        for (var i3 = 0; i3 < numSvgChildren; i3++) {
          var _path = new PathNode(paths2[i3]);
          var _svgNode = new SvgNode([_path], {
            "width": "400em",
            "height": makeEm(_height2),
            "viewBox": "0 0 " + viewBoxWidth + " " + _viewBoxHeight,
            "preserveAspectRatio": aligns[i3] + " slice"
          });
          var _span = makeSvgSpan([widthClasses[i3]], [_svgNode], options);
          if (numSvgChildren === 1) {
            return {
              span: _span,
              minWidth: _minWidth,
              height: _height2
            };
          } else {
            _span.style.height = makeEm(_height2);
            spans.push(_span);
          }
        }
        return {
          span: makeSpan(["katex-stretchy"], spans, options),
          minWidth: _minWidth,
          height: _height2
        };
      }
    }
    var _buildSvgSpan_ = buildSvgSpan_(), span = _buildSvgSpan_.span, minWidth = _buildSvgSpan_.minWidth, height = _buildSvgSpan_.height;
    span.height = height;
    span.style.height = makeEm(height);
    if (minWidth > 0) {
      span.style.minWidth = makeEm(minWidth);
    }
    return span;
  };
  var stretchyEnclose = function stretchyEnclose2(inner2, label, topPad, bottomPad, options) {
    var img;
    var totalHeight = inner2.height + inner2.depth + topPad + bottomPad;
    if (/fbox|color|angl/.test(label)) {
      img = makeSpan(["katex-stretchy", label], [], options);
      if (label === "fbox") {
        var color = options.color && options.getColor();
        if (color) {
          img.style.borderColor = color;
        }
      }
    } else {
      var lines = [];
      if (/^[bx]cancel$/.test(label)) {
        lines.push(new LineNode({
          "x1": "0",
          "y1": "0",
          "x2": "100%",
          "y2": "100%",
          "stroke-width": "0.046em"
        }));
      }
      if (/^x?cancel$/.test(label)) {
        lines.push(new LineNode({
          "x1": "0",
          "y1": "100%",
          "x2": "100%",
          "y2": "0",
          "stroke-width": "0.046em"
        }));
      }
      var svgNode = new SvgNode(lines, {
        "width": "100%",
        "height": makeEm(totalHeight)
      });
      img = makeSvgSpan([], [svgNode], options);
    }
    img.height = totalHeight;
    img.style.height = makeEm(totalHeight);
    return img;
  };
  var atomList = ["bin", "close", "inner", "open", "punct", "rel"];
  var nonAtomList = ["accent-token", "mathord", "op-token", "spacing", "textord"];
  var Atoms = new Set(atomList);
  var NonAtoms = new Set(nonAtomList);
  function isAtom(value) {
    return Atoms.has(value);
  }
  function assertNodeType(node, type) {
    if (!node || node.type !== type) {
      throw new Error("Expected node of type " + type + ", but got " + (node ? "node of type " + node.type : String(node)));
    }
    return node;
  }
  function assertSymbolNodeType(node) {
    var typedNode = checkSymbolNodeType(node);
    if (!typedNode) {
      throw new Error("Expected node of symbol group type, but got " + (node ? "node of type " + node.type : String(node)));
    }
    return typedNode;
  }
  function checkSymbolNodeType(node) {
    if (node.type === "atom" || NonAtoms.has(node.type)) {
      return node;
    }
    return null;
  }
  function assertCharacterGroup(group, errorMessage2, allowSpaces) {
    var text2 = "";
    for (var node of group.body) {
      if (node.type === "textord") {
        text2 += node.text;
      } else if (allowSpaces && node.type === "spacing" && node.text === " ") {
        text2 += " ";
      } else {
        throw new ParseError(errorMessage2, group);
      }
    }
    return text2;
  }
  var getBaseSymbol = (group) => {
    if (group instanceof SymbolNode) {
      return group;
    }
    if (hasHtmlDomChildren(group) && group.children.length === 1) {
      return getBaseSymbol(group.children[0]);
    }
  };
  var htmlBuilder$a = (grp, options) => {
    var base;
    var group;
    var supSubGroup;
    if (grp && grp.type === "supsub") {
      group = assertNodeType(grp.base, "accent");
      base = group.base;
      grp.base = base;
      supSubGroup = assertSpan(buildGroup$1(grp, options));
      grp.base = group;
    } else {
      group = assertNodeType(grp, "accent");
      base = group.base;
    }
    var body = buildGroup$1(base, options.havingCrampedStyle());
    var mustShift = group.isShifty && isCharacterBox(base);
    var skew = 0;
    if (mustShift) {
      var _getBaseSymbol$skew, _getBaseSymbol;
      skew = (_getBaseSymbol$skew = (_getBaseSymbol = getBaseSymbol(body)) == null ? void 0 : _getBaseSymbol.skew) != null ? _getBaseSymbol$skew : 0;
    }
    var accentBelow = group.label === "\\c";
    var clearance = accentBelow ? body.height + body.depth : Math.min(body.height, options.fontMetrics().xHeight);
    var accentBody;
    if (!group.isStretchy) {
      var accent2;
      var width;
      if (group.label === "\\vec") {
        accent2 = staticSvg("vec", options);
        width = svgData.vec[1];
      } else {
        accent2 = makeOrd({
          type: "textord",
          mode: group.mode,
          text: group.label
        }, options);
        accent2 = assertSymbolDomNode(accent2);
        accent2.italic = 0;
        width = accent2.width;
        if (accentBelow) {
          clearance += accent2.depth;
        }
      }
      accentBody = makeSpan(["accent-body"], [accent2]);
      var accentFull = group.label === "\\textcircled";
      if (accentFull) {
        accentBody.classes.push("accent-full");
        clearance = body.height;
      }
      var left = skew;
      if (!accentFull) {
        left -= width / 2;
      }
      accentBody.style.left = makeEm(left);
      if (group.label === "\\textcircled") {
        accentBody.style.top = ".2em";
      }
      accentBody = makeVList({
        positionType: "firstBaseline",
        children: [{
          type: "elem",
          elem: body
        }, {
          type: "kern",
          size: -clearance
        }, {
          type: "elem",
          elem: accentBody
        }]
      });
    } else {
      accentBody = stretchySvg(group, options);
      accentBody = makeVList({
        positionType: "firstBaseline",
        children: [{
          type: "elem",
          elem: body
        }, {
          type: "elem",
          elem: accentBody,
          wrapperClasses: ["svg-align"],
          wrapperStyle: skew > 0 ? {
            width: "calc(100% - " + makeEm(2 * skew) + ")",
            marginLeft: makeEm(2 * skew)
          } : void 0
        }]
      });
    }
    var accentWrap = makeSpan(["mord", "katex-accent"], [accentBody], options);
    if (supSubGroup) {
      supSubGroup.children[0] = accentWrap;
      supSubGroup.height = Math.max(accentWrap.height, supSubGroup.height);
      supSubGroup.classes[0] = "mord";
      return supSubGroup;
    } else {
      return accentWrap;
    }
  };
  var mathmlBuilder$9 = (group, options) => {
    var accentNode = group.isStretchy ? stretchyMathML(group.label) : new MathNode("mo", [makeText(group.label, group.mode)]);
    var node = new MathNode("mover", [buildGroup2(group.base, options), accentNode]);
    node.setAttribute("accent", "true");
    return node;
  };
  var NON_STRETCHY_ACCENT_REGEX = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map((accent2) => "\\" + accent2).join("|"));
  defineFunction({
    type: "accent",
    names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
    numArgs: 1,
    handler: (context, args) => {
      var base = normalizeArgument(args[0]);
      var isStretchy = !NON_STRETCHY_ACCENT_REGEX.test(context.funcName);
      var isShifty = !isStretchy || context.funcName === "\\widehat" || context.funcName === "\\widetilde" || context.funcName === "\\widecheck";
      return {
        type: "accent",
        mode: context.parser.mode,
        label: context.funcName,
        isStretchy,
        isShifty,
        base
      };
    },
    htmlBuilder: htmlBuilder$a,
    mathmlBuilder: mathmlBuilder$9
  });
  defineFunction({
    type: "accent",
    names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"],
    numArgs: 1,
    allowedInText: true,
    allowedInMath: true,
    // unless in strict mode
    argTypes: ["primitive"],
    handler: (context, args) => {
      var base = args[0];
      var mode = context.parser.mode;
      if (mode === "math") {
        handleStrict({
          strict: context.parser.settings.strict,
          errorCode: "mathVsTextAccents",
          errorMsg: "LaTeX's accent " + context.funcName + " works only in text mode",
          report: true
        });
        mode = "text";
      }
      return {
        type: "accent",
        mode,
        label: context.funcName,
        isStretchy: false,
        isShifty: true,
        base
      };
    }
  });
  defineFunction({
    type: "accentUnder",
    names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
    numArgs: 1,
    handler: (_ref, args) => {
      var parser = _ref.parser, funcName = _ref.funcName;
      var base = args[0];
      return {
        type: "accentUnder",
        mode: parser.mode,
        label: funcName,
        base
      };
    },
    htmlBuilder: (group, options) => {
      var innerGroup = buildGroup$1(group.base, options);
      var accentBody = stretchySvg(group, options);
      var kern = group.label === "\\utilde" ? 0.12 : 0;
      var vlist = makeVList({
        positionType: "top",
        positionData: innerGroup.height,
        children: [{
          type: "elem",
          elem: accentBody,
          wrapperClasses: ["svg-align"]
        }, {
          type: "kern",
          size: kern
        }, {
          type: "elem",
          elem: innerGroup
        }]
      });
      return makeSpan(["mord", "accentunder"], [vlist], options);
    },
    mathmlBuilder: (group, options) => {
      var accentNode = stretchyMathML(group.label);
      var node = new MathNode("munder", [buildGroup2(group.base, options), accentNode]);
      node.setAttribute("accentunder", "true");
      return node;
    }
  });
  var paddedNode = (group) => {
    var node = new MathNode("mpadded", group ? [group] : []);
    node.setAttribute("width", "+0.6em");
    node.setAttribute("lspace", "0.3em");
    return node;
  };
  defineFunction({
    type: "xArrow",
    names: [
      "\\xleftarrow",
      "\\xrightarrow",
      "\\xLeftarrow",
      "\\xRightarrow",
      "\\xleftrightarrow",
      "\\xLeftrightarrow",
      "\\xhookleftarrow",
      "\\xhookrightarrow",
      "\\xmapsto",
      "\\xrightharpoondown",
      "\\xrightharpoonup",
      "\\xleftharpoondown",
      "\\xleftharpoonup",
      "\\xrightleftharpoons",
      "\\xleftrightharpoons",
      "\\xlongequal",
      "\\xtwoheadrightarrow",
      "\\xtwoheadleftarrow",
      "\\xtofrom",
      // The next 3 functions are here to support the mhchem extension.
      // Direct use of these functions is discouraged and may break someday.
      "\\xrightleftarrows",
      "\\xrightequilibrium",
      "\\xleftequilibrium",
      // The next 3 functions are here only to support the {CD} environment.
      "\\\\cdrightarrow",
      "\\\\cdleftarrow",
      "\\\\cdlongequal"
    ],
    numArgs: 1,
    numOptionalArgs: 1,
    handler(_ref, args, optArgs) {
      var parser = _ref.parser, funcName = _ref.funcName;
      return {
        type: "xArrow",
        mode: parser.mode,
        label: funcName,
        body: args[0],
        below: optArgs[0]
      };
    },
    htmlBuilder(group, options) {
      var style = options.style;
      var newOptions = options.havingStyle(style.sup());
      var upperGroup = wrapFragment(buildGroup$1(group.body, newOptions, options), options);
      var arrowPrefix = group.label.slice(0, 2) === "\\x" ? "x" : "cd";
      upperGroup.classes.push(arrowPrefix + "-arrow-pad");
      var lowerGroup;
      if (group.below) {
        newOptions = options.havingStyle(style.sub());
        lowerGroup = wrapFragment(buildGroup$1(group.below, newOptions, options), options);
        lowerGroup.classes.push(arrowPrefix + "-arrow-pad");
      }
      var arrowBody = stretchySvg(group, options);
      var arrowShift = -options.fontMetrics().axisHeight + 0.5 * arrowBody.height;
      var upperShift = -options.fontMetrics().axisHeight - 0.5 * arrowBody.height - 0.111;
      if (upperGroup.depth > 0.25 || group.label === "\\xleftequilibrium") {
        upperShift -= upperGroup.depth;
      }
      var vlist;
      if (lowerGroup) {
        var lowerShift = -options.fontMetrics().axisHeight + lowerGroup.height + 0.5 * arrowBody.height + 0.111;
        vlist = makeVList({
          positionType: "individualShift",
          children: [{
            type: "elem",
            elem: upperGroup,
            shift: upperShift
          }, {
            type: "elem",
            elem: arrowBody,
            shift: arrowShift,
            wrapperClasses: ["svg-align"]
          }, {
            type: "elem",
            elem: lowerGroup,
            shift: lowerShift
          }]
        });
      } else {
        vlist = makeVList({
          positionType: "individualShift",
          children: [{
            type: "elem",
            elem: upperGroup,
            shift: upperShift
          }, {
            type: "elem",
            elem: arrowBody,
            shift: arrowShift,
            wrapperClasses: ["svg-align"]
          }]
        });
      }
      return makeSpan(["mrel", "x-arrow"], [vlist], options);
    },
    mathmlBuilder(group, options) {
      var arrowNode = stretchyMathML(group.label);
      arrowNode.setAttribute("minsize", group.label.charAt(0) === "x" ? "1.75em" : "3.0em");
      var node;
      if (group.body) {
        var upperNode = paddedNode(buildGroup2(group.body, options));
        if (group.below) {
          var lowerNode = paddedNode(buildGroup2(group.below, options));
          node = new MathNode("munderover", [arrowNode, lowerNode, upperNode]);
        } else {
          node = new MathNode("mover", [arrowNode, upperNode]);
        }
      } else if (group.below) {
        var _lowerNode = paddedNode(buildGroup2(group.below, options));
        node = new MathNode("munder", [arrowNode, _lowerNode]);
      } else {
        node = paddedNode();
        node = new MathNode("mover", [arrowNode, node]);
      }
      return node;
    }
  });
  function htmlBuilder$9(group, options) {
    var elements = buildExpression$1(group.body, options, true);
    return makeSpan([group.mclass], elements, options);
  }
  function mathmlBuilder$8(group, options) {
    var node;
    var inner2 = buildExpression2(group.body, options);
    if (group.mclass === "minner") {
      node = new MathNode("mpadded", inner2);
    } else if (group.mclass === "mord") {
      if (group.isCharacterBox) {
        node = inner2[0];
        node.type = "mi";
      } else {
        node = new MathNode("mi", inner2);
      }
    } else {
      if (group.isCharacterBox) {
        node = inner2[0];
        node.type = "mo";
      } else {
        node = new MathNode("mo", inner2);
      }
      if (group.mclass === "mbin") {
        node.attributes.lspace = "0.22em";
        node.attributes.rspace = "0.22em";
      } else if (group.mclass === "mpunct") {
        node.attributes.lspace = "0em";
        node.attributes.rspace = "0.17em";
      } else if (group.mclass === "mopen" || group.mclass === "mclose") {
        node.attributes.lspace = "0em";
        node.attributes.rspace = "0em";
      }
    }
    return node;
  }
  defineFunction({
    type: "mclass",
    names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
    numArgs: 1,
    primitive: true,
    handler(_ref, args) {
      var parser = _ref.parser, funcName = _ref.funcName;
      var body = args[0];
      return {
        type: "mclass",
        mode: parser.mode,
        mclass: "m" + funcName.slice(5),
        body: ordargument(body),
        isCharacterBox: isCharacterBox(body)
      };
    },
    htmlBuilder: htmlBuilder$9,
    mathmlBuilder: mathmlBuilder$8
  });
  var binrelClass = (arg) => {
    var atom = arg.type === "ordgroup" && arg.body.length ? arg.body[0] : arg;
    if (atom.type === "atom" && (atom.family === "bin" || atom.family === "rel")) {
      return "m" + atom.family;
    } else {
      return "mord";
    }
  };
  defineFunction({
    type: "mclass",
    names: ["\\@binrel"],
    numArgs: 2,
    handler(_ref2, args) {
      var parser = _ref2.parser;
      return {
        type: "mclass",
        mode: parser.mode,
        mclass: binrelClass(args[0]),
        body: ordargument(args[1]),
        isCharacterBox: isCharacterBox(args[1])
      };
    }
  });
  defineFunction({
    type: "mclass",
    names: ["\\stackrel", "\\overset", "\\underset"],
    numArgs: 2,
    handler(_ref3, args) {
      var parser = _ref3.parser, funcName = _ref3.funcName;
      var baseArg = args[1];
      var shiftedArg = args[0];
      var mclass;
      if (funcName !== "\\stackrel") {
        mclass = binrelClass(baseArg);
      } else {
        mclass = "mrel";
      }
      var baseOp = {
        type: "op",
        mode: baseArg.mode,
        limits: true,
        alwaysHandleSupSub: true,
        parentIsSupSub: false,
        symbol: false,
        suppressBaseShift: funcName !== "\\stackrel",
        body: ordargument(baseArg)
      };
      var supsub = funcName === "\\underset" ? {
        type: "supsub",
        mode: shiftedArg.mode,
        base: baseOp,
        sub: shiftedArg
      } : {
        type: "supsub",
        mode: shiftedArg.mode,
        base: baseOp,
        sup: shiftedArg
      };
      return {
        type: "mclass",
        mode: parser.mode,
        mclass,
        body: [supsub],
        isCharacterBox: isCharacterBox(supsub)
      };
    }
  });
  defineFunction({
    type: "pmb",
    names: ["\\pmb"],
    numArgs: 1,
    allowedInText: true,
    handler(_ref, args) {
      var parser = _ref.parser;
      return {
        type: "pmb",
        mode: parser.mode,
        mclass: binrelClass(args[0]),
        body: ordargument(args[0])
      };
    },
    htmlBuilder(group, options) {
      var elements = buildExpression$1(group.body, options, true);
      var node = makeSpan([group.mclass], elements, options);
      node.style.textShadow = "0.02em 0.01em 0.04px";
      return node;
    },
    mathmlBuilder(group, style) {
      var inner2 = buildExpression2(group.body, style);
      var node = new MathNode("mstyle", inner2);
      node.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px");
      return node;
    }
  });
  var cdArrowFunctionName = {
    ">": "\\\\cdrightarrow",
    "<": "\\\\cdleftarrow",
    "=": "\\\\cdlongequal",
    "A": "\\uparrow",
    "V": "\\downarrow",
    "|": "\\Vert",
    ".": "no arrow"
  };
  var newCell = () => {
    return {
      type: "styling",
      body: [],
      mode: "math",
      style: "display",
      resetFont: true
    };
  };
  var isStartOfArrow = (node) => {
    return node.type === "textord" && node.text === "@";
  };
  var isLabelEnd = (node, endChar) => {
    return (node.type === "mathord" || node.type === "atom") && node.text === endChar;
  };
  function cdArrow(arrowChar, labels, parser) {
    var funcName = cdArrowFunctionName[arrowChar];
    switch (funcName) {
      case "\\\\cdrightarrow":
      case "\\\\cdleftarrow":
        return parser.callFunction(funcName, [labels[0]], [labels[1]]);
      case "\\uparrow":
      case "\\downarrow": {
        var leftLabel = parser.callFunction("\\\\cdleft", [labels[0]], []);
        var bareArrow = {
          type: "atom",
          text: funcName,
          mode: "math",
          family: "rel"
        };
        var sizedArrow = parser.callFunction("\\Big", [bareArrow], []);
        var rightLabel = parser.callFunction("\\\\cdright", [labels[1]], []);
        var arrowGroup = {
          type: "ordgroup",
          mode: "math",
          body: [leftLabel, sizedArrow, rightLabel]
        };
        return parser.callFunction("\\\\cdparent", [arrowGroup], []);
      }
      case "\\\\cdlongequal":
        return parser.callFunction("\\\\cdlongequal", [], []);
      case "\\Vert": {
        var arrow = {
          type: "textord",
          text: "\\Vert",
          mode: "math"
        };
        return parser.callFunction("\\Big", [arrow], []);
      }
      default:
        return {
          type: "textord",
          text: " ",
          mode: "math"
        };
    }
  }
  function parseCD(parser) {
    var parsedRows = [];
    parser.gullet.beginGroup();
    parser.gullet.macros.set("\\cr", "\\\\\\relax");
    parser.gullet.beginGroup();
    while (true) {
      parsedRows.push(parser.parseExpression(false, "\\\\"));
      parser.gullet.endGroup();
      parser.gullet.beginGroup();
      var next = parser.fetch().text;
      if (next === "&" || next === "\\\\") {
        parser.consume();
      } else if (next === "\\end") {
        if (parsedRows[parsedRows.length - 1].length === 0) {
          parsedRows.pop();
        }
        break;
      } else {
        throw new ParseError("Expected \\\\ or \\cr or \\end", parser.nextToken);
      }
    }
    var row = [];
    var body = [row];
    for (var i3 = 0; i3 < parsedRows.length; i3++) {
      var rowNodes = parsedRows[i3];
      var cell = newCell();
      for (var j2 = 0; j2 < rowNodes.length; j2++) {
        if (!isStartOfArrow(rowNodes[j2])) {
          cell.body.push(rowNodes[j2]);
        } else {
          row.push(cell);
          j2 += 1;
          var arrowChar = assertSymbolNodeType(rowNodes[j2]).text;
          var labels = new Array(2);
          labels[0] = {
            type: "ordgroup",
            mode: "math",
            body: []
          };
          labels[1] = {
            type: "ordgroup",
            mode: "math",
            body: []
          };
          if ("=|.".includes(arrowChar)) ;
          else if ("<>AV".includes(arrowChar)) {
            for (var labelNum = 0; labelNum < 2; labelNum++) {
              var inLabel = true;
              for (var k3 = j2 + 1; k3 < rowNodes.length; k3++) {
                if (isLabelEnd(rowNodes[k3], arrowChar)) {
                  inLabel = false;
                  j2 = k3;
                  break;
                }
                if (isStartOfArrow(rowNodes[k3])) {
                  throw new ParseError("Missing a " + arrowChar + " character to complete a CD arrow.", rowNodes[k3]);
                }
                labels[labelNum].body.push(rowNodes[k3]);
              }
              if (inLabel) {
                throw new ParseError("Missing a " + arrowChar + " character to complete a CD arrow.", rowNodes[j2]);
              }
            }
          } else {
            throw new ParseError('Expected one of "<>AV=|." after @', rowNodes[j2]);
          }
          var arrow = cdArrow(arrowChar, labels, parser);
          var wrappedArrow = {
            type: "styling",
            body: [arrow],
            mode: "math",
            style: "display",
            // CD is always displaystyle.
            resetFont: true
          };
          row.push(wrappedArrow);
          cell = newCell();
        }
      }
      if (i3 % 2 === 0) {
        row.push(cell);
      } else {
        row.shift();
      }
      row = [];
      body.push(row);
    }
    parser.gullet.endGroup();
    parser.gullet.endGroup();
    var cols = new Array(body[0].length).fill({
      type: "align",
      align: "c",
      pregap: 0.25,
      // CD package sets \enskip between columns.
      postgap: 0.25
      // So pre and post each get half an \enskip, i.e. 0.25em.
    });
    return {
      type: "array",
      mode: "math",
      body,
      arraystretch: 1,
      addJot: true,
      rowGaps: [null],
      cols,
      colSeparationType: "CD",
      hLinesBeforeRow: new Array(body.length + 1).fill([])
    };
  }
  defineFunction({
    type: "cdlabel",
    names: ["\\\\cdleft", "\\\\cdright"],
    numArgs: 1,
    handler(_ref, args) {
      var parser = _ref.parser, funcName = _ref.funcName;
      return {
        type: "cdlabel",
        mode: parser.mode,
        side: funcName.slice(4),
        label: args[0]
      };
    },
    htmlBuilder(group, options) {
      var newOptions = options.havingStyle(options.style.sup());
      var label = wrapFragment(buildGroup$1(group.label, newOptions, options), options);
      label.classes.push("cd-label-" + group.side);
      label.style.bottom = makeEm(0.8 - label.depth);
      label.height = 0;
      label.depth = 0;
      return label;
    },
    mathmlBuilder(group, options) {
      var label = new MathNode("mrow", [buildGroup2(group.label, options)]);
      label = new MathNode("mpadded", [label]);
      label.setAttribute("width", "0");
      if (group.side === "left") {
        label.setAttribute("lspace", "-1width");
      }
      label.setAttribute("voffset", "0.7em");
      label = new MathNode("mstyle", [label]);
      label.setAttribute("displaystyle", "false");
      label.setAttribute("scriptlevel", "1");
      return label;
    }
  });
  defineFunction({
    type: "cdlabelparent",
    names: ["\\\\cdparent"],
    numArgs: 1,
    handler(_ref2, args) {
      var parser = _ref2.parser;
      return {
        type: "cdlabelparent",
        mode: parser.mode,
        fragment: args[0]
      };
    },
    htmlBuilder(group, options) {
      var parent = wrapFragment(buildGroup$1(group.fragment, options), options);
      parent.classes.push("cd-vert-arrow");
      return parent;
    },
    mathmlBuilder(group, options) {
      return new MathNode("mrow", [buildGroup2(group.fragment, options)]);
    }
  });
  defineFunction({
    type: "textord",
    names: ["\\@char"],
    numArgs: 1,
    allowedInText: true,
    handler(_ref, args) {
      var parser = _ref.parser;
      var arg = assertNodeType(args[0], "ordgroup");
      var number = assertCharacterGroup(arg, "\\@char has non-numeric argument");
      var code = parseInt(number);
      var text2;
      if (isNaN(code)) {
        throw new ParseError("\\@char has non-numeric argument " + number);
      } else if (code < 0 || code > 1114111) {
        throw new ParseError("\\@char with invalid code point " + number);
      } else if (code <= 65535) {
        text2 = String.fromCharCode(code);
      } else {
        code -= 65536;
        text2 = String.fromCharCode((code >> 10) + 55296, (code & 1023) + 56320);
      }
      return {
        type: "textord",
        mode: parser.mode,
        text: text2
      };
    }
  });
  var htmlBuilder$8 = (group, options) => {
    var elements = buildExpression$1(group.body, options.withColor(group.color), false);
    return makeFragment(elements);
  };
  var mathmlBuilder$7 = (group, options) => {
    var inner2 = buildExpression2(group.body, options.withColor(group.color));
    var node = new MathNode("mstyle", inner2);
    node.setAttribute("mathcolor", group.color);
    return node;
  };
  defineFunction({
    type: "color",
    names: ["\\textcolor"],
    numArgs: 2,
    allowedInText: true,
    argTypes: ["color", "original"],
    handler(_ref, args) {
      var parser = _ref.parser;
      var color = assertNodeType(args[0], "color-token").color;
      var body = args[1];
      return {
        type: "color",
        mode: parser.mode,
        color,
        body: ordargument(body)
      };
    },
    htmlBuilder: htmlBuilder$8,
    mathmlBuilder: mathmlBuilder$7
  });
  defineFunction({
    type: "color",
    names: ["\\color"],
    numArgs: 1,
    allowedInText: true,
    argTypes: ["color"],
    handler(_ref2, args) {
      var parser = _ref2.parser, breakOnTokenText = _ref2.breakOnTokenText;
      var color = assertNodeType(args[0], "color-token").color;
      parser.gullet.macros.set("\\current@color", color);
      var body = parser.parseExpression(true, breakOnTokenText);
      return {
        type: "color",
        mode: parser.mode,
        color,
        body
      };
    }
  });
  defineFunction({
    type: "cr",
    names: ["\\\\"],
    numArgs: 0,
    numOptionalArgs: 0,
    allowedInText: true,
    handler(_ref) {
      var parser = _ref.parser;
      var size = parser.gullet.future().text === "[" ? parser.parseSizeGroup(true) : null;
      var newLine = !parser.settings.displayMode || !handleStrict({
        strict: parser.settings.strict,
        errorCode: "newLineInDisplayMode",
        errorMsg: "In LaTeX, \\\\ or \\newline does nothing in display mode",
        report: false
      });
      return {
        type: "cr",
        mode: parser.mode,
        newLine,
        size: size && assertNodeType(size, "size").value
      };
    },
    // The following builders are called only at the top level,
    // not within tabular/array environments.
    htmlBuilder(group, options) {
      var span = makeSpan(["mspace"], [], options);
      if (group.newLine) {
        span.classes.push("katex-newline");
        if (group.size) {
          span.style.marginTop = makeEm(calculateSize(group.size, options));
        }
      }
      return span;
    },
    mathmlBuilder(group, options) {
      var node = new MathNode("mspace");
      if (group.newLine) {
        node.setAttribute("linebreak", "newline");
        if (group.size) {
          node.setAttribute("height", makeEm(calculateSize(group.size, options)));
        }
      }
      return node;
    }
  });
  var globalMap = {
    "\\global": "\\global",
    "\\long": "\\\\globallong",
    "\\\\globallong": "\\\\globallong",
    "\\def": "\\gdef",
    "\\gdef": "\\gdef",
    "\\edef": "\\xdef",
    "\\xdef": "\\xdef",
    "\\let": "\\\\globallet",
    "\\futurelet": "\\\\globalfuture"
  };
  var checkControlSequence = (tok) => {
    var name = tok.text;
    if (/^(?:[\\{}$&#^_]|EOF)$/.test(name)) {
      throw new ParseError("Expected a control sequence", tok);
    }
    return name;
  };
  var getRHS = (parser) => {
    var tok = parser.gullet.popToken();
    if (tok.text === "=") {
      tok = parser.gullet.popToken();
      if (tok.text === " ") {
        tok = parser.gullet.popToken();
      }
    }
    return tok;
  };
  var letCommand = (parser, name, tok, global) => {
    var macro = parser.gullet.macros.get(tok.text);
    if (macro == null) {
      tok.noexpand = true;
      macro = {
        tokens: [tok],
        numArgs: 0,
        // reproduce the same behavior in expansion
        unexpandable: !parser.gullet.isExpandable(tok.text)
      };
    }
    parser.gullet.macros.set(name, macro, global);
  };
  defineFunction({
    type: "internal",
    names: [
      "\\global",
      "\\long",
      "\\\\globallong"
      // can’t be entered directly
    ],
    numArgs: 0,
    allowedInText: true,
    handler(_ref) {
      var parser = _ref.parser, funcName = _ref.funcName;
      parser.consumeSpaces();
      var token = parser.fetch();
      if (globalMap[token.text]) {
        if (funcName === "\\global" || funcName === "\\\\globallong") {
          token.text = globalMap[token.text];
        }
        return assertNodeType(parser.parseFunction(), "internal");
      }
      throw new ParseError("Invalid token after macro prefix", token);
    }
  });
  defineFunction({
    type: "internal",
    names: ["\\def", "\\gdef", "\\edef", "\\xdef"],
    numArgs: 0,
    allowedInText: true,
    primitive: true,
    handler(_ref2) {
      var parser = _ref2.parser, funcName = _ref2.funcName;
      var tok = parser.gullet.popToken();
      var name = tok.text;
      if (/^(?:[\\{}$&#^_]|EOF)$/.test(name)) {
        throw new ParseError("Expected a control sequence", tok);
      }
      var numArgs = 0;
      var insert;
      var delimiters2 = [[]];
      while (parser.gullet.future().text !== "{") {
        tok = parser.gullet.popToken();
        if (tok.text === "#") {
          if (parser.gullet.future().text === "{") {
            insert = parser.gullet.future();
            delimiters2[numArgs].push("{");
            break;
          }
          tok = parser.gullet.popToken();
          if (!/^[1-9]$/.test(tok.text)) {
            throw new ParseError('Invalid argument number "' + tok.text + '"');
          }
          if (parseInt(tok.text) !== numArgs + 1) {
            throw new ParseError('Argument number "' + tok.text + '" out of order');
          }
          numArgs++;
          delimiters2.push([]);
        } else if (tok.text === "EOF") {
          throw new ParseError("Expected a macro definition");
        } else {
          delimiters2[numArgs].push(tok.text);
        }
      }
      var _parser$gullet$consum = parser.gullet.consumeArg(), tokens = _parser$gullet$consum.tokens;
      if (insert) {
        tokens.unshift(insert);
      }
      if (funcName === "\\edef" || funcName === "\\xdef") {
        tokens = parser.gullet.expandTokens(tokens);
        tokens.reverse();
      }
      parser.gullet.macros.set(name, {
        tokens,
        numArgs,
        delimiters: delimiters2
      }, funcName === globalMap[funcName]);
      return {
        type: "internal",
        mode: parser.mode
      };
    }
  });
  defineFunction({
    type: "internal",
    names: [
      "\\let",
      "\\\\globallet"
      // can’t be entered directly
    ],
    numArgs: 0,
    allowedInText: true,
    primitive: true,
    handler(_ref3) {
      var parser = _ref3.parser, funcName = _ref3.funcName;
      var name = checkControlSequence(parser.gullet.popToken());
      parser.gullet.consumeSpaces();
      var tok = getRHS(parser);
      letCommand(parser, name, tok, funcName === "\\\\globallet");
      return {
        type: "internal",
        mode: parser.mode
      };
    }
  });
  defineFunction({
    type: "internal",
    names: [
      "\\futurelet",
      "\\\\globalfuture"
      // can’t be entered directly
    ],
    numArgs: 0,
    allowedInText: true,
    primitive: true,
    handler(_ref4) {
      var parser = _ref4.parser, funcName = _ref4.funcName;
      var name = checkControlSequence(parser.gullet.popToken());
      var middle = parser.gullet.popToken();
      var tok = parser.gullet.popToken();
      letCommand(parser, name, tok, funcName === "\\\\globalfuture");
      parser.gullet.pushToken(tok);
      parser.gullet.pushToken(middle);
      return {
        type: "internal",
        mode: parser.mode
      };
    }
  });
  var getMetrics = function getMetrics2(symbol, font, mode) {
    var replace = symbols.math[symbol] && symbols.math[symbol].replace;
    var metrics = getCharacterMetrics(replace || symbol, font, mode);
    if (!metrics) {
      throw new Error("Unsupported symbol " + symbol + " and font size " + font + ".");
    }
    return metrics;
  };
  var styleWrap = function styleWrap2(delim, toStyle, options, classes) {
    var newOptions = options.havingBaseStyle(toStyle);
    var span = makeSpan(classes.concat(newOptions.sizingClasses(options)), [delim], options);
    var delimSizeMultiplier = newOptions.sizeMultiplier / options.sizeMultiplier;
    span.height *= delimSizeMultiplier;
    span.depth *= delimSizeMultiplier;
    span.maxFontSize = newOptions.sizeMultiplier;
    return span;
  };
  var centerSpan = function centerSpan2(span, options, style) {
    var newOptions = options.havingBaseStyle(style);
    var shift = (1 - options.sizeMultiplier / newOptions.sizeMultiplier) * options.fontMetrics().axisHeight;
    span.classes.push("delimcenter");
    span.style.top = makeEm(shift);
    span.height -= shift;
    span.depth += shift;
  };
  var makeSmallDelim = function makeSmallDelim2(delim, style, center, options, mode, classes) {
    var text2 = makeSymbol(delim, "Main-Regular", mode, options);
    var span = styleWrap(text2, style, options, classes);
    if (center) {
      centerSpan(span, options, style);
    }
    return span;
  };
  var mathrmSize = function mathrmSize2(value, size, mode, options) {
    return makeSymbol(value, "Size" + size + "-Regular", mode, options);
  };
  var makeLargeDelim = function makeLargeDelim2(delim, size, center, options, mode, classes) {
    var inner2 = mathrmSize(delim, size, mode, options);
    var span = styleWrap(makeSpan(["delimsizing", "size" + size], [inner2], options), Style$1.TEXT, options, classes);
    if (center) {
      centerSpan(span, options, Style$1.TEXT);
    }
    return span;
  };
  var makeGlyphSpan = function makeGlyphSpan2(symbol, font, mode, options) {
    var sizeClass;
    if (font === "Size1-Regular") {
      sizeClass = "delim-size1";
    } else {
      sizeClass = "delim-size4";
    }
    var corner = makeSpan(["delimsizinginner", sizeClass], [makeSpan([], [makeSymbol(symbol, font, mode, options)])]);
    return {
      type: "elem",
      elem: corner
    };
  };
  var makeInner = function makeInner2(ch, height, options) {
    var width = fontMetricsData["Size4-Regular"][ch.charCodeAt(0)] ? fontMetricsData["Size4-Regular"][ch.charCodeAt(0)][4] : fontMetricsData["Size1-Regular"][ch.charCodeAt(0)][4];
    var path2 = new PathNode("inner", innerPath(ch, Math.round(1e3 * height)));
    var svgNode = new SvgNode([path2], {
      "width": makeEm(width),
      "height": makeEm(height),
      // Override CSS rule `.katex svg { width: 100% }`
      "style": "width:" + makeEm(width),
      "viewBox": "0 0 " + 1e3 * width + " " + Math.round(1e3 * height),
      "preserveAspectRatio": "xMinYMin"
    });
    var span = makeSvgSpan([], [svgNode], options);
    span.height = height;
    span.style.height = makeEm(height);
    span.style.width = makeEm(width);
    return {
      type: "elem",
      elem: span
    };
  };
  var lapInEms = 8e-3;
  var lap = {
    type: "kern",
    size: -1 * lapInEms
  };
  var verts = /* @__PURE__ */ new Set(["|", "\\lvert", "\\rvert", "\\vert"]);
  var doubleVerts = /* @__PURE__ */ new Set(["\\|", "\\lVert", "\\rVert", "\\Vert"]);
  var makeStackedDelim = function makeStackedDelim2(delim, heightTotal, center, options, mode, classes) {
    var top;
    var middle;
    var repeat;
    var bottom;
    var svgLabel = "";
    var viewBoxWidth = 0;
    top = repeat = bottom = delim;
    middle = null;
    var font = "Size1-Regular";
    if (delim === "\\uparrow") {
      repeat = bottom = "\u23D0";
    } else if (delim === "\\Uparrow") {
      repeat = bottom = "\u2016";
    } else if (delim === "\\downarrow") {
      top = repeat = "\u23D0";
    } else if (delim === "\\Downarrow") {
      top = repeat = "\u2016";
    } else if (delim === "\\updownarrow") {
      top = "\\uparrow";
      repeat = "\u23D0";
      bottom = "\\downarrow";
    } else if (delim === "\\Updownarrow") {
      top = "\\Uparrow";
      repeat = "\u2016";
      bottom = "\\Downarrow";
    } else if (verts.has(delim)) {
      repeat = "\u2223";
      svgLabel = "vert";
      viewBoxWidth = 333;
    } else if (doubleVerts.has(delim)) {
      repeat = "\u2225";
      svgLabel = "doublevert";
      viewBoxWidth = 556;
    } else if (delim === "[" || delim === "\\lbrack") {
      top = "\u23A1";
      repeat = "\u23A2";
      bottom = "\u23A3";
      font = "Size4-Regular";
      svgLabel = "lbrack";
      viewBoxWidth = 667;
    } else if (delim === "]" || delim === "\\rbrack") {
      top = "\u23A4";
      repeat = "\u23A5";
      bottom = "\u23A6";
      font = "Size4-Regular";
      svgLabel = "rbrack";
      viewBoxWidth = 667;
    } else if (delim === "\\lfloor" || delim === "\u230A") {
      repeat = top = "\u23A2";
      bottom = "\u23A3";
      font = "Size4-Regular";
      svgLabel = "lfloor";
      viewBoxWidth = 667;
    } else if (delim === "\\lceil" || delim === "\u2308") {
      top = "\u23A1";
      repeat = bottom = "\u23A2";
      font = "Size4-Regular";
      svgLabel = "lceil";
      viewBoxWidth = 667;
    } else if (delim === "\\rfloor" || delim === "\u230B") {
      repeat = top = "\u23A5";
      bottom = "\u23A6";
      font = "Size4-Regular";
      svgLabel = "rfloor";
      viewBoxWidth = 667;
    } else if (delim === "\\rceil" || delim === "\u2309") {
      top = "\u23A4";
      repeat = bottom = "\u23A5";
      font = "Size4-Regular";
      svgLabel = "rceil";
      viewBoxWidth = 667;
    } else if (delim === "(" || delim === "\\lparen") {
      top = "\u239B";
      repeat = "\u239C";
      bottom = "\u239D";
      font = "Size4-Regular";
      svgLabel = "lparen";
      viewBoxWidth = 875;
    } else if (delim === ")" || delim === "\\rparen") {
      top = "\u239E";
      repeat = "\u239F";
      bottom = "\u23A0";
      font = "Size4-Regular";
      svgLabel = "rparen";
      viewBoxWidth = 875;
    } else if (delim === "\\{" || delim === "\\lbrace") {
      top = "\u23A7";
      middle = "\u23A8";
      bottom = "\u23A9";
      repeat = "\u23AA";
      font = "Size4-Regular";
    } else if (delim === "\\}" || delim === "\\rbrace") {
      top = "\u23AB";
      middle = "\u23AC";
      bottom = "\u23AD";
      repeat = "\u23AA";
      font = "Size4-Regular";
    } else if (delim === "\\lgroup" || delim === "\u27EE") {
      top = "\u23A7";
      bottom = "\u23A9";
      repeat = "\u23AA";
      font = "Size4-Regular";
    } else if (delim === "\\rgroup" || delim === "\u27EF") {
      top = "\u23AB";
      bottom = "\u23AD";
      repeat = "\u23AA";
      font = "Size4-Regular";
    } else if (delim === "\\lmoustache" || delim === "\u23B0") {
      top = "\u23A7";
      bottom = "\u23AD";
      repeat = "\u23AA";
      font = "Size4-Regular";
    } else if (delim === "\\rmoustache" || delim === "\u23B1") {
      top = "\u23AB";
      bottom = "\u23A9";
      repeat = "\u23AA";
      font = "Size4-Regular";
    }
    var topMetrics = getMetrics(top, font, mode);
    var topHeightTotal = topMetrics.height + topMetrics.depth;
    var repeatMetrics = getMetrics(repeat, font, mode);
    var repeatHeightTotal = repeatMetrics.height + repeatMetrics.depth;
    var bottomMetrics = getMetrics(bottom, font, mode);
    var bottomHeightTotal = bottomMetrics.height + bottomMetrics.depth;
    var middleHeightTotal = 0;
    var middleFactor = 1;
    if (middle !== null) {
      var middleMetrics = getMetrics(middle, font, mode);
      middleHeightTotal = middleMetrics.height + middleMetrics.depth;
      middleFactor = 2;
    }
    var minHeight = topHeightTotal + bottomHeightTotal + middleHeightTotal;
    var repeatCount = Math.max(0, Math.ceil((heightTotal - minHeight) / (middleFactor * repeatHeightTotal)));
    var realHeightTotal = minHeight + repeatCount * middleFactor * repeatHeightTotal;
    var axisHeight = options.fontMetrics().axisHeight;
    if (center) {
      axisHeight *= options.sizeMultiplier;
    }
    var depth = realHeightTotal / 2 - axisHeight;
    var stack = [];
    if (svgLabel.length > 0) {
      var midHeight = realHeightTotal - topHeightTotal - bottomHeightTotal;
      var viewBoxHeight = Math.round(realHeightTotal * 1e3);
      var pathStr = tallDelim(svgLabel, Math.round(midHeight * 1e3));
      var path2 = new PathNode(svgLabel, pathStr);
      var width = makeEm(viewBoxWidth / 1e3);
      var height = makeEm(viewBoxHeight / 1e3);
      var svg = new SvgNode([path2], {
        "width": width,
        "height": height,
        "viewBox": "0 0 " + viewBoxWidth + " " + viewBoxHeight
      });
      var wrapper = makeSvgSpan([], [svg], options);
      wrapper.height = viewBoxHeight / 1e3;
      wrapper.style.width = width;
      wrapper.style.height = height;
      stack.push({
        type: "elem",
        elem: wrapper
      });
    } else {
      stack.push(makeGlyphSpan(bottom, font, mode, options));
      stack.push(lap);
      if (middle === null) {
        var innerHeight = realHeightTotal - topHeightTotal - bottomHeightTotal + 2 * lapInEms;
        stack.push(makeInner(repeat, innerHeight, options));
      } else {
        var _innerHeight = (realHeightTotal - topHeightTotal - bottomHeightTotal - middleHeightTotal) / 2 + 2 * lapInEms;
        stack.push(makeInner(repeat, _innerHeight, options));
        stack.push(lap);
        stack.push(makeGlyphSpan(middle, font, mode, options));
        stack.push(lap);
        stack.push(makeInner(repeat, _innerHeight, options));
      }
      stack.push(lap);
      stack.push(makeGlyphSpan(top, font, mode, options));
    }
    var newOptions = options.havingBaseStyle(Style$1.TEXT);
    var inner2 = makeVList({
      positionType: "bottom",
      positionData: depth,
      children: stack
    });
    return styleWrap(makeSpan(["delimsizing", "mult"], [inner2], newOptions), Style$1.TEXT, options, classes);
  };
  var vbPad = 80;
  var emPad = 0.08;
  var sqrtSvg = function sqrtSvg2(sqrtName, height, viewBoxHeight, extraVinculum, options) {
    var path2 = sqrtPath(sqrtName, extraVinculum, viewBoxHeight);
    var pathNode = new PathNode(sqrtName, path2);
    var svg = new SvgNode([pathNode], {
      // Note: 1000:1 ratio of viewBox to document em width.
      "width": "400em",
      "height": makeEm(height),
      "viewBox": "0 0 400000 " + viewBoxHeight,
      "preserveAspectRatio": "xMinYMin slice"
    });
    return makeSvgSpan(["hide-tail"], [svg], options);
  };
  var makeSqrtImage = function makeSqrtImage2(height, options) {
    var newOptions = options.havingBaseSizing();
    var delim = traverseSequence("\\surd", height * newOptions.sizeMultiplier, stackLargeDelimiterSequence, newOptions);
    var sizeMultiplier = newOptions.sizeMultiplier;
    var extraVinculum = Math.max(0, options.minRuleThickness - options.fontMetrics().sqrtRuleThickness);
    var span;
    var spanHeight;
    var texHeight;
    var viewBoxHeight;
    var advanceWidth;
    if (delim.type === "small") {
      viewBoxHeight = 1e3 + 1e3 * extraVinculum + vbPad;
      if (height < 1) {
        sizeMultiplier = 1;
      } else if (height < 1.4) {
        sizeMultiplier = 0.7;
      }
      spanHeight = (1 + extraVinculum + emPad) / sizeMultiplier;
      texHeight = (1 + extraVinculum) / sizeMultiplier;
      span = sqrtSvg("sqrtMain", spanHeight, viewBoxHeight, extraVinculum, options);
      span.style.minWidth = "0.853em";
      advanceWidth = 0.833 / sizeMultiplier;
    } else if (delim.type === "large") {
      viewBoxHeight = (1e3 + vbPad) * sizeToMaxHeight[delim.size];
      texHeight = (sizeToMaxHeight[delim.size] + extraVinculum) / sizeMultiplier;
      spanHeight = (sizeToMaxHeight[delim.size] + extraVinculum + emPad) / sizeMultiplier;
      span = sqrtSvg("sqrtSize" + delim.size, spanHeight, viewBoxHeight, extraVinculum, options);
      span.style.minWidth = "1.02em";
      advanceWidth = 1 / sizeMultiplier;
    } else {
      spanHeight = height + extraVinculum + emPad;
      texHeight = height + extraVinculum;
      viewBoxHeight = Math.floor(1e3 * height + extraVinculum) + vbPad;
      span = sqrtSvg("sqrtTall", spanHeight, viewBoxHeight, extraVinculum, options);
      span.style.minWidth = "0.742em";
      advanceWidth = 1.056;
    }
    span.height = texHeight;
    span.style.height = makeEm(spanHeight);
    return {
      span,
      advanceWidth,
      // Calculate the actual line width.
      // This actually should depend on the chosen font -- e.g. \boldmath
      // should use the thicker surd symbols from e.g. KaTeX_Main-Bold, and
      // have thicker rules.
      ruleWidth: (options.fontMetrics().sqrtRuleThickness + extraVinculum) * sizeMultiplier
    };
  };
  var stackLargeDelimiters = /* @__PURE__ */ new Set(["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "\u230A", "\u230B", "\\lceil", "\\rceil", "\u2308", "\u2309", "\\surd"]);
  var stackAlwaysDelimiters = /* @__PURE__ */ new Set(["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "\u27EE", "\u27EF", "\\lmoustache", "\\rmoustache", "\u23B0", "\u23B1"]);
  var stackNeverDelimiters = /* @__PURE__ */ new Set(["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"]);
  var sizeToMaxHeight = [0, 1.2, 1.8, 2.4, 3];
  var makeSizedDelim = function makeSizedDelim2(delim, size, options, mode, classes) {
    if (delim === "<" || delim === "\\lt" || delim === "\u27E8") {
      delim = "\\langle";
    } else if (delim === ">" || delim === "\\gt" || delim === "\u27E9") {
      delim = "\\rangle";
    }
    if (stackLargeDelimiters.has(delim) || stackNeverDelimiters.has(delim)) {
      return makeLargeDelim(delim, size, false, options, mode, classes);
    } else if (stackAlwaysDelimiters.has(delim)) {
      return makeStackedDelim(delim, sizeToMaxHeight[size], false, options, mode, classes);
    } else {
      throw new ParseError("Illegal delimiter: '" + delim + "'");
    }
  };
  var stackNeverDelimiterSequence = [{
    type: "small",
    style: Style$1.SCRIPTSCRIPT
  }, {
    type: "small",
    style: Style$1.SCRIPT
  }, {
    type: "small",
    style: Style$1.TEXT
  }, {
    type: "large",
    size: 1
  }, {
    type: "large",
    size: 2
  }, {
    type: "large",
    size: 3
  }, {
    type: "large",
    size: 4
  }];
  var stackAlwaysDelimiterSequence = [{
    type: "small",
    style: Style$1.SCRIPTSCRIPT
  }, {
    type: "small",
    style: Style$1.SCRIPT
  }, {
    type: "small",
    style: Style$1.TEXT
  }, {
    type: "stack"
  }];
  var stackLargeDelimiterSequence = [{
    type: "small",
    style: Style$1.SCRIPTSCRIPT
  }, {
    type: "small",
    style: Style$1.SCRIPT
  }, {
    type: "small",
    style: Style$1.TEXT
  }, {
    type: "large",
    size: 1
  }, {
    type: "large",
    size: 2
  }, {
    type: "large",
    size: 3
  }, {
    type: "large",
    size: 4
  }, {
    type: "stack"
  }];
  var delimTypeToFont = function delimTypeToFont2(type) {
    if (type.type === "small") {
      return "Main-Regular";
    } else if (type.type === "large") {
      return "Size" + type.size + "-Regular";
    } else if (type.type === "stack") {
      return "Size4-Regular";
    } else {
      var delimKind = type.type;
      throw new Error("Add support for delim type '" + delimKind + "' here.");
    }
  };
  var traverseSequence = function traverseSequence2(delim, height, sequence, options) {
    var start = Math.min(2, 3 - options.style.size);
    for (var i3 = start; i3 < sequence.length; i3++) {
      var delimType = sequence[i3];
      if (delimType.type === "stack") {
        break;
      }
      var metrics = getMetrics(delim, delimTypeToFont(delimType), "math");
      var heightDepth = metrics.height + metrics.depth;
      if (delimType.type === "small") {
        var newOptions = options.havingBaseStyle(delimType.style);
        heightDepth *= newOptions.sizeMultiplier;
      }
      if (heightDepth > height) {
        return delimType;
      }
    }
    return sequence[sequence.length - 1];
  };
  var makeCustomSizedDelim = function makeCustomSizedDelim2(delim, height, center, options, mode, classes) {
    if (delim === "<" || delim === "\\lt" || delim === "\u27E8") {
      delim = "\\langle";
    } else if (delim === ">" || delim === "\\gt" || delim === "\u27E9") {
      delim = "\\rangle";
    }
    var sequence;
    if (stackNeverDelimiters.has(delim)) {
      sequence = stackNeverDelimiterSequence;
    } else if (stackLargeDelimiters.has(delim)) {
      sequence = stackLargeDelimiterSequence;
    } else {
      sequence = stackAlwaysDelimiterSequence;
    }
    var delimType = traverseSequence(delim, height, sequence, options);
    if (delimType.type === "small") {
      return makeSmallDelim(delim, delimType.style, center, options, mode, classes);
    } else if (delimType.type === "large") {
      return makeLargeDelim(delim, delimType.size, center, options, mode, classes);
    } else {
      return makeStackedDelim(delim, height, center, options, mode, classes);
    }
  };
  var makeLeftRightDelim = function makeLeftRightDelim2(delim, height, depth, options, mode, classes) {
    var axisHeight = options.fontMetrics().axisHeight * options.sizeMultiplier;
    var delimiterFactor = 901;
    var delimiterExtend = 5 / options.fontMetrics().ptPerEm;
    var maxDistFromAxis = Math.max(height - axisHeight, depth + axisHeight);
    var totalHeight = Math.max(
      // In real TeX, calculations are done using integral values which are
      // 65536 per pt, or 655360 per em. So, the division here truncates in
      // TeX but doesn't here, producing different results. If we wanted to
      // exactly match TeX's calculation, we could do
      //   Math.floor(655360 * maxDistFromAxis / 500) *
      //    delimiterFactor / 655360
      // (To see the difference, compare
      //    x^{x^{\left(\rule{0.1em}{0.68em}\right)}}
      // in TeX and KaTeX)
      maxDistFromAxis / 500 * delimiterFactor,
      2 * maxDistFromAxis - delimiterExtend
    );
    return makeCustomSizedDelim(delim, totalHeight, true, options, mode, classes);
  };
  var delimiterSizes = {
    "\\bigl": {
      mclass: "mopen",
      size: 1
    },
    "\\Bigl": {
      mclass: "mopen",
      size: 2
    },
    "\\biggl": {
      mclass: "mopen",
      size: 3
    },
    "\\Biggl": {
      mclass: "mopen",
      size: 4
    },
    "\\bigr": {
      mclass: "mclose",
      size: 1
    },
    "\\Bigr": {
      mclass: "mclose",
      size: 2
    },
    "\\biggr": {
      mclass: "mclose",
      size: 3
    },
    "\\Biggr": {
      mclass: "mclose",
      size: 4
    },
    "\\bigm": {
      mclass: "mrel",
      size: 1
    },
    "\\Bigm": {
      mclass: "mrel",
      size: 2
    },
    "\\biggm": {
      mclass: "mrel",
      size: 3
    },
    "\\Biggm": {
      mclass: "mrel",
      size: 4
    },
    "\\big": {
      mclass: "mord",
      size: 1
    },
    "\\Big": {
      mclass: "mord",
      size: 2
    },
    "\\bigg": {
      mclass: "mord",
      size: 3
    },
    "\\Bigg": {
      mclass: "mord",
      size: 4
    }
  };
  var delimiters = /* @__PURE__ */ new Set(["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "\u230A", "\u230B", "\\lceil", "\\rceil", "\u2308", "\u2309", "<", ">", "\\langle", "\u27E8", "\\rangle", "\u27E9", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "\u27EE", "\u27EF", "\\lmoustache", "\\rmoustache", "\u23B0", "\u23B1", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."]);
  function isMiddleDelimNode(node) {
    return "isMiddle" in node;
  }
  function checkDelimiter(delim, context) {
    var symDelim = checkSymbolNodeType(delim);
    if (symDelim && delimiters.has(symDelim.text)) {
      return symDelim;
    } else if (symDelim) {
      throw new ParseError("Invalid delimiter '" + symDelim.text + "' after '" + context.funcName + "'", delim);
    } else {
      throw new ParseError("Invalid delimiter type '" + delim.type + "'", delim);
    }
  }
  defineFunction({
    type: "delimsizing",
    names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
    numArgs: 1,
    argTypes: ["primitive"],
    handler: (context, args) => {
      var delim = checkDelimiter(normalizeArgument(args[0]), context);
      return {
        type: "delimsizing",
        mode: context.parser.mode,
        size: delimiterSizes[context.funcName].size,
        mclass: delimiterSizes[context.funcName].mclass,
        delim: delim.text
      };
    },
    htmlBuilder: (group, options) => {
      if (group.delim === ".") {
        return makeSpan([group.mclass]);
      }
      return makeSizedDelim(group.delim, group.size, options, group.mode, [group.mclass]);
    },
    mathmlBuilder: (group) => {
      var children = [];
      if (group.delim !== ".") {
        children.push(makeText(group.delim, group.mode));
      }
      var node = new MathNode("mo", children);
      if (group.mclass === "mopen" || group.mclass === "mclose") {
        node.setAttribute("fence", "true");
      } else {
        node.setAttribute("fence", "false");
      }
      node.setAttribute("stretchy", "true");
      var size = makeEm(sizeToMaxHeight[group.size]);
      node.setAttribute("minsize", size);
      node.setAttribute("maxsize", size);
      return node;
    }
  });
  function assertParsed(group) {
    if (!group.body) {
      throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
    }
  }
  defineFunction({
    type: "leftright-right",
    names: ["\\right"],
    numArgs: 1,
    primitive: true,
    handler: (context, args) => {
      var color = context.parser.gullet.macros.get("\\current@color");
      if (color && typeof color !== "string") {
        throw new ParseError("\\current@color set to non-string in \\right");
      }
      return {
        type: "leftright-right",
        mode: context.parser.mode,
        delim: checkDelimiter(args[0], context).text,
        color
        // undefined if not set via \color
      };
    }
  });
  defineFunction({
    type: "leftright",
    names: ["\\left"],
    numArgs: 1,
    primitive: true,
    handler: (context, args) => {
      var delim = checkDelimiter(args[0], context);
      var parser = context.parser;
      ++parser.leftrightDepth;
      var body = parser.parseExpression(false);
      --parser.leftrightDepth;
      parser.expect("\\right", false);
      var right = assertNodeType(parser.parseFunction(), "leftright-right");
      return {
        type: "leftright",
        mode: parser.mode,
        body,
        left: delim.text,
        right: right.delim,
        rightColor: right.color
      };
    },
    htmlBuilder: (group, options) => {
      assertParsed(group);
      var inner2 = buildExpression$1(group.body, options, true, ["mopen", "mclose"]);
      var innerHeight = 0;
      var innerDepth = 0;
      var hadMiddle = false;
      for (var i3 = 0; i3 < inner2.length; i3++) {
        var node = inner2[i3];
        if (isMiddleDelimNode(node)) {
          hadMiddle = true;
        } else {
          innerHeight = Math.max(inner2[i3].height, innerHeight);
          innerDepth = Math.max(inner2[i3].depth, innerDepth);
        }
      }
      innerHeight *= options.sizeMultiplier;
      innerDepth *= options.sizeMultiplier;
      var leftDelim;
      if (group.left === ".") {
        leftDelim = makeNullDelimiter(options, ["mopen"]);
      } else {
        leftDelim = makeLeftRightDelim(group.left, innerHeight, innerDepth, options, group.mode, ["mopen"]);
      }
      inner2.unshift(leftDelim);
      if (hadMiddle) {
        for (var _i = 1; _i < inner2.length; _i++) {
          var middleDelim = inner2[_i];
          if (isMiddleDelimNode(middleDelim)) {
            var isMiddle = middleDelim.isMiddle;
            inner2[_i] = makeLeftRightDelim(isMiddle.delim, innerHeight, innerDepth, isMiddle.options, group.mode, []);
          }
        }
      }
      var rightDelim;
      if (group.right === ".") {
        rightDelim = makeNullDelimiter(options, ["mclose"]);
      } else {
        var colorOptions = group.rightColor ? options.withColor(group.rightColor) : options;
        rightDelim = makeLeftRightDelim(group.right, innerHeight, innerDepth, colorOptions, group.mode, ["mclose"]);
      }
      inner2.push(rightDelim);
      return makeSpan(["minner"], inner2, options);
    },
    mathmlBuilder: (group, options) => {
      assertParsed(group);
      var inner2 = buildExpression2(group.body, options);
      if (group.left !== ".") {
        var leftNode = new MathNode("mo", [makeText(group.left, group.mode)]);
        leftNode.setAttribute("fence", "true");
        inner2.unshift(leftNode);
      }
      if (group.right !== ".") {
        var rightNode = new MathNode("mo", [makeText(group.right, group.mode)]);
        rightNode.setAttribute("fence", "true");
        if (group.rightColor) {
          rightNode.setAttribute("mathcolor", group.rightColor);
        }
        inner2.push(rightNode);
      }
      return makeRow(inner2);
    }
  });
  defineFunction({
    type: "middle",
    names: ["\\middle"],
    numArgs: 1,
    primitive: true,
    handler: (context, args) => {
      var delim = checkDelimiter(args[0], context);
      if (!context.parser.leftrightDepth) {
        throw new ParseError("\\middle without preceding \\left", delim);
      }
      return {
        type: "middle",
        mode: context.parser.mode,
        delim: delim.text
      };
    },
    htmlBuilder: (group, options) => {
      var middleDelim;
      if (group.delim === ".") {
        middleDelim = makeNullDelimiter(options, []);
      } else {
        middleDelim = makeSizedDelim(group.delim, 1, options, group.mode, []);
        middleDelim.isMiddle = {
          delim: group.delim,
          options
        };
      }
      return middleDelim;
    },
    mathmlBuilder: (group, options) => {
      var textNode = group.delim === "\\vert" || group.delim === "|" ? makeText("|", "text") : makeText(group.delim, group.mode);
      var middleNode = new MathNode("mo", [textNode]);
      middleNode.setAttribute("fence", "true");
      middleNode.setAttribute("lspace", "0.05em");
      middleNode.setAttribute("rspace", "0.05em");
      return middleNode;
    }
  });
  var htmlBuilder$7 = (group, options) => {
    var inner2 = wrapFragment(buildGroup$1(group.body, options), options);
    var label = group.label.slice(1);
    var scale = options.sizeMultiplier;
    var img;
    var imgShift;
    var isSingleChar = isCharacterBox(group.body);
    if (label === "sout") {
      img = makeSpan(["katex-stretchy", "katex-sout"]);
      img.height = options.fontMetrics().defaultRuleThickness / scale;
      imgShift = -0.5 * options.fontMetrics().xHeight;
    } else if (label === "phase") {
      var lineWeight = calculateSize({
        number: 0.6,
        unit: "pt"
      }, options);
      var clearance = calculateSize({
        number: 0.35,
        unit: "ex"
      }, options);
      var newOptions = options.havingBaseSizing();
      scale = scale / newOptions.sizeMultiplier;
      var angleHeight = inner2.height + inner2.depth + lineWeight + clearance;
      inner2.style.paddingLeft = makeEm(angleHeight / 2 + lineWeight);
      var viewBoxHeight = Math.floor(1e3 * angleHeight * scale);
      var path2 = phasePath(viewBoxHeight);
      var svgNode = new SvgNode([new PathNode("phase", path2)], {
        "width": "400em",
        "height": makeEm(viewBoxHeight / 1e3),
        "viewBox": "0 0 400000 " + viewBoxHeight,
        "preserveAspectRatio": "xMinYMin slice"
      });
      img = makeSvgSpan(["hide-tail"], [svgNode], options);
      img.style.height = makeEm(angleHeight);
      imgShift = inner2.depth + lineWeight + clearance;
    } else {
      if (/cancel/.test(label)) {
        if (!isSingleChar) {
          inner2.classes.push("cancel-pad");
        }
      } else if (label === "angl") {
        inner2.classes.push("anglpad");
      } else {
        inner2.classes.push("boxpad");
      }
      var topPad;
      var bottomPad;
      var ruleThickness = 0;
      if (/box/.test(label)) {
        ruleThickness = Math.max(
          options.fontMetrics().fboxrule,
          // default
          options.minRuleThickness
        );
        topPad = options.fontMetrics().fboxsep + (label === "colorbox" ? 0 : ruleThickness);
        bottomPad = topPad;
      } else if (label === "angl") {
        ruleThickness = Math.max(options.fontMetrics().defaultRuleThickness, options.minRuleThickness);
        topPad = 4 * ruleThickness;
        bottomPad = Math.max(0, 0.25 - inner2.depth);
      } else {
        topPad = isSingleChar ? 0.2 : 0;
        bottomPad = topPad;
      }
      img = stretchyEnclose(inner2, label, topPad, bottomPad, options);
      if (/fbox|boxed|fcolorbox/.test(label)) {
        img.style.borderStyle = "solid";
        img.style.borderWidth = makeEm(ruleThickness);
      } else if (label === "angl" && ruleThickness !== 0.049) {
        img.style.borderTopWidth = makeEm(ruleThickness);
        img.style.borderRightWidth = makeEm(ruleThickness);
      }
      imgShift = inner2.depth + bottomPad;
      if (group.backgroundColor) {
        img.style.backgroundColor = group.backgroundColor;
        if (group.borderColor) {
          img.style.borderColor = group.borderColor;
        }
      }
    }
    var vlist;
    if (group.backgroundColor) {
      vlist = makeVList({
        positionType: "individualShift",
        children: [
          // Put the color background behind inner;
          {
            type: "elem",
            elem: img,
            shift: imgShift
          },
          {
            type: "elem",
            elem: inner2,
            shift: 0
          }
        ]
      });
    } else {
      var classes = /cancel|phase/.test(label) ? ["svg-align"] : [];
      vlist = makeVList({
        positionType: "individualShift",
        children: [
          // Write the \cancel stroke on top of inner.
          {
            type: "elem",
            elem: inner2,
            shift: 0
          },
          {
            type: "elem",
            elem: img,
            shift: imgShift,
            wrapperClasses: classes
          }
        ]
      });
    }
    if (/cancel/.test(label)) {
      vlist.height = inner2.height;
      vlist.depth = inner2.depth;
    }
    if (/cancel/.test(label) && !isSingleChar) {
      return makeSpan(["mord", "cancel-lap"], [vlist], options);
    } else {
      return makeSpan(["mord"], [vlist], options);
    }
  };
  var mathmlBuilder$6 = (group, options) => {
    var fboxsep;
    var node = new MathNode(group.label.includes("colorbox") ? "mpadded" : "menclose", [buildGroup2(group.body, options)]);
    switch (group.label) {
      case "\\cancel":
        node.setAttribute("notation", "updiagonalstrike");
        break;
      case "\\bcancel":
        node.setAttribute("notation", "downdiagonalstrike");
        break;
      case "\\phase":
        node.setAttribute("notation", "phasorangle");
        break;
      case "\\sout":
        node.setAttribute("notation", "horizontalstrike");
        break;
      case "\\fbox":
        node.setAttribute("notation", "box");
        break;
      case "\\angl":
        node.setAttribute("notation", "actuarial");
        break;
      case "\\fcolorbox":
      case "\\colorbox":
        fboxsep = options.fontMetrics().fboxsep * options.fontMetrics().ptPerEm;
        node.setAttribute("width", "+" + 2 * fboxsep + "pt");
        node.setAttribute("height", "+" + 2 * fboxsep + "pt");
        node.setAttribute("lspace", fboxsep + "pt");
        node.setAttribute("voffset", fboxsep + "pt");
        if (group.label === "\\fcolorbox") {
          var thk = Math.max(
            options.fontMetrics().fboxrule,
            // default
            options.minRuleThickness
          );
          node.setAttribute("style", "border: " + makeEm(thk) + " solid " + group.borderColor);
        }
        break;
      case "\\xcancel":
        node.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
        break;
    }
    if (group.backgroundColor) {
      node.setAttribute("mathbackground", group.backgroundColor);
    }
    return node;
  };
  defineFunction({
    type: "enclose",
    names: ["\\colorbox"],
    numArgs: 2,
    allowedInText: true,
    argTypes: ["color", "hbox"],
    handler(_ref, args, optArgs) {
      var parser = _ref.parser, funcName = _ref.funcName;
      var color = assertNodeType(args[0], "color-token").color;
      var body = args[1];
      return {
        type: "enclose",
        mode: parser.mode,
        label: funcName,
        backgroundColor: color,
        body
      };
    },
    htmlBuilder: htmlBuilder$7,
    mathmlBuilder: mathmlBuilder$6
  });
  defineFunction({
    type: "enclose",
    names: ["\\fcolorbox"],
    numArgs: 3,
    allowedInText: true,
    argTypes: ["color", "color", "hbox"],
    handler(_ref2, args, optArgs) {
      var parser = _ref2.parser, funcName = _ref2.funcName;
      var borderColor = assertNodeType(args[0], "color-token").color;
      var backgroundColor = assertNodeType(args[1], "color-token").color;
      var body = args[2];
      return {
        type: "enclose",
        mode: parser.mode,
        label: funcName,
        backgroundColor,
        borderColor,
        body
      };
    }
  });
  defineFunction({
    type: "enclose",
    names: ["\\fbox"],
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: true,
    handler(_ref3, args) {
      var parser = _ref3.parser;
      return {
        type: "enclose",
        mode: parser.mode,
        label: "\\fbox",
        body: args[0]
      };
    }
  });
  defineFunction({
    type: "enclose",
    names: ["\\cancel", "\\bcancel", "\\xcancel", "\\phase"],
    numArgs: 1,
    handler(_ref4, args) {
      var parser = _ref4.parser, funcName = _ref4.funcName;
      var body = args[0];
      return {
        type: "enclose",
        mode: parser.mode,
        label: funcName,
        body
      };
    }
  });
  defineFunction({
    type: "enclose",
    names: ["\\sout"],
    numArgs: 1,
    allowedInText: true,
    handler(_ref5, args) {
      var parser = _ref5.parser, funcName = _ref5.funcName;
      if (parser.mode === "math") {
        handleStrict({
          strict: parser.settings.strict,
          errorCode: "mathVsSout",
          errorMsg: "LaTeX's \\sout works only in text mode",
          report: true
        });
      }
      var body = args[0];
      return {
        type: "enclose",
        mode: parser.mode,
        label: funcName,
        body
      };
    }
  });
  defineFunction({
    type: "enclose",
    names: ["\\angl"],
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: false,
    handler(_ref6, args) {
      var parser = _ref6.parser;
      return {
        type: "enclose",
        mode: parser.mode,
        label: "\\angl",
        body: args[0]
      };
    }
  });
  var _environments = {};
  function defineEnvironment(_ref) {
    var type = _ref.type, names = _ref.names, props = _ref.props, handler2 = _ref.handler, htmlBuilder3 = _ref.htmlBuilder, mathmlBuilder3 = _ref.mathmlBuilder;
    var data = {
      type,
      numArgs: props.numArgs || 0,
      allowedInText: false,
      numOptionalArgs: 0,
      handler: handler2
    };
    for (var i3 = 0; i3 < names.length; ++i3) {
      _environments[names[i3]] = data;
    }
    if (htmlBuilder3) {
      _htmlGroupBuilders[type] = htmlBuilder3;
    }
    if (mathmlBuilder3) {
      _mathmlGroupBuilders[type] = mathmlBuilder3;
    }
  }
  var _macros = {};
  function defineMacro(name, body) {
    _macros[name] = body;
  }
  var SourceLocation = class _SourceLocation {
    // End offset, zero-based exclusive.
    constructor(lexer, start, end) {
      this.lexer = void 0;
      this.start = void 0;
      this.end = void 0;
      this.lexer = lexer;
      this.start = start;
      this.end = end;
    }
    /**
     * Merges two `SourceLocation`s from location providers, given they are
     * provided in order of appearance.
     * - Returns the first one's location if only the first is provided.
     * - Returns a merged range of the first and the last if both are provided
     *   and their lexers match.
     * - Otherwise, returns null.
     */
    static range(first, second) {
      if (!second) {
        return first && first.loc;
      } else if (!first || !first.loc || !second.loc || first.loc.lexer !== second.loc.lexer) {
        return null;
      } else {
        return new _SourceLocation(first.loc.lexer, first.loc.start, second.loc.end);
      }
    }
  };
  var Token = class _Token {
    // used in \noexpand
    constructor(text2, loc) {
      this.text = void 0;
      this.loc = void 0;
      this.noexpand = void 0;
      this.treatAsRelax = void 0;
      this.text = text2;
      this.loc = loc;
    }
    /**
     * Given a pair of tokens (this and endToken), compute a `Token` encompassing
     * the whole input range enclosed by these two.
     */
    range(endToken, text2) {
      return new _Token(text2, SourceLocation.range(this, endToken));
    }
  };
  function getHLines(parser) {
    var hlineInfo = [];
    parser.consumeSpaces();
    var nxt = parser.fetch().text;
    if (nxt === "\\relax") {
      parser.consume();
      parser.consumeSpaces();
      nxt = parser.fetch().text;
    }
    while (nxt === "\\hline" || nxt === "\\hdashline") {
      parser.consume();
      hlineInfo.push(nxt === "\\hdashline");
      parser.consumeSpaces();
      nxt = parser.fetch().text;
    }
    return hlineInfo;
  }
  var validateAmsEnvironmentContext = (context) => {
    var settings = context.parser.settings;
    if (!settings.displayMode) {
      throw new ParseError("{" + context.envName + "} can be used only in display mode.");
    }
  };
  var gatherEnvironments = /* @__PURE__ */ new Set(["gather", "gather*"]);
  function getAutoTag(name) {
    if (!name.includes("ed")) {
      return !name.includes("*");
    }
  }
  function parseArray(parser, _ref, style) {
    var hskipBeforeAndAfter = _ref.hskipBeforeAndAfter, addJot = _ref.addJot, cols = _ref.cols, arraystretch = _ref.arraystretch, colSeparationType = _ref.colSeparationType, autoTag = _ref.autoTag, singleRow = _ref.singleRow, emptySingleRow = _ref.emptySingleRow, maxNumCols = _ref.maxNumCols, leqno = _ref.leqno;
    parser.gullet.beginGroup();
    if (!singleRow) {
      parser.gullet.macros.set("\\cr", "\\\\\\relax");
    }
    if (!arraystretch) {
      var stretch = parser.gullet.expandMacroAsText("\\arraystretch");
      if (stretch == null) {
        arraystretch = 1;
      } else {
        arraystretch = parseFloat(stretch);
        if (!arraystretch || arraystretch < 0) {
          throw new ParseError("Invalid \\arraystretch: " + stretch);
        }
      }
    }
    parser.gullet.beginGroup();
    var row = [];
    var body = [row];
    var rowGaps = [];
    var hLinesBeforeRow = [];
    var tags = autoTag != null ? [] : void 0;
    function beginRow() {
      if (autoTag) {
        parser.gullet.macros.set("\\@eqnsw", "1", true);
      }
    }
    function endRow() {
      if (tags) {
        if (parser.gullet.macros.get("\\df@tag")) {
          tags.push(parser.subparse([new Token("\\df@tag")]));
          parser.gullet.macros.set("\\df@tag", void 0, true);
        } else {
          tags.push(Boolean(autoTag) && parser.gullet.macros.get("\\@eqnsw") === "1");
        }
      }
    }
    beginRow();
    hLinesBeforeRow.push(getHLines(parser));
    while (true) {
      var cellBody = parser.parseExpression(false, singleRow ? "\\end" : "\\\\");
      parser.gullet.endGroup();
      parser.gullet.beginGroup();
      var cell = {
        type: "ordgroup",
        mode: parser.mode,
        body: cellBody
      };
      if (style) {
        cell = {
          type: "styling",
          mode: parser.mode,
          style,
          resetFont: true,
          body: [cell]
        };
      }
      row.push(cell);
      var next = parser.fetch().text;
      if (next === "&") {
        if (maxNumCols && row.length === maxNumCols) {
          if (singleRow || colSeparationType) {
            throw new ParseError("Too many tab characters: &", parser.nextToken);
          } else {
            handleStrict({
              strict: parser.settings.strict,
              errorCode: "textEnv",
              errorMsg: "Too few columns specified in the {array} column argument.",
              report: true
            });
          }
        }
        parser.consume();
      } else if (next === "\\end") {
        endRow();
        if (row.length === 1 && cell.type === "styling" && cell.body.length === 1 && cell.body[0].type === "ordgroup" && cell.body[0].body.length === 0 && (body.length > 1 || !emptySingleRow) && !Array.isArray(tags == null ? void 0 : tags[tags.length - 1]) && !(autoTag && (tags == null ? void 0 : tags[tags.length - 1]) === true)) {
          body.pop();
        }
        if (hLinesBeforeRow.length < body.length + 1) {
          hLinesBeforeRow.push([]);
        }
        break;
      } else if (next === "\\\\") {
        parser.consume();
        var size = void 0;
        if (parser.gullet.future().text !== " ") {
          size = parser.parseSizeGroup(true);
        }
        rowGaps.push(size ? size.value : null);
        endRow();
        hLinesBeforeRow.push(getHLines(parser));
        row = [];
        body.push(row);
        beginRow();
      } else {
        throw new ParseError("Expected & or \\\\ or \\cr or \\end", parser.nextToken);
      }
    }
    parser.gullet.endGroup();
    parser.gullet.endGroup();
    return {
      type: "array",
      mode: parser.mode,
      addJot,
      arraystretch,
      body,
      cols,
      rowGaps,
      hskipBeforeAndAfter,
      hLinesBeforeRow,
      colSeparationType,
      tags,
      leqno
    };
  }
  function dCellStyle(envName) {
    if (envName.slice(0, 1) === "d") {
      return "display";
    } else {
      return "text";
    }
  }
  var htmlBuilder$6 = function htmlBuilder(group, options) {
    var r3;
    var c3;
    var nr = group.body.length;
    var hLinesBeforeRow = group.hLinesBeforeRow;
    var nc = 0;
    var body = new Array(nr);
    var hlines = [];
    var ruleThickness = Math.max(
      // From LaTeX \showthe\arrayrulewidth. Equals 0.04 em.
      options.fontMetrics().arrayRuleWidth,
      options.minRuleThickness
    );
    var pt = 1 / options.fontMetrics().ptPerEm;
    var arraycolsep = 5 * pt;
    if (group.colSeparationType && group.colSeparationType === "small") {
      var localMultiplier = options.havingStyle(Style$1.SCRIPT).sizeMultiplier;
      arraycolsep = 0.2778 * (localMultiplier / options.sizeMultiplier);
    }
    var baselineskip = group.colSeparationType === "CD" ? calculateSize({
      number: 3,
      unit: "ex"
    }, options) : 12 * pt;
    var jot = 3 * pt;
    var arrayskip = group.arraystretch * baselineskip;
    var arstrutHeight = 0.7 * arrayskip;
    var arstrutDepth = 0.3 * arrayskip;
    var totalHeight = 0;
    function setHLinePos(hlinesInGap) {
      for (var i3 = 0; i3 < hlinesInGap.length; ++i3) {
        if (i3 > 0) {
          totalHeight += 0.25;
        }
        hlines.push({
          pos: totalHeight,
          isDashed: hlinesInGap[i3]
        });
      }
    }
    setHLinePos(hLinesBeforeRow[0]);
    for (r3 = 0; r3 < group.body.length; ++r3) {
      var inrow = group.body[r3];
      var height = arstrutHeight;
      var depth = arstrutDepth;
      if (nc < inrow.length) {
        nc = inrow.length;
      }
      var outrow = {
        cells: new Array(inrow.length),
        height: 0,
        depth: 0,
        pos: 0
      };
      for (c3 = 0; c3 < inrow.length; ++c3) {
        var elt = buildGroup$1(inrow[c3], options);
        if (depth < elt.depth) {
          depth = elt.depth;
        }
        if (height < elt.height) {
          height = elt.height;
        }
        outrow.cells[c3] = elt;
      }
      var rowGap = group.rowGaps[r3];
      var gap = 0;
      if (rowGap) {
        gap = calculateSize(rowGap, options);
        if (gap > 0) {
          gap += arstrutDepth;
          if (depth < gap) {
            depth = gap;
          }
          gap = 0;
        }
      }
      if (group.addJot && r3 < group.body.length - 1) {
        depth += jot;
      }
      outrow.height = height;
      outrow.depth = depth;
      totalHeight += height;
      outrow.pos = totalHeight;
      totalHeight += depth + gap;
      body[r3] = outrow;
      setHLinePos(hLinesBeforeRow[r3 + 1]);
    }
    var offset = totalHeight / 2 + options.fontMetrics().axisHeight;
    var colDescriptions = group.cols || [];
    var cols = [];
    var colSep;
    var colDescrNum;
    var tagSpans = [];
    if (group.tags && group.tags.some((tag2) => tag2)) {
      for (r3 = 0; r3 < nr; ++r3) {
        var rw = body[r3];
        var shift = rw.pos - offset;
        var tag = group.tags[r3];
        var tagSpan = void 0;
        if (tag === true) {
          tagSpan = makeSpan(["eqn-num"], [], options);
        } else if (tag === false) {
          tagSpan = makeSpan([], [], options);
        } else {
          tagSpan = makeSpan([], buildExpression$1(tag, options, true), options);
        }
        tagSpan.depth = rw.depth;
        tagSpan.height = rw.height;
        tagSpans.push({
          type: "elem",
          elem: tagSpan,
          shift
        });
      }
    }
    for (
      c3 = 0, colDescrNum = 0;
      // Continue while either there are more columns or more column
      // descriptions, so trailing separators don't get lost.
      c3 < nc || colDescrNum < colDescriptions.length;
      ++c3, ++colDescrNum
    ) {
      var _colDescr3;
      var colDescr = colDescriptions[colDescrNum];
      var firstSeparator = true;
      while (((_colDescr = colDescr) == null ? void 0 : _colDescr.type) === "separator") {
        var _colDescr;
        if (!firstSeparator) {
          colSep = makeSpan(["arraycolsep"], []);
          colSep.style.width = makeEm(options.fontMetrics().doubleRuleSep);
          cols.push(colSep);
        }
        if (colDescr.separator === "|" || colDescr.separator === ":") {
          var lineType = colDescr.separator === "|" ? "solid" : "dashed";
          var separator = makeSpan(["vertical-separator"], [], options);
          separator.style.height = makeEm(totalHeight);
          separator.style.borderRightWidth = makeEm(ruleThickness);
          separator.style.borderRightStyle = lineType;
          separator.style.margin = "0 " + makeEm(-ruleThickness / 2);
          var _shift = totalHeight - offset;
          if (_shift) {
            separator.style.verticalAlign = makeEm(-_shift);
          }
          cols.push(separator);
        } else {
          throw new ParseError("Invalid separator type: " + colDescr.separator);
        }
        colDescrNum++;
        colDescr = colDescriptions[colDescrNum];
        firstSeparator = false;
      }
      if (c3 >= nc) {
        continue;
      }
      var sepwidth = void 0;
      if (c3 > 0 || group.hskipBeforeAndAfter) {
        var _colDescr$pregap, _colDescr2;
        sepwidth = (_colDescr$pregap = (_colDescr2 = colDescr) == null ? void 0 : _colDescr2.pregap) != null ? _colDescr$pregap : arraycolsep;
        if (sepwidth !== 0) {
          colSep = makeSpan(["arraycolsep"], []);
          colSep.style.width = makeEm(sepwidth);
          cols.push(colSep);
        }
      }
      var colElems = [];
      for (r3 = 0; r3 < nr; ++r3) {
        var row = body[r3];
        var elem = row.cells[c3];
        if (!elem) {
          continue;
        }
        var _shift2 = row.pos - offset;
        elem.depth = row.depth;
        elem.height = row.height;
        colElems.push({
          type: "elem",
          elem,
          shift: _shift2
        });
      }
      var colVList = makeVList({
        positionType: "individualShift",
        children: colElems
      });
      var colSpan = makeSpan(["col-align-" + (((_colDescr3 = colDescr) == null ? void 0 : _colDescr3.align) || "c")], [colVList]);
      cols.push(colSpan);
      if (c3 < nc - 1 || group.hskipBeforeAndAfter) {
        var _colDescr$postgap, _colDescr4;
        sepwidth = (_colDescr$postgap = (_colDescr4 = colDescr) == null ? void 0 : _colDescr4.postgap) != null ? _colDescr$postgap : arraycolsep;
        if (sepwidth !== 0) {
          colSep = makeSpan(["arraycolsep"], []);
          colSep.style.width = makeEm(sepwidth);
          cols.push(colSep);
        }
      }
    }
    var tableBody = makeSpan(["mtable"], cols);
    if (hlines.length > 0) {
      var line = makeLineSpan("katex-hline", options, ruleThickness);
      var dashes = makeLineSpan("katex-hdashline", options, ruleThickness);
      var vListElems = [{
        type: "elem",
        elem: tableBody,
        shift: 0
      }];
      while (hlines.length > 0) {
        var hline = hlines.pop();
        var lineShift = hline.pos - offset;
        if (hline.isDashed) {
          vListElems.push({
            type: "elem",
            elem: dashes,
            shift: lineShift
          });
        } else {
          vListElems.push({
            type: "elem",
            elem: line,
            shift: lineShift
          });
        }
      }
      tableBody = makeVList({
        positionType: "individualShift",
        children: vListElems
      });
    }
    if (tagSpans.length === 0) {
      return makeSpan(["mord"], [tableBody], options);
    } else {
      var eqnNumCol = makeVList({
        positionType: "individualShift",
        children: tagSpans
      });
      var tagCol = makeSpan(["katex-tag"], [eqnNumCol], options);
      return makeFragment([tableBody, tagCol]);
    }
  };
  var alignMap = {
    c: "center ",
    l: "left ",
    r: "right "
  };
  var mathmlBuilder$5 = function mathmlBuilder(group, options) {
    var tbl = [];
    var glue = new MathNode("mtd", [], ["mtr-glue"]);
    var tag = new MathNode("mtd", [], ["mml-eqn-num"]);
    for (var i3 = 0; i3 < group.body.length; i3++) {
      var rw = group.body[i3];
      var row = [];
      for (var j2 = 0; j2 < rw.length; j2++) {
        row.push(new MathNode("mtd", [buildGroup2(rw[j2], options)]));
      }
      if (group.tags && group.tags[i3]) {
        row.unshift(glue);
        row.push(glue);
        if (group.leqno) {
          row.unshift(tag);
        } else {
          row.push(tag);
        }
      }
      tbl.push(new MathNode("mtr", row));
    }
    var table = new MathNode("mtable", tbl);
    var gap = group.arraystretch === 0.5 ? 0.1 : 0.16 + group.arraystretch - 1 + (group.addJot ? 0.09 : 0);
    table.setAttribute("rowspacing", makeEm(gap));
    var menclose = "";
    var align = "";
    if (group.cols && group.cols.length > 0) {
      var cols = group.cols;
      var columnLines = "";
      var prevTypeWasAlign = false;
      var iStart = 0;
      var iEnd = cols.length;
      if (cols[0].type === "separator") {
        menclose += "top ";
        iStart = 1;
      }
      if (cols[cols.length - 1].type === "separator") {
        menclose += "bottom ";
        iEnd -= 1;
      }
      for (var _i = iStart; _i < iEnd; _i++) {
        var col = cols[_i];
        if (col.type === "align") {
          align += alignMap[col.align];
          if (prevTypeWasAlign) {
            columnLines += "none ";
          }
          prevTypeWasAlign = true;
        } else if (col.type === "separator") {
          if (prevTypeWasAlign) {
            columnLines += col.separator === "|" ? "solid " : "dashed ";
            prevTypeWasAlign = false;
          }
        }
      }
      table.setAttribute("columnalign", align.trim());
      if (/[sd]/.test(columnLines)) {
        table.setAttribute("columnlines", columnLines.trim());
      }
    }
    if (group.colSeparationType === "align") {
      var _cols = group.cols || [];
      var spacing2 = "";
      for (var _i2 = 1; _i2 < _cols.length; _i2++) {
        spacing2 += _i2 % 2 ? "0em " : "1em ";
      }
      table.setAttribute("columnspacing", spacing2.trim());
    } else if (group.colSeparationType === "alignat" || group.colSeparationType === "gather") {
      table.setAttribute("columnspacing", "0em");
    } else if (group.colSeparationType === "small") {
      table.setAttribute("columnspacing", "0.2778em");
    } else if (group.colSeparationType === "CD") {
      table.setAttribute("columnspacing", "0.5em");
    } else {
      table.setAttribute("columnspacing", "1em");
    }
    var rowLines = "";
    var hlines = group.hLinesBeforeRow;
    menclose += hlines[0].length > 0 ? "left " : "";
    menclose += hlines[hlines.length - 1].length > 0 ? "right " : "";
    for (var _i3 = 1; _i3 < hlines.length - 1; _i3++) {
      rowLines += hlines[_i3].length === 0 ? "none " : hlines[_i3][0] ? "dashed " : "solid ";
    }
    if (/[sd]/.test(rowLines)) {
      table.setAttribute("rowlines", rowLines.trim());
    }
    if (menclose !== "") {
      table = new MathNode("menclose", [table]);
      table.setAttribute("notation", menclose.trim());
    }
    if (group.arraystretch && group.arraystretch < 1) {
      table = new MathNode("mstyle", [table]);
      table.setAttribute("scriptlevel", "1");
    }
    return table;
  };
  var alignedHandler = function alignedHandler2(context, args) {
    if (!context.envName.includes("ed")) {
      validateAmsEnvironmentContext(context);
    }
    var cols = [];
    var isSplit = context.envName === "split";
    var res = parseArray(context.parser, {
      cols,
      addJot: true,
      autoTag: isSplit ? void 0 : getAutoTag(context.envName),
      emptySingleRow: true,
      colSeparationType: context.envName.includes("at") ? "alignat" : "align",
      maxNumCols: isSplit ? 2 : void 0,
      leqno: context.parser.settings.leqno
    }, "display");
    var numMaths = 0;
    var numCols = 0;
    var emptyGroup = {
      type: "ordgroup",
      mode: context.mode,
      body: []
    };
    if (args[0] && args[0].type === "ordgroup") {
      var message2 = "Number of columns should be a positive integer";
      var numColumns = assertCharacterGroup(args[0], message2);
      if (!/^[0-9]+$/.test(numColumns) || Number(numColumns) < 1) {
        throw new ParseError(message2, args[0]);
      }
      numMaths = Number(numColumns);
      numCols = numMaths * 2;
    }
    var isAligned = !numCols;
    res.body.forEach(function(row) {
      for (var i4 = 1; i4 < row.length; i4 += 2) {
        var styling = assertNodeType(row[i4], "styling");
        var ordgroup = assertNodeType(styling.body[0], "ordgroup");
        ordgroup.body.unshift(emptyGroup);
      }
      if (!isAligned) {
        var curMaths = row.length / 2;
        if (numMaths < curMaths) {
          throw new ParseError("Too many math in a row: " + ("expected " + numMaths + ", but got " + curMaths), row[0]);
        }
      } else if (numCols < row.length) {
        numCols = row.length;
      }
    });
    for (var i3 = 0; i3 < numCols; ++i3) {
      var align = "r";
      var pregap = 0;
      if (i3 % 2 === 1) {
        align = "l";
      } else if (i3 > 0 && isAligned) {
        pregap = 1;
      }
      cols[i3] = {
        type: "align",
        align,
        pregap,
        postgap: 0
      };
    }
    res.colSeparationType = isAligned ? "align" : "alignat";
    return res;
  };
  defineEnvironment({
    type: "array",
    names: ["array", "darray"],
    props: {
      numArgs: 1
    },
    handler(context, args) {
      var symNode = checkSymbolNodeType(args[0]);
      var colalign = symNode ? [args[0]] : assertNodeType(args[0], "ordgroup").body;
      var cols = colalign.map(function(nde) {
        var node = assertSymbolNodeType(nde);
        var ca = node.text;
        if ("lcr".includes(ca)) {
          return {
            type: "align",
            align: ca
          };
        } else if (ca === "|") {
          return {
            type: "separator",
            separator: "|"
          };
        } else if (ca === ":") {
          return {
            type: "separator",
            separator: ":"
          };
        }
        throw new ParseError("Unknown column alignment: " + ca, nde);
      });
      var res = {
        cols,
        hskipBeforeAndAfter: true,
        // \@preamble in lttab.dtx
        maxNumCols: cols.length
      };
      return parseArray(context.parser, res, dCellStyle(context.envName));
    },
    htmlBuilder: htmlBuilder$6,
    mathmlBuilder: mathmlBuilder$5
  });
  defineEnvironment({
    type: "array",
    names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"],
    props: {
      numArgs: 0
    },
    handler(context) {
      var delimiters2 = {
        "matrix": null,
        "pmatrix": ["(", ")"],
        "bmatrix": ["[", "]"],
        "Bmatrix": ["\\{", "\\}"],
        "vmatrix": ["|", "|"],
        "Vmatrix": ["\\Vert", "\\Vert"]
      }[context.envName.replace("*", "")];
      var colAlign = "c";
      var payload = {
        hskipBeforeAndAfter: false,
        cols: [{
          type: "align",
          align: colAlign
        }]
      };
      if (context.envName.charAt(context.envName.length - 1) === "*") {
        var parser = context.parser;
        parser.consumeSpaces();
        if (parser.fetch().text === "[") {
          parser.consume();
          parser.consumeSpaces();
          colAlign = parser.fetch().text;
          if (!"lcr".includes(colAlign)) {
            throw new ParseError("Expected l or c or r", parser.nextToken);
          }
          parser.consume();
          parser.consumeSpaces();
          parser.expect("]");
          parser.consume();
          payload.cols = [{
            type: "align",
            align: colAlign
          }];
        }
      }
      var res = parseArray(context.parser, payload, dCellStyle(context.envName));
      var numCols = Math.max(0, ...res.body.map((row) => row.length));
      res.cols = new Array(numCols).fill({
        type: "align",
        align: colAlign
      });
      return delimiters2 ? {
        type: "leftright",
        mode: context.mode,
        body: [res],
        left: delimiters2[0],
        right: delimiters2[1],
        rightColor: void 0
        // \right uninfluenced by \color in array
      } : res;
    },
    htmlBuilder: htmlBuilder$6,
    mathmlBuilder: mathmlBuilder$5
  });
  defineEnvironment({
    type: "array",
    names: ["smallmatrix"],
    props: {
      numArgs: 0
    },
    handler(context) {
      var payload = {
        arraystretch: 0.5
      };
      var res = parseArray(context.parser, payload, "script");
      res.colSeparationType = "small";
      return res;
    },
    htmlBuilder: htmlBuilder$6,
    mathmlBuilder: mathmlBuilder$5
  });
  defineEnvironment({
    type: "array",
    names: ["subarray"],
    props: {
      numArgs: 1
    },
    handler(context, args) {
      var symNode = checkSymbolNodeType(args[0]);
      var colalign = symNode ? [args[0]] : assertNodeType(args[0], "ordgroup").body;
      var cols = colalign.map(function(nde) {
        var node = assertSymbolNodeType(nde);
        var ca = node.text;
        if ("lc".includes(ca)) {
          return {
            type: "align",
            align: ca
          };
        }
        throw new ParseError("Unknown column alignment: " + ca, nde);
      });
      if (cols.length > 1) {
        throw new ParseError("{subarray} can contain only one column");
      }
      var payload = {
        cols,
        hskipBeforeAndAfter: false,
        arraystretch: 0.5
      };
      var res = parseArray(context.parser, payload, "script");
      if (res.body.length > 0 && res.body[0].length > 1) {
        throw new ParseError("{subarray} can contain only one column");
      }
      return res;
    },
    htmlBuilder: htmlBuilder$6,
    mathmlBuilder: mathmlBuilder$5
  });
  defineEnvironment({
    type: "array",
    names: ["cases", "dcases", "rcases", "drcases"],
    props: {
      numArgs: 0
    },
    handler(context) {
      var payload = {
        arraystretch: 1.2,
        cols: [{
          type: "align",
          align: "l",
          pregap: 0,
          // TODO(kevinb) get the current style.
          // For now we use the metrics for TEXT style which is what we were
          // doing before.  Before attempting to get the current style we
          // should look at TeX's behavior especially for \over and matrices.
          postgap: 1
          /* 1em quad */
        }, {
          type: "align",
          align: "l",
          pregap: 0,
          postgap: 0
        }]
      };
      var res = parseArray(context.parser, payload, dCellStyle(context.envName));
      return {
        type: "leftright",
        mode: context.mode,
        body: [res],
        left: context.envName.includes("r") ? "." : "\\{",
        right: context.envName.includes("r") ? "\\}" : ".",
        rightColor: void 0
      };
    },
    htmlBuilder: htmlBuilder$6,
    mathmlBuilder: mathmlBuilder$5
  });
  defineEnvironment({
    type: "array",
    names: ["align", "align*", "aligned", "split"],
    props: {
      numArgs: 0
    },
    handler: alignedHandler,
    htmlBuilder: htmlBuilder$6,
    mathmlBuilder: mathmlBuilder$5
  });
  defineEnvironment({
    type: "array",
    names: ["gathered", "gather", "gather*"],
    props: {
      numArgs: 0
    },
    handler(context) {
      if (gatherEnvironments.has(context.envName)) {
        validateAmsEnvironmentContext(context);
      }
      var res = {
        cols: [{
          type: "align",
          align: "c"
        }],
        addJot: true,
        colSeparationType: "gather",
        autoTag: getAutoTag(context.envName),
        emptySingleRow: true,
        leqno: context.parser.settings.leqno
      };
      return parseArray(context.parser, res, "display");
    },
    htmlBuilder: htmlBuilder$6,
    mathmlBuilder: mathmlBuilder$5
  });
  defineEnvironment({
    type: "array",
    names: ["alignat", "alignat*", "alignedat"],
    props: {
      numArgs: 1
    },
    handler: alignedHandler,
    htmlBuilder: htmlBuilder$6,
    mathmlBuilder: mathmlBuilder$5
  });
  defineEnvironment({
    type: "array",
    names: ["equation", "equation*"],
    props: {
      numArgs: 0
    },
    handler(context) {
      validateAmsEnvironmentContext(context);
      var res = {
        autoTag: getAutoTag(context.envName),
        emptySingleRow: true,
        singleRow: true,
        maxNumCols: 1,
        leqno: context.parser.settings.leqno
      };
      return parseArray(context.parser, res, "display");
    },
    htmlBuilder: htmlBuilder$6,
    mathmlBuilder: mathmlBuilder$5
  });
  defineEnvironment({
    type: "array",
    names: ["CD"],
    props: {
      numArgs: 0
    },
    handler(context) {
      validateAmsEnvironmentContext(context);
      return parseCD(context.parser);
    },
    htmlBuilder: htmlBuilder$6,
    mathmlBuilder: mathmlBuilder$5
  });
  defineMacro("\\nonumber", "\\gdef\\@eqnsw{0}");
  defineMacro("\\notag", "\\nonumber");
  defineFunction({
    type: "text",
    // Doesn't matter what this is.
    names: ["\\hline", "\\hdashline"],
    numArgs: 0,
    allowedInText: true,
    allowedInMath: true,
    handler(context, args) {
      throw new ParseError(context.funcName + " valid only within array environment");
    }
  });
  var environments = _environments;
  defineFunction({
    type: "environment",
    names: ["\\begin", "\\end"],
    numArgs: 1,
    argTypes: ["text"],
    handler(_ref, args) {
      var parser = _ref.parser, funcName = _ref.funcName;
      var nameGroup = args[0];
      if (nameGroup.type !== "ordgroup") {
        throw new ParseError("Invalid environment name", nameGroup);
      }
      var envName = assertCharacterGroup(nameGroup, "Environment name should contain only text characters and spaces", true);
      if (funcName === "\\begin") {
        if (!Object.prototype.hasOwnProperty.call(environments, envName)) {
          throw new ParseError("No such environment: " + envName, nameGroup);
        }
        var env = environments[envName];
        var _parser$parseArgument = parser.parseArguments("\\begin{" + envName + "}", env), _args = _parser$parseArgument.args, optArgs = _parser$parseArgument.optArgs;
        var context = {
          mode: parser.mode,
          envName,
          parser
        };
        var result = env.handler(context, _args, optArgs);
        parser.expect("\\end", false);
        var endNameToken = parser.nextToken;
        var end = assertNodeType(parser.parseFunction(), "environment");
        if (end.name !== envName) {
          throw new ParseError("Mismatch: \\begin{" + envName + "} matched by \\end{" + end.name + "}", endNameToken);
        }
        return result;
      }
      return {
        type: "environment",
        mode: parser.mode,
        name: envName,
        nameGroup
      };
    }
  });
  var htmlBuilder$5 = (group, options) => {
    var font = group.font;
    var newOptions = options.withFont(font);
    return buildGroup$1(group.body, newOptions);
  };
  var mathmlBuilder$4 = (group, options) => {
    var font = group.font;
    var newOptions = options.withFont(font);
    return buildGroup2(group.body, newOptions);
  };
  var fontAliases = {
    "\\Bbb": "\\mathbb",
    "\\bold": "\\mathbf",
    "\\frak": "\\mathfrak"
  };
  defineFunction({
    type: "font",
    names: [
      // styles, except \boldsymbol defined below
      "\\mathrm",
      "\\mathit",
      "\\mathbf",
      "\\mathnormal",
      "\\mathsfit",
      // families
      "\\mathbb",
      "\\mathcal",
      "\\mathfrak",
      "\\mathscr",
      "\\mathsf",
      "\\mathtt",
      // aliases, except \bm defined below
      "\\Bbb",
      "\\bold",
      "\\frak"
    ],
    numArgs: 1,
    allowedInArgument: true,
    handler: (_ref, args) => {
      var parser = _ref.parser, funcName = _ref.funcName;
      var body = normalizeArgument(args[0]);
      var func = funcName in fontAliases ? fontAliases[funcName] : funcName;
      return {
        type: "font",
        mode: parser.mode,
        font: func.slice(1),
        body
      };
    },
    htmlBuilder: htmlBuilder$5,
    mathmlBuilder: mathmlBuilder$4
  });
  defineFunction({
    type: "mclass",
    names: ["\\boldsymbol", "\\bm"],
    numArgs: 1,
    handler: (_ref2, args) => {
      var parser = _ref2.parser;
      var body = args[0];
      return {
        type: "mclass",
        mode: parser.mode,
        mclass: binrelClass(body),
        body: [{
          type: "font",
          mode: parser.mode,
          font: "boldsymbol",
          body
        }],
        isCharacterBox: isCharacterBox(body)
      };
    }
  });
  defineFunction({
    type: "font",
    names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"],
    numArgs: 0,
    allowedInText: true,
    handler: (_ref3, args) => {
      var parser = _ref3.parser, funcName = _ref3.funcName, breakOnTokenText = _ref3.breakOnTokenText;
      var mode = parser.mode;
      var body = parser.parseExpression(true, breakOnTokenText);
      return {
        type: "font",
        mode,
        font: "math" + funcName.slice(1),
        body: {
          type: "ordgroup",
          mode: parser.mode,
          body
        }
      };
    }
  });
  var htmlBuilder$4 = (group, options) => {
    var style = options.style;
    var nstyle = style.fracNum();
    var dstyle = style.fracDen();
    var newOptions;
    newOptions = options.havingStyle(nstyle);
    var numerm = buildGroup$1(group.numer, newOptions, options);
    if (group.continued) {
      var hStrut = 8.5 / options.fontMetrics().ptPerEm;
      var dStrut = 3.5 / options.fontMetrics().ptPerEm;
      numerm.height = numerm.height < hStrut ? hStrut : numerm.height;
      numerm.depth = numerm.depth < dStrut ? dStrut : numerm.depth;
    }
    newOptions = options.havingStyle(dstyle);
    var denomm = buildGroup$1(group.denom, newOptions, options);
    var rule;
    var ruleWidth;
    var ruleSpacing;
    if (group.hasBarLine) {
      if (group.barSize) {
        ruleWidth = calculateSize(group.barSize, options);
        rule = makeLineSpan("frac-line", options, ruleWidth);
      } else {
        rule = makeLineSpan("frac-line", options);
      }
      ruleWidth = rule.height;
      ruleSpacing = rule.height;
    } else {
      rule = null;
      ruleWidth = 0;
      ruleSpacing = options.fontMetrics().defaultRuleThickness;
    }
    var numShift;
    var clearance;
    var denomShift;
    if (style.size === Style$1.DISPLAY.size) {
      numShift = options.fontMetrics().num1;
      if (ruleWidth > 0) {
        clearance = 3 * ruleSpacing;
      } else {
        clearance = 7 * ruleSpacing;
      }
      denomShift = options.fontMetrics().denom1;
    } else {
      if (ruleWidth > 0) {
        numShift = options.fontMetrics().num2;
        clearance = ruleSpacing;
      } else {
        numShift = options.fontMetrics().num3;
        clearance = 3 * ruleSpacing;
      }
      denomShift = options.fontMetrics().denom2;
    }
    var frac;
    if (!rule) {
      var candidateClearance = numShift - numerm.depth - (denomm.height - denomShift);
      if (candidateClearance < clearance) {
        numShift += 0.5 * (clearance - candidateClearance);
        denomShift += 0.5 * (clearance - candidateClearance);
      }
      frac = makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: denomm,
          shift: denomShift
        }, {
          type: "elem",
          elem: numerm,
          shift: -numShift
        }]
      });
    } else {
      var axisHeight = options.fontMetrics().axisHeight;
      if (numShift - numerm.depth - (axisHeight + 0.5 * ruleWidth) < clearance) {
        numShift += clearance - (numShift - numerm.depth - (axisHeight + 0.5 * ruleWidth));
      }
      if (axisHeight - 0.5 * ruleWidth - (denomm.height - denomShift) < clearance) {
        denomShift += clearance - (axisHeight - 0.5 * ruleWidth - (denomm.height - denomShift));
      }
      var midShift = -(axisHeight - 0.5 * ruleWidth);
      frac = makeVList({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: denomm,
          shift: denomShift
        }, {
          type: "elem",
          elem: rule,
          shift: midShift
        }, {
          type: "elem",
          elem: numerm,
          shift: -numShift
        }]
      });
    }
    newOptions = options.havingStyle(style);
    frac.height *= newOptions.sizeMultiplier / options.sizeMultiplier;
    frac.depth *= newOptions.sizeMultiplier / options.sizeMultiplier;
    var delimSize;
    if (style.size === Style$1.DISPLAY.size) {
      delimSize = options.fontMetrics().delim1;
    } else if (style.size === Style$1.SCRIPTSCRIPT.size) {
      delimSize = options.havingStyle(Style$1.SCRIPT).fontMetrics().delim2;
    } else {
      delimSize = options.fontMetrics().delim2;
    }
    var leftDelim;
    var rightDelim;
    if (group.leftDelim == null) {
      leftDelim = makeNullDelimiter(options, ["mopen"]);
    } else {
      leftDelim = makeCustomSizedDelim(group.leftDelim, delimSize, true, options.havingStyle(style), group.mode, ["mopen"]);
    }
    if (group.continued) {
      rightDelim = makeSpan([]);
    } else if (group.rightDelim == null) {
      rightDelim = makeNullDelimiter(options, ["mclose"]);
    } else {
      rightDelim = makeCustomSizedDelim(group.rightDelim, delimSize, true, options.havingStyle(style), group.mode, ["mclose"]);
    }
    return makeSpan(["mord"].concat(newOptions.sizingClasses(options)), [leftDelim, makeSpan(["mfrac"], [frac]), rightDelim], options);
  };
  var mathmlBuilder$3 = (group, options) => {
    var node = new MathNode("mfrac", [buildGroup2(group.numer, options), buildGroup2(group.denom, options)]);
    if (!group.hasBarLine) {
      node.setAttribute("linethickness", "0px");
    } else if (group.barSize) {
      var ruleWidth = calculateSize(group.barSize, options);
      node.setAttribute("linethickness", makeEm(ruleWidth));
    }
    if (group.leftDelim != null || group.rightDelim != null) {
      var withDelims = [];
      if (group.leftDelim != null) {
        var leftOp = new MathNode("mo", [new TextNode(group.leftDelim.replace("\\", ""))]);
        leftOp.setAttribute("fence", "true");
        withDelims.push(leftOp);
      }
      withDelims.push(node);
      if (group.rightDelim != null) {
        var rightOp = new MathNode("mo", [new TextNode(group.rightDelim.replace("\\", ""))]);
        rightOp.setAttribute("fence", "true");
        withDelims.push(rightOp);
      }
      return makeRow(withDelims);
    }
    return node;
  };
  var wrapWithStyle = (frac, style) => {
    if (!style) {
      return frac;
    }
    var wrapper = {
      type: "styling",
      mode: frac.mode,
      style,
      body: [frac]
    };
    return wrapper;
  };
  defineFunction({
    type: "genfrac",
    names: [
      "\\cfrac",
      "\\dfrac",
      "\\frac",
      "\\tfrac",
      "\\dbinom",
      "\\binom",
      "\\tbinom",
      "\\\\atopfrac",
      // can’t be entered directly
      "\\\\bracefrac",
      "\\\\brackfrac"
      // ditto
    ],
    numArgs: 2,
    allowedInArgument: true,
    handler: (_ref, args) => {
      var parser = _ref.parser, funcName = _ref.funcName;
      var numer = args[0];
      var denom = args[1];
      var hasBarLine;
      var leftDelim = null;
      var rightDelim = null;
      switch (funcName) {
        case "\\cfrac":
        case "\\dfrac":
        case "\\frac":
        case "\\tfrac":
          hasBarLine = true;
          break;
        case "\\\\atopfrac":
          hasBarLine = false;
          break;
        case "\\dbinom":
        case "\\binom":
        case "\\tbinom":
          hasBarLine = false;
          leftDelim = "(";
          rightDelim = ")";
          break;
        case "\\\\bracefrac":
          hasBarLine = false;
          leftDelim = "\\{";
          rightDelim = "\\}";
          break;
        case "\\\\brackfrac":
          hasBarLine = false;
          leftDelim = "[";
          rightDelim = "]";
          break;
        default:
          throw new Error("Unrecognized genfrac command");
      }
      var continued = funcName === "\\cfrac";
      var style = null;
      if (continued || funcName.startsWith("\\d")) {
        style = "display";
      } else if (funcName.startsWith("\\t")) {
        style = "text";
      }
      return wrapWithStyle({
        type: "genfrac",
        mode: parser.mode,
        numer,
        denom,
        continued,
        hasBarLine,
        leftDelim,
        rightDelim,
        barSize: null
      }, style);
    },
    htmlBuilder: htmlBuilder$4,
    mathmlBuilder: mathmlBuilder$3
  });
  defineFunction({
    type: "infix",
    names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
    numArgs: 0,
    infix: true,
    handler(_ref2) {
      var parser = _ref2.parser, funcName = _ref2.funcName, token = _ref2.token;
      var replaceWith;
      switch (funcName) {
        case "\\over":
          replaceWith = "\\frac";
          break;
        case "\\choose":
          replaceWith = "\\binom";
          break;
        case "\\atop":
          replaceWith = "\\\\atopfrac";
          break;
        case "\\brace":
          replaceWith = "\\\\bracefrac";
          break;
        case "\\brack":
          replaceWith = "\\\\brackfrac";
          break;
        default:
          throw new Error("Unrecognized infix genfrac command");
      }
      return {
        type: "infix",
        mode: parser.mode,
        replaceWith,
        token
      };
    }
  });
  var stylArray = ["display", "text", "script", "scriptscript"];
  var delimFromValue = function delimFromValue2(delimString) {
    var delim = null;
    if (delimString.length > 0) {
      delim = delimString;
      delim = delim === "." ? null : delim;
    }
    return delim;
  };
  defineFunction({
    type: "genfrac",
    names: ["\\genfrac"],
    numArgs: 6,
    allowedInArgument: true,
    argTypes: ["math", "math", "size", "text", "math", "math"],
    handler(_ref3, args) {
      var parser = _ref3.parser;
      var numer = args[4];
      var denom = args[5];
      var leftNode = normalizeArgument(args[0]);
      var leftDelim = leftNode.type === "atom" && leftNode.family === "open" ? delimFromValue(leftNode.text) : null;
      var rightNode = normalizeArgument(args[1]);
      var rightDelim = rightNode.type === "atom" && rightNode.family === "close" ? delimFromValue(rightNode.text) : null;
      var barNode = assertNodeType(args[2], "size");
      var hasBarLine;
      var barSize = null;
      if (barNode.isBlank) {
        hasBarLine = true;
      } else {
        barSize = barNode.value;
        hasBarLine = barSize.number > 0;
      }
      var size = null;
      var styl = args[3];
      if (styl.type === "ordgroup") {
        if (styl.body.length > 0) {
          var textOrd = assertNodeType(styl.body[0], "textord");
          size = stylArray[Number(textOrd.text)];
        }
      } else {
        styl = assertNodeType(styl, "textord");
        size = stylArray[Number(styl.text)];
      }
      return wrapWithStyle({
        type: "genfrac",
        mode: parser.mode,
        numer,
        denom,
        continued: false,
        hasBarLine,
        barSize,
        leftDelim,
        rightDelim
      }, size);
    }
  });
  defineFunction({
    type: "infix",
    names: ["\\above"],
    numArgs: 1,
    argTypes: ["size"],
    infix: true,
    handler(_ref4, args) {
      var parser = _ref4.parser;
      _ref4.funcName;
      var token = _ref4.token;
      return {
        type: "infix",
        mode: parser.mode,
        replaceWith: "\\\\abovefrac",
        size: assertNodeType(args[0], "size").value,
        token
      };
    }
  });
  defineFunction({
    type: "genfrac",
    names: ["\\\\abovefrac"],
    numArgs: 3,
    argTypes: ["math", "size", "math"],
    handler: (_ref5, args) => {
      var parser = _ref5.parser;
      _ref5.funcName;
      var numer = args[0];
      var barSize = assertNodeType(args[1], "infix").size;
      if (!barSize) {
        throw new Error("\\\\abovefrac expected size, but got " + String(barSize));
      }
      var denom = args[2];
      var hasBarLine = barSize.number > 0;
      return {
        type: "genfrac",
        mode: parser.mode,
        numer,
        denom,
        continued: false,
        hasBarLine,
        barSize,
        leftDelim: null,
        rightDelim: null
      };
    }
  });
  var htmlBuilder$3 = (grp, options) => {
    var style = options.style;
    var supSubGroup;
    var group;
    if (grp.type === "supsub") {
      supSubGroup = grp.sup ? buildGroup$1(grp.sup, options.havingStyle(style.sup()), options) : buildGroup$1(grp.sub, options.havingStyle(style.sub()), options);
      group = assertNodeType(grp.base, "horizBrace");
    } else {
      group = assertNodeType(grp, "horizBrace");
    }
    var body = buildGroup$1(group.base, options.havingBaseStyle(Style$1.DISPLAY));
    var braceBody = stretchySvg(group, options);
    var vlist;
    if (group.isOver) {
      vlist = makeVList({
        positionType: "firstBaseline",
        children: [{
          type: "elem",
          elem: body
        }, {
          type: "kern",
          size: 0.1
        }, {
          type: "elem",
          elem: braceBody,
          wrapperClasses: ["svg-align"]
        }]
      });
    } else {
      vlist = makeVList({
        positionType: "bottom",
        positionData: body.depth + 0.1 + braceBody.height,
        children: [{
          type: "elem",
          elem: braceBody,
          wrapperClasses: ["svg-align"]
        }, {
          type: "kern",
          size: 0.1
        }, {
          type: "elem",
          elem: body
        }]
      });
    }
    if (supSubGroup) {
      var vSpan = makeSpan(["minner", group.isOver ? "mover" : "munder"], [vlist], options);
      if (group.isOver) {
        vlist = makeVList({
          positionType: "firstBaseline",
          children: [{
            type: "elem",
            elem: vSpan
          }, {
            type: "kern",
            size: 0.2
          }, {
            type: "elem",
            elem: supSubGroup
          }]
        });
      } else {
        vlist = makeVList({
          positionType: "bottom",
          positionData: vSpan.depth + 0.2 + supSubGroup.height + supSubGroup.depth,
          children: [{
            type: "elem",
            elem: supSubGroup
          }, {
            type: "kern",
            size: 0.2
          }, {
            type: "elem",
            elem: vSpan
          }]
        });
      }
    }
    return makeSpan(["minner", group.isOver ? "mover" : "munder"], [vlist], options);
  };
  var mathmlBuilder$2 = (group, options) => {
    var accentNode = stretchyMathML(group.label);
    return new MathNode(group.isOver ? "mover" : "munder", [buildGroup2(group.base, options), accentNode]);
  };
  defineFunction({
    type: "horizBrace",
    names: ["\\overbrace", "\\underbrace", "\\overbracket", "\\underbracket"],
    numArgs: 1,
    handler(_ref, args) {
      var parser = _ref.parser, funcName = _ref.funcName;
      return {
        type: "horizBrace",
        mode: parser.mode,
        label: funcName,
        isOver: funcName.includes("\\over"),
        base: args[0]
      };
    },
    htmlBuilder: htmlBuilder$3,
    mathmlBuilder: mathmlBuilder$2
  });
  defineFunction({
    type: "href",
    names: ["\\href"],
    numArgs: 2,
    argTypes: ["url", "original"],
    allowedInText: true,
    handler: (_ref, args) => {
      var parser = _ref.parser;
      var body = args[1];
      var href = assertNodeType(args[0], "url").url;
      if (!parser.settings.isTrusted({
        command: "\\href",
        url: href
      })) {
        return parser.formatUnsupportedCmd("\\href");
      }
      return {
        type: "href",
        mode: parser.mode,
        href,
        body: ordargument(body)
      };
    },
    htmlBuilder: (group, options) => {
      var elements = buildExpression$1(group.body, options, false);
      return makeAnchor(group.href, [], elements, options);
    },
    mathmlBuilder: (group, options) => {
      var math2 = buildExpressionRow(group.body, options);
      if (!(math2 instanceof MathNode)) {
        math2 = new MathNode("mrow", [math2]);
      }
      math2.setAttribute("href", group.href);
      return math2;
    }
  });
  defineFunction({
    type: "href",
    names: ["\\url"],
    numArgs: 1,
    argTypes: ["url"],
    allowedInText: true,
    handler: (_ref2, args) => {
      var parser = _ref2.parser;
      var href = assertNodeType(args[0], "url").url;
      if (!parser.settings.isTrusted({
        command: "\\url",
        url: href
      })) {
        return parser.formatUnsupportedCmd("\\url");
      }
      var chars = [];
      for (var i3 = 0; i3 < href.length; i3++) {
        var c3 = href[i3];
        if (c3 === "~") {
          c3 = "\\textasciitilde";
        }
        chars.push({
          type: "textord",
          mode: "text",
          text: c3
        });
      }
      var body = {
        type: "text",
        mode: parser.mode,
        font: "\\texttt",
        body: chars
      };
      return {
        type: "href",
        mode: parser.mode,
        href,
        body: ordargument(body)
      };
    }
  });
  defineFunction({
    type: "hbox",
    names: ["\\hbox"],
    numArgs: 1,
    argTypes: ["text"],
    allowedInText: true,
    primitive: true,
    handler(_ref, args) {
      var parser = _ref.parser;
      return {
        type: "hbox",
        mode: parser.mode,
        body: ordargument(args[0])
      };
    },
    htmlBuilder(group, options) {
      var elements = buildExpression$1(group.body, options.withFont(""), false);
      return makeFragment(elements);
    },
    mathmlBuilder(group, options) {
      return new MathNode("mrow", buildExpression2(group.body, options.withFont("")));
    }
  });
  defineFunction({
    type: "html",
    names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"],
    numArgs: 2,
    argTypes: ["raw", "original"],
    allowedInText: true,
    handler: (_ref, args) => {
      var parser = _ref.parser, funcName = _ref.funcName;
      _ref.token;
      var value = assertNodeType(args[0], "raw").string;
      var body = args[1];
      if (parser.settings.strict) {
        handleStrict({
          strict: parser.settings.strict,
          errorCode: "htmlExtension",
          errorMsg: "HTML extension is disabled on strict mode",
          report: true
        });
      }
      var trustContext;
      var attributes = {};
      switch (funcName) {
        case "\\htmlClass":
          attributes.class = value;
          trustContext = {
            command: "\\htmlClass",
            class: value
          };
          break;
        case "\\htmlId":
          attributes.id = value;
          trustContext = {
            command: "\\htmlId",
            id: value
          };
          break;
        case "\\htmlStyle":
          attributes.style = value;
          trustContext = {
            command: "\\htmlStyle",
            style: value
          };
          break;
        case "\\htmlData": {
          var ESCAPED_COMMA = "{,}";
          var data = [];
          var current = "";
          for (var i3 = 0; i3 < value.length; i3++) {
            if (value.startsWith(ESCAPED_COMMA, i3)) {
              current += ",";
              i3 += ESCAPED_COMMA.length - 1;
            } else if (value[i3] === ",") {
              data.push(current);
              current = "";
            } else {
              current += value[i3];
            }
          }
          data.push(current);
          for (var _i = 0; _i < data.length; _i++) {
            var item = data[_i];
            var firstEquals = item.indexOf("=");
            if (firstEquals < 0) {
              throw new ParseError("\\htmlData key/value '" + item + "' missing equals sign");
            }
            var key = item.slice(0, firstEquals);
            var _value = item.slice(firstEquals + 1);
            attributes["data-" + key.trim()] = _value;
          }
          trustContext = {
            command: "\\htmlData",
            attributes
          };
          break;
        }
        default:
          throw new Error("Unrecognized html command");
      }
      if (!parser.settings.isTrusted(trustContext)) {
        return parser.formatUnsupportedCmd(funcName);
      }
      return {
        type: "html",
        mode: parser.mode,
        attributes,
        body: ordargument(body)
      };
    },
    htmlBuilder: (group, options) => {
      var elements = buildExpression$1(group.body, options, false);
      var classes = ["enclosing"];
      if (group.attributes.class) {
        classes.push(...group.attributes.class.trim().split(/\s+/));
      }
      var span = makeSpan(classes, elements, options);
      for (var _ref3 of Object.entries(group.attributes)) {
        var attr = _ref3[0];
        var value = _ref3[1];
        if (attr !== "class") {
          span.setAttribute(attr, value);
        }
      }
      return span;
    },
    mathmlBuilder: (group, options) => {
      return buildExpressionRow(group.body, options);
    }
  });
  defineFunction({
    type: "htmlmathml",
    names: ["\\html@mathml"],
    numArgs: 2,
    allowedInArgument: true,
    allowedInText: true,
    handler: (_ref, args) => {
      var parser = _ref.parser;
      return {
        type: "htmlmathml",
        mode: parser.mode,
        html: ordargument(args[0]),
        mathml: ordargument(args[1])
      };
    },
    htmlBuilder: (group, options) => {
      var elements = buildExpression$1(group.html, options, false);
      return makeFragment(elements);
    },
    mathmlBuilder: (group, options) => {
      return buildExpressionRow(group.mathml, options);
    }
  });
  var sizeData = function sizeData2(str) {
    if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(str)) {
      return {
        number: +str,
        unit: "bp"
      };
    } else {
      var match = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(str);
      if (!match) {
        throw new ParseError("Invalid size: '" + str + "' in \\includegraphics");
      }
      var data = {
        number: +(match[1] + match[2]),
        // sign + magnitude, cast to number
        unit: match[3]
      };
      if (!validUnit(data)) {
        throw new ParseError("Invalid unit: '" + data.unit + "' in \\includegraphics.");
      }
      return data;
    }
  };
  defineFunction({
    type: "includegraphics",
    names: ["\\includegraphics"],
    numArgs: 1,
    numOptionalArgs: 1,
    argTypes: ["raw", "url"],
    allowedInText: false,
    handler: (_ref, args, optArgs) => {
      var parser = _ref.parser;
      var width = {
        number: 0,
        unit: "em"
      };
      var height = {
        number: 0.9,
        unit: "em"
      };
      var totalheight = {
        number: 0,
        unit: "em"
      };
      var alt = "";
      if (optArgs[0]) {
        var attributeStr = assertNodeType(optArgs[0], "raw").string;
        var attributes = attributeStr.split(",");
        for (var i3 = 0; i3 < attributes.length; i3++) {
          var keyVal = attributes[i3].split("=");
          if (keyVal.length === 2) {
            var str = keyVal[1].trim();
            switch (keyVal[0].trim()) {
              case "alt":
                alt = str;
                break;
              case "width":
                width = sizeData(str);
                break;
              case "height":
                height = sizeData(str);
                break;
              case "totalheight":
                totalheight = sizeData(str);
                break;
              default:
                throw new ParseError("Invalid key: '" + keyVal[0] + "' in \\includegraphics.");
            }
          }
        }
      }
      var src = assertNodeType(args[0], "url").url;
      if (alt === "") {
        alt = src;
        alt = alt.replace(/^.*[\\/]/, "");
        alt = alt.substring(0, alt.lastIndexOf("."));
      }
      if (!parser.settings.isTrusted({
        command: "\\includegraphics",
        url: src
      })) {
        return parser.formatUnsupportedCmd("\\includegraphics");
      }
      return {
        type: "includegraphics",
        mode: parser.mode,
        alt,
        width,
        height,
        totalheight,
        src
      };
    },
    htmlBuilder: (group, options) => {
      var height = calculateSize(group.height, options);
      var depth = 0;
      if (group.totalheight.number > 0) {
        depth = calculateSize(group.totalheight, options) - height;
      }
      var width = 0;
      if (group.width.number > 0) {
        width = calculateSize(group.width, options);
      }
      var style = {
        height: makeEm(height + depth)
      };
      if (width > 0) {
        style.width = makeEm(width);
      }
      if (depth > 0) {
        style.verticalAlign = makeEm(-depth);
      }
      var node = new Img(group.src, group.alt, style);
      node.height = height;
      node.depth = depth;
      return node;
    },
    mathmlBuilder: (group, options) => {
      var node = new MathNode("mglyph", []);
      node.setAttribute("alt", group.alt);
      var height = calculateSize(group.height, options);
      var depth = 0;
      if (group.totalheight.number > 0) {
        depth = calculateSize(group.totalheight, options) - height;
        node.setAttribute("valign", makeEm(-depth));
      }
      node.setAttribute("height", makeEm(height + depth));
      if (group.width.number > 0) {
        var width = calculateSize(group.width, options);
        node.setAttribute("width", makeEm(width));
      }
      node.setAttribute("src", group.src);
      return node;
    }
  });
  defineFunction({
    type: "kern",
    names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
    numArgs: 1,
    argTypes: ["size"],
    primitive: true,
    allowedInText: true,
    handler(_ref, args) {
      var parser = _ref.parser, funcName = _ref.funcName;
      var size = assertNodeType(args[0], "size");
      if (parser.settings.strict) {
        var mathFunction = funcName[1] === "m";
        var muUnit = size.value.unit === "mu";
        if (mathFunction) {
          if (!muUnit) {
            handleStrict({
              strict: parser.settings.strict,
              errorCode: "mathVsTextUnits",
              errorMsg: "LaTeX's " + funcName + " supports only mu units, " + ("not " + size.value.unit + " units"),
              report: true
            });
          }
          if (parser.mode !== "math") {
            handleStrict({
              strict: parser.settings.strict,
              errorCode: "mathVsTextUnits",
              errorMsg: "LaTeX's " + funcName + " works only in math mode",
              report: true
            });
          }
        } else {
          if (muUnit) {
            handleStrict({
              strict: parser.settings.strict,
              errorCode: "mathVsTextUnits",
              errorMsg: "LaTeX's " + funcName + " doesn't support mu units",
              report: true
            });
          }
        }
      }
      return {
        type: "kern",
        mode: parser.mode,
        dimension: size.value
      };
    },
    htmlBuilder(group, options) {
      return makeGlue(group.dimension, options);
    },
    mathmlBuilder(group, options) {
      var dimension = calculateSize(group.dimension, options);
      return new SpaceNode(dimension);
    }
  });
  defineFunction({
    type: "lap",
    names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
    numArgs: 1,
    allowedInText: true,
    handler: (_ref, args) => {
      var parser = _ref.parser, funcName = _ref.funcName;
      var body = args[0];
      return {
        type: "lap",
        mode: parser.mode,
        alignment: funcName.slice(5),
        body
      };
    },
    htmlBuilder: (group, options) => {
      var inner2;
      if (group.alignment === "clap") {
        inner2 = makeSpan([], [buildGroup$1(group.body, options)]);
        inner2 = makeSpan(["katex-inner"], [inner2], options);
      } else {
        inner2 = makeSpan(["katex-inner"], [buildGroup$1(group.body, options)]);
      }
      var fix = makeSpan(["katex-fix"], []);
      var node = makeSpan([group.alignment], [inner2, fix], options);
      var strut = makeSpan(["katex-strut"]);
      strut.style.height = makeEm(node.height + node.depth);
      if (node.depth) {
        strut.style.verticalAlign = makeEm(-node.depth);
      }
      node.children.unshift(strut);
      node = makeSpan(["katex-thinbox"], [node], options);
      return makeSpan(["mord", "katex-vbox"], [node], options);
    },
    mathmlBuilder: (group, options) => {
      var node = new MathNode("mpadded", [buildGroup2(group.body, options)]);
      if (group.alignment !== "rlap") {
        var offset = group.alignment === "llap" ? "-1" : "-0.5";
        node.setAttribute("lspace", offset + "width");
      }
      node.setAttribute("width", "0px");
      return node;
    }
  });
  defineFunction({
    type: "styling",
    names: ["\\(", "$"],
    numArgs: 0,
    allowedInText: true,
    allowedInMath: false,
    handler(_ref, args) {
      var funcName = _ref.funcName, parser = _ref.parser;
      var outerMode = parser.mode;
      parser.switchMode("math");
      var close2 = funcName === "\\(" ? "\\)" : "$";
      var body = parser.parseExpression(false, close2);
      parser.expect(close2);
      parser.switchMode(outerMode);
      return {
        type: "styling",
        mode: parser.mode,
        style: "text",
        resetFont: true,
        body
      };
    }
  });
  defineFunction({
    type: "text",
    // Doesn't matter what this is.
    names: ["\\)", "\\]"],
    numArgs: 0,
    allowedInText: true,
    allowedInMath: false,
    handler(context, args) {
      throw new ParseError("Mismatched " + context.funcName);
    }
  });
  var chooseMathStyle = (group, options) => {
    switch (options.style.size) {
      case Style$1.DISPLAY.size:
        return group.display;
      case Style$1.TEXT.size:
        return group.text;
      case Style$1.SCRIPT.size:
        return group.script;
      case Style$1.SCRIPTSCRIPT.size:
        return group.scriptscript;
      default:
        return group.text;
    }
  };
  defineFunction({
    type: "mathchoice",
    names: ["\\mathchoice"],
    numArgs: 4,
    primitive: true,
    handler: (_ref, args) => {
      var parser = _ref.parser;
      return {
        type: "mathchoice",
        mode: parser.mode,
        display: ordargument(args[0]),
        text: ordargument(args[1]),
        script: ordargument(args[2]),
        scriptscript: ordargument(args[3])
      };
    },
    htmlBuilder: (group, options) => {
      var body = chooseMathStyle(group, options);
      var elements = buildExpression$1(body, options, false);
      return makeFragment(elements);
    },
    mathmlBuilder: (group, options) => {
      var body = chooseMathStyle(group, options);
      return buildExpressionRow(body, options);
    }
  });
  var assembleSupSub = (base, supGroup, subGroup, options, style, slant, baseShift) => {
    base = makeSpan([], [base]);
    var subIsSingleCharacter = subGroup && isCharacterBox(subGroup);
    var sub2;
    var sup2;
    if (supGroup) {
      var elem = buildGroup$1(supGroup, options.havingStyle(style.sup()), options);
      sup2 = {
        elem,
        kern: Math.max(options.fontMetrics().bigOpSpacing1, options.fontMetrics().bigOpSpacing3 - elem.depth)
      };
    }
    if (subGroup) {
      var _elem = buildGroup$1(subGroup, options.havingStyle(style.sub()), options);
      sub2 = {
        elem: _elem,
        kern: Math.max(options.fontMetrics().bigOpSpacing2, options.fontMetrics().bigOpSpacing4 - _elem.height)
      };
    }
    var finalGroup;
    if (sup2 && sub2) {
      var bottom = options.fontMetrics().bigOpSpacing5 + sub2.elem.height + sub2.elem.depth + sub2.kern + base.depth + baseShift;
      finalGroup = makeVList({
        positionType: "bottom",
        positionData: bottom,
        children: [{
          type: "kern",
          size: options.fontMetrics().bigOpSpacing5
        }, {
          type: "elem",
          elem: sub2.elem,
          marginLeft: makeEm(-slant)
        }, {
          type: "kern",
          size: sub2.kern
        }, {
          type: "elem",
          elem: base
        }, {
          type: "kern",
          size: sup2.kern
        }, {
          type: "elem",
          elem: sup2.elem,
          marginLeft: makeEm(slant)
        }, {
          type: "kern",
          size: options.fontMetrics().bigOpSpacing5
        }]
      });
    } else if (sub2) {
      var top = base.height - baseShift;
      finalGroup = makeVList({
        positionType: "top",
        positionData: top,
        children: [{
          type: "kern",
          size: options.fontMetrics().bigOpSpacing5
        }, {
          type: "elem",
          elem: sub2.elem,
          marginLeft: makeEm(-slant)
        }, {
          type: "kern",
          size: sub2.kern
        }, {
          type: "elem",
          elem: base
        }]
      });
    } else if (sup2) {
      var _bottom = base.depth + baseShift;
      finalGroup = makeVList({
        positionType: "bottom",
        positionData: _bottom,
        children: [{
          type: "elem",
          elem: base
        }, {
          type: "kern",
          size: sup2.kern
        }, {
          type: "elem",
          elem: sup2.elem,
          marginLeft: makeEm(slant)
        }, {
          type: "kern",
          size: options.fontMetrics().bigOpSpacing5
        }]
      });
    } else {
      return base;
    }
    var parts = [finalGroup];
    if (sub2 && slant !== 0 && !subIsSingleCharacter) {
      var spacer = makeSpan(["mspace"], [], options);
      spacer.style.marginRight = makeEm(slant);
      parts.unshift(spacer);
    }
    return makeSpan(["mop", "op-limits"], parts, options);
  };
  var noSuccessor = /* @__PURE__ */ new Set(["\\smallint"]);
  var htmlBuilder$2 = (grp, options) => {
    var supGroup;
    var subGroup;
    var hasLimits = false;
    var group;
    if (grp.type === "supsub") {
      supGroup = grp.sup;
      subGroup = grp.sub;
      group = assertNodeType(grp.base, "op");
      hasLimits = true;
    } else {
      group = assertNodeType(grp, "op");
    }
    var style = options.style;
    var large = false;
    if (style.size === Style$1.DISPLAY.size && group.symbol && !noSuccessor.has(group.name)) {
      large = true;
    }
    var base;
    var symbolItalic;
    if (group.symbol) {
      var fontName = large ? "Size2-Regular" : "Size1-Regular";
      var stash = "";
      if (group.name === "\\oiint" || group.name === "\\oiiint") {
        stash = group.name.slice(1);
        group.name = stash === "oiint" ? "\\iint" : "\\iiint";
      }
      base = makeSymbol(group.name, fontName, "math", options, ["mop", "op-symbol", large ? "large-op" : "small-op"]);
      symbolItalic = base.italic;
      if (stash.length > 0) {
        var oval = staticSvg(stash + "Size" + (large ? "2" : "1"), options);
        base = makeVList({
          positionType: "individualShift",
          children: [{
            type: "elem",
            elem: base,
            shift: 0
          }, {
            type: "elem",
            elem: oval,
            shift: large ? 0.08 : 0
          }]
        });
        group.name = "\\" + stash;
        base.classes.unshift("mop");
        base.italic = symbolItalic;
      }
    } else if (group.body) {
      var inner2 = buildExpression$1(group.body, options, true);
      if (inner2.length === 1 && inner2[0] instanceof SymbolNode) {
        base = inner2[0];
        base.classes[0] = "mop";
      } else {
        base = makeSpan(["mop"], inner2, options);
      }
    } else {
      var output = [];
      for (var i3 = 1; i3 < group.name.length; i3++) {
        output.push(mathsym(group.name[i3], group.mode, options));
      }
      base = makeSpan(["mop"], output, options);
    }
    var baseShift = 0;
    var slant = 0;
    if ((base instanceof SymbolNode || group.name === "\\oiint" || group.name === "\\oiiint") && !group.suppressBaseShift) {
      var _base$italic;
      baseShift = (base.height - base.depth) / 2 - options.fontMetrics().axisHeight;
      slant = (_base$italic = base.italic) != null ? _base$italic : 0;
    }
    if (hasLimits) {
      return assembleSupSub(base, supGroup, subGroup, options, style, slant, baseShift);
    } else {
      if (baseShift) {
        base.style.position = "relative";
        base.style.top = makeEm(baseShift);
      }
      return base;
    }
  };
  var mathmlBuilder$1 = (group, options) => {
    var node;
    if (group.symbol) {
      node = new MathNode("mo", [makeText(group.name, group.mode)]);
      if (noSuccessor.has(group.name)) {
        node.setAttribute("largeop", "false");
      }
    } else if (group.body) {
      node = new MathNode("mo", buildExpression2(group.body, options));
    } else {
      node = new MathNode("mi", [new TextNode(group.name.slice(1))]);
      var operator = new MathNode("mo", [makeText("\u2061", "text")]);
      if (group.parentIsSupSub) {
        node = new MathNode("mrow", [node, operator]);
      } else {
        node = newDocumentFragment([node, operator]);
      }
    }
    return node;
  };
  var singleCharBigOps = {
    "\u220F": "\\prod",
    "\u2210": "\\coprod",
    "\u2211": "\\sum",
    "\u22C0": "\\bigwedge",
    "\u22C1": "\\bigvee",
    "\u22C2": "\\bigcap",
    "\u22C3": "\\bigcup",
    "\u2A00": "\\bigodot",
    "\u2A01": "\\bigoplus",
    "\u2A02": "\\bigotimes",
    "\u2A04": "\\biguplus",
    "\u2A06": "\\bigsqcup"
  };
  defineFunction({
    type: "op",
    names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "\u220F", "\u2210", "\u2211", "\u22C0", "\u22C1", "\u22C2", "\u22C3", "\u2A00", "\u2A01", "\u2A02", "\u2A04", "\u2A06"],
    numArgs: 0,
    handler: (_ref, args) => {
      var parser = _ref.parser, funcName = _ref.funcName;
      var fName = funcName;
      if (fName.length === 1) {
        fName = singleCharBigOps[fName];
      }
      return {
        type: "op",
        mode: parser.mode,
        limits: true,
        parentIsSupSub: false,
        symbol: true,
        name: fName
      };
    },
    htmlBuilder: htmlBuilder$2,
    mathmlBuilder: mathmlBuilder$1
  });
  defineFunction({
    type: "op",
    names: ["\\mathop"],
    numArgs: 1,
    primitive: true,
    handler: (_ref2, args) => {
      var parser = _ref2.parser;
      var body = args[0];
      return {
        type: "op",
        mode: parser.mode,
        limits: false,
        parentIsSupSub: false,
        symbol: false,
        body: ordargument(body)
      };
    }
  });
  var singleCharIntegrals = {
    "\u222B": "\\int",
    "\u222C": "\\iint",
    "\u222D": "\\iiint",
    "\u222E": "\\oint",
    "\u222F": "\\oiint",
    "\u2230": "\\oiiint"
  };
  defineFunction({
    type: "op",
    names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
    numArgs: 0,
    handler(_ref3) {
      var parser = _ref3.parser, funcName = _ref3.funcName;
      return {
        type: "op",
        mode: parser.mode,
        limits: false,
        parentIsSupSub: false,
        symbol: false,
        name: funcName
      };
    }
  });
  defineFunction({
    type: "op",
    names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
    numArgs: 0,
    handler(_ref4) {
      var parser = _ref4.parser, funcName = _ref4.funcName;
      return {
        type: "op",
        mode: parser.mode,
        limits: true,
        parentIsSupSub: false,
        symbol: false,
        name: funcName
      };
    }
  });
  defineFunction({
    type: "op",
    names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "\u222B", "\u222C", "\u222D", "\u222E", "\u222F", "\u2230"],
    numArgs: 0,
    allowedInArgument: true,
    handler(_ref5) {
      var parser = _ref5.parser, funcName = _ref5.funcName;
      var fName = funcName;
      if (fName.length === 1) {
        fName = singleCharIntegrals[fName];
      }
      return {
        type: "op",
        mode: parser.mode,
        limits: false,
        parentIsSupSub: false,
        symbol: true,
        name: fName
      };
    }
  });
  var htmlBuilder$1 = (grp, options) => {
    var supGroup;
    var subGroup;
    var hasLimits = false;
    var group;
    if (grp.type === "supsub") {
      supGroup = grp.sup;
      subGroup = grp.sub;
      group = assertNodeType(grp.base, "operatorname");
      hasLimits = true;
    } else {
      group = assertNodeType(grp, "operatorname");
    }
    var base;
    if (group.body.length > 0) {
      var body = group.body.map((child2) => {
        var childText = "text" in child2 ? child2.text : void 0;
        if (typeof childText === "string") {
          return {
            type: "textord",
            mode: child2.mode,
            text: childText
          };
        } else {
          return child2;
        }
      });
      var expression = buildExpression$1(body, options.withFont("mathrm"), true);
      for (var i3 = 0; i3 < expression.length; i3++) {
        var child = expression[i3];
        if (child instanceof SymbolNode) {
          child.text = child.text.replace(/\u2212/, "-").replace(/\u2217/, "*");
        }
      }
      base = makeSpan(["mop"], expression, options);
    } else {
      base = makeSpan(["mop"], [], options);
    }
    if (hasLimits) {
      return assembleSupSub(base, supGroup, subGroup, options, options.style, 0, 0);
    } else {
      return base;
    }
  };
  var mathmlBuilder2 = (group, options) => {
    var expression = buildExpression2(group.body, options.withFont("mathrm"));
    var isAllString = true;
    for (var i3 = 0; i3 < expression.length; i3++) {
      var node = expression[i3];
      if (node instanceof SpaceNode) ;
      else if (node instanceof MathNode) {
        switch (node.type) {
          case "mi":
          case "mn":
          case "mspace":
          case "mtext":
            break;
          case "mo": {
            var child = node.children[0];
            if (node.children.length === 1 && child instanceof TextNode) {
              child.text = child.text.replace(/\u2212/, "-").replace(/\u2217/, "*");
            } else {
              isAllString = false;
            }
            break;
          }
          default:
            isAllString = false;
        }
      } else {
        isAllString = false;
      }
    }
    if (isAllString) {
      var word = expression.map((node2) => node2.toText()).join("");
      expression = [new TextNode(word)];
    }
    var identifier = new MathNode("mi", expression);
    identifier.setAttribute("mathvariant", "normal");
    var operator = new MathNode("mo", [makeText("\u2061", "text")]);
    if (group.parentIsSupSub) {
      return new MathNode("mrow", [identifier, operator]);
    } else {
      return newDocumentFragment([identifier, operator]);
    }
  };
  defineFunction({
    type: "operatorname",
    names: ["\\operatorname@", "\\operatornamewithlimits"],
    numArgs: 1,
    handler: (_ref, args) => {
      var parser = _ref.parser, funcName = _ref.funcName;
      var body = args[0];
      return {
        type: "operatorname",
        mode: parser.mode,
        body: ordargument(body),
        alwaysHandleSupSub: funcName === "\\operatornamewithlimits",
        limits: false,
        parentIsSupSub: false
      };
    },
    htmlBuilder: htmlBuilder$1,
    mathmlBuilder: mathmlBuilder2
  });
  defineMacro("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@");
  defineFunctionBuilders({
    type: "ordgroup",
    htmlBuilder(group, options) {
      if (group.semisimple) {
        return makeFragment(buildExpression$1(group.body, options, false));
      }
      return makeSpan(["mord"], buildExpression$1(group.body, options, true), options);
    },
    mathmlBuilder(group, options) {
      return buildExpressionRow(group.body, options, true);
    }
  });
  defineFunction({
    type: "overline",
    names: ["\\overline"],
    numArgs: 1,
    handler(_ref, args) {
      var parser = _ref.parser;
      var body = args[0];
      return {
        type: "overline",
        mode: parser.mode,
        body
      };
    },
    htmlBuilder(group, options) {
      var innerGroup = buildGroup$1(group.body, options.havingCrampedStyle());
      var line = makeLineSpan("overline-line", options);
      var defaultRuleThickness = options.fontMetrics().defaultRuleThickness;
      var vlist = makeVList({
        positionType: "firstBaseline",
        children: [{
          type: "elem",
          elem: innerGroup
        }, {
          type: "kern",
          size: 3 * defaultRuleThickness
        }, {
          type: "elem",
          elem: line
        }, {
          type: "kern",
          size: defaultRuleThickness
        }]
      });
      return makeSpan(["mord", "katex-overline"], [vlist], options);
    },
    mathmlBuilder(group, options) {
      var operator = new MathNode("mo", [new TextNode("\u203E")]);
      operator.setAttribute("stretchy", "true");
      var node = new MathNode("mover", [buildGroup2(group.body, options), operator]);
      node.setAttribute("accent", "true");
      return node;
    }
  });
  defineFunction({
    type: "phantom",
    names: ["\\phantom"],
    numArgs: 1,
    allowedInText: true,
    handler: (_ref, args) => {
      var parser = _ref.parser;
      var body = args[0];
      return {
        type: "phantom",
        mode: parser.mode,
        body: ordargument(body)
      };
    },
    htmlBuilder: (group, options) => {
      var elements = buildExpression$1(group.body, options.withPhantom(), false);
      return makeFragment(elements);
    },
    mathmlBuilder: (group, options) => {
      var inner2 = buildExpression2(group.body, options);
      return new MathNode("mphantom", inner2);
    }
  });
  defineMacro("\\hphantom", "\\smash{\\phantom{#1}}");
  defineFunction({
    type: "vphantom",
    names: ["\\vphantom"],
    numArgs: 1,
    allowedInText: true,
    handler: (_ref2, args) => {
      var parser = _ref2.parser;
      var body = args[0];
      return {
        type: "vphantom",
        mode: parser.mode,
        body
      };
    },
    htmlBuilder: (group, options) => {
      var inner2 = makeSpan(["katex-inner"], [buildGroup$1(group.body, options.withPhantom())]);
      var fix = makeSpan(["katex-fix"], []);
      return makeSpan(["mord", "rlap"], [inner2, fix], options);
    },
    mathmlBuilder: (group, options) => {
      var inner2 = buildExpression2(ordargument(group.body), options);
      var phantom = new MathNode("mphantom", inner2);
      var node = new MathNode("mpadded", [phantom]);
      node.setAttribute("width", "0px");
      return node;
    }
  });
  defineFunction({
    type: "raisebox",
    names: ["\\raisebox"],
    numArgs: 2,
    argTypes: ["size", "hbox"],
    allowedInText: true,
    handler(_ref, args) {
      var parser = _ref.parser;
      var amount = assertNodeType(args[0], "size").value;
      var body = args[1];
      return {
        type: "raisebox",
        mode: parser.mode,
        dy: amount,
        body
      };
    },
    htmlBuilder(group, options) {
      var body = buildGroup$1(group.body, options);
      var dy = calculateSize(group.dy, options);
      return makeVList({
        positionType: "shift",
        positionData: -dy,
        children: [{
          type: "elem",
          elem: body
        }]
      });
    },
    mathmlBuilder(group, options) {
      var node = new MathNode("mpadded", [buildGroup2(group.body, options)]);
      var dy = group.dy.number + group.dy.unit;
      node.setAttribute("voffset", dy);
      return node;
    }
  });
  var handler = (_ref, args) => {
    var parser = _ref.parser;
    return {
      type: "reflectbox",
      mode: parser.mode,
      body: args[0]
    };
  };
  defineFunction({
    type: "reflectbox",
    names: ["\\reflectbox"],
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: true,
    handler,
    htmlBuilder(group, options) {
      return makeSpan(["mord", "reflectbox"], [buildGroup$1(group.body, options)], options);
    },
    mathmlBuilder(group, options) {
      return buildGroup2(group.body, options);
    }
  });
  defineFunction({
    type: "reflectbox",
    names: ["\\mathreflectbox"],
    numArgs: 1,
    argTypes: ["math"],
    handler
  });
  defineFunction({
    type: "internal",
    names: ["\\relax"],
    numArgs: 0,
    allowedInText: true,
    allowedInArgument: true,
    handler(_ref) {
      var parser = _ref.parser;
      return {
        type: "internal",
        mode: parser.mode
      };
    }
  });
  defineFunction({
    type: "rule",
    names: ["\\rule"],
    numArgs: 2,
    numOptionalArgs: 1,
    allowedInText: true,
    allowedInMath: true,
    argTypes: ["size", "size", "size"],
    handler(_ref, args, optArgs) {
      var parser = _ref.parser;
      var shift = optArgs[0];
      var width = assertNodeType(args[0], "size");
      var height = assertNodeType(args[1], "size");
      return {
        type: "rule",
        mode: parser.mode,
        shift: shift && assertNodeType(shift, "size").value,
        width: width.value,
        height: height.value
      };
    },
    htmlBuilder(group, options) {
      var rule = makeSpan(["mord", "katex-rule"], [], options);
      var width = calculateSize(group.width, options);
      var height = calculateSize(group.height, options);
      var shift = group.shift ? calculateSize(group.shift, options) : 0;
      rule.style.borderRightWidth = makeEm(width);
      rule.style.borderTopWidth = makeEm(height);
      rule.style.bottom = makeEm(shift);
      rule.width = width;
      rule.height = height + shift;
      rule.depth = -shift;
      rule.maxFontSize = height * 1.125 * options.sizeMultiplier;
      return rule;
    },
    mathmlBuilder(group, options) {
      var width = calculateSize(group.width, options);
      var height = calculateSize(group.height, options);
      var shift = group.shift ? calculateSize(group.shift, options) : 0;
      var color = options.color && options.getColor() || "black";
      var rule = new MathNode("mspace");
      rule.setAttribute("mathbackground", color);
      rule.setAttribute("width", makeEm(width));
      rule.setAttribute("height", makeEm(height));
      var wrapper = new MathNode("mpadded", [rule]);
      if (shift >= 0) {
        wrapper.setAttribute("height", makeEm(shift));
      } else {
        wrapper.setAttribute("height", makeEm(shift));
        wrapper.setAttribute("depth", makeEm(-shift));
      }
      wrapper.setAttribute("voffset", makeEm(shift));
      return wrapper;
    }
  });
  function sizingGroup(value, options, baseOptions) {
    var inner2 = buildExpression$1(value, options, false);
    var multiplier = options.sizeMultiplier / baseOptions.sizeMultiplier;
    for (var i3 = 0; i3 < inner2.length; i3++) {
      var pos = inner2[i3].classes.indexOf("katex-sizing");
      if (pos < 0) {
        Array.prototype.push.apply(inner2[i3].classes, options.sizingClasses(baseOptions));
      } else if (inner2[i3].classes[pos + 1] === "reset-size" + options.size) {
        inner2[i3].classes[pos + 1] = "reset-size" + baseOptions.size;
      }
      inner2[i3].height *= multiplier;
      inner2[i3].depth *= multiplier;
    }
    return makeFragment(inner2);
  }
  var sizeFuncs = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"];
  var htmlBuilder2 = (group, options) => {
    var newOptions = options.havingSize(group.size);
    return sizingGroup(group.body, newOptions, options);
  };
  defineFunction({
    type: "sizing",
    names: sizeFuncs,
    numArgs: 0,
    allowedInText: true,
    handler: (_ref, args) => {
      var breakOnTokenText = _ref.breakOnTokenText, funcName = _ref.funcName, parser = _ref.parser;
      var body = parser.parseExpression(false, breakOnTokenText);
      return {
        type: "sizing",
        mode: parser.mode,
        // Figure out what size to use based on the list of functions above
        size: sizeFuncs.indexOf(funcName) + 1,
        body
      };
    },
    htmlBuilder: htmlBuilder2,
    mathmlBuilder: (group, options) => {
      var newOptions = options.havingSize(group.size);
      var inner2 = buildExpression2(group.body, newOptions);
      var node = new MathNode("mstyle", inner2);
      node.setAttribute("mathsize", makeEm(newOptions.sizeMultiplier));
      return node;
    }
  });
  defineFunction({
    type: "smash",
    names: ["\\smash"],
    numArgs: 1,
    numOptionalArgs: 1,
    allowedInText: true,
    handler: (_ref, args, optArgs) => {
      var parser = _ref.parser;
      var smashHeight = false;
      var smashDepth = false;
      var tbArg = optArgs[0] && assertNodeType(optArgs[0], "ordgroup");
      if (tbArg) {
        var letter;
        for (var i3 = 0; i3 < tbArg.body.length; ++i3) {
          var node = tbArg.body[i3];
          letter = assertSymbolNodeType(node).text;
          if (letter === "t") {
            smashHeight = true;
          } else if (letter === "b") {
            smashDepth = true;
          } else {
            smashHeight = false;
            smashDepth = false;
            break;
          }
        }
      } else {
        smashHeight = true;
        smashDepth = true;
      }
      var body = args[0];
      return {
        type: "smash",
        mode: parser.mode,
        body,
        smashHeight,
        smashDepth
      };
    },
    htmlBuilder: (group, options) => {
      var node = makeSpan([], [buildGroup$1(group.body, options)]);
      if (!group.smashHeight && !group.smashDepth) {
        return node;
      }
      if (group.smashHeight) {
        node.height = 0;
      }
      if (group.smashDepth) {
        node.depth = 0;
      }
      if (group.smashHeight && group.smashDepth) {
        return makeSpan(["mord", "katex-smash"], [node], options);
      }
      if (node.children) {
        for (var i3 = 0; i3 < node.children.length; i3++) {
          if (group.smashHeight) {
            node.children[i3].height = 0;
          }
          if (group.smashDepth) {
            node.children[i3].depth = 0;
          }
        }
      }
      var smashedNode = makeVList({
        positionType: "firstBaseline",
        children: [{
          type: "elem",
          elem: node
        }]
      });
      return makeSpan(["mord"], [smashedNode], options);
    },
    mathmlBuilder: (group, options) => {
      var node = new MathNode("mpadded", [buildGroup2(group.body, options)]);
      if (group.smashHeight) {
        node.setAttribute("height", "0px");
      }
      if (group.smashDepth) {
        node.setAttribute("depth", "0px");
      }
      return node;
    }
  });
  defineFunction({
    type: "sqrt",
    names: ["\\sqrt"],
    numArgs: 1,
    numOptionalArgs: 1,
    handler(_ref, args, optArgs) {
      var parser = _ref.parser;
      var index = optArgs[0];
      var body = args[0];
      return {
        type: "sqrt",
        mode: parser.mode,
        body,
        index
      };
    },
    htmlBuilder(group, options) {
      var inner2 = buildGroup$1(group.body, options.havingCrampedStyle());
      if (inner2.height === 0) {
        inner2.height = options.fontMetrics().xHeight;
      }
      inner2 = wrapFragment(inner2, options);
      var metrics = options.fontMetrics();
      var theta = metrics.defaultRuleThickness;
      var phi = theta;
      if (options.style.id < Style$1.TEXT.id) {
        phi = options.fontMetrics().xHeight;
      }
      var lineClearance = theta + phi / 4;
      var minDelimiterHeight = inner2.height + inner2.depth + lineClearance + theta;
      var _makeSqrtImage = makeSqrtImage(minDelimiterHeight, options), img = _makeSqrtImage.span, ruleWidth = _makeSqrtImage.ruleWidth, advanceWidth = _makeSqrtImage.advanceWidth;
      var delimDepth = img.height - ruleWidth;
      if (delimDepth > inner2.height + inner2.depth + lineClearance) {
        lineClearance = (lineClearance + delimDepth - inner2.height - inner2.depth) / 2;
      }
      var imgShift = img.height - inner2.height - lineClearance - ruleWidth;
      inner2.style.paddingLeft = makeEm(advanceWidth);
      var body = makeVList({
        positionType: "firstBaseline",
        children: [{
          type: "elem",
          elem: inner2,
          wrapperClasses: ["svg-align"]
        }, {
          type: "kern",
          size: -(inner2.height + imgShift)
        }, {
          type: "elem",
          elem: img
        }, {
          type: "kern",
          size: ruleWidth
        }]
      });
      if (!group.index) {
        return makeSpan(["mord", "sqrt"], [body], options);
      } else {
        var newOptions = options.havingStyle(Style$1.SCRIPTSCRIPT);
        var rootm = buildGroup$1(group.index, newOptions, options);
        var toShift = 0.6 * (body.height - body.depth);
        var rootVList = makeVList({
          positionType: "shift",
          positionData: -toShift,
          children: [{
            type: "elem",
            elem: rootm
          }]
        });
        var rootVListWrap = makeSpan(["katex-root"], [rootVList]);
        return makeSpan(["mord", "sqrt"], [rootVListWrap, body], options);
      }
    },
    mathmlBuilder(group, options) {
      var body = group.body, index = group.index;
      return index ? new MathNode("mroot", [buildGroup2(body, options), buildGroup2(index, options)]) : new MathNode("msqrt", [buildGroup2(body, options)]);
    }
  });
  var styleMap = {
    "display": Style$1.DISPLAY,
    "text": Style$1.TEXT,
    "script": Style$1.SCRIPT,
    "scriptscript": Style$1.SCRIPTSCRIPT
  };
  function isStyleStr(s3) {
    return s3 in styleMap;
  }
  defineFunction({
    type: "styling",
    names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
    numArgs: 0,
    allowedInText: true,
    primitive: true,
    handler(_ref, args) {
      var breakOnTokenText = _ref.breakOnTokenText, funcName = _ref.funcName, parser = _ref.parser;
      var body = parser.parseExpression(true, breakOnTokenText);
      var style = funcName.slice(1, funcName.length - 5);
      if (!isStyleStr(style)) {
        throw new Error("Unknown style: " + style);
      }
      return {
        type: "styling",
        mode: parser.mode,
        // Figure out what style to use by pulling out the style from
        // the function name
        style,
        body
      };
    },
    htmlBuilder(group, options) {
      var newStyle = styleMap[group.style];
      var newOptions = options.havingStyle(newStyle);
      if (group.resetFont) {
        newOptions = newOptions.withFont("");
      }
      return sizingGroup(group.body, newOptions, options);
    },
    mathmlBuilder(group, options) {
      var newStyle = styleMap[group.style];
      var newOptions = options.havingStyle(newStyle);
      if (group.resetFont) {
        newOptions = newOptions.withFont("");
      }
      var inner2 = buildExpression2(group.body, newOptions);
      var node = new MathNode("mstyle", inner2);
      var styleAttributes = {
        "display": ["0", "true"],
        "text": ["0", "false"],
        "script": ["1", "false"],
        "scriptscript": ["2", "false"]
      };
      var attr = styleAttributes[group.style];
      node.setAttribute("scriptlevel", attr[0]);
      node.setAttribute("displaystyle", attr[1]);
      return node;
    }
  });
  var htmlBuilderDelegate = function htmlBuilderDelegate2(group, options) {
    var base = group.base;
    if (!base) {
      return null;
    } else if (base.type === "op") {
      var delegate = base.limits && (options.style.size === Style$1.DISPLAY.size || base.alwaysHandleSupSub);
      return delegate ? htmlBuilder$2 : null;
    } else if (base.type === "operatorname") {
      var _delegate = base.alwaysHandleSupSub && (options.style.size === Style$1.DISPLAY.size || base.limits);
      return _delegate ? htmlBuilder$1 : null;
    } else if (base.type === "accent") {
      return isCharacterBox(base.base) ? htmlBuilder$a : null;
    } else if (base.type === "horizBrace") {
      var isSup = !group.sub;
      return isSup === base.isOver ? htmlBuilder$3 : null;
    } else {
      return null;
    }
  };
  defineFunctionBuilders({
    type: "supsub",
    htmlBuilder(group, options) {
      var builderDelegate = htmlBuilderDelegate(group, options);
      if (builderDelegate) {
        return builderDelegate(group, options);
      }
      var valueBase = group.base, valueSup = group.sup, valueSub = group.sub;
      var base = buildGroup$1(valueBase, options);
      var supm;
      var subm;
      var metrics = options.fontMetrics();
      var supShift = 0;
      var subShift = 0;
      var isCharBox = valueBase && isCharacterBox(valueBase);
      if (valueSup) {
        var newOptions = options.havingStyle(options.style.sup());
        supm = buildGroup$1(valueSup, newOptions, options);
        if (!isCharBox) {
          supShift = base.height - newOptions.fontMetrics().supDrop * newOptions.sizeMultiplier / options.sizeMultiplier;
        }
      }
      if (valueSub) {
        var _newOptions = options.havingStyle(options.style.sub());
        subm = buildGroup$1(valueSub, _newOptions, options);
        if (!isCharBox) {
          subShift = base.depth + _newOptions.fontMetrics().subDrop * _newOptions.sizeMultiplier / options.sizeMultiplier;
        }
      }
      var minSupShift;
      if (options.style === Style$1.DISPLAY) {
        minSupShift = metrics.sup1;
      } else if (options.style.cramped) {
        minSupShift = metrics.sup3;
      } else {
        minSupShift = metrics.sup2;
      }
      var multiplier = options.sizeMultiplier;
      var marginRight = makeEm(0.5 / metrics.ptPerEm / multiplier);
      var marginLeft = null;
      if (subm) {
        var isOiint = group.base && group.base.type === "op" && group.base.name && (group.base.name === "\\oiint" || group.base.name === "\\oiiint");
        if (base instanceof SymbolNode || isOiint) {
          var _base$italic;
          marginLeft = makeEm(-((_base$italic = base.italic) != null ? _base$italic : 0));
        }
      }
      var supsub;
      if (supm && subm) {
        supShift = Math.max(supShift, minSupShift, supm.depth + 0.25 * metrics.xHeight);
        subShift = Math.max(subShift, metrics.sub2);
        var ruleWidth = metrics.defaultRuleThickness;
        var maxWidth = 4 * ruleWidth;
        if (supShift - supm.depth - (subm.height - subShift) < maxWidth) {
          subShift = maxWidth - (supShift - supm.depth) + subm.height;
          var psi = 0.8 * metrics.xHeight - (supShift - supm.depth);
          if (psi > 0) {
            supShift += psi;
            subShift -= psi;
          }
        }
        var vlistElem = [{
          type: "elem",
          elem: subm,
          shift: subShift,
          marginRight,
          marginLeft
        }, {
          type: "elem",
          elem: supm,
          shift: -supShift,
          marginRight
        }];
        supsub = makeVList({
          positionType: "individualShift",
          children: vlistElem
        });
      } else if (subm) {
        subShift = Math.max(subShift, metrics.sub1, subm.height - 0.8 * metrics.xHeight);
        var _vlistElem = [{
          type: "elem",
          elem: subm,
          marginLeft,
          marginRight
        }];
        supsub = makeVList({
          positionType: "shift",
          positionData: subShift,
          children: _vlistElem
        });
      } else if (supm) {
        supShift = Math.max(supShift, minSupShift, supm.depth + 0.25 * metrics.xHeight);
        supsub = makeVList({
          positionType: "shift",
          positionData: -supShift,
          children: [{
            type: "elem",
            elem: supm,
            marginRight
          }]
        });
      } else {
        throw new Error("supsub must have either sup or sub.");
      }
      var mclass = getTypeOfDomTree(base, "right") || "mord";
      return makeSpan([mclass], [base, makeSpan(["msupsub"], [supsub])], options);
    },
    mathmlBuilder(group, options) {
      var isBrace = false;
      var isOver;
      var isSup;
      if (group.base && group.base.type === "horizBrace") {
        isSup = !!group.sup;
        if (isSup === group.base.isOver) {
          isBrace = true;
          isOver = group.base.isOver;
        }
      }
      if (group.base && (group.base.type === "op" || group.base.type === "operatorname")) {
        group.base.parentIsSupSub = true;
      }
      var children = [buildGroup2(group.base, options)];
      if (group.sub) {
        children.push(buildGroup2(group.sub, options));
      }
      if (group.sup) {
        children.push(buildGroup2(group.sup, options));
      }
      var nodeType;
      if (isBrace) {
        nodeType = isOver ? "mover" : "munder";
      } else if (!group.sub) {
        var base = group.base;
        if (base && base.type === "op" && base.limits && (options.style === Style$1.DISPLAY || base.alwaysHandleSupSub)) {
          nodeType = "mover";
        } else if (base && base.type === "operatorname" && base.alwaysHandleSupSub && (base.limits || options.style === Style$1.DISPLAY)) {
          nodeType = "mover";
        } else {
          nodeType = "msup";
        }
      } else if (!group.sup) {
        var _base = group.base;
        if (_base && _base.type === "op" && _base.limits && (options.style === Style$1.DISPLAY || _base.alwaysHandleSupSub)) {
          nodeType = "munder";
        } else if (_base && _base.type === "operatorname" && _base.alwaysHandleSupSub && (_base.limits || options.style === Style$1.DISPLAY)) {
          nodeType = "munder";
        } else {
          nodeType = "msub";
        }
      } else {
        var _base2 = group.base;
        if (_base2 && _base2.type === "op" && _base2.limits && options.style === Style$1.DISPLAY) {
          nodeType = "munderover";
        } else if (_base2 && _base2.type === "operatorname" && _base2.alwaysHandleSupSub && (options.style === Style$1.DISPLAY || _base2.limits)) {
          nodeType = "munderover";
        } else {
          nodeType = "msubsup";
        }
      }
      return new MathNode(nodeType, children);
    }
  });
  defineFunctionBuilders({
    type: "atom",
    htmlBuilder(group, options) {
      return mathsym(group.text, group.mode, options, ["m" + group.family]);
    },
    mathmlBuilder(group, options) {
      var node = new MathNode("mo", [makeText(group.text, group.mode)]);
      if (group.family === "bin") {
        var variant = getVariant(group, options);
        if (variant === "bold-italic") {
          node.setAttribute("mathvariant", variant);
        }
      } else if (group.family === "punct") {
        node.setAttribute("separator", "true");
      } else if (group.family === "open" || group.family === "close") {
        node.setAttribute("stretchy", "false");
      }
      return node;
    }
  });
  var defaultVariant = {
    "mi": "italic",
    "mn": "normal",
    "mtext": "normal"
  };
  defineFunctionBuilders({
    type: "mathord",
    htmlBuilder(group, options) {
      return makeOrd(group, options);
    },
    mathmlBuilder(group, options) {
      var node = new MathNode("mi", [makeText(group.text, group.mode, options)]);
      var variant = getVariant(group, options) || "italic";
      if (variant !== defaultVariant[node.type]) {
        node.setAttribute("mathvariant", variant);
      }
      return node;
    }
  });
  defineFunctionBuilders({
    type: "textord",
    htmlBuilder(group, options) {
      return makeOrd(group, options);
    },
    mathmlBuilder(group, options) {
      var text2 = makeText(group.text, group.mode, options);
      var variant = getVariant(group, options) || "normal";
      var node;
      if (group.mode === "text") {
        node = new MathNode("mtext", [text2]);
      } else if (/[0-9]/.test(group.text)) {
        node = new MathNode("mn", [text2]);
      } else if (group.text === "\\prime") {
        node = new MathNode("mo", [text2]);
      } else {
        node = new MathNode("mi", [text2]);
      }
      if (variant !== defaultVariant[node.type]) {
        node.setAttribute("mathvariant", variant);
      }
      return node;
    }
  });
  var cssSpace = /* @__PURE__ */ new Map([["\\nobreak", "nobreak"], ["\\allowbreak", "allowbreak"]]);
  var regularSpace = /* @__PURE__ */ new Map([[" ", {}], ["\\ ", {}], ["~", {
    className: "nobreak"
  }], ["\\space", {}], ["\\nobreakspace", {
    className: "nobreak"
  }]]);
  defineFunctionBuilders({
    type: "spacing",
    htmlBuilder(group, options) {
      var regularSpaceItem = regularSpace.get(group.text);
      var cssSpaceClass = cssSpace.get(group.text);
      if (regularSpaceItem) {
        var className = regularSpaceItem.className || "";
        if (group.mode === "text") {
          var ord = makeOrd(group, options);
          ord.classes.push(className);
          return ord;
        } else {
          return makeSpan(["mspace", className], [mathsym(group.text, group.mode, options)], options);
        }
      } else if (cssSpaceClass) {
        return makeSpan(["mspace", cssSpaceClass], [], options);
      } else {
        throw new ParseError('Unknown type of space "' + group.text + '"');
      }
    },
    mathmlBuilder(group, options) {
      var node;
      if (regularSpace.has(group.text)) {
        node = new MathNode("mtext", [new TextNode("\xA0")]);
      } else if (cssSpace.has(group.text)) {
        return new MathNode("mspace");
      } else {
        throw new ParseError('Unknown type of space "' + group.text + '"');
      }
      return node;
    }
  });
  var pad = () => {
    var padNode = new MathNode("mtd", []);
    padNode.setAttribute("width", "50%");
    return padNode;
  };
  defineFunctionBuilders({
    type: "tag",
    mathmlBuilder(group, options) {
      var table = new MathNode("mtable", [new MathNode("mtr", [pad(), new MathNode("mtd", [buildExpressionRow(group.body, options)]), pad(), new MathNode("mtd", [buildExpressionRow(group.tag, options)])])]);
      table.setAttribute("width", "100%");
      return table;
    }
  });
  var textFontFamilies = {
    "\\text": void 0,
    "\\textrm": "textrm",
    "\\textsf": "textsf",
    "\\texttt": "texttt",
    "\\textnormal": "textrm"
  };
  var textFontWeights = {
    "\\textbf": "textbf",
    "\\textmd": "textmd"
  };
  var textFontShapes = {
    "\\textit": "textit",
    "\\textup": "textup"
  };
  var optionsWithFont = (group, options) => {
    var font = group.font;
    if (!font) {
      return options;
    } else if (textFontFamilies[font]) {
      return options.withTextFontFamily(textFontFamilies[font]);
    } else if (textFontWeights[font]) {
      return options.withTextFontWeight(textFontWeights[font]);
    } else if (font === "\\emph") {
      return options.fontShape === "textit" ? options.withTextFontShape("textup") : options.withTextFontShape("textit");
    }
    return options.withTextFontShape(textFontShapes[font]);
  };
  defineFunction({
    type: "text",
    names: [
      // Font families
      "\\text",
      "\\textrm",
      "\\textsf",
      "\\texttt",
      "\\textnormal",
      // Font weights
      "\\textbf",
      "\\textmd",
      // Font Shapes
      "\\textit",
      "\\textup",
      "\\emph"
    ],
    numArgs: 1,
    argTypes: ["text"],
    allowedInArgument: true,
    allowedInText: true,
    handler(_ref, args) {
      var parser = _ref.parser, funcName = _ref.funcName;
      var body = args[0];
      return {
        type: "text",
        mode: parser.mode,
        body: ordargument(body),
        font: funcName
      };
    },
    htmlBuilder(group, options) {
      var newOptions = optionsWithFont(group, options);
      var inner2 = buildExpression$1(group.body, newOptions, true);
      return makeSpan(["mord", "text"], inner2, newOptions);
    },
    mathmlBuilder(group, options) {
      var newOptions = optionsWithFont(group, options);
      return buildExpressionRow(group.body, newOptions);
    }
  });
  defineFunction({
    type: "underline",
    names: ["\\underline"],
    numArgs: 1,
    allowedInText: true,
    handler(_ref, args) {
      var parser = _ref.parser;
      return {
        type: "underline",
        mode: parser.mode,
        body: args[0]
      };
    },
    htmlBuilder(group, options) {
      var innerGroup = buildGroup$1(group.body, options);
      var line = makeLineSpan("underline-line", options);
      var defaultRuleThickness = options.fontMetrics().defaultRuleThickness;
      var vlist = makeVList({
        positionType: "top",
        positionData: innerGroup.height,
        children: [{
          type: "kern",
          size: defaultRuleThickness
        }, {
          type: "elem",
          elem: line
        }, {
          type: "kern",
          size: 3 * defaultRuleThickness
        }, {
          type: "elem",
          elem: innerGroup
        }]
      });
      return makeSpan(["mord", "katex-underline"], [vlist], options);
    },
    mathmlBuilder(group, options) {
      var operator = new MathNode("mo", [new TextNode("\u203E")]);
      operator.setAttribute("stretchy", "true");
      var node = new MathNode("munder", [buildGroup2(group.body, options), operator]);
      node.setAttribute("accentunder", "true");
      return node;
    }
  });
  defineFunction({
    type: "vcenter",
    names: ["\\vcenter"],
    numArgs: 1,
    argTypes: ["original"],
    // In LaTeX, \vcenter can act only on a box.
    allowedInText: false,
    handler(_ref, args) {
      var parser = _ref.parser;
      return {
        type: "vcenter",
        mode: parser.mode,
        body: args[0]
      };
    },
    htmlBuilder(group, options) {
      var body = buildGroup$1(group.body, options);
      var axisHeight = options.fontMetrics().axisHeight;
      var dy = 0.5 * (body.height - axisHeight - (body.depth + axisHeight));
      return makeVList({
        positionType: "shift",
        positionData: dy,
        children: [{
          type: "elem",
          elem: body
        }]
      });
    },
    mathmlBuilder(group, options) {
      var mpadded = new MathNode("mpadded", [buildGroup2(group.body, options)], ["vcenter"]);
      return new MathNode("mrow", [mpadded]);
    }
  });
  defineFunction({
    type: "verb",
    names: ["\\verb"],
    numArgs: 0,
    allowedInText: true,
    handler(context, args, optArgs) {
      throw new ParseError("\\verb ended by end of line instead of matching delimiter");
    },
    htmlBuilder(group, options) {
      var text2 = makeVerb(group);
      var body = [];
      var newOptions = options.havingStyle(options.style.text());
      for (var i3 = 0; i3 < text2.length; i3++) {
        var c3 = text2[i3];
        if (c3 === "~") {
          c3 = "\\textasciitilde";
        }
        body.push(makeSymbol(c3, "Typewriter-Regular", group.mode, newOptions, ["mord", "texttt"]));
      }
      return makeSpan(["mord", "text"].concat(newOptions.sizingClasses(options)), tryCombineChars(body), newOptions);
    },
    mathmlBuilder(group, options) {
      var text2 = new TextNode(makeVerb(group));
      var node = new MathNode("mtext", [text2]);
      node.setAttribute("mathvariant", "monospace");
      return node;
    }
  });
  var makeVerb = (group) => group.body.replace(/ /g, group.star ? "\u2423" : "\xA0");
  var functions = _functions;
  var spaceRegexString = "[ \r\n	]";
  var controlWordRegexString = "\\\\[a-zA-Z@]+";
  var controlSymbolRegexString = "\\\\[^\uD800-\uDFFF]";
  var controlWordWhitespaceRegexString = "(" + controlWordRegexString + ")" + spaceRegexString + "*";
  var controlSpaceRegexString = "\\\\(\n|[ \r	]+\n?)[ \r	]*";
  var combiningDiacriticalMarkString = "[\u0300-\u036F]";
  var combiningDiacriticalMarksEndRegex = new RegExp(combiningDiacriticalMarkString + "+$");
  var tokenRegexString = "(" + spaceRegexString + "+)|" + // whitespace
  (controlSpaceRegexString + "|") + // \whitespace
  "([!-\\[\\]-\u2027\u202A-\uD7FF\uF900-\uFFFF]" + // single codepoint
  (combiningDiacriticalMarkString + "*") + // ...plus accents
  "|[\uD800-\uDBFF][\uDC00-\uDFFF]" + // surrogate pair
  (combiningDiacriticalMarkString + "*") + // ...plus accents
  "|\\\\verb\\*([^]).*?\\4|\\\\verb([^*a-zA-Z]).*?\\5" + // \verb unstarred
  ("|" + controlWordWhitespaceRegexString) + // \macroName + spaces
  ("|" + controlSymbolRegexString + ")");
  var Lexer = class {
    constructor(input, settings) {
      this.input = void 0;
      this.settings = void 0;
      this.tokenRegex = void 0;
      this.catcodes = void 0;
      this.input = input;
      this.settings = settings;
      this.tokenRegex = new RegExp(tokenRegexString, "g");
      this.catcodes = {
        "%": 14,
        // comment character
        "~": 13
        // active character
      };
    }
    setCatcode(char, code) {
      this.catcodes[char] = code;
    }
    /**
     * This function lexes a single token.
     */
    lex() {
      var input = this.input;
      var pos = this.tokenRegex.lastIndex;
      if (pos === input.length) {
        return new Token("EOF", new SourceLocation(this, pos, pos));
      }
      var match = this.tokenRegex.exec(input);
      if (match === null || match.index !== pos) {
        throw new ParseError("Unexpected character: '" + input[pos] + "'", new Token(input[pos], new SourceLocation(this, pos, pos + 1)));
      }
      var text2 = match[6] || match[3] || (match[2] ? "\\ " : " ");
      if (this.catcodes[text2] === 14) {
        var nlIndex = input.indexOf("\n", this.tokenRegex.lastIndex);
        if (nlIndex === -1) {
          this.tokenRegex.lastIndex = input.length;
          handleStrict({
            strict: this.settings.strict,
            errorCode: "commentAtEnd",
            errorMsg: "% comment has no terminating newline; LaTeX would fail because of commenting the end of math mode (e.g. $)",
            report: true
          });
        } else {
          this.tokenRegex.lastIndex = nlIndex + 1;
        }
        return this.lex();
      }
      return new Token(text2, new SourceLocation(this, pos, this.tokenRegex.lastIndex));
    }
  };
  var Namespace = class {
    /**
     * Both arguments are optional.  The first argument is an object of
     * built-in mappings which never change.  The second argument is an object
     * of initial (global-level) mappings, which will constantly change
     * according to any global/top-level `set`s done.
     */
    constructor(builtins, globalMacros) {
      if (builtins === void 0) {
        builtins = {};
      }
      if (globalMacros === void 0) {
        globalMacros = {};
      }
      this.current = void 0;
      this.builtins = void 0;
      this.undefStack = void 0;
      this.current = globalMacros;
      this.builtins = builtins;
      this.undefStack = [];
    }
    /**
     * Start a new nested group, affecting future local `set`s.
     */
    beginGroup() {
      this.undefStack.push({});
    }
    /**
     * End current nested group, restoring values before the group began.
     */
    endGroup() {
      if (this.undefStack.length === 0) {
        throw new ParseError("Unbalanced namespace destruction: attempt to pop global namespace; please report this as a bug");
      }
      var undefs = this.undefStack.pop();
      for (var key of Object.keys(undefs)) {
        if (undefs[key] === void 0) {
          delete this.current[key];
        } else {
          this.current[key] = undefs[key];
        }
      }
    }
    /**
     * Ends all currently nested groups (if any), restoring values before the
     * groups began.  Useful in case of an error in the middle of parsing.
     */
    endGroups() {
      while (this.undefStack.length > 0) {
        this.endGroup();
      }
    }
    /**
     * Detect whether `name` has a definition.  Equivalent to
     * `get(name) != null`.
     */
    has(name) {
      return Object.prototype.hasOwnProperty.call(this.current, name) || Object.prototype.hasOwnProperty.call(this.builtins, name);
    }
    /**
     * Get the current value of a name, or `undefined` if there is no value.
     *
     * Note: Do not use `if (namespace.get(...))` to detect whether a macro
     * is defined, as the definition may be the empty string which evaluates
     * to `false` in JavaScript.  Use `if (namespace.get(...) != null)` or
     * `if (namespace.has(...))`.
     */
    get(name) {
      if (Object.prototype.hasOwnProperty.call(this.current, name)) {
        return this.current[name];
      } else if (Object.prototype.hasOwnProperty.call(this.builtins, name)) {
        return this.builtins[name];
      } else {
        return void 0;
      }
    }
    /**
     * Set the current value of a name, and optionally set it globally too.
     * Local set() sets the current value and (when appropriate) adds an undo
     * operation to the undo stack.  Global set() may change the undo
     * operation at every level, so takes time linear in their number.
     * A value of undefined means to delete existing definitions.
     */
    set(name, value, global) {
      if (global === void 0) {
        global = false;
      }
      if (global) {
        for (var i3 = 0; i3 < this.undefStack.length; i3++) {
          delete this.undefStack[i3][name];
        }
        if (this.undefStack.length > 0) {
          this.undefStack[this.undefStack.length - 1][name] = value;
        }
      } else {
        var top = this.undefStack[this.undefStack.length - 1];
        if (top && !Object.prototype.hasOwnProperty.call(top, name)) {
          top[name] = Object.prototype.hasOwnProperty.call(this.current, name) ? this.current[name] : void 0;
        }
      }
      if (value == null) {
        delete this.current[name];
      } else {
        this.current[name] = value;
      }
    }
  };
  var macros = _macros;
  defineMacro("\\noexpand", function(context) {
    var t3 = context.popToken();
    if (context.isExpandable(t3.text)) {
      t3.noexpand = true;
      t3.treatAsRelax = true;
    }
    return {
      tokens: [t3],
      numArgs: 0
    };
  });
  defineMacro("\\expandafter", function(context) {
    var t3 = context.popToken();
    context.expandOnce(true);
    return {
      tokens: [t3],
      numArgs: 0
    };
  });
  defineMacro("\\@firstoftwo", function(context) {
    var args = context.consumeArgs(2);
    return {
      tokens: args[0],
      numArgs: 0
    };
  });
  defineMacro("\\@secondoftwo", function(context) {
    var args = context.consumeArgs(2);
    return {
      tokens: args[1],
      numArgs: 0
    };
  });
  defineMacro("\\@ifnextchar", function(context) {
    var args = context.consumeArgs(3);
    context.consumeSpaces();
    var nextToken = context.future();
    if (args[0].length === 1 && args[0][0].text === nextToken.text) {
      return {
        tokens: args[1],
        numArgs: 0
      };
    } else {
      return {
        tokens: args[2],
        numArgs: 0
      };
    }
  });
  defineMacro("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
  defineMacro("\\TextOrMath", function(context) {
    var args = context.consumeArgs(2);
    if (context.mode === "text") {
      return {
        tokens: args[0],
        numArgs: 0
      };
    } else {
      return {
        tokens: args[1],
        numArgs: 0
      };
    }
  });
  var digitToNumber = {
    "0": 0,
    "1": 1,
    "2": 2,
    "3": 3,
    "4": 4,
    "5": 5,
    "6": 6,
    "7": 7,
    "8": 8,
    "9": 9,
    "a": 10,
    "A": 10,
    "b": 11,
    "B": 11,
    "c": 12,
    "C": 12,
    "d": 13,
    "D": 13,
    "e": 14,
    "E": 14,
    "f": 15,
    "F": 15
  };
  defineMacro("\\char", function(context) {
    var token = context.popToken();
    var base;
    var number = 0;
    if (token.text === "'") {
      base = 8;
      token = context.popToken();
    } else if (token.text === '"') {
      base = 16;
      token = context.popToken();
    } else if (token.text === "`") {
      token = context.popToken();
      if (token.text[0] === "\\") {
        number = token.text.charCodeAt(1);
      } else if (token.text === "EOF") {
        throw new ParseError("\\char` missing argument");
      } else {
        number = token.text.charCodeAt(0);
      }
    } else {
      base = 10;
    }
    if (base) {
      number = digitToNumber[token.text];
      if (number == null || number >= base) {
        throw new ParseError("Invalid base-" + base + " digit " + token.text);
      }
      var digit;
      while ((digit = digitToNumber[context.future().text]) != null && digit < base) {
        number *= base;
        number += digit;
        context.popToken();
      }
    }
    return "\\@char{" + number + "}";
  });
  var newcommand = (context, existsOK, nonexistsOK, skipIfExists) => {
    var arg = context.consumeArg().tokens;
    if (arg.length !== 1) {
      throw new ParseError("\\newcommand's first argument must be a macro name");
    }
    var name = arg[0].text;
    var exists = context.isDefined(name);
    if (exists && !existsOK) {
      throw new ParseError("\\newcommand{" + name + "} attempting to redefine " + (name + "; use \\renewcommand"));
    }
    if (!exists && !nonexistsOK) {
      throw new ParseError("\\renewcommand{" + name + "} when command " + name + " does not yet exist; use \\newcommand");
    }
    var numArgs = 0;
    arg = context.consumeArg().tokens;
    if (arg.length === 1 && arg[0].text === "[") {
      var argText = "";
      var token = context.expandNextToken();
      while (token.text !== "]" && token.text !== "EOF") {
        argText += token.text;
        token = context.expandNextToken();
      }
      if (!argText.match(/^\s*[0-9]+\s*$/)) {
        throw new ParseError("Invalid number of arguments: " + argText);
      }
      numArgs = parseInt(argText);
      arg = context.consumeArg().tokens;
    }
    if (!(exists && skipIfExists)) {
      context.macros.set(name, {
        tokens: arg,
        numArgs
      });
    }
    return "";
  };
  defineMacro("\\newcommand", (context) => newcommand(context, false, true, false));
  defineMacro("\\renewcommand", (context) => newcommand(context, true, false, false));
  defineMacro("\\providecommand", (context) => newcommand(context, true, true, true));
  defineMacro("\\message", (context) => {
    var arg = context.consumeArgs(1)[0];
    console.log(arg.reverse().map((token) => token.text).join(""));
    return "";
  });
  defineMacro("\\errmessage", (context) => {
    var arg = context.consumeArgs(1)[0];
    console.error(arg.reverse().map((token) => token.text).join(""));
    return "";
  });
  defineMacro("\\show", (context) => {
    var tok = context.popToken();
    var name = tok.text;
    console.log(tok, context.macros.get(name), functions[name], symbols.math[name], symbols.text[name]);
    return "";
  });
  defineMacro("\\bgroup", "{");
  defineMacro("\\egroup", "}");
  defineMacro("~", "\\nobreakspace");
  defineMacro("\\lq", "`");
  defineMacro("\\rq", "'");
  defineMacro("\\aa", "\\r a");
  defineMacro("\\AA", "\\r A");
  defineMacro("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`\xA9}");
  defineMacro("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
  defineMacro("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`\xAE}");
  defineMacro("\u212C", "\\mathscr{B}");
  defineMacro("\u2130", "\\mathscr{E}");
  defineMacro("\u2131", "\\mathscr{F}");
  defineMacro("\u210B", "\\mathscr{H}");
  defineMacro("\u2110", "\\mathscr{I}");
  defineMacro("\u2112", "\\mathscr{L}");
  defineMacro("\u2133", "\\mathscr{M}");
  defineMacro("\u211B", "\\mathscr{R}");
  defineMacro("\u212D", "\\mathfrak{C}");
  defineMacro("\u210C", "\\mathfrak{H}");
  defineMacro("\u2128", "\\mathfrak{Z}");
  defineMacro("\\Bbbk", "\\Bbb{k}");
  defineMacro("\\llap", "\\mathllap{\\textrm{#1}}");
  defineMacro("\\rlap", "\\mathrlap{\\textrm{#1}}");
  defineMacro("\\clap", "\\mathclap{\\textrm{#1}}");
  defineMacro("\\mathstrut", "\\vphantom{(}");
  defineMacro("\\underbar", "\\underline{\\text{#1}}");
  defineMacro("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}\\nobreak}{\\char"338}');
  defineMacro("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`\u2260}}");
  defineMacro("\\ne", "\\neq");
  defineMacro("\u2260", "\\neq");
  defineMacro("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`\u2209}}");
  defineMacro("\u2209", "\\notin");
  defineMacro("\u2258", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`\u2258}}");
  defineMacro("\u2259", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`\u2258}}");
  defineMacro("\u225A", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`\u225A}}");
  defineMacro("\u225B", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`\u225B}}");
  defineMacro("\u225D", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`\u225D}}");
  defineMacro("\u225E", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`\u225E}}");
  defineMacro("\u225F", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`\u225F}}");
  defineMacro("\u27C2", "\\perp");
  defineMacro("\u203C", "\\mathclose{!\\mkern-0.8mu!}");
  defineMacro("\u220C", "\\notni");
  defineMacro("\u231C", "\\ulcorner");
  defineMacro("\u231D", "\\urcorner");
  defineMacro("\u231E", "\\llcorner");
  defineMacro("\u231F", "\\lrcorner");
  defineMacro("\xA9", "\\copyright");
  defineMacro("\xAE", "\\textregistered");
  defineMacro("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');
  defineMacro("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');
  defineMacro("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');
  defineMacro("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');
  defineMacro("\\vdots", "{\\varvdots\\rule{0pt}{15pt}}");
  defineMacro("\u22EE", "\\vdots");
  defineMacro("\\varGamma", "\\mathit{\\Gamma}");
  defineMacro("\\varDelta", "\\mathit{\\Delta}");
  defineMacro("\\varTheta", "\\mathit{\\Theta}");
  defineMacro("\\varLambda", "\\mathit{\\Lambda}");
  defineMacro("\\varXi", "\\mathit{\\Xi}");
  defineMacro("\\varPi", "\\mathit{\\Pi}");
  defineMacro("\\varSigma", "\\mathit{\\Sigma}");
  defineMacro("\\varUpsilon", "\\mathit{\\Upsilon}");
  defineMacro("\\varPhi", "\\mathit{\\Phi}");
  defineMacro("\\varPsi", "\\mathit{\\Psi}");
  defineMacro("\\varOmega", "\\mathit{\\Omega}");
  defineMacro("\\substack", "\\begin{subarray}{c}#1\\end{subarray}");
  defineMacro("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");
  defineMacro("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
  defineMacro("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
  defineMacro("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
  defineMacro("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
  defineMacro("\\dddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ...}}{#1}}");
  defineMacro("\\ddddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ....}}{#1}}");
  var dotsByToken = {
    ",": "\\dotsc",
    "\\not": "\\dotsb",
    // \keybin@ checks for the following:
    "+": "\\dotsb",
    "=": "\\dotsb",
    "<": "\\dotsb",
    ">": "\\dotsb",
    "-": "\\dotsb",
    "*": "\\dotsb",
    ":": "\\dotsb",
    // Symbols whose definition starts with \DOTSB:
    "\\DOTSB": "\\dotsb",
    "\\coprod": "\\dotsb",
    "\\bigvee": "\\dotsb",
    "\\bigwedge": "\\dotsb",
    "\\biguplus": "\\dotsb",
    "\\bigcap": "\\dotsb",
    "\\bigcup": "\\dotsb",
    "\\prod": "\\dotsb",
    "\\sum": "\\dotsb",
    "\\bigotimes": "\\dotsb",
    "\\bigoplus": "\\dotsb",
    "\\bigodot": "\\dotsb",
    "\\bigsqcup": "\\dotsb",
    "\\And": "\\dotsb",
    "\\longrightarrow": "\\dotsb",
    "\\Longrightarrow": "\\dotsb",
    "\\longleftarrow": "\\dotsb",
    "\\Longleftarrow": "\\dotsb",
    "\\longleftrightarrow": "\\dotsb",
    "\\Longleftrightarrow": "\\dotsb",
    "\\mapsto": "\\dotsb",
    "\\longmapsto": "\\dotsb",
    "\\hookrightarrow": "\\dotsb",
    "\\doteq": "\\dotsb",
    // Symbols whose definition starts with \mathbin:
    "\\mathbin": "\\dotsb",
    // Symbols whose definition starts with \mathrel:
    "\\mathrel": "\\dotsb",
    "\\relbar": "\\dotsb",
    "\\Relbar": "\\dotsb",
    "\\xrightarrow": "\\dotsb",
    "\\xleftarrow": "\\dotsb",
    // Symbols whose definition starts with \DOTSI:
    "\\DOTSI": "\\dotsi",
    "\\int": "\\dotsi",
    "\\oint": "\\dotsi",
    "\\iint": "\\dotsi",
    "\\iiint": "\\dotsi",
    "\\iiiint": "\\dotsi",
    "\\idotsint": "\\dotsi",
    // Symbols whose definition starts with \DOTSX:
    "\\DOTSX": "\\dotsx"
  };
  var dotsbGroups = /* @__PURE__ */ new Set(["bin", "rel"]);
  defineMacro("\\dots", function(context) {
    var thedots = "\\dotso";
    var next = context.expandAfterFuture().text;
    if (next in dotsByToken) {
      thedots = dotsByToken[next];
    } else if (next.slice(0, 4) === "\\not") {
      thedots = "\\dotsb";
    } else if (next in symbols.math) {
      if (dotsbGroups.has(symbols.math[next].group)) {
        thedots = "\\dotsb";
      }
    }
    return thedots;
  });
  var spaceAfterDots = {
    // \rightdelim@ checks for the following:
    ")": true,
    "]": true,
    "\\rbrack": true,
    "\\}": true,
    "\\rbrace": true,
    "\\rangle": true,
    "\\rceil": true,
    "\\rfloor": true,
    "\\rgroup": true,
    "\\rmoustache": true,
    "\\right": true,
    "\\bigr": true,
    "\\biggr": true,
    "\\Bigr": true,
    "\\Biggr": true,
    // \extra@ also tests for the following:
    "$": true,
    // \extrap@ checks for the following:
    ";": true,
    ".": true,
    ",": true
  };
  defineMacro("\\dotso", function(context) {
    var next = context.future().text;
    if (next in spaceAfterDots) {
      return "\\ldots\\,";
    } else {
      return "\\ldots";
    }
  });
  defineMacro("\\dotsc", function(context) {
    var next = context.future().text;
    if (next in spaceAfterDots && next !== ",") {
      return "\\ldots\\,";
    } else {
      return "\\ldots";
    }
  });
  defineMacro("\\cdots", function(context) {
    var next = context.future().text;
    if (next in spaceAfterDots) {
      return "\\@cdots\\,";
    } else {
      return "\\@cdots";
    }
  });
  defineMacro("\\dotsb", "\\cdots");
  defineMacro("\\dotsm", "\\cdots");
  defineMacro("\\dotsi", "\\!\\cdots");
  defineMacro("\\dotsx", "\\ldots\\,");
  defineMacro("\\DOTSI", "\\relax");
  defineMacro("\\DOTSB", "\\relax");
  defineMacro("\\DOTSX", "\\relax");
  defineMacro("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
  defineMacro("\\,", "\\tmspace+{3mu}{.1667em}");
  defineMacro("\\thinspace", "\\,");
  defineMacro("\\>", "\\mskip{4mu}");
  defineMacro("\\:", "\\tmspace+{4mu}{.2222em}");
  defineMacro("\\medspace", "\\:");
  defineMacro("\\;", "\\tmspace+{5mu}{.2777em}");
  defineMacro("\\thickspace", "\\;");
  defineMacro("\\!", "\\tmspace-{3mu}{.1667em}");
  defineMacro("\\negthinspace", "\\!");
  defineMacro("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
  defineMacro("\\negthickspace", "\\tmspace-{5mu}{.277em}");
  defineMacro("\\enspace", "\\kern.5em ");
  defineMacro("\\enskip", "\\hskip.5em\\relax");
  defineMacro("\\quad", "\\hskip1em\\relax");
  defineMacro("\\qquad", "\\hskip2em\\relax");
  defineMacro("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
  defineMacro("\\tag@paren", "\\tag@literal{({#1})}");
  defineMacro("\\tag@literal", (context) => {
    if (context.macros.get("\\df@tag")) {
      throw new ParseError("Multiple \\tag");
    }
    return "\\gdef\\df@tag{\\text{#1}}";
  });
  defineMacro("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
  defineMacro("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
  defineMacro("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
  defineMacro("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
  defineMacro("\\newline", "\\\\\\relax");
  defineMacro("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
  var latexRaiseA = makeEm(fontMetricsData["Main-Regular"]["T".charCodeAt(0)][1] - 0.7 * fontMetricsData["Main-Regular"]["A".charCodeAt(0)][1]);
  defineMacro("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + latexRaiseA + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}");
  defineMacro("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + latexRaiseA + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}");
  defineMacro("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
  defineMacro("\\@hspace", "\\hskip #1\\relax");
  defineMacro("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
  defineMacro("\\ordinarycolon", ":");
  defineMacro("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
  defineMacro("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');
  defineMacro("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');
  defineMacro("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');
  defineMacro("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');
  defineMacro("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');
  defineMacro("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');
  defineMacro("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');
  defineMacro("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');
  defineMacro("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');
  defineMacro("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');
  defineMacro("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');
  defineMacro("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');
  defineMacro("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');
  defineMacro("\u2237", "\\dblcolon");
  defineMacro("\u2239", "\\eqcolon");
  defineMacro("\u2254", "\\coloneqq");
  defineMacro("\u2255", "\\eqqcolon");
  defineMacro("\u2A74", "\\Coloneqq");
  defineMacro("\\ratio", "\\vcentcolon");
  defineMacro("\\coloncolon", "\\dblcolon");
  defineMacro("\\colonequals", "\\coloneqq");
  defineMacro("\\coloncolonequals", "\\Coloneqq");
  defineMacro("\\equalscolon", "\\eqqcolon");
  defineMacro("\\equalscoloncolon", "\\Eqqcolon");
  defineMacro("\\colonminus", "\\coloneq");
  defineMacro("\\coloncolonminus", "\\Coloneq");
  defineMacro("\\minuscolon", "\\eqcolon");
  defineMacro("\\minuscoloncolon", "\\Eqcolon");
  defineMacro("\\coloncolonapprox", "\\Colonapprox");
  defineMacro("\\coloncolonsim", "\\Colonsim");
  defineMacro("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
  defineMacro("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
  defineMacro("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
  defineMacro("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
  defineMacro("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`\u220C}}");
  defineMacro("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}");
  defineMacro("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}");
  defineMacro("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}");
  defineMacro("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}");
  defineMacro("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}");
  defineMacro("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}");
  defineMacro("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}");
  defineMacro("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}");
  defineMacro("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{\u2269}");
  defineMacro("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{\u2268}");
  defineMacro("\\ngeqq", "\\html@mathml{\\@ngeqq}{\u2271}");
  defineMacro("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{\u2271}");
  defineMacro("\\nleqq", "\\html@mathml{\\@nleqq}{\u2270}");
  defineMacro("\\nleqslant", "\\html@mathml{\\@nleqslant}{\u2270}");
  defineMacro("\\nshortmid", "\\html@mathml{\\@nshortmid}{\u2224}");
  defineMacro("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{\u2226}");
  defineMacro("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{\u2288}");
  defineMacro("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{\u2289}");
  defineMacro("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{\u228A}");
  defineMacro("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{\u2ACB}");
  defineMacro("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{\u228B}");
  defineMacro("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{\u2ACC}");
  defineMacro("\\imath", "\\html@mathml{\\@imath}{\u0131}");
  defineMacro("\\jmath", "\\html@mathml{\\@jmath}{\u0237}");
  defineMacro("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`\u27E6}}");
  defineMacro("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`\u27E7}}");
  defineMacro("\u27E6", "\\llbracket");
  defineMacro("\u27E7", "\\rrbracket");
  defineMacro("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`\u2983}}");
  defineMacro("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`\u2984}}");
  defineMacro("\u21A4", "\\mapsfrom");
  defineMacro("\\mapsfrom", "\\html@mathml{\\mathrel{\\mathreflectbox{\\mapsto}}}{\\mathrel{\\char`\u21A4}}");
  defineMacro("\u2983", "\\lBrace");
  defineMacro("\u2984", "\\rBrace");
  defineMacro("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`\u29B5}}");
  defineMacro("\u29B5", "\\minuso");
  defineMacro("\\darr", "\\downarrow");
  defineMacro("\\dArr", "\\Downarrow");
  defineMacro("\\Darr", "\\Downarrow");
  defineMacro("\\lang", "\\langle");
  defineMacro("\\rang", "\\rangle");
  defineMacro("\\uarr", "\\uparrow");
  defineMacro("\\uArr", "\\Uparrow");
  defineMacro("\\Uarr", "\\Uparrow");
  defineMacro("\\N", "\\mathbb{N}");
  defineMacro("\\R", "\\mathbb{R}");
  defineMacro("\\Z", "\\mathbb{Z}");
  defineMacro("\\alef", "\\aleph");
  defineMacro("\\alefsym", "\\aleph");
  defineMacro("\\Alpha", "\\mathrm{A}");
  defineMacro("\\Beta", "\\mathrm{B}");
  defineMacro("\\bull", "\\bullet");
  defineMacro("\\Chi", "\\mathrm{X}");
  defineMacro("\\clubs", "\\clubsuit");
  defineMacro("\\cnums", "\\mathbb{C}");
  defineMacro("\\Complex", "\\mathbb{C}");
  defineMacro("\\Dagger", "\\ddagger");
  defineMacro("\\diamonds", "\\diamondsuit");
  defineMacro("\\empty", "\\emptyset");
  defineMacro("\\Epsilon", "\\mathrm{E}");
  defineMacro("\\Eta", "\\mathrm{H}");
  defineMacro("\\exist", "\\exists");
  defineMacro("\\harr", "\\leftrightarrow");
  defineMacro("\\hArr", "\\Leftrightarrow");
  defineMacro("\\Harr", "\\Leftrightarrow");
  defineMacro("\\hearts", "\\heartsuit");
  defineMacro("\\image", "\\Im");
  defineMacro("\\infin", "\\infty");
  defineMacro("\\Iota", "\\mathrm{I}");
  defineMacro("\\isin", "\\in");
  defineMacro("\\Kappa", "\\mathrm{K}");
  defineMacro("\\larr", "\\leftarrow");
  defineMacro("\\lArr", "\\Leftarrow");
  defineMacro("\\Larr", "\\Leftarrow");
  defineMacro("\\lrarr", "\\leftrightarrow");
  defineMacro("\\lrArr", "\\Leftrightarrow");
  defineMacro("\\Lrarr", "\\Leftrightarrow");
  defineMacro("\\Mu", "\\mathrm{M}");
  defineMacro("\\natnums", "\\mathbb{N}");
  defineMacro("\\Nu", "\\mathrm{N}");
  defineMacro("\\Omicron", "\\mathrm{O}");
  defineMacro("\\plusmn", "\\pm");
  defineMacro("\\rarr", "\\rightarrow");
  defineMacro("\\rArr", "\\Rightarrow");
  defineMacro("\\Rarr", "\\Rightarrow");
  defineMacro("\\real", "\\Re");
  defineMacro("\\reals", "\\mathbb{R}");
  defineMacro("\\Reals", "\\mathbb{R}");
  defineMacro("\\Rho", "\\mathrm{P}");
  defineMacro("\\sdot", "\\cdot");
  defineMacro("\\sect", "\\S");
  defineMacro("\\spades", "\\spadesuit");
  defineMacro("\\sub", "\\subset");
  defineMacro("\\sube", "\\subseteq");
  defineMacro("\\supe", "\\supseteq");
  defineMacro("\\Tau", "\\mathrm{T}");
  defineMacro("\\thetasym", "\\vartheta");
  defineMacro("\\weierp", "\\wp");
  defineMacro("\\Zeta", "\\mathrm{Z}");
  defineMacro("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}");
  defineMacro("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}");
  defineMacro("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits");
  defineMacro("\\bra", "\\mathinner{\\langle{#1}|}");
  defineMacro("\\ket", "\\mathinner{|{#1}\\rangle}");
  defineMacro("\\braket", "\\mathinner{\\langle{#1}\\rangle}");
  defineMacro("\\Bra", "\\left\\langle#1\\right|");
  defineMacro("\\Ket", "\\left|#1\\right\\rangle");
  var braketHelper = (one) => (context) => {
    var left = context.consumeArg().tokens;
    var middle = context.consumeArg().tokens;
    var middleDouble = context.consumeArg().tokens;
    var right = context.consumeArg().tokens;
    var oldMiddle = context.macros.get("|");
    var oldMiddleDouble = context.macros.get("\\|");
    context.macros.beginGroup();
    var midMacro = (double) => (context2) => {
      if (one) {
        context2.macros.set("|", oldMiddle);
        if (middleDouble.length) {
          context2.macros.set("\\|", oldMiddleDouble);
        }
      }
      var doubled = double;
      if (!double && middleDouble.length) {
        var nextToken = context2.future();
        if (nextToken.text === "|") {
          context2.popToken();
          doubled = true;
        }
      }
      return {
        tokens: doubled ? middleDouble : middle,
        numArgs: 0
      };
    };
    context.macros.set("|", midMacro(false));
    if (middleDouble.length) {
      context.macros.set("\\|", midMacro(true));
    }
    var arg = context.consumeArg().tokens;
    var expanded = context.expandTokens([
      ...right,
      ...arg,
      ...left
      // reversed
    ]);
    context.macros.endGroup();
    return {
      tokens: expanded.reverse(),
      numArgs: 0
    };
  };
  defineMacro("\\bra@ket", braketHelper(false));
  defineMacro("\\bra@set", braketHelper(true));
  defineMacro("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");
  defineMacro("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");
  defineMacro("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");
  defineMacro("\\angln", "{\\angl n}");
  defineMacro("\\blue", "\\textcolor{##6495ed}{#1}");
  defineMacro("\\orange", "\\textcolor{##ffa500}{#1}");
  defineMacro("\\pink", "\\textcolor{##ff00af}{#1}");
  defineMacro("\\red", "\\textcolor{##df0030}{#1}");
  defineMacro("\\green", "\\textcolor{##28ae7b}{#1}");
  defineMacro("\\gray", "\\textcolor{gray}{#1}");
  defineMacro("\\purple", "\\textcolor{##9d38bd}{#1}");
  defineMacro("\\blueA", "\\textcolor{##ccfaff}{#1}");
  defineMacro("\\blueB", "\\textcolor{##80f6ff}{#1}");
  defineMacro("\\blueC", "\\textcolor{##63d9ea}{#1}");
  defineMacro("\\blueD", "\\textcolor{##11accd}{#1}");
  defineMacro("\\blueE", "\\textcolor{##0c7f99}{#1}");
  defineMacro("\\tealA", "\\textcolor{##94fff5}{#1}");
  defineMacro("\\tealB", "\\textcolor{##26edd5}{#1}");
  defineMacro("\\tealC", "\\textcolor{##01d1c1}{#1}");
  defineMacro("\\tealD", "\\textcolor{##01a995}{#1}");
  defineMacro("\\tealE", "\\textcolor{##208170}{#1}");
  defineMacro("\\greenA", "\\textcolor{##b6ffb0}{#1}");
  defineMacro("\\greenB", "\\textcolor{##8af281}{#1}");
  defineMacro("\\greenC", "\\textcolor{##74cf70}{#1}");
  defineMacro("\\greenD", "\\textcolor{##1fab54}{#1}");
  defineMacro("\\greenE", "\\textcolor{##0d923f}{#1}");
  defineMacro("\\goldA", "\\textcolor{##ffd0a9}{#1}");
  defineMacro("\\goldB", "\\textcolor{##ffbb71}{#1}");
  defineMacro("\\goldC", "\\textcolor{##ff9c39}{#1}");
  defineMacro("\\goldD", "\\textcolor{##e07d10}{#1}");
  defineMacro("\\goldE", "\\textcolor{##a75a05}{#1}");
  defineMacro("\\redA", "\\textcolor{##fca9a9}{#1}");
  defineMacro("\\redB", "\\textcolor{##ff8482}{#1}");
  defineMacro("\\redC", "\\textcolor{##f9685d}{#1}");
  defineMacro("\\redD", "\\textcolor{##e84d39}{#1}");
  defineMacro("\\redE", "\\textcolor{##bc2612}{#1}");
  defineMacro("\\maroonA", "\\textcolor{##ffbde0}{#1}");
  defineMacro("\\maroonB", "\\textcolor{##ff92c6}{#1}");
  defineMacro("\\maroonC", "\\textcolor{##ed5fa6}{#1}");
  defineMacro("\\maroonD", "\\textcolor{##ca337c}{#1}");
  defineMacro("\\maroonE", "\\textcolor{##9e034e}{#1}");
  defineMacro("\\purpleA", "\\textcolor{##ddd7ff}{#1}");
  defineMacro("\\purpleB", "\\textcolor{##c6b9fc}{#1}");
  defineMacro("\\purpleC", "\\textcolor{##aa87ff}{#1}");
  defineMacro("\\purpleD", "\\textcolor{##7854ab}{#1}");
  defineMacro("\\purpleE", "\\textcolor{##543b78}{#1}");
  defineMacro("\\mintA", "\\textcolor{##f5f9e8}{#1}");
  defineMacro("\\mintB", "\\textcolor{##edf2df}{#1}");
  defineMacro("\\mintC", "\\textcolor{##e0e5cc}{#1}");
  defineMacro("\\grayA", "\\textcolor{##f6f7f7}{#1}");
  defineMacro("\\grayB", "\\textcolor{##f0f1f2}{#1}");
  defineMacro("\\grayC", "\\textcolor{##e3e5e6}{#1}");
  defineMacro("\\grayD", "\\textcolor{##d6d8da}{#1}");
  defineMacro("\\grayE", "\\textcolor{##babec2}{#1}");
  defineMacro("\\grayF", "\\textcolor{##888d93}{#1}");
  defineMacro("\\grayG", "\\textcolor{##626569}{#1}");
  defineMacro("\\grayH", "\\textcolor{##3b3e40}{#1}");
  defineMacro("\\grayI", "\\textcolor{##21242c}{#1}");
  defineMacro("\\kaBlue", "\\textcolor{##314453}{#1}");
  defineMacro("\\kaGreen", "\\textcolor{##71B307}{#1}");
  var implicitCommands = {
    "^": true,
    // Parser.js
    "_": true,
    // Parser.js
    "\\limits": true,
    // Parser.js
    "\\nolimits": true
    // Parser.js
  };
  var MacroExpander = class {
    constructor(input, settings, mode) {
      this.settings = void 0;
      this.expansionCount = void 0;
      this.lexer = void 0;
      this.macros = void 0;
      this.stack = void 0;
      this.mode = void 0;
      this.settings = settings;
      this.expansionCount = 0;
      this.feed(input);
      this.macros = new Namespace(macros, settings.macros);
      this.mode = mode;
      this.stack = [];
    }
    /**
     * Feed a new input string to the same MacroExpander
     * (with existing macros etc.).
     */
    feed(input) {
      this.lexer = new Lexer(input, this.settings);
    }
    /**
     * Switches between "text" and "math" modes.
     */
    switchMode(newMode) {
      this.mode = newMode;
    }
    /**
     * Start a new group nesting within all namespaces.
     */
    beginGroup() {
      this.macros.beginGroup();
    }
    /**
     * End current group nesting within all namespaces.
     */
    endGroup() {
      this.macros.endGroup();
    }
    /**
     * Ends all currently nested groups (if any), restoring values before the
     * groups began.  Useful in case of an error in the middle of parsing.
     */
    endGroups() {
      this.macros.endGroups();
    }
    /**
     * Returns the topmost token on the stack, without expanding it.
     * Similar in behavior to TeX's `\futurelet`.
     */
    future() {
      if (this.stack.length === 0) {
        this.pushToken(this.lexer.lex());
      }
      return this.stack[this.stack.length - 1];
    }
    /**
     * Remove and return the next unexpanded token.
     */
    popToken() {
      this.future();
      return this.stack.pop();
    }
    /**
     * Add a given token to the token stack.  In particular, this get be used
     * to put back a token returned from one of the other methods.
     */
    pushToken(token) {
      this.stack.push(token);
    }
    /**
     * Append an array of tokens to the token stack.
     */
    pushTokens(tokens) {
      this.stack.push(...tokens);
    }
    /**
     * Find an macro argument without expanding tokens and append the array of
     * tokens to the token stack. Uses Token as a container for the result.
     */
    scanArgument(isOptional) {
      var start;
      var end;
      var tokens;
      if (isOptional) {
        this.consumeSpaces();
        if (this.future().text !== "[") {
          return null;
        }
        start = this.popToken();
        var _this$consumeArg = this.consumeArg(["]"]);
        tokens = _this$consumeArg.tokens;
        end = _this$consumeArg.end;
      } else {
        var _this$consumeArg2 = this.consumeArg();
        tokens = _this$consumeArg2.tokens;
        start = _this$consumeArg2.start;
        end = _this$consumeArg2.end;
      }
      this.pushToken(new Token("EOF", end.loc));
      this.pushTokens(tokens);
      return new Token("", SourceLocation.range(start, end));
    }
    /**
     * Consume all following space tokens, without expansion.
     */
    consumeSpaces() {
      for (; ; ) {
        var token = this.future();
        if (token.text === " ") {
          this.stack.pop();
        } else {
          break;
        }
      }
    }
    /**
     * Consume an argument from the token stream, and return the resulting array
     * of tokens and start/end token.
     */
    consumeArg(delims) {
      var tokens = [];
      var isDelimited = delims && delims.length > 0;
      if (!isDelimited) {
        this.consumeSpaces();
      }
      var start = this.future();
      var tok;
      var depth = 0;
      var match = 0;
      do {
        tok = this.popToken();
        tokens.push(tok);
        if (tok.text === "{") {
          ++depth;
        } else if (tok.text === "}") {
          --depth;
          if (depth === -1) {
            throw new ParseError("Extra }", tok);
          }
        } else if (tok.text === "EOF") {
          throw new ParseError("Unexpected end of input in a macro argument, expected '" + (delims && isDelimited ? delims[match] : "}") + "'", tok);
        }
        if (delims && isDelimited) {
          if ((depth === 0 || depth === 1 && delims[match] === "{") && tok.text === delims[match]) {
            ++match;
            if (match === delims.length) {
              tokens.splice(-match, match);
              break;
            }
          } else {
            match = 0;
          }
        }
      } while (depth !== 0 || isDelimited);
      if (start.text === "{" && tokens[tokens.length - 1].text === "}") {
        tokens.pop();
        tokens.shift();
      }
      tokens.reverse();
      return {
        tokens,
        start,
        end: tok
      };
    }
    /**
     * Consume the specified number of (delimited) arguments from the token
     * stream and return the resulting array of arguments.
     */
    consumeArgs(numArgs, delimiters2) {
      if (delimiters2) {
        if (delimiters2.length !== numArgs + 1) {
          throw new ParseError("The length of delimiters doesn't match the number of args!");
        }
        var delims = delimiters2[0];
        for (var i3 = 0; i3 < delims.length; i3++) {
          var tok = this.popToken();
          if (delims[i3] !== tok.text) {
            throw new ParseError("Use of the macro doesn't match its definition", tok);
          }
        }
      }
      var args = [];
      for (var _i = 0; _i < numArgs; _i++) {
        args.push(this.consumeArg(delimiters2 && delimiters2[_i + 1]).tokens);
      }
      return args;
    }
    /**
     * Increment `expansionCount` by the specified amount.
     * Throw an error if it exceeds `maxExpand`.
     */
    countExpansion(amount) {
      this.expansionCount += amount;
      if (this.expansionCount > this.settings.maxExpand) {
        throw new ParseError("Too many expansions: infinite loop or need to increase maxExpand setting");
      }
    }
    /**
     * Expand the next token only once if possible.
     *
     * If the token is expanded, the resulting tokens will be pushed onto
     * the stack in reverse order, and the number of such tokens will be
     * returned.  This number might be zero or positive.
     *
     * If not, the return value is `false`, and the next token remains at the
     * top of the stack.
     *
     * In either case, the next token will be on the top of the stack,
     * or the stack will be empty (in case of empty expansion
     * and no other tokens).
     *
     * Used to implement `expandAfterFuture` and `expandNextToken`.
     *
     * If expandableOnly, only expandable tokens are expanded and
     * an undefined control sequence results in an error.
     */
    expandOnce(expandableOnly) {
      var topToken = this.popToken();
      var name = topToken.text;
      var expansion = !topToken.noexpand ? this._getExpansion(name) : null;
      if (expansion == null || expandableOnly && expansion.unexpandable) {
        if (expandableOnly && expansion == null && name[0] === "\\" && !this.isDefined(name)) {
          throw new ParseError("Undefined control sequence: " + name);
        }
        this.pushToken(topToken);
        return false;
      }
      this.countExpansion(1);
      var tokens = expansion.tokens;
      var args = this.consumeArgs(expansion.numArgs, expansion.delimiters);
      if (expansion.numArgs) {
        tokens = tokens.slice();
        for (var i3 = tokens.length - 1; i3 >= 0; --i3) {
          var tok = tokens[i3];
          if (tok.text === "#") {
            if (i3 === 0) {
              throw new ParseError("Incomplete placeholder at end of macro body", tok);
            }
            tok = tokens[--i3];
            if (tok.text === "#") {
              tokens.splice(i3 + 1, 1);
            } else if (/^[1-9]$/.test(tok.text)) {
              tokens.splice(i3, 2, ...args[+tok.text - 1]);
            } else {
              throw new ParseError("Not a valid argument number", tok);
            }
          }
        }
      }
      this.pushTokens(tokens);
      return tokens.length;
    }
    /**
     * Expand the next token only once (if possible), and return the resulting
     * top token on the stack (without removing anything from the stack).
     * Similar in behavior to TeX's `\expandafter\futurelet`.
     * Equivalent to expandOnce() followed by future().
     */
    expandAfterFuture() {
      this.expandOnce();
      return this.future();
    }
    /**
     * Recursively expand first token, then return first non-expandable token.
     */
    expandNextToken() {
      for (; ; ) {
        if (this.expandOnce() === false) {
          var token = this.stack.pop();
          if (token.treatAsRelax) {
            token.text = "\\relax";
          }
          return token;
        }
      }
    }
    /**
     * Fully expand the given macro name and return the resulting list of
     * tokens, or return `undefined` if no such macro is defined.
     */
    expandMacro(name) {
      return this.macros.has(name) ? this.expandTokens([new Token(name)]) : void 0;
    }
    /**
     * Fully expand the given token stream and return the resulting list of
     * tokens.  Note that the input tokens are in reverse order, but the
     * output tokens are in forward order.
     */
    expandTokens(tokens) {
      var output = [];
      var oldStackLength = this.stack.length;
      this.pushTokens(tokens);
      while (this.stack.length > oldStackLength) {
        if (this.expandOnce(true) === false) {
          var token = this.stack.pop();
          if (token.treatAsRelax) {
            token.noexpand = false;
            token.treatAsRelax = false;
          }
          output.push(token);
        }
      }
      this.countExpansion(output.length);
      return output;
    }
    /**
     * Fully expand the given macro name and return the result as a string,
     * or return `undefined` if no such macro is defined.
     */
    expandMacroAsText(name) {
      var tokens = this.expandMacro(name);
      if (tokens) {
        return tokens.map((token) => token.text).join("");
      } else {
        return tokens;
      }
    }
    /**
     * Returns the expanded macro as a reversed array of tokens and a macro
     * argument count.  Or returns `null` if no such macro.
     */
    _getExpansion(name) {
      var definition = this.macros.get(name);
      if (definition == null) {
        return definition;
      }
      if (name.length === 1) {
        var catcode = this.lexer.catcodes[name];
        if (catcode != null && catcode !== 13) {
          return;
        }
      }
      var expansion = typeof definition === "function" ? definition(this) : definition;
      if (typeof expansion === "string") {
        var numArgs = 0;
        if (expansion.includes("#")) {
          var stripped = expansion.replace(/##/g, "");
          while (stripped.includes("#" + (numArgs + 1))) {
            ++numArgs;
          }
        }
        var bodyLexer = new Lexer(expansion, this.settings);
        var tokens = [];
        var tok = bodyLexer.lex();
        while (tok.text !== "EOF") {
          tokens.push(tok);
          tok = bodyLexer.lex();
        }
        tokens.reverse();
        var expanded = {
          tokens,
          numArgs
        };
        return expanded;
      }
      return expansion;
    }
    /**
     * Determine whether a command is currently "defined" (has some
     * functionality), meaning that it's a macro (in the current group),
     * a function, a symbol, or one of the special commands listed in
     * `implicitCommands`.
     */
    isDefined(name) {
      return this.macros.has(name) || Object.prototype.hasOwnProperty.call(functions, name) || Object.prototype.hasOwnProperty.call(symbols.math, name) || Object.prototype.hasOwnProperty.call(symbols.text, name) || Object.prototype.hasOwnProperty.call(implicitCommands, name);
    }
    /**
     * Determine whether a command is expandable.
     */
    isExpandable(name) {
      var macro = this.macros.get(name);
      if (macro != null) {
        return typeof macro === "string" || typeof macro === "function" || !macro.unexpandable;
      }
      return Object.prototype.hasOwnProperty.call(functions, name) && !functions[name].primitive;
    }
  };
  var unicodeSubRegEx = /^[₊₋₌₍₎₀₁₂₃₄₅₆₇₈₉ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓᵦᵧᵨᵩᵪ]/;
  var uSubsAndSups = Object.freeze({
    "\u208A": "+",
    "\u208B": "-",
    "\u208C": "=",
    "\u208D": "(",
    "\u208E": ")",
    "\u2080": "0",
    "\u2081": "1",
    "\u2082": "2",
    "\u2083": "3",
    "\u2084": "4",
    "\u2085": "5",
    "\u2086": "6",
    "\u2087": "7",
    "\u2088": "8",
    "\u2089": "9",
    "\u2090": "a",
    "\u2091": "e",
    "\u2095": "h",
    "\u1D62": "i",
    "\u2C7C": "j",
    "\u2096": "k",
    "\u2097": "l",
    "\u2098": "m",
    "\u2099": "n",
    "\u2092": "o",
    "\u209A": "p",
    "\u1D63": "r",
    "\u209B": "s",
    "\u209C": "t",
    "\u1D64": "u",
    "\u1D65": "v",
    "\u2093": "x",
    "\u1D66": "\u03B2",
    "\u1D67": "\u03B3",
    "\u1D68": "\u03C1",
    "\u1D69": "\u03D5",
    "\u1D6A": "\u03C7",
    "\u207A": "+",
    "\u207B": "-",
    "\u207C": "=",
    "\u207D": "(",
    "\u207E": ")",
    "\u2070": "0",
    "\xB9": "1",
    "\xB2": "2",
    "\xB3": "3",
    "\u2074": "4",
    "\u2075": "5",
    "\u2076": "6",
    "\u2077": "7",
    "\u2078": "8",
    "\u2079": "9",
    "\u1D2C": "A",
    "\u1D2E": "B",
    "\u1D30": "D",
    "\u1D31": "E",
    "\u1D33": "G",
    "\u1D34": "H",
    "\u1D35": "I",
    "\u1D36": "J",
    "\u1D37": "K",
    "\u1D38": "L",
    "\u1D39": "M",
    "\u1D3A": "N",
    "\u1D3C": "O",
    "\u1D3E": "P",
    "\u1D3F": "R",
    "\u1D40": "T",
    "\u1D41": "U",
    "\u2C7D": "V",
    "\u1D42": "W",
    "\u1D43": "a",
    "\u1D47": "b",
    "\u1D9C": "c",
    "\u1D48": "d",
    "\u1D49": "e",
    "\u1DA0": "f",
    "\u1D4D": "g",
    "\u02B0": "h",
    "\u2071": "i",
    "\u02B2": "j",
    "\u1D4F": "k",
    "\u02E1": "l",
    "\u1D50": "m",
    "\u207F": "n",
    "\u1D52": "o",
    "\u1D56": "p",
    "\u02B3": "r",
    "\u02E2": "s",
    "\u1D57": "t",
    "\u1D58": "u",
    "\u1D5B": "v",
    "\u02B7": "w",
    "\u02E3": "x",
    "\u02B8": "y",
    "\u1DBB": "z",
    "\u1D5D": "\u03B2",
    "\u1D5E": "\u03B3",
    "\u1D5F": "\u03B4",
    "\u1D60": "\u03D5",
    "\u1D61": "\u03C7",
    "\u1DBF": "\u03B8"
  });
  var unicodeAccents = {
    "\u0301": {
      "text": "\\'",
      "math": "\\acute"
    },
    "\u0300": {
      "text": "\\`",
      "math": "\\grave"
    },
    "\u0308": {
      "text": '\\"',
      "math": "\\ddot"
    },
    "\u0303": {
      "text": "\\~",
      "math": "\\tilde"
    },
    "\u0304": {
      "text": "\\=",
      "math": "\\bar"
    },
    "\u0306": {
      "text": "\\u",
      "math": "\\breve"
    },
    "\u030C": {
      "text": "\\v",
      "math": "\\check"
    },
    "\u0302": {
      "text": "\\^",
      "math": "\\hat"
    },
    "\u0307": {
      "text": "\\.",
      "math": "\\dot"
    },
    "\u030A": {
      "text": "\\r",
      "math": "\\mathring"
    },
    "\u030B": {
      "text": "\\H"
    },
    "\u0327": {
      "text": "\\c"
    }
  };
  var unicodeSymbols = {
    "\xE1": "a\u0301",
    "\xE0": "a\u0300",
    "\xE4": "a\u0308",
    "\u01DF": "a\u0308\u0304",
    "\xE3": "a\u0303",
    "\u0101": "a\u0304",
    "\u0103": "a\u0306",
    "\u1EAF": "a\u0306\u0301",
    "\u1EB1": "a\u0306\u0300",
    "\u1EB5": "a\u0306\u0303",
    "\u01CE": "a\u030C",
    "\xE2": "a\u0302",
    "\u1EA5": "a\u0302\u0301",
    "\u1EA7": "a\u0302\u0300",
    "\u1EAB": "a\u0302\u0303",
    "\u0227": "a\u0307",
    "\u01E1": "a\u0307\u0304",
    "\xE5": "a\u030A",
    "\u01FB": "a\u030A\u0301",
    "\u1E03": "b\u0307",
    "\u0107": "c\u0301",
    "\u1E09": "c\u0327\u0301",
    "\u010D": "c\u030C",
    "\u0109": "c\u0302",
    "\u010B": "c\u0307",
    "\xE7": "c\u0327",
    "\u010F": "d\u030C",
    "\u1E0B": "d\u0307",
    "\u1E11": "d\u0327",
    "\xE9": "e\u0301",
    "\xE8": "e\u0300",
    "\xEB": "e\u0308",
    "\u1EBD": "e\u0303",
    "\u0113": "e\u0304",
    "\u1E17": "e\u0304\u0301",
    "\u1E15": "e\u0304\u0300",
    "\u0115": "e\u0306",
    "\u1E1D": "e\u0327\u0306",
    "\u011B": "e\u030C",
    "\xEA": "e\u0302",
    "\u1EBF": "e\u0302\u0301",
    "\u1EC1": "e\u0302\u0300",
    "\u1EC5": "e\u0302\u0303",
    "\u0117": "e\u0307",
    "\u0229": "e\u0327",
    "\u1E1F": "f\u0307",
    "\u01F5": "g\u0301",
    "\u1E21": "g\u0304",
    "\u011F": "g\u0306",
    "\u01E7": "g\u030C",
    "\u011D": "g\u0302",
    "\u0121": "g\u0307",
    "\u0123": "g\u0327",
    "\u1E27": "h\u0308",
    "\u021F": "h\u030C",
    "\u0125": "h\u0302",
    "\u1E23": "h\u0307",
    "\u1E29": "h\u0327",
    "\xED": "i\u0301",
    "\xEC": "i\u0300",
    "\xEF": "i\u0308",
    "\u1E2F": "i\u0308\u0301",
    "\u0129": "i\u0303",
    "\u012B": "i\u0304",
    "\u012D": "i\u0306",
    "\u01D0": "i\u030C",
    "\xEE": "i\u0302",
    "\u01F0": "j\u030C",
    "\u0135": "j\u0302",
    "\u1E31": "k\u0301",
    "\u01E9": "k\u030C",
    "\u0137": "k\u0327",
    "\u013A": "l\u0301",
    "\u013E": "l\u030C",
    "\u013C": "l\u0327",
    "\u1E3F": "m\u0301",
    "\u1E41": "m\u0307",
    "\u0144": "n\u0301",
    "\u01F9": "n\u0300",
    "\xF1": "n\u0303",
    "\u0148": "n\u030C",
    "\u1E45": "n\u0307",
    "\u0146": "n\u0327",
    "\xF3": "o\u0301",
    "\xF2": "o\u0300",
    "\xF6": "o\u0308",
    "\u022B": "o\u0308\u0304",
    "\xF5": "o\u0303",
    "\u1E4D": "o\u0303\u0301",
    "\u1E4F": "o\u0303\u0308",
    "\u022D": "o\u0303\u0304",
    "\u014D": "o\u0304",
    "\u1E53": "o\u0304\u0301",
    "\u1E51": "o\u0304\u0300",
    "\u014F": "o\u0306",
    "\u01D2": "o\u030C",
    "\xF4": "o\u0302",
    "\u1ED1": "o\u0302\u0301",
    "\u1ED3": "o\u0302\u0300",
    "\u1ED7": "o\u0302\u0303",
    "\u022F": "o\u0307",
    "\u0231": "o\u0307\u0304",
    "\u0151": "o\u030B",
    "\u1E55": "p\u0301",
    "\u1E57": "p\u0307",
    "\u0155": "r\u0301",
    "\u0159": "r\u030C",
    "\u1E59": "r\u0307",
    "\u0157": "r\u0327",
    "\u015B": "s\u0301",
    "\u1E65": "s\u0301\u0307",
    "\u0161": "s\u030C",
    "\u1E67": "s\u030C\u0307",
    "\u015D": "s\u0302",
    "\u1E61": "s\u0307",
    "\u015F": "s\u0327",
    "\u1E97": "t\u0308",
    "\u0165": "t\u030C",
    "\u1E6B": "t\u0307",
    "\u0163": "t\u0327",
    "\xFA": "u\u0301",
    "\xF9": "u\u0300",
    "\xFC": "u\u0308",
    "\u01D8": "u\u0308\u0301",
    "\u01DC": "u\u0308\u0300",
    "\u01D6": "u\u0308\u0304",
    "\u01DA": "u\u0308\u030C",
    "\u0169": "u\u0303",
    "\u1E79": "u\u0303\u0301",
    "\u016B": "u\u0304",
    "\u1E7B": "u\u0304\u0308",
    "\u016D": "u\u0306",
    "\u01D4": "u\u030C",
    "\xFB": "u\u0302",
    "\u016F": "u\u030A",
    "\u0171": "u\u030B",
    "\u1E7D": "v\u0303",
    "\u1E83": "w\u0301",
    "\u1E81": "w\u0300",
    "\u1E85": "w\u0308",
    "\u0175": "w\u0302",
    "\u1E87": "w\u0307",
    "\u1E98": "w\u030A",
    "\u1E8D": "x\u0308",
    "\u1E8B": "x\u0307",
    "\xFD": "y\u0301",
    "\u1EF3": "y\u0300",
    "\xFF": "y\u0308",
    "\u1EF9": "y\u0303",
    "\u0233": "y\u0304",
    "\u0177": "y\u0302",
    "\u1E8F": "y\u0307",
    "\u1E99": "y\u030A",
    "\u017A": "z\u0301",
    "\u017E": "z\u030C",
    "\u1E91": "z\u0302",
    "\u017C": "z\u0307",
    "\xC1": "A\u0301",
    "\xC0": "A\u0300",
    "\xC4": "A\u0308",
    "\u01DE": "A\u0308\u0304",
    "\xC3": "A\u0303",
    "\u0100": "A\u0304",
    "\u0102": "A\u0306",
    "\u1EAE": "A\u0306\u0301",
    "\u1EB0": "A\u0306\u0300",
    "\u1EB4": "A\u0306\u0303",
    "\u01CD": "A\u030C",
    "\xC2": "A\u0302",
    "\u1EA4": "A\u0302\u0301",
    "\u1EA6": "A\u0302\u0300",
    "\u1EAA": "A\u0302\u0303",
    "\u0226": "A\u0307",
    "\u01E0": "A\u0307\u0304",
    "\xC5": "A\u030A",
    "\u01FA": "A\u030A\u0301",
    "\u1E02": "B\u0307",
    "\u0106": "C\u0301",
    "\u1E08": "C\u0327\u0301",
    "\u010C": "C\u030C",
    "\u0108": "C\u0302",
    "\u010A": "C\u0307",
    "\xC7": "C\u0327",
    "\u010E": "D\u030C",
    "\u1E0A": "D\u0307",
    "\u1E10": "D\u0327",
    "\xC9": "E\u0301",
    "\xC8": "E\u0300",
    "\xCB": "E\u0308",
    "\u1EBC": "E\u0303",
    "\u0112": "E\u0304",
    "\u1E16": "E\u0304\u0301",
    "\u1E14": "E\u0304\u0300",
    "\u0114": "E\u0306",
    "\u1E1C": "E\u0327\u0306",
    "\u011A": "E\u030C",
    "\xCA": "E\u0302",
    "\u1EBE": "E\u0302\u0301",
    "\u1EC0": "E\u0302\u0300",
    "\u1EC4": "E\u0302\u0303",
    "\u0116": "E\u0307",
    "\u0228": "E\u0327",
    "\u1E1E": "F\u0307",
    "\u01F4": "G\u0301",
    "\u1E20": "G\u0304",
    "\u011E": "G\u0306",
    "\u01E6": "G\u030C",
    "\u011C": "G\u0302",
    "\u0120": "G\u0307",
    "\u0122": "G\u0327",
    "\u1E26": "H\u0308",
    "\u021E": "H\u030C",
    "\u0124": "H\u0302",
    "\u1E22": "H\u0307",
    "\u1E28": "H\u0327",
    "\xCD": "I\u0301",
    "\xCC": "I\u0300",
    "\xCF": "I\u0308",
    "\u1E2E": "I\u0308\u0301",
    "\u0128": "I\u0303",
    "\u012A": "I\u0304",
    "\u012C": "I\u0306",
    "\u01CF": "I\u030C",
    "\xCE": "I\u0302",
    "\u0130": "I\u0307",
    "\u0134": "J\u0302",
    "\u1E30": "K\u0301",
    "\u01E8": "K\u030C",
    "\u0136": "K\u0327",
    "\u0139": "L\u0301",
    "\u013D": "L\u030C",
    "\u013B": "L\u0327",
    "\u1E3E": "M\u0301",
    "\u1E40": "M\u0307",
    "\u0143": "N\u0301",
    "\u01F8": "N\u0300",
    "\xD1": "N\u0303",
    "\u0147": "N\u030C",
    "\u1E44": "N\u0307",
    "\u0145": "N\u0327",
    "\xD3": "O\u0301",
    "\xD2": "O\u0300",
    "\xD6": "O\u0308",
    "\u022A": "O\u0308\u0304",
    "\xD5": "O\u0303",
    "\u1E4C": "O\u0303\u0301",
    "\u1E4E": "O\u0303\u0308",
    "\u022C": "O\u0303\u0304",
    "\u014C": "O\u0304",
    "\u1E52": "O\u0304\u0301",
    "\u1E50": "O\u0304\u0300",
    "\u014E": "O\u0306",
    "\u01D1": "O\u030C",
    "\xD4": "O\u0302",
    "\u1ED0": "O\u0302\u0301",
    "\u1ED2": "O\u0302\u0300",
    "\u1ED6": "O\u0302\u0303",
    "\u022E": "O\u0307",
    "\u0230": "O\u0307\u0304",
    "\u0150": "O\u030B",
    "\u1E54": "P\u0301",
    "\u1E56": "P\u0307",
    "\u0154": "R\u0301",
    "\u0158": "R\u030C",
    "\u1E58": "R\u0307",
    "\u0156": "R\u0327",
    "\u015A": "S\u0301",
    "\u1E64": "S\u0301\u0307",
    "\u0160": "S\u030C",
    "\u1E66": "S\u030C\u0307",
    "\u015C": "S\u0302",
    "\u1E60": "S\u0307",
    "\u015E": "S\u0327",
    "\u0164": "T\u030C",
    "\u1E6A": "T\u0307",
    "\u0162": "T\u0327",
    "\xDA": "U\u0301",
    "\xD9": "U\u0300",
    "\xDC": "U\u0308",
    "\u01D7": "U\u0308\u0301",
    "\u01DB": "U\u0308\u0300",
    "\u01D5": "U\u0308\u0304",
    "\u01D9": "U\u0308\u030C",
    "\u0168": "U\u0303",
    "\u1E78": "U\u0303\u0301",
    "\u016A": "U\u0304",
    "\u1E7A": "U\u0304\u0308",
    "\u016C": "U\u0306",
    "\u01D3": "U\u030C",
    "\xDB": "U\u0302",
    "\u016E": "U\u030A",
    "\u0170": "U\u030B",
    "\u1E7C": "V\u0303",
    "\u1E82": "W\u0301",
    "\u1E80": "W\u0300",
    "\u1E84": "W\u0308",
    "\u0174": "W\u0302",
    "\u1E86": "W\u0307",
    "\u1E8C": "X\u0308",
    "\u1E8A": "X\u0307",
    "\xDD": "Y\u0301",
    "\u1EF2": "Y\u0300",
    "\u0178": "Y\u0308",
    "\u1EF8": "Y\u0303",
    "\u0232": "Y\u0304",
    "\u0176": "Y\u0302",
    "\u1E8E": "Y\u0307",
    "\u0179": "Z\u0301",
    "\u017D": "Z\u030C",
    "\u1E90": "Z\u0302",
    "\u017B": "Z\u0307",
    "\u03AC": "\u03B1\u0301",
    "\u1F70": "\u03B1\u0300",
    "\u1FB1": "\u03B1\u0304",
    "\u1FB0": "\u03B1\u0306",
    "\u03AD": "\u03B5\u0301",
    "\u1F72": "\u03B5\u0300",
    "\u03AE": "\u03B7\u0301",
    "\u1F74": "\u03B7\u0300",
    "\u03AF": "\u03B9\u0301",
    "\u1F76": "\u03B9\u0300",
    "\u03CA": "\u03B9\u0308",
    "\u0390": "\u03B9\u0308\u0301",
    "\u1FD2": "\u03B9\u0308\u0300",
    "\u1FD1": "\u03B9\u0304",
    "\u1FD0": "\u03B9\u0306",
    "\u03CC": "\u03BF\u0301",
    "\u1F78": "\u03BF\u0300",
    "\u03CD": "\u03C5\u0301",
    "\u1F7A": "\u03C5\u0300",
    "\u03CB": "\u03C5\u0308",
    "\u03B0": "\u03C5\u0308\u0301",
    "\u1FE2": "\u03C5\u0308\u0300",
    "\u1FE1": "\u03C5\u0304",
    "\u1FE0": "\u03C5\u0306",
    "\u03CE": "\u03C9\u0301",
    "\u1F7C": "\u03C9\u0300",
    "\u038E": "\u03A5\u0301",
    "\u1FEA": "\u03A5\u0300",
    "\u03AB": "\u03A5\u0308",
    "\u1FE9": "\u03A5\u0304",
    "\u1FE8": "\u03A5\u0306",
    "\u038F": "\u03A9\u0301",
    "\u1FFA": "\u03A9\u0300"
  };
  var Parser = class _Parser {
    constructor(input, settings) {
      this.mode = void 0;
      this.gullet = void 0;
      this.settings = void 0;
      this.leftrightDepth = void 0;
      this.nextToken = void 0;
      this.mode = "math";
      this.gullet = new MacroExpander(input, settings, this.mode);
      this.settings = settings;
      this.leftrightDepth = 0;
      this.nextToken = null;
    }
    /**
     * Checks a result to make sure it has the right type, and throws an
     * appropriate error otherwise.
     */
    expect(text2, consume) {
      if (consume === void 0) {
        consume = true;
      }
      if (this.fetch().text !== text2) {
        throw new ParseError("Expected '" + text2 + "', got '" + this.fetch().text + "'", this.fetch());
      }
      if (consume) {
        this.consume();
      }
    }
    /**
     * Discards the current lookahead token, considering it consumed.
     */
    consume() {
      this.nextToken = null;
    }
    /**
     * Return the current lookahead token, or if there isn't one (at the
     * beginning, or if the previous lookahead token was consume()d),
     * fetch the next token as the new lookahead token and return it.
     */
    fetch() {
      if (this.nextToken == null) {
        this.nextToken = this.gullet.expandNextToken();
      }
      return this.nextToken;
    }
    /**
     * Switches between "text" and "math" modes.
     */
    switchMode(newMode) {
      this.mode = newMode;
      this.gullet.switchMode(newMode);
    }
    /**
     * Main parsing function, which parses an entire input.
     */
    parse() {
      if (!this.settings.globalGroup) {
        this.gullet.beginGroup();
      }
      if (this.settings.colorIsTextColor) {
        this.gullet.macros.set("\\color", "\\textcolor");
      }
      try {
        var parse = this.parseExpression(false);
        this.expect("EOF");
        if (!this.settings.globalGroup) {
          this.gullet.endGroup();
        }
        return parse;
      } finally {
        this.gullet.endGroups();
      }
    }
    /**
     * Fully parse a separate sequence of tokens as a separate job.
     * Tokens should be specified in reverse order, as in a MacroDefinition.
     */
    subparse(tokens) {
      var oldToken = this.nextToken;
      this.consume();
      this.gullet.pushToken(new Token("}"));
      this.gullet.pushTokens(tokens);
      var parse = this.parseExpression(false);
      this.expect("}");
      this.nextToken = oldToken;
      return parse;
    }
    /**
     * Parses an "expression", which is a list of atoms.
     *
     * `breakOnInfix`: Should the parsing stop when we hit infix nodes? This
     *                 happens when functions have higher precedence than infix
     *                 nodes in implicit parses.
     *
     * `breakOnTokenText`: The text of the token that the expression should end
     *                     with, or `null` if something else should end the
     *                     expression.
     */
    parseExpression(breakOnInfix, breakOnTokenText) {
      var body = [];
      while (true) {
        if (this.mode === "math") {
          this.consumeSpaces();
        }
        var lex = this.fetch();
        if (_Parser.endOfExpression.has(lex.text)) {
          break;
        }
        if (breakOnTokenText && lex.text === breakOnTokenText) {
          break;
        }
        if (breakOnInfix && functions[lex.text] && functions[lex.text].infix) {
          break;
        }
        var atom = this.parseAtom(breakOnTokenText);
        if (!atom) {
          break;
        } else if (atom.type === "internal") {
          continue;
        }
        body.push(atom);
      }
      if (this.mode === "text") {
        this.formLigatures(body);
      }
      return this.handleInfixNodes(body);
    }
    /**
     * Rewrites infix operators such as \over with corresponding commands such
     * as \frac.
     *
     * There can only be one infix operator per group.  If there's more than one
     * then the expression is ambiguous.  This can be resolved by adding {}.
     */
    handleInfixNodes(body) {
      var overIndex = -1;
      var funcName;
      for (var i3 = 0; i3 < body.length; i3++) {
        var node = body[i3];
        if (node.type === "infix") {
          if (overIndex !== -1) {
            throw new ParseError("only one infix operator per group", node.token);
          }
          overIndex = i3;
          funcName = node.replaceWith;
        }
      }
      if (overIndex !== -1 && funcName) {
        var numerNode;
        var denomNode;
        var numerBody = body.slice(0, overIndex);
        var denomBody = body.slice(overIndex + 1);
        if (numerBody.length === 1 && numerBody[0].type === "ordgroup") {
          numerNode = numerBody[0];
        } else {
          numerNode = {
            type: "ordgroup",
            mode: this.mode,
            body: numerBody
          };
        }
        if (denomBody.length === 1 && denomBody[0].type === "ordgroup") {
          denomNode = denomBody[0];
        } else {
          denomNode = {
            type: "ordgroup",
            mode: this.mode,
            body: denomBody
          };
        }
        var _node;
        if (funcName === "\\\\abovefrac") {
          _node = this.callFunction(funcName, [numerNode, body[overIndex], denomNode], []);
        } else {
          _node = this.callFunction(funcName, [numerNode, denomNode], []);
        }
        return [_node];
      } else {
        return body;
      }
    }
    /**
     * Handle a subscript or superscript with nice errors.
     */
    handleSupSubscript(name) {
      var symbolToken = this.fetch();
      var symbol = symbolToken.text;
      this.consume();
      this.consumeSpaces();
      var group;
      do {
        var _group;
        group = this.parseGroup(name);
      } while (((_group = group) == null ? void 0 : _group.type) === "internal");
      if (!group) {
        throw new ParseError("Expected group after '" + symbol + "'", symbolToken);
      }
      return group;
    }
    /**
     * Converts the textual input of an unsupported command into a text node
     * contained within a color node whose color is determined by errorColor
     */
    formatUnsupportedCmd(text2) {
      var textordArray = [];
      for (var i3 = 0; i3 < text2.length; i3++) {
        textordArray.push({
          type: "textord",
          mode: "text",
          text: text2[i3]
        });
      }
      var textNode = {
        type: "text",
        mode: this.mode,
        body: textordArray
      };
      var colorNode = {
        type: "color",
        mode: this.mode,
        color: this.settings.errorColor,
        body: [textNode]
      };
      return colorNode;
    }
    /**
     * Parses a group with optional super/subscripts.
     */
    parseAtom(breakOnTokenText) {
      var base = this.parseGroup("atom", breakOnTokenText);
      if ((base == null ? void 0 : base.type) === "internal") {
        return base;
      }
      if (this.mode === "text") {
        return base;
      }
      var superscript;
      var subscript;
      while (true) {
        this.consumeSpaces();
        var lex = this.fetch();
        if (lex.text === "\\limits" || lex.text === "\\nolimits") {
          if (base && base.type === "op") {
            base.limits = lex.text === "\\limits";
            base.alwaysHandleSupSub = true;
          } else if (base && base.type === "operatorname") {
            if (base.alwaysHandleSupSub) {
              base.limits = lex.text === "\\limits";
            }
          } else {
            throw new ParseError("Limit controls must follow a math operator", lex);
          }
          this.consume();
        } else if (lex.text === "^") {
          if (superscript) {
            throw new ParseError("Double superscript", lex);
          }
          superscript = this.handleSupSubscript("superscript");
        } else if (lex.text === "_") {
          if (subscript) {
            throw new ParseError("Double subscript", lex);
          }
          subscript = this.handleSupSubscript("subscript");
        } else if (lex.text === "'") {
          if (superscript) {
            throw new ParseError("Double superscript", lex);
          }
          var prime = {
            type: "textord",
            mode: this.mode,
            text: "\\prime"
          };
          var primes = [prime];
          this.consume();
          while (this.fetch().text === "'") {
            primes.push(prime);
            this.consume();
          }
          if (this.fetch().text === "^") {
            primes.push(this.handleSupSubscript("superscript"));
          }
          superscript = {
            type: "ordgroup",
            mode: this.mode,
            body: primes
          };
        } else if (uSubsAndSups[lex.text]) {
          var isSub = unicodeSubRegEx.test(lex.text);
          var subsupTokens = [];
          subsupTokens.push(new Token(uSubsAndSups[lex.text]));
          this.consume();
          while (true) {
            var token = this.fetch().text;
            if (!uSubsAndSups[token]) {
              break;
            }
            if (unicodeSubRegEx.test(token) !== isSub) {
              break;
            }
            subsupTokens.unshift(new Token(uSubsAndSups[token]));
            this.consume();
          }
          var body = this.subparse(subsupTokens);
          if (isSub) {
            subscript = {
              type: "ordgroup",
              mode: "math",
              body
            };
          } else {
            superscript = {
              type: "ordgroup",
              mode: "math",
              body
            };
          }
        } else {
          break;
        }
      }
      if (superscript && subscript) {
        return {
          type: "supsub",
          mode: this.mode,
          base,
          sup: superscript,
          sub: subscript
        };
      } else if (superscript) {
        return {
          type: "supsub",
          mode: this.mode,
          base,
          sup: superscript
        };
      } else if (subscript) {
        return {
          type: "supsub",
          mode: this.mode,
          base,
          sub: subscript
        };
      } else {
        return base;
      }
    }
    /**
     * Parses an entire function, including its base and all of its arguments.
     */
    parseFunction(breakOnTokenText, name) {
      var token = this.fetch();
      var func = token.text;
      var funcData = functions[func];
      if (!funcData) {
        return null;
      }
      this.consume();
      if (name && name !== "atom" && !funcData.allowedInArgument) {
        throw new ParseError("Got function '" + func + "' with no arguments" + (name ? " as " + name : ""), token);
      } else if (this.mode === "text" && !funcData.allowedInText) {
        throw new ParseError("Can't use function '" + func + "' in text mode", token);
      } else if (this.mode === "math" && funcData.allowedInMath === false) {
        throw new ParseError("Can't use function '" + func + "' in math mode", token);
      }
      var _this$parseArguments = this.parseArguments(func, funcData), args = _this$parseArguments.args, optArgs = _this$parseArguments.optArgs;
      return this.callFunction(func, args, optArgs, token, breakOnTokenText);
    }
    /**
     * Call a function handler with a suitable context and arguments.
     */
    callFunction(name, args, optArgs, token, breakOnTokenText) {
      var context = {
        funcName: name,
        parser: this,
        token,
        breakOnTokenText
      };
      var func = functions[name];
      if (func && func.handler) {
        return func.handler(context, args, optArgs);
      } else {
        throw new ParseError("No function handler for " + name);
      }
    }
    /**
     * Parses the arguments of a function or environment
     */
    parseArguments(func, funcData) {
      var _funcData$numOptional;
      var numOptionalArgs = (_funcData$numOptional = funcData.numOptionalArgs) != null ? _funcData$numOptional : 0;
      var totalArgs = funcData.numArgs + numOptionalArgs;
      if (totalArgs === 0) {
        return {
          args: [],
          optArgs: []
        };
      }
      var args = [];
      var optArgs = [];
      for (var i3 = 0; i3 < totalArgs; i3++) {
        var _funcData$argTypes;
        var argType = (_funcData$argTypes = funcData.argTypes) == null ? void 0 : _funcData$argTypes[i3];
        var isOptional = i3 < numOptionalArgs;
        if ("primitive" in funcData && funcData.primitive && argType == null || // \sqrt expands into primitive if optional argument doesn't exist
        funcData.type === "sqrt" && i3 === 1 && optArgs[0] == null) {
          argType = "primitive";
        }
        var arg = this.parseGroupOfType("argument to '" + func + "'", argType, isOptional);
        if (isOptional) {
          optArgs.push(arg);
        } else if (arg != null) {
          args.push(arg);
        } else {
          throw new ParseError("Null argument, please report this as a bug");
        }
      }
      return {
        args,
        optArgs
      };
    }
    /**
     * Parses a group when the mode is changing.
     */
    parseGroupOfType(name, type, optional) {
      switch (type) {
        case "color":
          return this.parseColorGroup(optional);
        case "size":
          return this.parseSizeGroup(optional);
        case "url":
          return this.parseUrlGroup(optional);
        case "math":
        case "text":
          return this.parseArgumentGroup(optional, type);
        case "hbox": {
          var group = this.parseArgumentGroup(optional, "text");
          return group != null ? {
            type: "styling",
            mode: group.mode,
            body: [group],
            style: "text",
            // simulate \textstyle
            resetFont: true
          } : null;
        }
        case "raw": {
          this.gullet.consumeSpaces();
          var percentCatcode = this.gullet.lexer.catcodes["%"];
          this.gullet.lexer.setCatcode("%", 12);
          var token = this.parseStringGroup(optional);
          this.gullet.lexer.setCatcode("%", percentCatcode);
          return token != null ? {
            type: "raw",
            mode: "text",
            string: token.text
          } : null;
        }
        case "primitive": {
          if (optional) {
            throw new ParseError("A primitive argument cannot be optional");
          }
          var _group2 = this.parseGroup(name);
          if (_group2 == null) {
            throw new ParseError("Expected group as " + name, this.fetch());
          }
          return _group2;
        }
        case "original":
        case void 0:
          return this.parseArgumentGroup(optional);
        default:
          throw new ParseError("Unknown group type as " + name, this.fetch());
      }
    }
    /**
     * Discard any space tokens, fetching the next non-space token.
     */
    consumeSpaces() {
      while (this.fetch().text === " ") {
        this.consume();
      }
    }
    /**
     * Parses a group, essentially returning the string formed by the
     * brace-enclosed tokens plus some position information.
     */
    parseStringGroup(optional) {
      var argToken = this.gullet.scanArgument(optional);
      if (argToken == null) {
        return null;
      }
      var str = "";
      var nextToken;
      while ((nextToken = this.fetch()).text !== "EOF") {
        str += nextToken.text;
        this.consume();
      }
      this.consume();
      argToken.text = str;
      return argToken;
    }
    /**
     * Parses a regex-delimited group: the largest sequence of tokens
     * whose concatenated strings match `regex`. Returns the string
     * formed by the tokens plus some position information.
     */
    parseRegexGroup(regex, modeName) {
      var firstToken = this.fetch();
      var lastToken = firstToken;
      var str = "";
      var nextToken;
      while ((nextToken = this.fetch()).text !== "EOF" && regex.test(str + nextToken.text)) {
        lastToken = nextToken;
        str += lastToken.text;
        this.consume();
      }
      if (str === "") {
        throw new ParseError("Invalid " + modeName + ": '" + firstToken.text + "'", firstToken);
      }
      return firstToken.range(lastToken, str);
    }
    /**
     * Parses a color description.
     */
    parseColorGroup(optional) {
      var res = this.parseStringGroup(optional);
      if (res == null) {
        return null;
      }
      var match = /^(#[a-f0-9]{3,4}|#[a-f0-9]{6}|#[a-f0-9]{8}|[a-f0-9]{6}|[a-z]+)$/i.exec(res.text);
      if (!match) {
        throw new ParseError("Invalid color: '" + res.text + "'", res);
      }
      var color = match[0];
      if (/^[0-9a-f]{6}$/i.test(color)) {
        color = "#" + color;
      }
      return {
        type: "color-token",
        mode: this.mode,
        color
      };
    }
    /**
     * Parses a size specification, consisting of magnitude and unit.
     */
    parseSizeGroup(optional) {
      var res;
      var isBlank = false;
      this.gullet.consumeSpaces();
      if (!optional && this.gullet.future().text !== "{") {
        res = this.parseRegexGroup(/^[-+]? *(?:$|\d+|\d+\.\d*|\.\d*) *[a-z]{0,2} *$/, "size");
      } else {
        res = this.parseStringGroup(optional);
      }
      if (!res) {
        return null;
      }
      if (!optional && res.text.length === 0) {
        res.text = "0pt";
        isBlank = true;
      }
      var match = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(res.text);
      if (!match) {
        throw new ParseError("Invalid size: '" + res.text + "'", res);
      }
      var data = {
        number: +(match[1] + match[2]),
        // sign + magnitude, cast to number
        unit: match[3]
      };
      if (!validUnit(data)) {
        throw new ParseError("Invalid unit: '" + data.unit + "'", res);
      }
      return {
        type: "size",
        mode: this.mode,
        value: data,
        isBlank
      };
    }
    /**
     * Parses an URL, checking escaped letters and allowed protocols,
     * and setting the catcode of % as an active character (as in \hyperref).
     */
    parseUrlGroup(optional) {
      var percentCatcode = this.gullet.lexer.catcodes["%"];
      var tildeCatcode = this.gullet.lexer.catcodes["~"];
      this.gullet.lexer.setCatcode("%", 13);
      this.gullet.lexer.setCatcode("~", 12);
      var res = this.parseStringGroup(optional);
      this.gullet.lexer.setCatcode("%", percentCatcode);
      this.gullet.lexer.setCatcode("~", tildeCatcode);
      if (res == null) {
        return null;
      }
      var url = res.text.replace(/\\([#$%&~_^{}])/g, "$1");
      return {
        type: "url",
        mode: this.mode,
        url
      };
    }
    /**
     * Parses an argument with the mode specified.
     */
    parseArgumentGroup(optional, mode) {
      var argToken = this.gullet.scanArgument(optional);
      if (argToken == null) {
        return null;
      }
      var outerMode = this.mode;
      if (mode) {
        this.switchMode(mode);
      }
      this.gullet.beginGroup();
      var expression = this.parseExpression(false, "EOF");
      this.expect("EOF");
      this.gullet.endGroup();
      var result = {
        type: "ordgroup",
        mode: this.mode,
        loc: argToken.loc,
        body: expression
      };
      if (mode) {
        this.switchMode(outerMode);
      }
      return result;
    }
    /**
     * Parses an ordinary group, which is either a single nucleus (like "x")
     * or an expression in braces (like "{x+y}") or an implicit group, a group
     * that starts at the current position, and ends right before a higher explicit
     * group ends, or at EOF.
     */
    parseGroup(name, breakOnTokenText) {
      var firstToken = this.fetch();
      var text2 = firstToken.text;
      var result;
      if (text2 === "{" || text2 === "\\begingroup") {
        this.consume();
        var groupEnd = text2 === "{" ? "}" : "\\endgroup";
        this.gullet.beginGroup();
        var expression = this.parseExpression(false, groupEnd);
        var lastToken = this.fetch();
        this.expect(groupEnd);
        this.gullet.endGroup();
        result = {
          type: "ordgroup",
          mode: this.mode,
          loc: SourceLocation.range(firstToken, lastToken),
          body: expression,
          // A group formed by \begingroup...\endgroup is a semi-simple group
          // which doesn't affect spacing in math mode, i.e., is transparent.
          // https://tex.stackexchange.com/questions/1930/when-should-one-
          // use-begingroup-instead-of-bgroup
          semisimple: text2 === "\\begingroup" || void 0
        };
      } else {
        result = this.parseFunction(breakOnTokenText, name) || this.parseSymbol();
        if (result == null && text2[0] === "\\" && !Object.prototype.hasOwnProperty.call(implicitCommands, text2)) {
          if (this.settings.throwOnError) {
            throw new ParseError("Undefined control sequence: " + text2, firstToken);
          }
          result = this.formatUnsupportedCmd(text2);
          this.consume();
        }
      }
      return result;
    }
    /**
     * Form ligature-like combinations of characters for text mode.
     * This includes inputs like "--", "---", "``" and "''".
     * The result will simply replace multiple textord nodes with a single
     * character in each value by a single textord node having multiple
     * characters in its value.  The representation is still ASCII source.
     * The group will be modified in place.
     */
    formLigatures(group) {
      var n2 = group.length - 1;
      for (var i3 = 0; i3 < n2; ++i3) {
        var a4 = group[i3];
        if (a4.type !== "textord") {
          continue;
        }
        var v3 = a4.text;
        var next = group[i3 + 1];
        if (!next || next.type !== "textord") {
          continue;
        }
        if (v3 === "-" && next.text === "-") {
          var afterNext = group[i3 + 2];
          if (i3 + 1 < n2 && afterNext && afterNext.type === "textord" && afterNext.text === "-") {
            group.splice(i3, 3, {
              type: "textord",
              mode: "text",
              loc: SourceLocation.range(a4, afterNext),
              text: "---"
            });
            n2 -= 2;
          } else {
            group.splice(i3, 2, {
              type: "textord",
              mode: "text",
              loc: SourceLocation.range(a4, next),
              text: "--"
            });
            n2 -= 1;
          }
        }
        if ((v3 === "'" || v3 === "`") && next.text === v3) {
          group.splice(i3, 2, {
            type: "textord",
            mode: "text",
            loc: SourceLocation.range(a4, next),
            text: v3 + v3
          });
          n2 -= 1;
        }
      }
    }
    /**
     * Parse a single symbol out of the string. Here, we handle single character
     * symbols and special functions like \verb.
     */
    parseSymbol() {
      var nucleus = this.fetch();
      var text2 = nucleus.text;
      if (/^\\verb[^a-zA-Z]/.test(text2)) {
        this.consume();
        var arg = text2.slice(5);
        var star = arg.charAt(0) === "*";
        if (star) {
          arg = arg.slice(1);
        }
        if (arg.length < 2 || arg.charAt(0) !== arg.slice(-1)) {
          throw new ParseError("\\verb assertion failed --\n                    please report what input caused this bug");
        }
        arg = arg.slice(1, -1);
        return {
          type: "verb",
          mode: "text",
          body: arg,
          star
        };
      }
      if (Object.prototype.hasOwnProperty.call(unicodeSymbols, text2[0]) && !symbols[this.mode][text2[0]]) {
        if (this.settings.strict && this.mode === "math") {
          handleStrict({
            strict: this.settings.strict,
            errorCode: "unicodeTextInMathMode",
            errorMsg: 'Accented Unicode text character "' + text2[0] + '" used in math mode',
            report: true,
            token: nucleus
          });
        }
        text2 = unicodeSymbols[text2[0]] + text2.slice(1);
      }
      var match = combiningDiacriticalMarksEndRegex.exec(text2);
      if (match) {
        text2 = text2.substring(0, match.index);
        if (text2 === "i") {
          text2 = "\u0131";
        } else if (text2 === "j") {
          text2 = "\u0237";
        }
      }
      var symbol;
      if (symbols[this.mode][text2]) {
        if (this.settings.strict && this.mode === "math" && extraLatin.includes(text2)) {
          handleStrict({
            strict: this.settings.strict,
            errorCode: "unicodeTextInMathMode",
            errorMsg: 'Latin-1/Unicode text character "' + text2[0] + '" used in math mode',
            report: true,
            token: nucleus
          });
        }
        var group = symbols[this.mode][text2].group;
        var loc = SourceLocation.range(nucleus);
        var s3;
        if (isAtom(group)) {
          s3 = {
            type: "atom",
            mode: this.mode,
            family: group,
            loc,
            text: text2
          };
        } else {
          s3 = {
            type: group,
            mode: this.mode,
            loc,
            text: text2
          };
        }
        symbol = s3;
      } else if (text2.charCodeAt(0) >= 128) {
        if (this.settings.strict) {
          if (!supportedCodepoint(text2.charCodeAt(0))) {
            handleStrict({
              strict: this.settings.strict,
              errorCode: "unknownSymbol",
              errorMsg: 'Unrecognized Unicode character "' + text2[0] + '"' + (" (" + text2.charCodeAt(0) + ")"),
              report: true,
              token: nucleus
            });
          } else if (this.mode === "math") {
            handleStrict({
              strict: this.settings.strict,
              errorCode: "unicodeTextInMathMode",
              errorMsg: 'Unicode text character "' + text2[0] + '" used in math mode',
              report: true,
              token: nucleus
            });
          }
        }
        symbol = {
          type: "textord",
          mode: "text",
          loc: SourceLocation.range(nucleus),
          text: text2
        };
      } else {
        return null;
      }
      this.consume();
      if (match) {
        for (var i3 = 0; i3 < match[0].length; i3++) {
          var accent2 = match[0][i3];
          if (!unicodeAccents[accent2]) {
            throw new ParseError("Unknown accent ' " + accent2 + "'", nucleus);
          }
          var command = unicodeAccents[accent2][this.mode] || unicodeAccents[accent2].text;
          if (!command) {
            throw new ParseError("Accent " + accent2 + " unsupported in " + this.mode + " mode", nucleus);
          }
          symbol = {
            type: "accent",
            mode: this.mode,
            loc: SourceLocation.range(nucleus),
            label: command,
            isStretchy: false,
            isShifty: true,
            base: symbol
          };
        }
      }
      return symbol;
    }
  };
  Parser.endOfExpression = /* @__PURE__ */ new Set(["}", "\\endgroup", "\\end", "\\right", "&"]);
  var parseTree = function parseTree2(toParse, settings) {
    if (!(typeof toParse === "string" || toParse instanceof String)) {
      throw new TypeError("KaTeX can only parse string typed expression");
    }
    var parser = new Parser(toParse, settings);
    delete parser.gullet.macros.current["\\df@tag"];
    var tree = parser.parse();
    delete parser.gullet.macros.current["\\current@color"];
    delete parser.gullet.macros.current["\\color"];
    if (parser.gullet.macros.get("\\df@tag")) {
      if (!settings.displayMode) {
        throw new ParseError("\\tag works only in display equations");
      }
      tree = [{
        type: "tag",
        mode: "text",
        body: tree,
        tag: parser.subparse([new Token("\\df@tag")])
      }];
    }
    return tree;
  };
  var render = function render2(expression, baseNode, options) {
    baseNode.textContent = "";
    var node = renderToDomTree(expression, options).toNode();
    baseNode.appendChild(node);
  };
  if (typeof document !== "undefined") {
    if (document.compatMode !== "CSS1Compat") {
      typeof console !== "undefined" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype.");
      render = function render3() {
        throw new ParseError("KaTeX doesn't work in quirks mode.");
      };
    }
  }
  var renderToString = function renderToString2(expression, options) {
    var markup = renderToDomTree(expression, options).toMarkup();
    return markup;
  };
  var renderError = function renderError2(error, expression, options) {
    if (options.throwOnError || !(error instanceof ParseError)) {
      throw error;
    }
    var node = makeSpan(["katex-error"], [new SymbolNode(expression)]);
    node.setAttribute("title", error.toString());
    node.setAttribute("style", "color:" + options.errorColor);
    return node;
  };
  var renderToDomTree = function renderToDomTree2(expression, options) {
    var settings = new Settings(options);
    try {
      var tree = parseTree(expression, settings);
      return buildTree(tree, expression, settings);
    } catch (error) {
      return renderError(error, expression, settings);
    }
  };

  // extension/assistantTransport.ts
  function validateBackendUrl(value) {
    let url;
    try {
      url = new URL(value);
    } catch {
      throw new Error("Enter a local backend URL, for example http://127.0.0.1:8765.");
    }
    if (url.protocol !== "http:" || !["127.0.0.1", "localhost"].includes(url.hostname) || url.username || url.password || url.search || url.hash || !["", "/"].includes(url.pathname)) {
      throw new Error("The AI backend must be an HTTP service on localhost.");
    }
    return url.origin;
  }
  function validateAssistantPath(path2, method) {
    const get = method === "GET" && (/^\/api\/v1\/assistant\/health$/.test(path2) || /^\/api\/v1\/assistant\/jobs\/[a-zA-Z0-9_-]{1,80}$/.test(path2));
    const post = method === "POST" && /^\/api\/v1\/assistant\/(models\/pull|generate|browser\/plan|materials\/extract|jobs)$/.test(path2);
    if (!get && !post) throw new Error("This local assistant operation is not supported.");
  }
  async function localAssistantFetch(backendUrl, path2, method, body) {
    const origin = validateBackendUrl(backendUrl);
    validateAssistantPath(path2, method);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 24e3);
    try {
      const response = await fetch(origin + path2, {
        method,
        headers: { "Content-Type": "application/json", "X-Gradient-Client": "gradient-extension" },
        body: body === void 0 ? void 0 : JSON.stringify(body),
        credentials: "omit",
        redirect: "error",
        cache: "no-store",
        signal: controller.signal
      });
      const data = await response.json().catch(() => null);
      if (!response.ok) {
        const detail = data?.detail;
        throw new Error(typeof detail === "string" ? detail : `The local assistant returned HTTP ${response.status}.`);
      }
      return data;
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") throw new Error("The local assistant took too long to respond. Check that the service is running.");
      if (error instanceof TypeError) throw new Error("Cannot reach the local AI service. Start it on 127.0.0.1:8765, then check the connection.");
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }

  // extension/canvasMaterials.ts
  var MAX_FILE_BYTES = 12 * 1024 * 1024;
  function canvasHtmlText(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    doc.querySelectorAll("script,style,iframe,input,textarea,select").forEach((el) => el.remove());
    doc.querySelectorAll("p,br,li,h1,h2,h3,tr").forEach((el) => el.append(doc.createTextNode("\n")));
    return (doc.body.textContent ?? "").replace(/\n{3,}/g, "\n\n").trim();
  }
  function materialEndpoint(value, origin, courseId) {
    try {
      const url = new URL(value, origin);
      if (url.origin !== origin) return null;
      const page = url.pathname.match(/^\/courses\/([^/]+)\/pages\/([^/]+)\/?$/);
      if (page && page[1] === courseId) {
        const slug = decodeURIComponent(page[2]);
        if (/[\\/%]/.test(slug) || /^\.+$/.test(slug)) return null;
        return { kind: "page", path: `/api/v1/courses/${encodeURIComponent(courseId)}/pages/${encodeURIComponent(slug)}` };
      }
      const file = url.pathname.match(/^\/courses\/([^/]+)\/files\/(\d+)(?:\/download)?\/?$/);
      if (file && file[1] === courseId) return { kind: "file", path: `/api/v1/files/${file[2]}` };
      const globalFile = url.pathname.match(/^\/files\/(\d+)(?:\/download)?\/?$/);
      if (globalFile) return { kind: "file", path: `/api/v1/files/${globalFile[1]}` };
      return null;
    } catch {
      return null;
    }
  }
  async function boundedBytes(response) {
    if (Number(response.headers.get("Content-Length")) > MAX_FILE_BYTES) throw new Error("File exceeds the 12 MB reading limit.");
    if (!response.body) throw new Error("Canvas returned an empty file.");
    const reader = response.body.getReader();
    const chunks = [];
    let length = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        length += value.byteLength;
        if (length > MAX_FILE_BYTES) throw new Error("File exceeds the 12 MB reading limit.");
        chunks.push(value);
      }
    } catch (error) {
      await reader.cancel();
      throw error;
    } finally {
      reader.releaseLock();
    }
    const bytes = new Uint8Array(length);
    let position = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, position);
      position += chunk.length;
    }
    return bytes;
  }
  function base64(bytes) {
    let binary = "";
    for (let i3 = 0; i3 < bytes.length; i3 += 32768) binary += String.fromCharCode(...bytes.subarray(i3, i3 + 32768));
    return btoa(binary);
  }
  async function readCanvasMaterials(resources, origin, courseId, extract) {
    const warnings = [];
    const result = [];
    for (const resource of resources.slice(0, 12)) {
      if (resource.text?.trim()) {
        result.push({ ...resource, text: resource.text.slice(0, 22e3) });
        continue;
      }
      const endpoint = materialEndpoint(resource.url, origin, courseId);
      if (!endpoint) {
        result.push(resource);
        continue;
      }
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 18e3);
      try {
        const metadata = await fetch(origin + endpoint.path, { method: "GET", credentials: "include", cache: "no-store", redirect: "error", headers: { Accept: "application/json" }, signal: controller.signal });
        if (!metadata.ok) throw new Error(`Canvas returned HTTP ${metadata.status}.`);
        const record = JSON.parse((await metadata.text()).replace(/^\s*while\s*\(\s*1\s*\)\s*;\s*/, ""));
        if (record.locked_for_user || record.hidden_for_user || record.published === false) throw new Error("This material is locked or unpublished.");
        if (endpoint.kind === "page") {
          if (typeof record.body !== "string") throw new Error("Canvas did not return the page body.");
          result.push({ ...resource, text: canvasHtmlText(record.body).slice(0, 22e3) });
        } else {
          if (typeof record.url !== "string") throw new Error("Canvas did not return a download link.");
          const download2 = new URL(record.url, origin);
          if (download2.protocol !== "https:" && download2.origin !== origin) throw new Error("Canvas returned an unsupported download link.");
          const response = await fetch(download2.href, { method: "GET", credentials: download2.origin === origin ? "include" : "omit", redirect: "follow", signal: controller.signal });
          if (!response.ok) throw new Error(`File download returned HTTP ${response.status}.`);
          const bytes = await boundedBytes(response);
          const extracted = await extract({ title: record.display_name || resource.title, mimeType: record["content-type"] || response.headers.get("Content-Type") || "application/octet-stream", data: base64(bytes) });
          warnings.push(...extracted.warnings.map((w3) => `${resource.title}: ${w3}`));
          result.push({ ...resource, text: extracted.text.slice(0, 22e3) });
        }
      } catch (error) {
        result.push(resource);
        warnings.push(`${resource.title}: could not read contents (${error instanceof Error ? error.message : "access unavailable"}). The link is included for reference only.`);
      } finally {
        clearTimeout(timer);
      }
    }
    return { resources: result, warnings };
  }

  // extension/assistantClient.ts
  var DEFAULT_ASSISTANT_SETTINGS = {
    backendUrl: "http://127.0.0.1:8765",
    reasoningModel: "gpt-oss:20b",
    visionModel: "gemma4:e4b",
    detailLevel: "a_bit_more",
    webResearch: true
  };
  var SETTINGS_KEY = "gradient_assistant_settings";
  var settingsSchema = z2.object({
    backendUrl: z2.string().transform(validateBackendUrl),
    reasoningModel: z2.string().min(1).max(200),
    visionModel: z2.string().min(1).max(100),
    detailLevel: z2.enum(["a_bit", "a_bit_more", "all_in"]),
    webResearch: z2.boolean()
  });
  var packetSchema = z2.object({
    title: z2.string().max(1e3),
    summary: z2.string().max(1e4),
    markdown: z2.string().max(2e5),
    sampleMarkdown: z2.string().max(2e5),
    sources: z2.array(z2.object({ id: z2.string(), title: z2.string(), url: z2.string(), excerpt: z2.string().optional(), kind: z2.enum(["canvas", "web"]).optional() })).max(80),
    diagrams: z2.array(z2.object({ title: z2.string(), nodes: z2.array(z2.object({ id: z2.string(), label: z2.string() })).max(20), edges: z2.array(z2.object({ from: z2.string(), to: z2.string(), label: z2.string().optional() })).max(40) })).max(10),
    graphs: z2.array(z2.object({ title: z2.string(), xLabel: z2.string().optional(), yLabel: z2.string().optional(), points: z2.array(z2.object({ label: z2.string(), value: z2.number().finite() })).max(100) })).max(10),
    images: z2.array(z2.object({ title: z2.string(), url: z2.string(), alt: z2.string(), sourceUrl: z2.string() })).max(20),
    warnings: z2.array(z2.string()).max(100),
    checklist: z2.array(z2.string()).optional(),
    generatedAt: z2.string().optional()
  });
  function extensionAvailable() {
    return typeof chrome !== "undefined" && !!chrome.runtime?.id;
  }
  async function sendMessage(message2) {
    const response = await chrome.runtime.sendMessage(message2);
    if (!response?.ok) throw new Error(response?.error || "The extension could not complete this operation. Reload the extension and Canvas tab.");
    return response.data;
  }
  async function request(settings, path2, method, body) {
    const backendUrl = validateBackendUrl(settings.backendUrl);
    if (extensionAvailable()) return sendMessage({ type: "GRADIENT_ASSISTANT_REQUEST", backendUrl, path: `/api/v1/assistant/${path2}`, method, body });
    return localAssistantFetch(backendUrl, `/api/v1/assistant/${path2}`, method, body);
  }
  async function loadAssistantSettings() {
    let saved;
    if (typeof chrome !== "undefined" && chrome.storage?.local) saved = (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY];
    else if (typeof localStorage !== "undefined") {
      try {
        saved = JSON.parse(localStorage.getItem(SETTINGS_KEY) || "{}");
      } catch {
        saved = {};
      }
    }
    const parsed = settingsSchema.safeParse({ ...DEFAULT_ASSISTANT_SETTINGS, ...saved && typeof saved === "object" ? saved : {} });
    return parsed.success ? parsed.data : { ...DEFAULT_ASSISTANT_SETTINGS };
  }
  var settingsWrite = Promise.resolve();
  function saveAssistantSettings(patch) {
    const write = settingsWrite.catch(() => {
    }).then(async () => {
      const next = settingsSchema.parse({ ...await loadAssistantSettings(), ...patch });
      if (typeof chrome !== "undefined" && chrome.storage?.local) await chrome.storage.local.set({ [SETTINGS_KEY]: next });
      else if (typeof localStorage !== "undefined") localStorage.setItem(SETTINGS_KEY, JSON.stringify(next));
      return next;
    });
    settingsWrite = write;
    return write;
  }
  async function getAssistantHealth(settings) {
    return z2.object({
      ok: z2.boolean(),
      ollamaConnected: z2.boolean(),
      models: z2.array(z2.string()),
      message: z2.string().optional(),
      pullStates: z2.record(z2.string()).optional(),
      modelDetails: z2.array(z2.object({ name: z2.string(), size: z2.number(), capabilities: z2.array(z2.string()), parameterSize: z2.string().optional(), quantization: z2.string().optional(), remote: z2.boolean().optional() })).optional(),
      recommended: z2.object({ reasoningModel: z2.string(), visionModel: z2.string(), reason: z2.string().optional(), contextLength: z2.number().optional() }).optional()
    }).parse(await request(settings, "health", "GET"));
  }
  async function runJob(settings, type, input) {
    const job = z2.object({ id: z2.string().regex(/^[a-zA-Z0-9_-]{1,80}$/) }).parse(await request(settings, "jobs", "POST", { type, request: input }));
    const start = Date.now();
    while (Date.now() - start < 15 * 60 * 1e3) {
      const state = await request(settings, `jobs/${job.id}`, "GET");
      if (state.status === "complete") return state.result;
      if (state.status === "error") throw new Error(state.error || "Local model generation failed.");
      await new Promise((resolve) => setTimeout(resolve, 1500));
    }
    throw new Error("Generation exceeded 15 minutes. Try a smaller installed model or a lower detail level.");
  }
  async function enableBrowserSearch() {
    if (!extensionAvailable()) throw new Error("Browser Google search requires the installed Chrome extension.");
    return (await sendMessage({ type: "GRADIENT_ENABLE_SEARCH" })).granted;
  }
  async function generateStudyPacket(settings, input) {
    let webSources = [];
    const searchWarnings = [];
    if (input.webResearch && extensionAvailable()) {
      try {
        webSources = await sendMessage({ type: "GRADIENT_BROWSER_SEARCH", query: `${input.assignment.title} tutorial explanation`.slice(0, 250), limit: input.level === "all_in" ? 8 : input.level === "a_bit_more" ? 5 : 3 });
      } catch (error) {
        searchWarnings.push(error instanceof Error ? error.message : "Browser search was unavailable.");
      }
    }
    const origin = typeof window !== "undefined" ? window.location.origin : new URL(input.assignment.url).origin;
    const materials = await readCanvasMaterials(
      input.resources,
      origin,
      input.course.id,
      (file) => request(settings, "materials/extract", "POST", file)
    );
    const packet = packetSchema.parse(await runJob(settings, "generate", { ...input, resources: materials.resources, webSources }));
    packet.warnings = [...searchWarnings, ...materials.warnings, ...packet.warnings];
    return packet;
  }
  async function captureBrowserContext() {
    const root = (document.querySelector("main") || document.body).cloneNode(true);
    root.querySelectorAll("#gradient-panel-host,script,style,input,textarea,select,[contenteditable],iframe").forEach((el) => el.remove());
    const links = Array.from(root.querySelectorAll("a[href]")).slice(0, 100).flatMap((anchor) => {
      try {
        const url = new URL(anchor.getAttribute("href") || "", window.location.href);
        return url.origin === window.location.origin && ["http:", "https:"].includes(url.protocol) ? [`${(anchor.textContent || "").trim().slice(0, 150)}: ${url.href}`] : [];
      } catch {
        return [];
      }
    });
    const text2 = (root.textContent || "").replace(/\s+/g, " ").trim().slice(0, 16e3) + "\n\nVisible resource links:\n" + links.join("\n").slice(0, 8e3);
    let screenshot;
    if (extensionAvailable()) {
      const host = document.getElementById("gradient-panel-host");
      const oldVisibility = host?.style.getPropertyValue("visibility") || "";
      const oldPriority = host?.style.getPropertyPriority("visibility") || "";
      try {
        host?.style.setProperty("visibility", "hidden", "important");
        await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
        const capture = await sendMessage({ type: "GRADIENT_CAPTURE_CONTEXT" });
        screenshot = capture.screenshot;
      } finally {
        if (oldVisibility) host?.style.setProperty("visibility", oldVisibility, oldPriority);
        else host?.style.removeProperty("visibility");
      }
    }
    return { url: window.location.href, title: document.title, text: text2, ...screenshot ? { screenshot } : {} };
  }
  async function planBrowserAction(settings, input) {
    return z2.object({ summary: z2.string(), actions: z2.array(z2.object({ kind: z2.enum(["open", "find", "scroll", "read"]), description: z2.string(), url: z2.string().optional(), text: z2.string().optional() })).max(12), warnings: z2.array(z2.string()) }).parse(await runJob(settings, "browser", input));
  }
  function safeBrowserUrl(value) {
    const url = new URL(value, window.location.href);
    if (!["https:", "http:"].includes(url.protocol) || url.username || url.password) throw new Error("The model suggested an unsupported link.");
    let path2 = url.pathname;
    for (let i3 = 0; i3 < 3 && /%[0-9a-f]{2}/i.test(path2); i3++) path2 = decodeURIComponent(path2);
    if (/\/(?:quizzes|assessments)\/.*(?:take|resume)|\/logout(?:\/|$)|\/(?:submissions|submit)(?:\/|$)/i.test(path2)) throw new Error("This action is outside the study browser workspace.");
    return url.href;
  }
  async function applyBrowserAction(action) {
    if (action.kind === "open" && action.url) {
      const url = safeBrowserUrl(action.url);
      window.open(url, "_blank", "noopener,noreferrer");
    } else if (action.kind === "find" && action.text) {
      const found = window.find?.(action.text.slice(0, 300));
      if (!found) throw new Error("That text is not visible on this page. Open the relevant resource and inspect it again.");
    } else if (action.kind === "scroll") {
      window.scrollBy({ top: Math.round(window.innerHeight * 0.75), behavior: "smooth" });
    } else if (action.kind === "read") {
      if (action.url) window.open(safeBrowserUrl(action.url), "_blank", "noopener,noreferrer");
      else if (action.text) {
        const found = window.find?.(action.text.slice(0, 300));
        if (!found) throw new Error("The suggested text was not found on this page.");
      } else throw new Error("The model did not provide a section or link to read. Inspect the page again with a more specific goal.");
    } else throw new Error("This action needs a link or text target.");
  }

  // extension/ui/assistantStyles.ts
  var ASSISTANT_STYLES = `
.ja{--ja-bg:#f7f8fc;--ja-panel:#ffffff;--ja-border:#dce3ee;--ja-muted:#647087;--ja-cyan:#2855e8;background:var(--ja-bg);color:#182037;border:1px solid #e5e9f1;border-radius:16px;overflow:hidden;font-size:12px;line-height:1.6;min-width:0;color-scheme:light}
.ja *{box-sizing:border-box}.ja button,.ja input,.ja select,.ja textarea{font:inherit}.ja button{cursor:pointer}.ja button:disabled{cursor:wait;opacity:.55}.ja a{color:var(--ja-cyan);text-decoration:none}.ja a:hover{text-decoration:underline}.ja button:focus-visible,.ja a:focus-visible,.ja input:focus-visible,.ja select:focus-visible,.ja textarea:focus-visible,.ja summary:focus-visible{outline:2px solid var(--ja-cyan);outline-offset:3px}
.ja-head{display:flex;align-items:center;gap:13px;padding:23px 20px 18px;background:#fff;border-bottom:1px solid var(--ja-border)}
.ja-core{width:47px;height:47px;flex-shrink:0;border:1px solid #dbe3f5;border-radius:11px;padding:7px;display:grid;place-items:center}.ja-core>span{width:100%;height:100%;display:grid;place-items:center;border:0;border-radius:7px;color:var(--ja-cyan)}
.ja-eyebrow{font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--ja-cyan)}.ja-head h1{font-size:29px;line-height:1.2;letter-spacing:-.7px;margin:3px 0 4px}.ja-head p{font-size:10px;color:var(--ja-muted);margin:0}.ja-status{margin-left:auto;align-self:flex-start;font-size:9px;white-space:nowrap;color:#647087;display:flex;align-items:center;gap:5px}.ja-led{width:6px;height:6px;border-radius:50%;background:#d2a975}.ja-led.ready{background:#16825c;box-shadow:0 0 8px #16825c60}
.ja-inner{padding:18px 20px;display:flex;flex-direction:column;gap:19px;min-width:0}.ja-section{min-width:0}.ja-row{display:flex;align-items:center;justify-content:space-between;gap:9px}.ja h2{font-size:14px;font-weight:700;letter-spacing:-.2px;margin:0}.ja h3{font-size:12px;margin:0}.ja-note{font-size:10px;color:var(--ja-muted);line-height:1.6;margin:5px 0 0}.ja-label{display:block;font-size:10px;font-weight:650;color:#34425d;margin-bottom:6px}.ja-control{background:#ffffff;border:1px solid var(--ja-border);border-radius:8px;color:#182037;padding:9px 10px;width:100%;min-width:0;line-height:1.5}.ja-control::placeholder{color:#647087}.ja-control:focus{border-color:#2855e8}.ja textarea{resize:vertical;min-height:80px}.ja-fields{display:grid;grid-template-columns:minmax(0,1fr);gap:11px}.ja-fields.two{grid-template-columns:1fr 1fr}.ja small{font-size:10px;color:var(--ja-muted)}
.ja-detail{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;margin-top:9px}.ja-detail button{border:1px solid var(--ja-border);border-radius:9px;background:#ffffff;color:#536079;padding:11px 6px;text-align:left;line-height:1.4;min-width:0}.ja-detail button.active{border-color:var(--ja-cyan);background:#edf2ff;color:#2855e8;box-shadow:0 0 0 1px var(--ja-cyan)}.ja-detail strong{display:block;font-size:11px;letter-spacing:-.2px}.ja-detail small{display:block;font-size:9px;margin-top:5px;color:#647087}.ja-detail button.active small{color:#426080}
.ja-switches{display:flex;flex-wrap:wrap;gap:9px 14px;margin-top:12px}.ja-switch{display:flex;align-items:center;gap:6px;font-size:10px;color:#536079;cursor:pointer}.ja-switch input{accent-color:var(--ja-cyan);margin:0;width:13px;height:13px}.ja-btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;border:1px solid var(--ja-border);background:#ffffff;color:#34425d;border-radius:8px;padding:8px 11px;font-size:10px;font-weight:650;line-height:1.5;white-space:normal}.ja-btn:hover{border-color:#b7c8fa;background:#f0f4ff}.ja-btn.primary{background:var(--ja-cyan);border-color:var(--ja-cyan);color:#ffffff;min-height:42px;font-size:11px}.ja-btn.primary:hover{background:#1740c8}.ja-btn.full{width:100%}.ja-btn.link{background:transparent;border:0;color:var(--ja-cyan);padding:0}.ja-actions{display:flex;gap:8px;flex-wrap:wrap}.ja-rule{border:0;border-top:1px solid var(--ja-border);margin:0}.ja-mode{display:flex;gap:6px;margin-top:9px}.ja-mode .ja-btn{flex:1}.ja-mode .ja-btn.active{color:var(--ja-cyan);border-color:#b7c8fa;background:#edf2ff}
.ja-settings{background:#ffffff;border:1px solid var(--ja-border);border-radius:10px;padding:12px}.ja-settings>summary{display:flex;align-items:center;gap:7px;font-size:11px;font-weight:650;cursor:pointer;list-style:none}.ja-settings>summary::after{content:'+';margin-left:auto;color:var(--ja-cyan)}.ja-settings[open]>summary::after{content:'\u2212'}.ja-settings[open]>summary{margin-bottom:13px}.ja-settings .ja-note code{word-break:break-word;color:#34425d}.ja-setup{background:#edf3ff;border:1px solid #dbe3f5;border-radius:9px;padding:11px 12px}.ja-setup strong{font-size:11px;color:#2855e8}.ja-setup code{display:block;margin-top:8px;background:#ffffff;color:#34425d;padding:9px;border-radius:6px;white-space:pre-wrap;font-size:10px;overflow-wrap:anywhere}.ja-notice{font-size:10px;line-height:1.7;border:1px solid #dbe3f5;background:#eaf2ff;color:#345276;border-radius:8px;padding:10px 11px;overflow-wrap:anywhere}.ja-notice.error{border-color:#f0c9ce;background:#fff0f1;color:#963b48}.ja-notice.warning{border-color:#ead7b1;background:#fff4df;color:#7f5520}.ja-progress{display:flex;align-items:center;gap:8px;color:#2855e8;font-size:11px;padding:11px 0}.ja-progress span{animation:ja-pulse 1.8s ease-in-out infinite}
.ja-context{font-size:10px;color:#536079;padding:10px 11px;background:#f4f6fb;border-left:2px solid #2855e8;border-radius:0 7px 7px 0;margin-top:9px}.ja-context strong{display:block;color:#182037;font-size:11px}.ja-context a{display:inline-flex;align-items:center;gap:4px;margin-top:4px}.ja-context details{margin-top:7px}.ja-context summary{cursor:pointer;color:#2855e8}.ja-context .ja-brief{white-space:pre-wrap;font-size:10px;max-height:200px;overflow:auto;margin-top:7px}
.ja-result{background:#f4f7fb;color:#1c3046;border-radius:11px;overflow:hidden;border:1px solid #c3d3e2}.ja-result-header{padding:17px 16px;background:#e8f0f6;border-bottom:1px solid #cfdae6}.ja-result-header h2{font-size:17px;color:#142e43;line-height:1.35}.ja-result-header p{font-size:11px;color:#4b6275;margin:7px 0 0}.ja-result-body{padding:16px;min-width:0}.ja-result a{color:#2855e8}.ja-result .ja-note{color:#50667a}.ja-result .ja-eyebrow{color:#2855e8;margin-bottom:7px}.ja-export{display:flex;gap:7px;flex-wrap:wrap;margin-top:13px}.ja-export .ja-btn{background:#fff;border-color:#c3d1df;color:#23445b;font-size:10px}.ja-prose{font-size:12px;line-height:1.8;overflow-wrap:anywhere}.ja-prose p{margin:0 0 11px;white-space:pre-wrap}.ja-prose h2{font-size:15px;margin:19px 0 9px;color:#173b52}.ja-prose h3{font-size:13px;margin:15px 0 7px;color:#173b52}.ja-prose h4{font-size:12px;margin:13px 0 5px}.ja-prose ul,.ja-prose ol{padding-left:19px;margin:9px 0 13px}.ja-prose li{padding-left:2px;margin:4px 0}.ja-prose pre{background:#122437;color:#d9eaf8;border-radius:7px;padding:11px;overflow:auto;font-size:10px;white-space:pre-wrap}.ja-prose code{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:.9em;background:#dae7ef;padding:1px 4px;border-radius:3px}.ja-prose pre code{background:transparent;padding:0}.ja-prose blockquote{border-left:3px solid #4d93a5;padding:4px 12px;margin:12px 0;color:#4c6376}.ja-prose hr{border:0;border-top:1px solid #d2dde6;margin:17px 0}
.ja-visual{margin:17px 0;padding:13px;background:#fff;border:1px solid #d0dde6;border-radius:9px;overflow:hidden;break-inside:avoid}.ja-visual figcaption{font-size:11px;font-weight:700;color:#294c60;margin-bottom:12px}.ja-visual svg{display:block;width:100%;height:auto;overflow:visible}.ja-diagram-node{border:1px solid #a8c6d2;background:#edf2ff;border-radius:7px;padding:8px 10px;color:#34425d;font-size:11px;overflow-wrap:anywhere}.ja-diagram-edge{color:#617b88;font-size:10px;display:flex;align-items:center;gap:7px;margin:7px 0}.ja-diagram-edge>span:first-child{color:#2855e8;font-size:16px}.ja-visual img{width:100%;max-height:300px;object-fit:contain;display:block;border-radius:6px;margin:9px 0}.ja-visual a{font-size:10px}.ja-chart-table{font-size:10px;width:100%;border-collapse:collapse;margin-top:7px}.ja-chart-table th,.ja-chart-table td{text-align:left;padding:5px 7px;border-bottom:1px solid #d9e3eb}.ja-chart-table th{color:#49677a}.ja-chart-table td:last-child{text-align:right;font-variant-numeric:tabular-nums}
.ja-table-wrap{overflow:auto;margin:12px 0 17px;border:1px solid #d1dee8;border-radius:7px}.ja-table-wrap table{width:100%;border-collapse:collapse;font-size:11px;line-height:1.6}.ja-table-wrap th{text-align:left;background:#e4eef4;font-weight:650;color:#274c61}.ja-table-wrap th,.ja-table-wrap td{padding:8px 10px;border-bottom:1px solid #d1dee8;vertical-align:top;min-width:85px}.ja-table-wrap tr:last-child td{border:0}
.ja-sample{margin-top:18px;border-top:1px solid #cfdae6;padding-top:18px}.ja-sample-tag{display:inline-block;color:#815921;background:#fff0cf;border:1px solid #e5cc9d;border-radius:5px;padding:3px 7px;font-size:9px;font-weight:750;margin-bottom:9px}.ja-sources{border-top:1px solid #cfdae6;margin-top:19px;padding-top:15px}.ja-sources ol{padding-left:19px;margin:9px 0 0}.ja-sources li{margin:0 0 11px;padding-left:3px;font-size:10px}.ja-sources a{font-weight:650;overflow-wrap:anywhere}.ja-sources p{font-size:10px;color:#586e7e;margin:3px 0 0}.ja-sources small{color:#62798b}.ja-browser{border-top:1px solid var(--ja-border);padding-top:17px}.ja-browser-steps{list-style:none;padding:0;margin:13px 0 0;display:flex;flex-direction:column;gap:8px}.ja-browser-steps li{padding:10px;border:1px solid var(--ja-border);border-radius:8px;background:#f4f6fb}.ja-browser-steps strong{color:#182037;font-size:11px}.ja-browser-steps p{font-size:10px;margin:4px 0 8px;color:#647087}.ja-checklist{padding-left:18px;font-size:11px;color:#35566b}.ja-model-row{display:flex;gap:7px;align-items:flex-start}.ja-model-row .ja-control{flex:1}.ja-model-row .ja-btn{min-height:38px;flex-shrink:0}.ja-footnote{font-size:9px;color:#647087;display:flex;align-items:flex-start;gap:6px}.ja-footnote svg{margin-top:2px;flex-shrink:0}
.ja-math{font-size:1.08em}.ja-math-block{overflow-x:auto;padding:12px 0;margin:8px 0}.ja-math.display{display:block;text-align:center}.ja-math math{color:inherit}.ja-math-error{white-space:pre-wrap;overflow-wrap:anywhere}
@keyframes ja-pulse{0%,100%{opacity:.55}50%{opacity:1}}@media(prefers-reduced-motion:reduce){.ja-progress span{animation:none}}@media(max-width:420px){.ja-inner{padding:16px 13px}.ja-head{padding:19px 13px}.ja-status{font-size:8px}.ja-fields.two{grid-template-columns:1fr}.ja-detail strong{font-size:10px}.ja-detail small{font-size:8px}}
`;

  // extension/ui/AssistantView.tsx
  var DEFAULTS = { backendUrl: "http://127.0.0.1:8765", reasoningModel: "gpt-oss:20b", visionModel: "gemma4:e4b", detailLevel: "a_bit_more", webResearch: true };
  var LEVELS = [
    { id: "a_bit", title: "A bit", description: "Key ideas + a starting point" },
    { id: "a_bit_more", title: "A bit more", description: "Worked explanations + sources" },
    { id: "all_in", title: "Go all in", description: "A complete research packet" }
  ];
  function errorMessage(error) {
    return error instanceof Error ? error.message : "The local assistant could not complete this request.";
  }
  function installedModels(health, capability) {
    if (!health) return [];
    const raw = [...new Set(health.models)].filter((name) => {
      const detail = health.modelDetails?.find((model) => model.name === name);
      if (detail?.remote || /(?:-cloud|:cloud)$/.test(name)) return false;
      return detail ? detail.capabilities.includes(capability) : capability === "completion";
    });
    const humanNames = raw.filter((name) => !/^llamacpp[:/]/i.test(name));
    return humanNames.length ? humanNames : raw;
  }
  function modelLabel(name, health) {
    const detail = health?.modelDetails?.find((model) => model.name === name);
    const size = detail && detail.size > 0 ? `${(detail.size / 1024 ** 3).toFixed(1)} GB` : "";
    return [name, detail?.parameterSize, detail?.quantization, size].filter(Boolean).join(" \xB7 ");
  }
  function recommendedSettings(health, current) {
    const patch = {};
    for (const [key, capability] of [["reasoningModel", "completion"], ["visionModel", "vision"]]) {
      const candidates = installedModels(health, capability);
      if (candidates.includes(current[key])) continue;
      const recommended = health.recommended?.[key];
      const replacement = recommended && candidates.includes(recommended) ? recommended : candidates[0];
      if (replacement) patch[key] = replacement;
    }
    return patch;
  }
  function safeUrl(value) {
    try {
      const url = new URL(value);
      return ["http:", "https:"].includes(url.protocol) ? url.href : void 0;
    } catch {
      return void 0;
    }
  }
  function plain(value) {
    const doc = new DOMParser().parseFromString(value, "text/html");
    doc.querySelectorAll("script,style,noscript").forEach((node) => node.remove());
    doc.querySelectorAll("p,br,li,h1,h2,h3,div").forEach((node) => node.append(doc.createTextNode("\n")));
    return (doc.body.textContent ?? "").replace(/\n{3,}/g, "\n\n").trim();
  }
  function MathFormula({ tex, display = false }) {
    try {
      const html = renderToString(tex, { output: "mathml", displayMode: display, trust: false, throwOnError: true, maxExpand: 300, maxSize: 20 });
      return /* @__PURE__ */ a3("span", { class: display ? "ja-math display" : "ja-math", dangerouslySetInnerHTML: { __html: html } });
    } catch {
      return /* @__PURE__ */ a3("code", { class: "ja-math-error", title: "Unsupported or incomplete formula", children: tex });
    }
  }
  function inline(text2) {
    const nodes = [];
    const pattern = /\[([^\]]+)\]\(([^\s)]+)\)|\*\*([^*]+)\*\*|`([^`]+)`|\\\(([^]*?)\\\)|\$([^$\n]+)\$/g;
    let start = 0;
    for (const match of text2.matchAll(pattern)) {
      const index = match.index ?? 0;
      if (index > start) nodes.push(text2.slice(start, index));
      if (match[1] !== void 0) {
        const href = safeUrl(match[2] ?? "");
        nodes.push(href ? /* @__PURE__ */ a3("a", { href, target: "_blank", rel: "noopener noreferrer", children: match[1] }) : match[1]);
      } else if (match[3] !== void 0) nodes.push(/* @__PURE__ */ a3("strong", { children: match[3] }));
      else if (match[4] !== void 0) nodes.push(/* @__PURE__ */ a3("code", { children: match[4] }));
      else nodes.push(/* @__PURE__ */ a3(MathFormula, { tex: match[5] ?? match[6] ?? "" }));
      start = index + match[0].length;
    }
    if (start < text2.length) nodes.push(text2.slice(start));
    return nodes;
  }
  var embeddedDiagramSchema = z2.object({
    title: z2.string().max(300),
    nodes: z2.array(z2.object({ id: z2.string().max(100), label: z2.string().max(500) })).min(1).max(16),
    edges: z2.array(z2.object({ from: z2.string(), to: z2.string(), label: z2.string().max(300).optional() })).max(40)
  }).refine((d3) => new Set(d3.nodes.map((n2) => n2.id)).size === d3.nodes.length && d3.edges.every((e3) => d3.nodes.some((n2) => n2.id === e3.from) && d3.nodes.some((n2) => n2.id === e3.to)));
  function embeddedDiagram(text2) {
    if (text2.length > 3e4) return null;
    try {
      const parsed = embeddedDiagramSchema.safeParse(JSON.parse(text2));
      return parsed.success ? parsed.data : null;
    } catch {
      return null;
    }
  }
  function AssistantMarkdown({ text: text2 }) {
    const blocks = [];
    const lines = text2.replace(/\r/g, "").split("\n");
    for (let i3 = 0; i3 < lines.length; i3++) {
      const line = lines[i3] ?? "";
      if (!line.trim()) continue;
      const trimmed = line.trim();
      if (trimmed.startsWith("{")) {
        let candidate = "";
        let end = i3;
        let diagram = null;
        for (; end < Math.min(lines.length, i3 + 150); end++) {
          candidate += (candidate ? "\n" : "") + lines[end];
          if (candidate.length > 3e4) break;
          diagram = embeddedDiagram(candidate);
          if (diagram) break;
        }
        if (diagram) {
          blocks.push(/* @__PURE__ */ a3(ConceptDiagram, { diagram }));
          i3 = end;
          continue;
        }
      }
      const delimiter = trimmed.startsWith("$$") ? "$$" : trimmed.startsWith("\\[") ? "\\[" : null;
      if (delimiter) {
        const close2 = delimiter === "$$" ? "$$" : "\\]";
        let formula = trimmed.slice(delimiter.length);
        while (!formula.trimEnd().endsWith(close2) && i3 + 1 < lines.length) formula += "\n" + (lines[++i3] ?? "");
        if (formula.trimEnd().endsWith(close2)) formula = formula.trimEnd().slice(0, -close2.length);
        blocks.push(/* @__PURE__ */ a3("div", { class: "ja-math-block", children: /* @__PURE__ */ a3(MathFormula, { tex: formula.trim(), display: true }) }));
        continue;
      }
      if (/^```/.test(line)) {
        const code = [];
        while (++i3 < lines.length && !/^```/.test(lines[i3] ?? "")) code.push(lines[i3] ?? "");
        const diagram = embeddedDiagram(code.join("\n"));
        blocks.push(diagram ? /* @__PURE__ */ a3(ConceptDiagram, { diagram }) : /* @__PURE__ */ a3("pre", { children: /* @__PURE__ */ a3("code", { children: code.join("\n") }) }));
        continue;
      }
      if (line.includes("|") && /^\s*\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(lines[i3 + 1] ?? "")) {
        const cells = (row) => row.trim().replace(/^\|/, "").replace(/\|$/, "").split(/(?<!\\)\|/).map((cell) => cell.trim().replace(/\\\|/g, "|"));
        const headers = cells(line);
        const rows = [];
        i3 += 2;
        while (i3 < lines.length && (lines[i3] ?? "").includes("|") && (lines[i3] ?? "").trim()) rows.push(cells(lines[i3++] ?? ""));
        i3--;
        blocks.push(/* @__PURE__ */ a3("div", { class: "ja-table-wrap", children: /* @__PURE__ */ a3("table", { children: [
          /* @__PURE__ */ a3("thead", { children: /* @__PURE__ */ a3("tr", { children: headers.map((header, index) => /* @__PURE__ */ a3("th", { children: inline(header) }, index)) }) }),
          /* @__PURE__ */ a3("tbody", { children: rows.map((row, index) => /* @__PURE__ */ a3("tr", { children: headers.map((_header, column) => /* @__PURE__ */ a3("td", { children: inline(row[column] ?? "") }, column)) }, index)) })
        ] }) }));
        continue;
      }
      const heading = line.match(/^(#{1,6})\s+(.+)$/);
      if (heading) {
        const children = inline(heading[2] ?? "");
        blocks.push((heading[1]?.length ?? 1) <= 2 ? /* @__PURE__ */ a3("h2", { children }) : (heading[1]?.length ?? 3) === 3 ? /* @__PURE__ */ a3("h3", { children }) : /* @__PURE__ */ a3("h4", { children }));
        continue;
      }
      if (/^\s*([-*_])(?:\s*\1){2,}\s*$/.test(line)) {
        blocks.push(/* @__PURE__ */ a3("hr", {}));
        continue;
      }
      if (/^\s*[-*+]\s+/.test(line) || /^\s*\d+[.)]\s+/.test(line)) {
        const ordered = /^\s*\d+[.)]\s+/.test(line);
        const items = [];
        const pattern = ordered ? /^\s*\d+[.)]\s+/ : /^\s*[-*+]\s+/;
        do {
          items.push(/* @__PURE__ */ a3("li", { children: inline((lines[i3] ?? "").replace(pattern, "")) }));
          i3++;
        } while (i3 < lines.length && pattern.test(lines[i3] ?? ""));
        i3--;
        blocks.push(ordered ? /* @__PURE__ */ a3("ol", { children: items }) : /* @__PURE__ */ a3("ul", { children: items }));
        continue;
      }
      if (/^>\s?/.test(line)) {
        blocks.push(/* @__PURE__ */ a3("blockquote", { children: inline(line.replace(/^>\s?/, "")) }));
        continue;
      }
      const paragraph = [line];
      while (i3 + 1 < lines.length && (lines[i3 + 1] ?? "").trim() && !/^(?:#{1,6}\s|```|\s*[-*+]\s|\s*\d+[.)]\s|>|\s*\{)/.test(lines[i3 + 1] ?? "")) paragraph.push(lines[++i3] ?? "");
      blocks.push(/* @__PURE__ */ a3("p", { children: inline(paragraph.join("\n")) }));
    }
    return /* @__PURE__ */ a3("div", { class: "ja-prose", children: blocks });
  }
  function ConceptDiagram({ diagram }) {
    const nodes = diagram.nodes.slice(0, 16);
    const labels = new Map(nodes.map((node) => [node.id, node.label]));
    return /* @__PURE__ */ a3("figure", { class: "ja-visual", children: [
      /* @__PURE__ */ a3("figcaption", { children: diagram.title }),
      /* @__PURE__ */ a3("div", { role: "img", "aria-label": `${diagram.title}: ${nodes.map((node) => node.label).join(", ")}`, children: [
        nodes.map((node, i3) => {
          const edge = diagram.edges.find((item) => item.from === node.id && item.to === nodes[i3 + 1]?.id);
          return /* @__PURE__ */ a3("div", { children: [
            /* @__PURE__ */ a3("div", { class: "ja-diagram-node", children: node.label }),
            edge ? /* @__PURE__ */ a3("div", { class: "ja-diagram-edge", children: [
              /* @__PURE__ */ a3("span", { "aria-hidden": "true", children: "\u2193" }),
              /* @__PURE__ */ a3("span", { children: edge.label ?? "" })
            ] }) : i3 < nodes.length - 1 ? /* @__PURE__ */ a3("div", { style: { height: "9px" } }) : null
          ] }, node.id);
        }),
        diagram.edges.filter((edge) => !nodes.some((node, i3) => node.id === edge.from && nodes[i3 + 1]?.id === edge.to)).map((edge, i3) => /* @__PURE__ */ a3("div", { class: "ja-diagram-edge", children: [
          /* @__PURE__ */ a3("span", { "aria-hidden": "true", children: "\u21B3" }),
          /* @__PURE__ */ a3("span", { children: [
            labels.get(edge.from) ?? edge.from,
            " \u2192 ",
            labels.get(edge.to) ?? edge.to,
            edge.label ? `: ${edge.label}` : ""
          ] })
        ] }, i3))
      ] })
    ] });
  }
  function DataGraph({ graph }) {
    const points = graph.points.filter((point) => Number.isFinite(point.value)).slice(0, 16);
    if (!points.length) return null;
    const maximum = Math.max(1, ...points.map((point) => Math.abs(point.value)));
    const width = 420, height = Math.max(130, 43 + points.length * 29);
    const displayValue = (value) => Math.abs(value) >= 1e12 || value !== 0 && Math.abs(value) < 1e-3 ? value.toExponential(2) : value.toLocaleString(void 0, { maximumFractionDigits: 3 });
    return /* @__PURE__ */ a3("figure", { class: "ja-visual", children: [
      /* @__PURE__ */ a3("figcaption", { children: graph.title }),
      /* @__PURE__ */ a3("svg", { viewBox: `0 0 ${width} ${height}`, role: "img", "aria-label": graph.title, children: [
        points.map((point, i3) => /* @__PURE__ */ a3("g", { children: [
          /* @__PURE__ */ a3("text", { x: "0", y: 23 + i3 * 29, fill: "#45657a", "font-size": "10", children: point.label.slice(0, 19) }),
          /* @__PURE__ */ a3("rect", { x: "130", y: 10 + i3 * 29, width: Math.max(1, Math.abs(point.value) / maximum * 195), height: "18", rx: "3", fill: point.value < 0 ? "#bd7958" : "#237e95" }),
          /* @__PURE__ */ a3("text", { x: "415", y: 23 + i3 * 29, "text-anchor": "end", fill: "#274e63", "font-size": "10", children: displayValue(point.value) })
        ] }, i3)),
        /* @__PURE__ */ a3("text", { x: "130", y: height - 5, fill: "#5b7484", "font-size": "9", children: [
          (graph.yLabel ?? "Value").slice(0, 24),
          " \xB7 bar length represents magnitude"
        ] })
      ] }),
      /* @__PURE__ */ a3("details", { children: [
        /* @__PURE__ */ a3("summary", { class: "ja-note", children: "View data values" }),
        /* @__PURE__ */ a3("table", { class: "ja-chart-table", children: [
          /* @__PURE__ */ a3("thead", { children: /* @__PURE__ */ a3("tr", { children: [
            /* @__PURE__ */ a3("th", { children: graph.xLabel ?? "Label" }),
            /* @__PURE__ */ a3("th", { children: graph.yLabel ?? "Value" })
          ] }) }),
          /* @__PURE__ */ a3("tbody", { children: points.map((point, i3) => /* @__PURE__ */ a3("tr", { children: [
            /* @__PURE__ */ a3("td", { children: point.label }),
            /* @__PURE__ */ a3("td", { children: point.value })
          ] }, i3)) })
        ] })
      ] })
    ] });
  }
  function download(content, name, type) {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = name;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function filename(title) {
    return title.replace(/[^a-z0-9_-]+/gi, "-").replace(/^-|-$/g, "").slice(0, 80) || "gradient-study-packet";
  }
  function escapeHtml(value) {
    return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function packetMarkdown(packet) {
    return `# ${packet.title}

${packet.summary}

${packet.markdown}${packet.sampleMarkdown ? `

## Sample assignment

AI-generated reference sample. Review, verify, and follow your course policy before using it.

${packet.sampleMarkdown}` : ""}

${packet.diagrams.map((diagram) => `## ${diagram.title}

${diagram.nodes.map((node) => `- ${node.id}: ${node.label}`).join("\n")}
${diagram.edges.map((edge) => `- ${edge.from} -> ${edge.to}${edge.label ? `: ${edge.label}` : ""}`).join("\n")}`).join("\n\n")}

${packet.graphs.map((graph) => `## ${graph.title}

| Label | Value |
| --- | ---: |
${graph.points.map((point) => `| ${point.label.replace(/\|/g, "\\|")} | ${point.value} |`).join("\n")}`).join("\n\n")}

${packet.images.filter((image) => safeUrl(image.url) && safeUrl(image.sourceUrl)).map((image) => `![${image.alt.replace(/[\[\]]/g, "")}](${safeUrl(image.url)})
[Image source](${safeUrl(image.sourceUrl)})`).join("\n\n")}

## Sources

${packet.sources.filter((source) => safeUrl(source.url)).map((source) => `- [${source.title.replace(/[\[\]]/g, "")}](${safeUrl(source.url)})${source.excerpt ? `: ${source.excerpt}` : ""}`).join("\n")}${packet.warnings.length ? `

## Notes to verify

${packet.warnings.map((warning) => `- ${warning}`).join("\n")}` : ""}
`;
  }
  function assignmentBrief(assignment) {
    return assignment ? plain(assignment.descriptionHtml) : "";
  }
  function AssistantView({ snapshot, preview = false, initialCourseId, initialAssignmentId }) {
    const [settings, setSettings] = d2(DEFAULTS);
    const [health, setHealth] = d2(null);
    const [checking, setChecking] = d2(false);
    const [connectionError, setConnectionError] = d2("");
    const [courseId, setCourseId] = d2(initialCourseId ?? snapshot.courses[0]?.id ?? "");
    const course = snapshot.courses.find((item) => item.id === courseId) ?? snapshot.courses[0];
    const [assignmentId, setAssignmentId] = d2(initialAssignmentId ?? "");
    const assignment = course?.assignments.find((item) => item.id === assignmentId) ?? course?.assignments.find((item) => !item.submission?.excused && item.submission?.score == null && !["submitted", "pending_review", "graded"].includes(item.submission?.workflowState ?? "")) ?? course?.assignments[0];
    const [prompt, setPrompt] = d2("");
    const [mode, setMode] = d2("explain");
    const [visuals, setVisuals] = d2({ diagrams: true, graphs: true, images: true });
    const [generating, setGenerating] = d2(false);
    const [packet, setPacket] = d2(null);
    const [generationError, setGenerationError] = d2("");
    const [browserGoal, setBrowserGoal] = d2("Find the assignment instructions and the course materials that will help me.");
    const [browserBusy, setBrowserBusy] = d2(false);
    const [browserPlan, setBrowserPlan] = d2(null);
    const [browserError, setBrowserError] = d2("");
    const [actionMessage, setActionMessage] = d2("");
    const resultRef = T2(null);
    const mounted = T2(true);
    const settingsRef = T2(DEFAULTS);
    const earlySettingsEdits = T2({});
    const settingsLoaded = T2(false);
    const healthRequest = T2(0);
    const reasoningModels = installedModels(health, "completion");
    const visionModels = installedModels(health, "vision");
    const ready = health?.ok && health.ollamaConnected && reasoningModels.includes(settings.reasoningModel);
    const visionReady = health?.ok && health.ollamaConnected && visionModels.includes(settings.visionModel);
    const brief = assignmentBrief(assignment);
    const resources = w2(() => {
      const words = new Set(`${assignment?.name ?? ""} ${brief.slice(0, 1e3)}`.toLowerCase().match(/[a-z]{4,}/g) ?? []);
      return (course?.resources ?? []).map((resource) => ({ resource, rank: (resource.title.toLowerCase().match(/[a-z]{4,}/g) ?? []).filter((word) => words.has(word)).length })).sort((a4, b2) => b2.rank - a4.rank).slice(0, 12).map((item) => item.resource);
    }, [course, assignment, brief]);
    A(() => {
      mounted.current = true;
      loadAssistantSettings().then(async (saved) => {
        if (!mounted.current) return;
        const initial = { ...saved, ...earlySettingsEdits.current };
        settingsLoaded.current = true;
        settingsRef.current = initial;
        setSettings(initial);
        await checkHealth(initial);
      }).catch((error) => {
        if (mounted.current) setConnectionError(errorMessage(error));
      });
      return () => {
        mounted.current = false;
        healthRequest.current++;
      };
    }, []);
    const updateSettings = (patch) => {
      if (!settingsLoaded.current) earlySettingsEdits.current = { ...earlySettingsEdits.current, ...patch };
      settingsRef.current = { ...settingsRef.current, ...patch };
      setSettings((current) => ({ ...current, ...patch }));
      if (patch.backendUrl !== void 0) {
        healthRequest.current++;
        setChecking(false);
        setHealth(null);
      }
      saveAssistantSettings(patch).catch((error) => {
        if (mounted.current) setConnectionError(errorMessage(error));
      });
    };
    const checkHealth = async (requestSettings) => {
      const requestId = ++healthRequest.current;
      const currentRequest = () => mounted.current && requestId === healthRequest.current && settingsRef.current.backendUrl === requestSettings.backendUrl;
      setChecking(true);
      setConnectionError("");
      try {
        const status = await getAssistantHealth(requestSettings);
        if (!currentRequest()) return;
        setHealth(status);
        const patch = recommendedSettings(status, settingsRef.current);
        if (Object.keys(patch).length) {
          settingsRef.current = { ...settingsRef.current, ...patch };
          setSettings((current) => ({ ...current, ...patch }));
          await saveAssistantSettings(patch);
        }
      } catch (error) {
        if (currentRequest()) {
          setHealth(null);
          setConnectionError(errorMessage(error));
        }
      } finally {
        if (currentRequest()) setChecking(false);
      }
    };
    const checkConnection = () => checkHealth(settingsRef.current);
    const generate = async () => {
      if (!course || !assignment || generating) return;
      setGenerating(true);
      setGenerationError("");
      try {
        const preferences = `Visual preferences: ${visuals.diagrams ? "include clean concept diagrams when helpful" : "omit diagrams"}; ${visuals.graphs ? "include graphs only when numerical data is available and label illustrative examples" : "omit graphs"}; ${visuals.images ? "include only relevant, attributed images from retrieved resources when available" : "omit images"}. Never invent sources, measurements, or image URLs.`;
        const result = await generateStudyPacket(settings, {
          course: { id: course.id, name: course.name, code: course.code },
          assignment: { id: assignment.id, title: assignment.name, description: brief, url: assignment.htmlUrl, dueAt: assignment.dueAt ?? null, rubric: assignment.rubric?.map((criterion) => `${plain(criterion.description)} (${criterion.points} points): ${criterion.ratings.map((rating) => plain(rating.description)).join("; ")}`).join("\n") },
          prompt: `${prompt.trim()}

${preferences}`,
          level: settings.detailLevel,
          mode,
          model: settings.reasoningModel,
          webResearch: settings.webResearch,
          resources: resources.map((resource) => ({ title: resource.title, url: resource.url }))
        });
        if (mounted.current) setPacket({ ...result, diagrams: visuals.diagrams ? result.diagrams : [], graphs: visuals.graphs ? result.graphs : [], images: visuals.images ? result.images : [] });
      } catch (error) {
        if (mounted.current) setGenerationError(errorMessage(error));
      } finally {
        if (mounted.current) setGenerating(false);
      }
    };
    const inspectPage = async () => {
      setBrowserBusy(true);
      setBrowserError("");
      setActionMessage("");
      try {
        const context = await captureBrowserContext();
        const plan = await planBrowserAction(settings, { ...context, goal: browserGoal, model: settings.visionModel });
        if (mounted.current) setBrowserPlan(plan);
      } catch (error) {
        if (mounted.current) setBrowserError(errorMessage(error));
      } finally {
        if (mounted.current) setBrowserBusy(false);
      }
    };
    const exportHtml = () => {
      if (!packet || !resultRef.current) return;
      download(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(packet.title)}</title><style>body{margin:0;background:#e8eef4;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;padding:30px 15px}main{max-width:850px;margin:auto}${ASSISTANT_STYLES}.ja{border:0}.ja-result{border:0}.ja-result-header{padding:30px}.ja-result-body{padding:30px}@media print{body{background:white;padding:0}.ja{border:0}.ja-result{overflow:visible}.ja-result-header,.ja-result-body{padding:15px}.ja-visual{break-inside:avoid}a{overflow-wrap:anywhere}}</style></head><body><main class="ja"><article class="ja-result">${resultRef.current.innerHTML}</article></main></body></html>`, `${filename(packet.title)}.html`, "text/html;charset=utf-8");
    };
    return /* @__PURE__ */ a3(M, { children: [
      /* @__PURE__ */ a3("style", { children: ASSISTANT_STYLES }),
      /* @__PURE__ */ a3("section", { class: "ja", "aria-label": "Local AI study assistant", children: [
        /* @__PURE__ */ a3("header", { class: "ja-head", children: [
          /* @__PURE__ */ a3("div", { class: "ja-core", "aria-hidden": "true", children: /* @__PURE__ */ a3("span", { children: /* @__PURE__ */ a3(Icon, { name: "spark", size: 19 }) }) }),
          /* @__PURE__ */ a3("div", { children: [
            /* @__PURE__ */ a3("div", { class: "ja-eyebrow", children: "Your local intelligence" }),
            /* @__PURE__ */ a3("h1", { children: "Consider it handled." }),
            /* @__PURE__ */ a3("p", { children: "Research. Understand. Create. Stay ahead." })
          ] }),
          /* @__PURE__ */ a3("span", { class: "ja-status", children: [
            /* @__PURE__ */ a3("i", { class: `ja-led ${ready ? "ready" : ""}` }),
            checking ? "Connecting" : ready ? "Local AI ready" : "Setup needed"
          ] })
        ] }),
        /* @__PURE__ */ a3("div", { class: "ja-inner", children: [
          preview && /* @__PURE__ */ a3("div", { class: "ja-notice warning", children: "Canvas is showing sample courses. AI requests use the local models you connect below." }),
          /* @__PURE__ */ a3("details", { class: "ja-settings", open: !ready, children: [
            /* @__PURE__ */ a3("summary", { children: [
              /* @__PURE__ */ a3(Icon, { name: "settings", size: 14 }),
              "Local model connection"
            ] }),
            /* @__PURE__ */ a3("div", { class: "ja-fields", children: [
              /* @__PURE__ */ a3("label", { children: [
                /* @__PURE__ */ a3("span", { class: "ja-label", children: "Local assistant service" }),
                /* @__PURE__ */ a3("input", { class: "ja-control", "aria-label": "Local assistant service URL", type: "url", value: settings.backendUrl, disabled: generating, onChange: (e3) => updateSettings({ backendUrl: e3.currentTarget.value }), placeholder: "http://127.0.0.1:8765" })
              ] }),
              /* @__PURE__ */ a3("div", { children: [
                /* @__PURE__ */ a3("label", { class: "ja-label", for: "ja-reasoning-model", children: "Reasoning model \xB7 installed on your Mac" }),
                /* @__PURE__ */ a3("select", { id: "ja-reasoning-model", class: "ja-control", value: settings.reasoningModel, disabled: generating || checking || !reasoningModels.length, onChange: (e3) => updateSettings({ reasoningModel: e3.currentTarget.value }), children: reasoningModels.length ? reasoningModels.map((name) => /* @__PURE__ */ a3("option", { value: name, children: [
                  modelLabel(name, health),
                  health?.recommended?.reasoningModel === name ? " \xB7 Recommended" : ""
                ] }, name)) : /* @__PURE__ */ a3("option", { value: "", children: "Connect Ollama to discover your installed models" }) })
              ] }),
              /* @__PURE__ */ a3("div", { children: [
                /* @__PURE__ */ a3("label", { class: "ja-label", for: "ja-vision-model", children: "Vision & browser companion \xB7 installed" }),
                /* @__PURE__ */ a3("select", { id: "ja-vision-model", class: "ja-control", value: settings.visionModel, disabled: browserBusy || checking || !visionModels.length, onChange: (e3) => updateSettings({ visionModel: e3.currentTarget.value }), children: visionModels.length ? visionModels.map((name) => /* @__PURE__ */ a3("option", { value: name, children: [
                  modelLabel(name, health),
                  health?.recommended?.visionModel === name ? " \xB7 Recommended" : ""
                ] }, name)) : /* @__PURE__ */ a3("option", { value: "", children: "No installed vision model detected" }) })
              ] }),
              /* @__PURE__ */ a3("button", { class: "ja-btn", disabled: checking, onClick: checkConnection, children: [
                /* @__PURE__ */ a3(Icon, { name: "refresh", size: 13, className: checking ? "g-spinner" : "" }),
                checking ? "Checking local services\u2026" : "Check connection"
              ] }),
              health && /* @__PURE__ */ a3("p", { class: "ja-note", children: health.ollamaConnected ? `Ollama connected \xB7 ${health.models.length} installed model${health.models.length === 1 ? "" : "s"}` : health.message ?? "Start Ollama, then check again." }),
              (health?.recommended?.reason || health?.recommendationReason) && /* @__PURE__ */ a3("div", { class: "ja-notice", children: [
                /* @__PURE__ */ a3("strong", { children: "Recommended for this Mac:" }),
                " ",
                health?.recommended?.reason ?? health?.recommendationReason,
                health?.recommended?.contextLength ? ` \xB7 ${health.recommended.contextLength.toLocaleString()} token context` : ""
              ] }),
              health?.recommended && reasoningModels.includes(health.recommended.reasoningModel) && visionModels.includes(health.recommended.visionModel) && (settings.reasoningModel !== health.recommended.reasoningModel || settings.visionModel !== health.recommended.visionModel) && /* @__PURE__ */ a3("button", { class: "ja-btn", disabled: generating || browserBusy, onClick: () => updateSettings({ reasoningModel: health.recommended.reasoningModel, visionModel: health.recommended.visionModel }), children: [
                /* @__PURE__ */ a3(Icon, { name: "bolt", size: 13 }),
                "Use recommended model pair"
              ] }),
              !ready && /* @__PURE__ */ a3("div", { class: "ja-setup", children: [
                /* @__PURE__ */ a3("strong", { children: "Connect your local engine" }),
                /* @__PURE__ */ a3("p", { class: "ja-note", children: "Run this from the project folder after installing the backend dependencies, and keep Ollama running. Your existing models will appear here." }),
                /* @__PURE__ */ a3("code", { children: "make assistant" }),
                /* @__PURE__ */ a3("p", { class: "ja-note", children: [
                  "Ollama listens on ",
                  /* @__PURE__ */ a3("code", { style: { display: "inline", padding: 0, background: "transparent" }, children: "127.0.0.1:11434" }),
                  ". See gradient/docs/LOCAL_AI.md for setup and memory guidance."
                ] })
              ] }),
              connectionError && /* @__PURE__ */ a3("div", { class: "ja-notice error", role: "alert", children: connectionError })
            ] })
          ] }),
          /* @__PURE__ */ a3("section", { class: "ja-section", children: [
            /* @__PURE__ */ a3("div", { class: "ja-row", children: [
              /* @__PURE__ */ a3("h2", { children: "What are we working on?" }),
              /* @__PURE__ */ a3(Icon, { name: "book", size: 16 })
            ] }),
            /* @__PURE__ */ a3("div", { class: "ja-fields", style: { marginTop: "11px" }, children: [
              /* @__PURE__ */ a3("label", { children: [
                /* @__PURE__ */ a3("span", { class: "ja-label", children: "Course" }),
                /* @__PURE__ */ a3("select", { class: "ja-control", "aria-label": "Assistant course", value: course?.id ?? "", disabled: generating, onChange: (e3) => {
                  setCourseId(e3.currentTarget.value);
                  setAssignmentId("");
                }, children: snapshot.courses.map((item) => /* @__PURE__ */ a3("option", { value: item.id, children: [
                  item.code,
                  " \xB7 ",
                  item.name
                ] }, item.id)) })
              ] }),
              /* @__PURE__ */ a3("label", { children: [
                /* @__PURE__ */ a3("span", { class: "ja-label", children: "Assignment or homework" }),
                /* @__PURE__ */ a3("select", { class: "ja-control", "aria-label": "Assistant assignment", value: assignment?.id ?? "", disabled: generating || !course?.assignments.length, onChange: (e3) => setAssignmentId(e3.currentTarget.value), children: course?.assignments.length ? course.assignments.map((item) => /* @__PURE__ */ a3("option", { value: item.id, children: item.name }, item.id)) : /* @__PURE__ */ a3("option", { value: "", children: "No assignments available" }) })
              ] })
            ] }),
            assignment && /* @__PURE__ */ a3("div", { class: "ja-context", children: [
              /* @__PURE__ */ a3("strong", { children: assignment.name }),
              /* @__PURE__ */ a3("span", { children: [
                assignment.dueAt && Number.isFinite(Date.parse(assignment.dueAt)) ? `Due ${new Date(assignment.dueAt).toLocaleString(void 0, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })} \xB7 ` : "",
                resources.length,
                " course materials in context"
              ] }),
              safeUrl(assignment.htmlUrl) && /* @__PURE__ */ a3("div", { children: /* @__PURE__ */ a3("a", { href: safeUrl(assignment.htmlUrl), target: "_blank", rel: "noopener noreferrer", children: [
                "Open in Canvas ",
                /* @__PURE__ */ a3(Icon, { name: "external", size: 10 })
              ] }) }),
              brief && /* @__PURE__ */ a3("details", { children: [
                /* @__PURE__ */ a3("summary", { children: "Read the assignment brief" }),
                /* @__PURE__ */ a3("div", { class: "ja-brief", children: brief })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ a3("section", { class: "ja-section", children: [
            /* @__PURE__ */ a3("h2", { children: "How far should I go?" }),
            /* @__PURE__ */ a3("div", { class: "ja-detail", role: "group", "aria-label": "Response detail level", children: LEVELS.map((level) => /* @__PURE__ */ a3("button", { class: settings.detailLevel === level.id ? "active" : "", "aria-pressed": settings.detailLevel === level.id, disabled: generating, onClick: () => updateSettings({ detailLevel: level.id }), children: [
              /* @__PURE__ */ a3("strong", { children: level.title }),
              /* @__PURE__ */ a3("small", { children: level.description })
            ] }, level.id)) }),
            /* @__PURE__ */ a3("div", { class: "ja-mode", role: "group", "aria-label": "Assistant output type", children: [
              /* @__PURE__ */ a3("button", { class: `ja-btn ${mode === "explain" ? "active" : ""}`, "aria-pressed": mode === "explain", disabled: generating, onClick: () => setMode("explain"), children: [
                /* @__PURE__ */ a3(Icon, { name: "layers", size: 12 }),
                "Study & understand"
              ] }),
              /* @__PURE__ */ a3("button", { class: `ja-btn ${mode === "sample" ? "active" : ""}`, "aria-pressed": mode === "sample", disabled: generating, onClick: () => setMode("sample"), children: [
                /* @__PURE__ */ a3(Icon, { name: "file", size: 12 }),
                "Sample assignment"
              ] })
            ] }),
            mode === "sample" && /* @__PURE__ */ a3("p", { class: "ja-note", children: "A complete reference draft, clearly marked as an AI-generated sample. Verify it and follow your course\u2019s AI policy." }),
            /* @__PURE__ */ a3("div", { class: "ja-switches", children: [
              /* @__PURE__ */ a3("label", { class: "ja-switch", children: [
                /* @__PURE__ */ a3("input", { type: "checkbox", checked: settings.webResearch, disabled: generating, onChange: (e3) => updateSettings({ webResearch: e3.currentTarget.checked }) }),
                "Research the web"
              ] }),
              ["diagrams", "graphs", "images"].map((key) => /* @__PURE__ */ a3("label", { class: "ja-switch", children: [
                /* @__PURE__ */ a3("input", { type: "checkbox", checked: visuals[key], disabled: generating, onChange: (e3) => setVisuals({ ...visuals, [key]: e3.currentTarget.checked }) }),
                key[0]?.toUpperCase(),
                key.slice(1)
              ] }, key))
            ] })
          ] }),
          /* @__PURE__ */ a3("section", { class: "ja-section", children: [
            /* @__PURE__ */ a3("button", { class: "ja-btn", style: { marginBottom: "12px", marginRight: "8px" }, onClick: async () => {
              try {
                const granted = await enableBrowserSearch();
                setGenerationError(granted ? "" : "Google access was not enabled.");
              } catch (error) {
                setGenerationError(errorMessage(error));
              }
            }, children: "Enable Google browser search" }),
            /* @__PURE__ */ a3("a", { class: "ja-btn", style: { marginBottom: "12px" }, target: "_blank", rel: "noopener noreferrer", href: `https://www.google.com/search?q=${encodeURIComponent(`${assignment?.name ?? ""} ${prompt.trim()} tutorial explanation`.slice(0, 250))}`, children: [
              "Open Google search ",
              /* @__PURE__ */ a3(Icon, { name: "external", size: 12 })
            ] }),
            /* @__PURE__ */ a3("label", { class: "ja-label", for: "ja-prompt", children: "Anything you want me to focus on?" }),
            /* @__PURE__ */ a3("textarea", { id: "ja-prompt", class: "ja-control", rows: 3, value: prompt, disabled: generating, onInput: (e3) => setPrompt(e3.currentTarget.value), placeholder: "Explain the hard parts, compare approaches, or write a sample with diagrams and references\u2026" }),
            /* @__PURE__ */ a3("button", { class: "ja-btn primary full", style: { marginTop: "11px" }, disabled: !ready || !assignment || generating, onClick: generate, children: generating ? /* @__PURE__ */ a3(M, { children: [
              /* @__PURE__ */ a3(Icon, { name: "refresh", size: 15, className: "g-spinner" }),
              "Working on your request\u2026"
            ] }) : /* @__PURE__ */ a3(M, { children: [
              /* @__PURE__ */ a3(Icon, { name: "spark", size: 15 }),
              mode === "sample" ? "Create my sample assignment" : "Build my study packet",
              /* @__PURE__ */ a3(Icon, { name: "arrow", size: 14 })
            ] }) }),
            generating && /* @__PURE__ */ a3("div", { class: "ja-progress", role: "status", children: /* @__PURE__ */ a3("span", { children: [
              "Reading Canvas materials, researching, then drafting with ",
              settings.reasoningModel,
              ". This can take several minutes."
            ] }) }),
            generationError && /* @__PURE__ */ a3("div", { class: "ja-notice error", role: "alert", style: { marginTop: "10px" }, children: generationError }),
            /* @__PURE__ */ a3("p", { class: "ja-note", style: { marginTop: "9px" }, children: "Coursework is sent to the local service on your computer. Web research sends search queries to public search engines. Generated work stays in this tab until you export it." })
          ] }),
          packet && /* @__PURE__ */ a3("section", { "aria-label": "Generated study packet", children: [
            /* @__PURE__ */ a3("div", { class: "ja-row", style: { marginBottom: "10px" }, children: [
              /* @__PURE__ */ a3("h2", { children: "Your study packet" }),
              /* @__PURE__ */ a3("span", { class: "ja-eyebrow", children: "Ready for review" })
            ] }),
            /* @__PURE__ */ a3("article", { class: "ja-result", ref: resultRef, children: [
              /* @__PURE__ */ a3("header", { class: "ja-result-header", children: [
                /* @__PURE__ */ a3("div", { class: "ja-eyebrow", children: "Gradient \xB7 AI-generated study reference" }),
                /* @__PURE__ */ a3("h2", { children: packet.title }),
                /* @__PURE__ */ a3("p", { children: packet.summary }),
                packet.generatedAt && /* @__PURE__ */ a3("p", { children: [
                  "Created ",
                  new Date(packet.generatedAt).toLocaleString()
                ] })
              ] }),
              /* @__PURE__ */ a3("div", { class: "ja-result-body", children: [
                /* @__PURE__ */ a3(AssistantMarkdown, { text: packet.markdown }),
                packet.diagrams.map((diagram, i3) => /* @__PURE__ */ a3(ConceptDiagram, { diagram }, i3)),
                packet.graphs.map((graph, i3) => /* @__PURE__ */ a3(DataGraph, { graph }, i3)),
                packet.images.filter((image) => safeUrl(image.url) && safeUrl(image.sourceUrl)).map((image, i3) => /* @__PURE__ */ a3("figure", { class: "ja-visual", children: [
                  /* @__PURE__ */ a3("figcaption", { children: image.title }),
                  /* @__PURE__ */ a3("img", { src: safeUrl(image.url), alt: image.alt, loading: "lazy", referrerPolicy: "no-referrer", onError: (e3) => {
                    e3.currentTarget.style.display = "none";
                  } }),
                  /* @__PURE__ */ a3("a", { href: safeUrl(image.sourceUrl), target: "_blank", rel: "noopener noreferrer", children: "View image source" })
                ] }, i3)),
                packet.sampleMarkdown && /* @__PURE__ */ a3("section", { class: "ja-sample", children: [
                  /* @__PURE__ */ a3("span", { class: "ja-sample-tag", children: "AI-GENERATED SAMPLE \xB7 REVIEW BEFORE USE" }),
                  /* @__PURE__ */ a3(AssistantMarkdown, { text: packet.sampleMarkdown })
                ] }),
                !!packet.checklist?.length && /* @__PURE__ */ a3("section", { class: "ja-sample", children: [
                  /* @__PURE__ */ a3("h3", { children: "Before you finish" }),
                  /* @__PURE__ */ a3("ul", { class: "ja-checklist", children: packet.checklist.map((item, i3) => /* @__PURE__ */ a3("li", { children: item }, i3)) })
                ] }),
                packet.warnings.map((warning, i3) => /* @__PURE__ */ a3("p", { class: "ja-note", style: { marginTop: "10px" }, children: [
                  /* @__PURE__ */ a3("strong", { children: "Verify:" }),
                  " ",
                  warning
                ] }, i3)),
                /* @__PURE__ */ a3("section", { class: "ja-sources", children: [
                  /* @__PURE__ */ a3("h3", { children: "Sources & further reading" }),
                  packet.sources.length ? /* @__PURE__ */ a3("ol", { children: packet.sources.map((source, i3) => /* @__PURE__ */ a3("li", { children: [
                    safeUrl(source.url) ? /* @__PURE__ */ a3("a", { href: safeUrl(source.url), target: "_blank", rel: "noopener noreferrer", children: source.title }) : /* @__PURE__ */ a3("strong", { children: source.title }),
                    source.kind && /* @__PURE__ */ a3("small", { children: [
                      " \xB7 ",
                      source.kind === "canvas" ? "Course material" : "Web resource"
                    ] }),
                    source.excerpt && /* @__PURE__ */ a3("p", { children: source.excerpt })
                  ] }, source.id || i3)) }) : /* @__PURE__ */ a3("p", { class: "ja-note", children: "No verified external sources were returned. Check claims against your course materials." })
                ] })
              ] })
            ] }),
            /* @__PURE__ */ a3("div", { class: "ja-export", children: [
              /* @__PURE__ */ a3("button", { class: "ja-btn", onClick: exportHtml, children: [
                /* @__PURE__ */ a3(Icon, { name: "download", size: 13 }),
                "Export illustrated HTML"
              ] }),
              /* @__PURE__ */ a3("button", { class: "ja-btn", onClick: () => download(packetMarkdown(packet), `${filename(packet.title)}.md`, "text/markdown;charset=utf-8"), children: [
                /* @__PURE__ */ a3(Icon, { name: "download", size: 13 }),
                "Markdown"
              ] })
            ] }),
            /* @__PURE__ */ a3("p", { class: "ja-note", children: "Open the HTML in your browser to print or save it as a PDF, with diagrams and references." })
          ] }),
          /* @__PURE__ */ a3("section", { class: "ja-browser", children: [
            /* @__PURE__ */ a3("div", { class: "ja-row", children: [
              /* @__PURE__ */ a3("h2", { children: "Eyes on your browser" }),
              /* @__PURE__ */ a3(Icon, { name: "search", size: 16 })
            ] }),
            /* @__PURE__ */ a3("p", { class: "ja-note", children: "Your local vision model reads a screenshot and page text, then suggests a sequence of browsing steps. You choose each step." }),
            /* @__PURE__ */ a3("label", { style: { display: "block", marginTop: "10px" }, children: [
              /* @__PURE__ */ a3("span", { class: "ja-label", children: "What should the vision model look for?" }),
              /* @__PURE__ */ a3("textarea", { class: "ja-control", "aria-label": "Browser companion goal", rows: 2, value: browserGoal, disabled: browserBusy, onInput: (e3) => setBrowserGoal(e3.currentTarget.value) })
            ] }),
            /* @__PURE__ */ a3("button", { class: "ja-btn full", style: { marginTop: "9px" }, disabled: !visionReady || browserBusy || !browserGoal.trim(), onClick: inspectPage, children: [
              /* @__PURE__ */ a3(Icon, { name: browserBusy ? "refresh" : "search", size: 14, className: browserBusy ? "g-spinner" : "" }),
              browserBusy ? `Inspecting with ${settings.visionModel}\u2026` : "Inspect this Canvas page"
            ] }),
            !visionReady && /* @__PURE__ */ a3("p", { class: "ja-note", children: "Connect Ollama and select an installed model with vision support to enable page inspection." }),
            browserError && /* @__PURE__ */ a3("div", { class: "ja-notice error", role: "alert", style: { marginTop: "9px" }, children: browserError }),
            browserPlan && /* @__PURE__ */ a3("div", { style: { marginTop: "12px" }, children: [
              /* @__PURE__ */ a3("p", { class: "ja-note", children: browserPlan.summary }),
              /* @__PURE__ */ a3("ol", { class: "ja-browser-steps", children: browserPlan.actions.map((action, i3) => /* @__PURE__ */ a3("li", { children: [
                /* @__PURE__ */ a3("strong", { children: [
                  i3 + 1,
                  ". ",
                  action.kind === "open" ? "Open a resource" : action.kind === "find" ? "Find on this page" : action.kind === "scroll" ? "Move through the page" : "Read this section"
                ] }),
                /* @__PURE__ */ a3("p", { children: action.description }),
                /* @__PURE__ */ a3("button", { class: "ja-btn", onClick: async () => {
                  try {
                    await applyBrowserAction(action);
                    setActionMessage(`Step ${i3 + 1}: ${action.description}`);
                  } catch (error) {
                    setBrowserError(errorMessage(error));
                  }
                }, children: [
                  action.kind === "open" ? "Open link" : action.kind === "find" ? "Find text" : action.kind === "scroll" ? "Scroll" : "Show section",
                  /* @__PURE__ */ a3(Icon, { name: "arrow", size: 11 })
                ] })
              ] }, i3)) }),
              browserPlan.warnings.map((warning, i3) => /* @__PURE__ */ a3("p", { class: "ja-note", children: warning }, i3))
            ] }),
            actionMessage && /* @__PURE__ */ a3("p", { class: "ja-note", role: "status", children: actionMessage })
          ] }),
          /* @__PURE__ */ a3("div", { class: "ja-footnote", children: [
            /* @__PURE__ */ a3(Icon, { name: "shield", size: 12 }),
            /* @__PURE__ */ a3("span", { children: "Local models. Your Canvas access. References you can inspect. The assistant does not submit assignments." })
          ] })
        ] })
      ] })
    ] });
  }

  // extension/deadlineCalendar.ts
  var STORAGE_KEY2 = "gradient_deadline_tracking_v1";
  var HOUR = 60 * 60 * 1e3;
  var emptyStore = () => ({ accounts: {}, delivered: {} });
  var emptyState = () => ({ enabled: false, excludedIds: [], deadlines: [], updatedAt: "" });
  var scope = (origin, userId) => `${origin}|${userId}`;
  var extensionAvailable2 = () => typeof chrome !== "undefined" && !!chrome.runtime?.id;
  function getSnapshotDeadlines(snapshot) {
    const deadlines = [];
    for (const course of snapshot.courses) for (const assignment of course.assignments) {
      if (!assignment.dueAt || !Number.isFinite(Date.parse(assignment.dueAt))) continue;
      if (assignment.submission?.excused || assignment.submission?.score != null || ["submitted", "pending_review", "graded"].includes(assignment.submission?.workflowState ?? "")) continue;
      deadlines.push({
        id: `${scope(snapshot.origin, snapshot.user.id)}|${course.id}|${assignment.id}`,
        origin: snapshot.origin,
        userId: snapshot.user.id,
        courseId: course.id,
        assignmentId: assignment.id,
        title: assignment.name,
        courseName: course.name,
        courseCode: course.code,
        dueAt: new Date(assignment.dueAt).toISOString(),
        url: `${snapshot.origin}/courses/${encodeURIComponent(course.id)}/assignments/${encodeURIComponent(assignment.id)}`
      });
    }
    return [...new Map(deadlines.map((deadline) => [deadline.id, deadline])).values()].sort((a4, b2) => Date.parse(a4.dueAt) - Date.parse(b2.dueAt));
  }
  function escapeIcs(value) {
    return value.replace(/\\/g, "\\\\").replace(/\r\n|\r|\n/g, "\\n").replace(/,/g, "\\,").replace(/;/g, "\\;");
  }
  function icsDate(date) {
    return date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
  }
  function foldIcsLine(line) {
    let result = "", octets = 0;
    for (const char of line) {
      const size = new TextEncoder().encode(char).length;
      if (octets + size > 75) {
        result += "\r\n ";
        octets = 1;
      }
      result += char;
      octets += size;
    }
    return result;
  }
  function createDeadlineCalendar(deadlines, now = /* @__PURE__ */ new Date()) {
    const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//GRADIENT//Assignment Deadlines//EN", "CALSCALE:GREGORIAN", "METHOD:PUBLISH"];
    for (const deadline of new Map(deadlines.map((d3) => [d3.id, d3])).values()) {
      const due = new Date(deadline.dueAt);
      if (!Number.isFinite(due.getTime())) continue;
      const hostname = new URL(deadline.origin).hostname;
      lines.push(
        "BEGIN:VEVENT",
        `UID:gradient-${encodeURIComponent(deadline.userId)}-${encodeURIComponent(deadline.courseId)}-${encodeURIComponent(deadline.assignmentId)}@${hostname}`,
        `DTSTAMP:${icsDate(now)}`,
        `DTSTART:${icsDate(due)}`,
        `DTEND:${icsDate(new Date(due.getTime() + 15 * 6e4))}`,
        `SUMMARY:${escapeIcs(`${deadline.courseCode}: ${deadline.title}`)}`,
        `DESCRIPTION:${escapeIcs(`${deadline.courseName}
Assignment deadline from Canvas.
${deadline.url}`)}`,
        `URL:${escapeIcs(deadline.url)}`
      );
      for (const hours of [24, 1]) lines.push("BEGIN:VALARM", `TRIGGER:-PT${hours}H`, "ACTION:DISPLAY", `DESCRIPTION:${escapeIcs(`${deadline.title} is due in ${hours} hour${hours === 1 ? "" : "s"}.`)}`, "END:VALARM");
      lines.push("END:VEVENT");
    }
    return [...lines, "END:VCALENDAR"].map(foldIcsLine).join("\r\n") + "\r\n";
  }
  function googleCalendarUrl(deadline) {
    const due = new Date(deadline.dueAt);
    if (!Number.isFinite(due.getTime())) throw new Error("This deadline has no valid date.");
    const url = new URL("https://calendar.google.com/calendar/render");
    url.searchParams.set("action", "TEMPLATE");
    url.searchParams.set("text", `${deadline.courseCode}: ${deadline.title}`);
    url.searchParams.set("dates", `${icsDate(due)}/${icsDate(new Date(due.getTime() + 15 * 6e4))}`);
    url.searchParams.set("details", `${deadline.courseName}
Assignment deadline from Canvas.
${deadline.url}`);
    return url.href;
  }
  function downloadDeadlineCalendar(deadlines) {
    const url = URL.createObjectURL(new Blob([createDeadlineCalendar(deadlines)], { type: "text/calendar;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "gradient-canvas-deadlines.ics";
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  async function readStore() {
    let stored;
    if (typeof chrome !== "undefined" && chrome.storage?.local) stored = (await chrome.storage.local.get(STORAGE_KEY2))[STORAGE_KEY2];
    else if (typeof localStorage !== "undefined") {
      const raw = localStorage.getItem(STORAGE_KEY2);
      if (raw) try {
        stored = JSON.parse(raw);
      } catch {
      }
    }
    if (!stored || typeof stored !== "object") return emptyStore();
    const value = stored;
    return { accounts: value.accounts && typeof value.accounts === "object" ? value.accounts : {}, delivered: value.delivered && typeof value.delivered === "object" ? value.delivered : {} };
  }
  async function writeStore(store) {
    if (typeof chrome !== "undefined" && chrome.storage?.local) await chrome.storage.local.set({ [STORAGE_KEY2]: store });
    else if (typeof localStorage !== "undefined") localStorage.setItem(STORAGE_KEY2, JSON.stringify(store));
  }
  async function sendTrackingMessage(message2) {
    const response = await chrome.runtime.sendMessage(message2);
    if (!response?.ok || !response.state) throw new Error(response?.error || "The extension could not update your reminders. Reload your Canvas tab and try again.");
    return response.state;
  }
  async function getDeadlineTracking(snapshot) {
    if (extensionAvailable2()) return sendTrackingMessage({ type: "GRADIENT_GET_TRACKING", origin: snapshot.origin, userId: snapshot.user.id });
    return (await readStore()).accounts[scope(snapshot.origin, snapshot.user.id)] ?? emptyState();
  }
  async function setDeadlineTracking(snapshot, enabled, excludedIds) {
    const message2 = { type: "GRADIENT_TRACK_DEADLINES", origin: snapshot.origin, userId: snapshot.user.id, enabled, deadlines: getSnapshotDeadlines(snapshot), ...excludedIds ? { excludedIds } : {} };
    if (extensionAvailable2()) return sendTrackingMessage(message2);
    const store = await readStore();
    const key = scope(snapshot.origin, snapshot.user.id);
    const previous = store.accounts[key] ?? emptyState();
    const state = { ...previous, enabled, deadlines: message2.deadlines, excludedIds: excludedIds ?? previous.excludedIds, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
    store.accounts[key] = state;
    await writeStore(store);
    return state;
  }
  async function syncTrackedDeadlines(snapshot) {
    if (!extensionAvailable2()) return;
    await sendTrackingMessage({ type: "GRADIENT_SYNC_DEADLINES", origin: snapshot.origin, userId: snapshot.user.id, deadlines: getSnapshotDeadlines(snapshot) });
  }
  var queue = Promise.resolve();

  // extension/ui/DeadlineTracker.tsx
  function DeadlineTracker({ snapshot, preview = false }) {
    const deadlines = w2(() => getSnapshotDeadlines(snapshot), [snapshot]);
    const [state, setState] = d2(null);
    const [busy, setBusy] = d2(false);
    const [error, setError] = d2("");
    const [showPast, setShowPast] = d2(false);
    A(() => {
      let mounted = true;
      const load = async () => {
        if (!preview) await syncTrackedDeadlines(snapshot);
        const loaded = await getDeadlineTracking(snapshot);
        if (mounted) {
          setState(loaded);
          setError("");
        }
      };
      load().catch((err) => {
        if (mounted) setError(err instanceof Error ? err.message : "Could not read deadline preferences.");
      });
      return () => {
        mounted = false;
      };
    }, [snapshot, preview]);
    const future = deadlines.filter((d3) => Date.parse(d3.dueAt) > Date.now());
    const overdue = deadlines.filter((d3) => Date.parse(d3.dueAt) <= Date.now());
    const excluded = new Set(state?.excludedIds ?? []);
    const selected = future.filter((d3) => !excluded.has(d3.id));
    const update = async (enabled, excludedIds) => {
      setBusy(true);
      setError("");
      try {
        setState(await setDeadlineTracking(snapshot, enabled, excludedIds));
      } catch (err) {
        setError(err instanceof Error ? err.message : "Your reminder preferences could not be saved.");
      } finally {
        setBusy(false);
      }
    };
    const visible = showPast ? deadlines : future;
    const canNotify = !preview && typeof chrome !== "undefined" && !!chrome.runtime?.id;
    return /* @__PURE__ */ a3("section", { class: "g-card", "aria-label": "Deadline tracking and calendar", children: [
      /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
        /* @__PURE__ */ a3("h2", { children: "Keep your deadlines close." }),
        /* @__PURE__ */ a3(Icon, { name: "calendar", size: 18 })
      ] }),
      /* @__PURE__ */ a3("p", { class: "g-small", children: [
        future.length,
        " upcoming deadline",
        future.length === 1 ? "" : "s",
        overdue.length ? ` \xB7 ${overdue.length} past due` : "",
        ". Browser reminders arrive 24 hours and 1 hour before selected deadlines."
      ] }),
      /* @__PURE__ */ a3("div", { style: { display: "flex", gap: "8px", flexWrap: "wrap", marginTop: "14px" }, children: [
        /* @__PURE__ */ a3("button", { class: state?.enabled ? "g-secondary" : "g-primary", disabled: busy || state === null || preview, onClick: () => update(!state?.enabled), children: [
          /* @__PURE__ */ a3(Icon, { name: state?.enabled ? "check" : "clock", size: 14 }),
          busy ? "Saving\u2026" : state?.enabled ? "Pause reminders" : "Track deadlines"
        ] }),
        /* @__PURE__ */ a3("button", { class: "g-secondary", disabled: !selected.length, onClick: () => downloadDeadlineCalendar(selected), children: [
          /* @__PURE__ */ a3(Icon, { name: "download", size: 14 }),
          "Download calendar (.ics)"
        ] })
      ] }),
      state?.enabled && /* @__PURE__ */ a3("p", { class: "g-small", role: "status", style: { marginTop: "10px", color: "#187352" }, children: canNotify ? "Browser reminders are on. Keep Chrome running to receive them." : "Preferences saved. Load the extension in Chrome to receive browser reminders." }),
      preview && /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "10px" }, children: "Sample deadlines. Install the extension on Canvas to enable reminders for your real coursework." }),
      /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "10px" }, children: "Import the .ics file into Apple Calendar or Google Calendar. Google links let you review and save one event. Calendar copies do not automatically sync; refresh Canvas and export again after a deadline changes." }),
      error && /* @__PURE__ */ a3("p", { class: "g-notice", role: "alert", style: { marginTop: "12px" }, children: error }),
      !!overdue.length && /* @__PURE__ */ a3("label", { class: "g-small", style: { display: "flex", gap: "7px", alignItems: "center", marginTop: "14px", cursor: "pointer" }, children: [
        /* @__PURE__ */ a3("input", { type: "checkbox", checked: showPast, onChange: (e3) => setShowPast(e3.currentTarget.checked) }),
        "Show past-due work"
      ] }),
      /* @__PURE__ */ a3("div", { style: { marginTop: "12px", maxHeight: "350px", overflowY: "auto" }, children: [
        visible.map((deadline) => {
          const past = Date.parse(deadline.dueAt) <= Date.now();
          return /* @__PURE__ */ a3("div", { class: "g-task", style: { alignItems: "flex-start" }, children: [
            /* @__PURE__ */ a3("input", { type: "checkbox", "aria-label": `Include ${deadline.title} in reminders and calendar export`, disabled: busy || !state || preview || past, checked: !past && !excluded.has(deadline.id), style: { marginTop: "4px", accentColor: "#2855e8" }, onChange: (e3) => {
              const next = new Set(excluded);
              if (e3.currentTarget.checked) next.delete(deadline.id);
              else next.add(deadline.id);
              update(state?.enabled ?? false, [...next]);
            } }),
            /* @__PURE__ */ a3("div", { class: "g-task-main", children: [
              /* @__PURE__ */ a3("strong", { children: /* @__PURE__ */ a3("a", { href: deadline.url, children: deadline.title }) }),
              /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "4px" }, children: [
                deadline.courseCode,
                " \xB7 ",
                new Date(deadline.dueAt).toLocaleString(void 0, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }),
                past ? " \xB7 Past due" : ""
              ] }),
              !past && /* @__PURE__ */ a3("a", { class: "g-link-btn", style: { display: "inline-flex", marginTop: "7px", fontSize: "10px" }, href: googleCalendarUrl(deadline), target: "_blank", rel: "noopener noreferrer", children: [
                "Add to Google Calendar ",
                /* @__PURE__ */ a3(Icon, { name: "external", size: 11 })
              ] })
            ] })
          ] }, deadline.id);
        }),
        !visible.length && /* @__PURE__ */ a3("p", { class: "g-small", style: { padding: "14px 0" }, children: "No upcoming, unsubmitted assignments with a due date were found." })
      ] }),
      /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "12px" }, children: "Saved locally: assignment titles, course names, deadlines, and Canvas links. Reminder schedules update whenever GRADIENT refreshes Canvas. Submitted work is removed from the schedule." })
    ] });
  }

  // extension/ui/Workspace.tsx
  var colors = [
    { tint: "#edf2ff", ink: "#2855e8" },
    { tint: "#fff0e8", ink: "#a84726" },
    { tint: "#e6f5ee", ink: "#187352" },
    { tint: "#f1eafd", ink: "#7950b9" },
    { tint: "#fff5d9", ink: "#87651b" },
    { tint: "#e6f5fa", ink: "#22708c" }
  ];
  function plain2(html) {
    const doc = new DOMParser().parseFromString(html, "text/html");
    doc.querySelectorAll("script,style").forEach((el) => el.remove());
    doc.querySelectorAll("p,br,li,h1,h2,h3").forEach((el) => el.append(doc.createTextNode("\n")));
    return (doc.body.textContent ?? "").replace(/\n{3,}/g, "\n\n").trim();
  }
  function safeLink(value) {
    try {
      const url = new URL(value, window.location.origin);
      return ["https:", "http:"].includes(url.protocol) ? url.href : "#";
    } catch {
      return "#";
    }
  }
  function score(value) {
    return value == null ? "\u2014" : `${value.toFixed(1)}%`;
  }
  function pending(a4) {
    return !a4.submission?.excused && a4.submission?.score == null && a4.submission?.workflowState !== "submitted" && a4.submission?.workflowState !== "pending_review" && a4.submission?.workflowState !== "graded";
  }
  function dueDate(a4) {
    return a4.dueAt ? Date.parse(a4.dueAt) : Number.POSITIVE_INFINITY;
  }
  function dueLabel(a4) {
    if (!a4.dueAt) return "No due date";
    const date = new Date(a4.dueAt);
    const now = /* @__PURE__ */ new Date();
    if (!Number.isFinite(date.getTime())) return "No due date";
    if (date.getTime() < now.getTime()) return "Past due";
    const dayKey = (d3) => Date.UTC(d3.getFullYear(), d3.getMonth(), d3.getDate());
    const days = (dayKey(date) - dayKey(now)) / 864e5;
    if (days === 0) return "Due today";
    if (days === 1) return "Tomorrow";
    return date.toLocaleDateString(void 0, { month: "short", day: "numeric" });
  }
  function taskStatus(a4) {
    if (a4.submission?.excused) return "Excused";
    if (a4.submission?.score != null) return `${a4.submission.score} / ${a4.pointsPossible} pts`;
    if (a4.submission?.workflowState === "graded") return "Graded \xB7 score hidden";
    if (a4.submission?.workflowState === "submitted" || a4.submission?.workflowState === "pending_review") return "Submitted";
    return "To do";
  }
  function initials(name) {
    return name.split(" ").filter(Boolean).slice(0, 2).map((n2) => n2[0]).join("").toUpperCase();
  }
  function exportCalendar(tasks, origin) {
    const esc = (s3) => s3.replace(/\\/g, "\\\\").replace(/\r?\n/g, "\\n").replace(/,/g, "\\,").replace(/;/g, "\\;");
    const stamp = (d3) => d3.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
    const now = stamp(/* @__PURE__ */ new Date());
    const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//GRADIENT//Canvas Coursework//EN", "CALSCALE:GREGORIAN"];
    for (const { course, assignment: a4 } of tasks.filter((t3) => t3.assignment.dueAt)) {
      const start = new Date(a4.dueAt);
      if (!Number.isFinite(start.getTime())) continue;
      lines.push("BEGIN:VEVENT", `UID:gradient-${course.id}-${a4.id}@${new URL(origin).hostname}`, `DTSTAMP:${now}`, `DTSTART:${stamp(start)}`, `DTEND:${stamp(new Date(start.getTime() + 15 * 6e4))}`, `SUMMARY:${esc(a4.name)}`, `DESCRIPTION:${esc(course.name + "\nAssignment deadline from Canvas.\n" + a4.htmlUrl)}`, `URL:${safeLink(a4.htmlUrl)}`, "END:VEVENT");
    }
    lines.push("END:VCALENDAR");
    const folded = lines.map((line) => {
      let result = "", count = 0;
      for (const char of line) {
        const bytes = new TextEncoder().encode(char).length;
        if (count + bytes > 74) {
          result += "\r\n ";
          count = 1;
        }
        result += char;
        count += bytes;
      }
      return result;
    }).join("\r\n") + "\r\n";
    const url = URL.createObjectURL(new Blob([folded], { type: "text/calendar;charset=utf-8" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "gradient-canvas-deadlines.ics";
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1e3);
  }
  function Empty({ title, children }) {
    return /* @__PURE__ */ a3("div", { class: "g-empty", children: [
      /* @__PURE__ */ a3("div", { class: "g-empty-icon", children: /* @__PURE__ */ a3(Icon, { name: "check", size: 22 }) }),
      /* @__PURE__ */ a3("h2", { children: title }),
      /* @__PURE__ */ a3("p", { children })
    ] });
  }
  function TaskRow({ task, onSelect }) {
    const { course, assignment: a4 } = task;
    return /* @__PURE__ */ a3("div", { class: "g-task", children: [
      /* @__PURE__ */ a3("div", { class: "g-task-marker", children: /* @__PURE__ */ a3(Icon, { name: "book", size: 15 }) }),
      /* @__PURE__ */ a3("div", { class: "g-task-main", children: [
        /* @__PURE__ */ a3("strong", { children: onSelect ? /* @__PURE__ */ a3("button", { class: "g-link-btn", style: { textAlign: "left", color: "inherit", fontSize: "12px", fontWeight: 650 }, onClick: onSelect, children: a4.name }) : /* @__PURE__ */ a3("a", { href: safeLink(a4.htmlUrl), children: a4.name }) }),
        /* @__PURE__ */ a3("div", { class: "g-task-meta", children: [
          /* @__PURE__ */ a3("span", { children: course.code }),
          /* @__PURE__ */ a3("span", { children: "\xB7" }),
          /* @__PURE__ */ a3("span", { children: [
            a4.pointsPossible,
            " pts"
          ] }),
          !pending(a4) && /* @__PURE__ */ a3(M, { children: [
            /* @__PURE__ */ a3("span", { children: "\xB7" }),
            /* @__PURE__ */ a3("span", { children: taskStatus(a4) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ a3("span", { class: `g-due ${dueDate(a4) > Date.now() + 2 * 864e5 || !a4.dueAt ? "normal" : ""}`, children: dueLabel(a4) })
    ] });
  }
  function AssignmentFeedback({ assignment }) {
    const rubric = assignment.rubric ?? [];
    const comments = assignment.submission?.submissionComments ?? [];
    const assessment = assignment.submission?.rubricAssessment ?? {};
    if (!rubric.length && !comments.length) return null;
    return /* @__PURE__ */ a3("section", { class: "g-card", "aria-label": "Assignment rubric and instructor feedback", children: /* @__PURE__ */ a3("details", { children: [
      /* @__PURE__ */ a3("summary", { class: "g-feedback-summary", children: [
        /* @__PURE__ */ a3("span", { children: "Rubric & instructor feedback" }),
        /* @__PURE__ */ a3("span", { class: "g-label-count", children: "FROM CANVAS" })
      ] }),
      /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "10px" }, children: [
        "The criteria and feedback published for ",
        assignment.name,
        "."
      ] }),
      rubric.length > 0 && /* @__PURE__ */ a3("div", { class: "g-rubric-list", children: rubric.map((criterion) => {
        const assessed = assessment[criterion.id];
        return /* @__PURE__ */ a3("div", { class: "g-rubric-criterion", children: [
          /* @__PURE__ */ a3("div", { class: "g-section-head", style: { marginBottom: "8px" }, children: [
            /* @__PURE__ */ a3("h3", { children: plain2(criterion.description) || "Rubric criterion" }),
            /* @__PURE__ */ a3("span", { class: "g-label-count", children: [
              criterion.points,
              " pts"
            ] })
          ] }),
          assessed && /* @__PURE__ */ a3("div", { class: "g-notice info", style: { marginBottom: "9px" }, children: [
            /* @__PURE__ */ a3(Icon, { name: "check", size: 14 }),
            /* @__PURE__ */ a3("div", { children: [
              /* @__PURE__ */ a3("strong", { children: [
                "Instructor assessment: ",
                assessed.points,
                " / ",
                criterion.points,
                " pts"
              ] }),
              assessed.comments && /* @__PURE__ */ a3("p", { style: { marginTop: "4px" }, children: plain2(assessed.comments) })
            ] })
          ] }),
          criterion.ratings.length > 0 && /* @__PURE__ */ a3("details", { children: [
            /* @__PURE__ */ a3("summary", { class: "g-ratings-summary", children: "Rating descriptions" }),
            /* @__PURE__ */ a3("ul", { class: "g-rubric-ratings", children: criterion.ratings.map((rating, i3) => /* @__PURE__ */ a3("li", { children: [
              /* @__PURE__ */ a3("span", { children: plain2(rating.description) || "No description provided" }),
              /* @__PURE__ */ a3("strong", { children: [
                rating.points,
                " pts"
              ] })
            ] }, rating.id ?? i3)) })
          ] })
        ] }, criterion.id);
      }) }),
      comments.length > 0 && /* @__PURE__ */ a3("div", { class: "g-feedback-comments", children: [
        /* @__PURE__ */ a3("h3", { children: "Submission comments" }),
        comments.map((comment, i3) => /* @__PURE__ */ a3("div", { class: "g-instructor-comment", children: [
          /* @__PURE__ */ a3("div", { class: "g-comment-author", children: [
            /* @__PURE__ */ a3("strong", { children: comment.authorName || "Canvas user" }),
            comment.createdAt && Number.isFinite(Date.parse(comment.createdAt)) && /* @__PURE__ */ a3("time", { dateTime: comment.createdAt, children: new Date(comment.createdAt).toLocaleDateString(void 0, { month: "short", day: "numeric" }) })
          ] }),
          /* @__PURE__ */ a3("p", { children: plain2(comment.comment) })
        ] }, i3))
      ] })
    ] }) });
  }
  function Workspace({ snapshot, loading, error, onRefresh, initialCourseId, initialAssignmentId, progress, preview = false }) {
    const [tab, setTab] = d2("overview");
    const [assistantOpened, setAssistantOpened] = d2(false);
    A(() => {
      if (tab === "assistant") setAssistantOpened(true);
    }, [tab]);
    const assistantSnapshot = T2(null);
    if (snapshot) assistantSnapshot.current = snapshot;
    else if (!loading) assistantSnapshot.current = null;
    const [minimized, setMinimized] = d2(false);
    const [wide, setWide] = d2(false);
    A(() => {
      const toggle = () => setMinimized((previous) => !previous);
      window.addEventListener("gradient:toggle", toggle);
      return () => window.removeEventListener("gradient:toggle", toggle);
    }, []);
    const [selectedCourseId, setSelectedCourseId] = d2(initialCourseId ?? "");
    const [query, setQuery] = d2("");
    const [resourceQuery, setResourceQuery] = d2("");
    const [filter, setFilter] = d2("todo");
    const [resourceFilter, setResourceFilter] = d2("all");
    const [assignmentId, setAssignmentId] = d2("");
    const [whatIf, setWhatIf] = d2(85);
    const [hours, setHours] = d2(8);
    const [planning, setPlanning] = d2(false);
    const [plan, setPlan] = d2(null);
    const [planError, setPlanError] = d2("");
    const [credits, setCredits] = d2({});
    const [creditError, setCreditError] = d2("");
    const courses = snapshot?.courses ?? [];
    const active = courses.find((c3) => c3.id === selectedCourseId) ?? courses[0];
    A(() => {
      if (initialCourseId) setSelectedCourseId(initialCourseId);
    }, [initialCourseId]);
    A(() => {
      if (initialAssignmentId) {
        setAssignmentId(initialAssignmentId);
        setTab("coursework");
      }
    }, [initialAssignmentId]);
    A(() => {
      let mounted = true;
      loadOptions().then((o4) => {
        if (mounted) setCredits(o4.courseCreditHours);
      }).catch(() => {
      });
      return () => {
        mounted = false;
      };
    }, []);
    A(() => {
      setPlan(null);
      setPlanError("");
    }, [snapshot, selectedCourseId, credits, hours]);
    const tasks = w2(() => courses.flatMap((course) => course.assignments.map((assignment) => ({ course, assignment }))).sort((a4, b2) => dueDate(a4.assignment) - dueDate(b2.assignment)), [snapshot]);
    const upcoming = tasks.filter((t3) => pending(t3.assignment) && dueDate(t3.assignment) >= Date.now());
    const dueThisWeek = upcoming.filter((t3) => dueDate(t3.assignment) < Date.now() + 7 * 864e5);
    const submittedCount = tasks.filter((t3) => t3.assignment.submission?.workflowState === "submitted" || t3.assignment.submission?.workflowState === "pending_review").length;
    const activeTasks = tasks.filter((t3) => t3.course.id === active?.id && t3.assignment.name.toLowerCase().includes(query.toLowerCase())).filter((t3) => filter === "all" || filter === "todo" && pending(t3.assignment) || filter === "submitted" && ["submitted", "pending_review"].includes(t3.assignment.submission?.workflowState ?? "") || filter === "graded" && (t3.assignment.submission?.score != null || t3.assignment.submission?.workflowState === "graded"));
    const simAssignment = active?.assignments.find((a4) => a4.id === assignmentId) ?? active?.assignments.find((a4) => pending(a4) && a4.pointsPossible > 0) ?? active?.assignments.find((a4) => a4.pointsPossible > 0);
    const simulated = w2(() => {
      if (!active || !simAssignment) return null;
      const otherSubmissions = active.input.submissions.filter((s3) => s3.assignmentId !== simAssignment.id);
      return currentGrade({ ...active.input, submissions: [...otherSubmissions, { assignmentId: simAssignment.id, score: simAssignment.pointsPossible * whatIf / 100, posted: true, excused: false, missing: false, late: false, workflowState: "graded" }] }).percentage;
    }, [active, simAssignment, whatIf]);
    const computed = w2(() => active ? currentGrade(active.input).percentage : null, [active]);
    const gradeMatches = active?.currentScore != null && computed != null && Math.abs(active.currentScore - computed) <= 0.01;
    const allIssues = [...snapshot?.issues ?? [], ...courses.flatMap((c3) => c3.issues)];
    const changeTab = (next) => {
      setTab(next);
    };
    const selectCourse = (id) => {
      setSelectedCourseId(id);
      setAssignmentId("");
      setPlan(null);
    };
    const buildPlan = () => {
      if (!active || planning) return;
      setPlanning(true);
      setPlanError("");
      setTimeout(() => {
        try {
          const input = { ...active.input, studyEligibleAssignmentIds: active.assignments.filter(pending).map((assignment) => assignment.id), course: { ...active.input.course, creditHours: credits[active.id] ?? 3 } };
          const result = optimizeEffort([input], { capacityHours: hours, stepSizeHours: 0.5, numSamples: 100, seed: 42, currentTime: /* @__PURE__ */ new Date(), protectMastery: true, masteryFloorHours: 0.5, isRobustnessRun: true });
          setPlan(result);
        } catch (e3) {
          setPlanError(e3 instanceof Error ? e3.message : "The study plan could not be calculated.");
        } finally {
          setPlanning(false);
        }
      }, 30);
    };
    const saveCredit = (id, n2) => {
      if (!Number.isFinite(n2) || n2 <= 0 || n2 > 30) return;
      const next = { ...credits, [id]: n2 };
      setCredits(next);
      saveOptions({ courseCreditHours: next }).catch(() => setCreditError("Your credit hours could not be saved. They will apply for this session."));
    };
    const coursePicker = active ? /* @__PURE__ */ a3("div", { class: "g-course-menu", children: [
      /* @__PURE__ */ a3("select", { class: "g-select", "aria-label": "Choose a course", value: active.id, onChange: (e3) => selectCourse(e3.currentTarget.value), children: courses.map((c3) => /* @__PURE__ */ a3("option", { value: c3.id, children: [
        c3.code,
        " \xB7 ",
        c3.name
      ] }, c3.id)) }),
      /* @__PURE__ */ a3("a", { class: "g-icon-btn", href: safeLink(active.url), title: "Open course in Canvas", "aria-label": "Open course in Canvas", children: /* @__PURE__ */ a3(Icon, { name: "external", size: 17 }) })
    ] }) : null;
    return /* @__PURE__ */ a3(M, { children: [
      /* @__PURE__ */ a3("style", { children: WORKSPACE_STYLES + ASSISTANT_ENTRY_STYLES }),
      minimized ? /* @__PURE__ */ a3("button", { id: "gradient-launcher", class: "g-launcher", "aria-label": "Open GRADIENT", onClick: () => setMinimized(false), children: [
        /* @__PURE__ */ a3(Icon, { name: "chart", size: 21 }),
        "GRADIENT",
        /* @__PURE__ */ a3(Icon, { name: "chevron", size: 16 })
      ] }) : /* @__PURE__ */ a3("aside", { id: "gradient-workspace", class: `gw ${wide ? "wide" : ""}`, "aria-label": "GRADIENT Canvas workspace", children: [
        /* @__PURE__ */ a3("header", { class: "g-header", children: [
          /* @__PURE__ */ a3("div", { class: "g-brand", children: [
            /* @__PURE__ */ a3("div", { class: "g-logo", children: /* @__PURE__ */ a3(Icon, { name: "chart", size: 22 }) }),
            /* @__PURE__ */ a3("div", { children: [
              /* @__PURE__ */ a3("div", { class: "g-wordmark", children: [
                "gradient",
                /* @__PURE__ */ a3("span", { style: { color: "#2855e8" }, children: "." })
              ] }),
              /* @__PURE__ */ a3("div", { class: "g-brand-sub", children: "Your academic advantage" })
            ] })
          ] }),
          /* @__PURE__ */ a3("button", { class: "g-icon-btn g-hide-mobile", "aria-label": wide ? "Compact workspace" : "Expand workspace", title: wide ? "Compact workspace" : "Expand workspace", onClick: () => setWide(!wide), children: /* @__PURE__ */ a3(Icon, { name: "expand", size: 16 }) }),
          /* @__PURE__ */ a3("button", { class: "g-icon-btn", "aria-label": "Refresh Canvas data", title: "Refresh Canvas data", disabled: loading, onClick: onRefresh, children: /* @__PURE__ */ a3(Icon, { name: "refresh", size: 16, className: loading ? "g-spinner" : "" }) }),
          /* @__PURE__ */ a3("button", { class: "g-icon-btn", "aria-label": "Minimize GRADIENT", title: "Minimize GRADIENT", onClick: () => setMinimized(true), children: /* @__PURE__ */ a3(Icon, { name: "collapse", size: 17 }) })
        ] }),
        /* @__PURE__ */ a3("div", { class: "g-status", children: [
          /* @__PURE__ */ a3("span", { class: "g-live", children: [
            /* @__PURE__ */ a3("i", { class: `g-dot ${preview ? "g-demo-dot" : ""}` }),
            preview ? "Demo preview" : loading && !snapshot ? "Connecting to Canvas" : error && !snapshot ? "Connection needed" : "Canvas connected"
          ] }),
          /* @__PURE__ */ a3("span", { children: snapshot?.syncedAt ? `Synced ${new Date(snapshot.syncedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}` : "Your account. Your workspace." })
        ] }),
        /* @__PURE__ */ a3("nav", { class: "g-nav", role: "tablist", "aria-label": "Workspace views", children: [{ id: "overview", label: "Overview", icon: "grid" }, { id: "assistant", label: "Assistant", icon: "spark" }, { id: "coursework", label: "Coursework", icon: "book" }, { id: "resources", label: "Resources", icon: "folder" }, { id: "settings", label: "Settings", icon: "settings" }].map((item) => /* @__PURE__ */ a3("button", { id: `g-tab-${item.id}`, class: `g-tab ${tab === item.id ? "active" : ""}`, role: "tab", "aria-selected": tab === item.id, "aria-controls": "gradient-tab-content", onClick: () => changeTab(item.id), children: [
          /* @__PURE__ */ a3(Icon, { name: item.icon, size: 15 }),
          item.label
        ] }, item.id)) }),
        /* @__PURE__ */ a3("div", { id: "gradient-tab-content", class: "g-body", role: "tabpanel", "aria-labelledby": `g-tab-${tab}`, children: [
          loading && /* @__PURE__ */ a3("div", { class: "g-sync-loading", role: "status", children: [
            /* @__PURE__ */ a3(Icon, { name: "refresh", size: 14, className: "g-spinner" }),
            progress || "Syncing your Canvas account\u2026"
          ] }),
          error && /* @__PURE__ */ a3("div", { class: "g-notice", role: "alert", style: { marginBottom: "16px" }, children: [
            /* @__PURE__ */ a3(Icon, { name: "alert", size: 16 }),
            /* @__PURE__ */ a3("div", { children: [
              error,
              /* @__PURE__ */ a3("button", { class: "g-link-btn", onClick: onRefresh, disabled: loading, children: [
                "Try again ",
                /* @__PURE__ */ a3(Icon, { name: "arrow", size: 12 })
              ] })
            ] })
          ] }),
          !snapshot && loading ? /* @__PURE__ */ a3("div", { class: "g-stack", children: [
            /* @__PURE__ */ a3("div", { children: [
              /* @__PURE__ */ a3("div", { class: "g-eyebrow", children: "Everything, in one place" }),
              /* @__PURE__ */ a3("h1", { class: "g-title", children: [
                "Making room",
                /* @__PURE__ */ a3("br", {}),
                "for your ",
                /* @__PURE__ */ a3("span", { class: "g-accent", children: "next win." })
              ] }),
              /* @__PURE__ */ a3("p", { class: "g-subtitle", children: "Connecting your courses, deadlines, and materials." })
            ] }),
            /* @__PURE__ */ a3("div", { class: "g-skeleton" }),
            /* @__PURE__ */ a3("div", { class: "g-skeleton" }),
            /* @__PURE__ */ a3("div", { class: "g-skeleton" })
          ] }) : !snapshot ? /* @__PURE__ */ a3(Empty, { title: "Let's connect your Canvas", children: "Open Canvas and sign in, then refresh GRADIENT to see your courses here." }) : /* @__PURE__ */ a3(M, { children: [
            tab === "overview" && /* @__PURE__ */ a3("div", { class: "g-stack", children: [
              /* @__PURE__ */ a3("div", { class: "g-greeting", children: [
                /* @__PURE__ */ a3("div", { children: [
                  /* @__PURE__ */ a3("div", { class: "g-eyebrow", children: "Your semester, in focus" }),
                  /* @__PURE__ */ a3("h1", { class: "g-title", children: [
                    "Hey ",
                    snapshot.user.shortName?.split(" ")[0] || snapshot.user.name.split(" ")[0],
                    ",",
                    /* @__PURE__ */ a3("br", {}),
                    "let's make ",
                    /* @__PURE__ */ a3("span", { class: "g-accent", children: "progress." })
                  ] }),
                  /* @__PURE__ */ a3("p", { class: "g-subtitle", children: "A little clarity. A better plan. All inside Canvas." })
                ] }),
                /* @__PURE__ */ a3("span", { class: "g-date", children: (/* @__PURE__ */ new Date()).toLocaleDateString(void 0, { month: "short", day: "numeric" }) })
              ] }),
              /* @__PURE__ */ a3("button", { class: "g-assistant-entry", onClick: () => setTab("assistant"), children: [
                /* @__PURE__ */ a3("span", { class: "g-assistant-entry-icon", children: /* @__PURE__ */ a3(Icon, { name: "spark", size: 22 }) }),
                /* @__PURE__ */ a3("span", { children: [
                  /* @__PURE__ */ a3("strong", { children: "Your local AI, ready for the mission." }),
                  /* @__PURE__ */ a3("small", { children: "Read the brief. Research the web. Build your study packet." })
                ] }),
                /* @__PURE__ */ a3(Icon, { name: "arrow", size: 18 })
              ] }),
              /* @__PURE__ */ a3("div", { class: "g-metrics", children: [
                /* @__PURE__ */ a3("div", { class: "g-metric blue", children: [
                  /* @__PURE__ */ a3("strong", { children: courses.length.toString().padStart(2, "0") }),
                  /* @__PURE__ */ a3("small", { children: "Active courses" })
                ] }),
                /* @__PURE__ */ a3("div", { class: "g-metric peach", children: [
                  /* @__PURE__ */ a3("strong", { children: dueThisWeek.length.toString().padStart(2, "0") }),
                  /* @__PURE__ */ a3("small", { children: "Due this week" })
                ] }),
                /* @__PURE__ */ a3("div", { class: "g-metric", children: [
                  /* @__PURE__ */ a3("strong", { children: submittedCount.toString().padStart(2, "0") }),
                  /* @__PURE__ */ a3("small", { children: "Awaiting grades" })
                ] })
              ] }),
              /* @__PURE__ */ a3("div", { class: "g-overview-grid", children: [
                /* @__PURE__ */ a3("section", { children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("h2", { children: "Your courses" }),
                    /* @__PURE__ */ a3("span", { class: "g-label-count", children: "FROM CANVAS" })
                  ] }),
                  /* @__PURE__ */ a3("div", { class: "g-course-list", children: [
                    courses.map((course, i3) => {
                      const color = colors[i3 % colors.length];
                      return /* @__PURE__ */ a3("button", { class: "g-course", style: { "--tint": color.tint, "--ink": color.ink }, onClick: () => {
                        selectCourse(course.id);
                        setTab("coursework");
                      }, children: [
                        /* @__PURE__ */ a3("div", { class: "g-course-symbol", children: course.code.replace(/[^A-Za-z]/g, "").slice(0, 3).toUpperCase() }),
                        /* @__PURE__ */ a3("div", { class: "g-course-info", children: [
                          /* @__PURE__ */ a3("strong", { children: course.name }),
                          /* @__PURE__ */ a3("small", { children: [
                            course.assignments.filter(pending).length,
                            " to do \xB7 ",
                            course.resources.length,
                            " resources"
                          ] }),
                          /* @__PURE__ */ a3("div", { class: "g-track", children: /* @__PURE__ */ a3("span", { style: { width: `${Math.min(100, Math.max(0, course.currentScore ?? 0))}%` } }) })
                        ] }),
                        /* @__PURE__ */ a3("div", { class: "g-course-score g-bold-number", children: [
                          score(course.currentScore),
                          /* @__PURE__ */ a3("small", { children: "current grade" })
                        ] })
                      ] }, course.id);
                    }),
                    !courses.length && /* @__PURE__ */ a3(Empty, { title: "No student courses found", children: "Your active student enrollments will appear here when Canvas makes them available." })
                  ] })
                ] }),
                /* @__PURE__ */ a3("section", { class: "g-card", children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("h2", { children: "Up next" }),
                    /* @__PURE__ */ a3("button", { class: "g-link-btn", onClick: () => setTab("coursework"), children: [
                      "View all ",
                      /* @__PURE__ */ a3(Icon, { name: "arrow", size: 13 })
                    ] })
                  ] }),
                  upcoming.length ? upcoming.slice(0, 4).map((task) => /* @__PURE__ */ a3(TaskRow, { task, onSelect: () => {
                    selectCourse(task.course.id);
                    setAssignmentId(task.assignment.id);
                    setTab("coursework");
                  } }, `${task.course.id}-${task.assignment.id}`)) : /* @__PURE__ */ a3(Empty, { title: "A little breathing room", children: "No upcoming unsubmitted assignments with deadlines were found." })
                ] }),
                /* @__PURE__ */ a3("section", { class: "g-card g-plan", children: [
                  /* @__PURE__ */ a3("div", { class: "g-eyebrow", style: { color: "#2855e8", marginBottom: "9px" }, children: "Make time for what matters" }),
                  /* @__PURE__ */ a3("h2", { children: [
                    "A smarter week",
                    /* @__PURE__ */ a3("br", {}),
                    "starts here."
                  ] }),
                  /* @__PURE__ */ a3("p", { class: "g-subtitle", children: "Turn your available study hours into a focused plan for your course." }),
                  /* @__PURE__ */ a3("div", { class: "g-gradient-art", children: [
                    /* @__PURE__ */ a3("i", {}),
                    /* @__PURE__ */ a3("i", {}),
                    /* @__PURE__ */ a3("i", {}),
                    /* @__PURE__ */ a3("i", {}),
                    /* @__PURE__ */ a3("i", {})
                  ] }),
                  /* @__PURE__ */ a3("button", { class: "g-primary", style: { marginTop: "17px", width: "fit-content" }, onClick: () => {
                    setTab("coursework");
                  }, children: [
                    "Plan my study time ",
                    /* @__PURE__ */ a3(Icon, { name: "arrow", size: 14 })
                  ] })
                ] })
              ] }),
              allIssues.length > 0 && /* @__PURE__ */ a3("div", { class: "g-bottom-note", children: [
                /* @__PURE__ */ a3(Icon, { name: "shield", size: 13 }),
                /* @__PURE__ */ a3("span", { children: [
                  "Some sections need attention. ",
                  /* @__PURE__ */ a3("button", { class: "g-link-btn", style: { display: "inline", fontSize: "10px" }, onClick: () => setTab("settings"), children: "View sync details" })
                ] })
              ] })
            ] }),
            tab === "coursework" && /* @__PURE__ */ a3("div", { class: "g-stack", children: [
              /* @__PURE__ */ a3("div", { children: [
                /* @__PURE__ */ a3("div", { class: "g-eyebrow", children: "One thing at a time" }),
                /* @__PURE__ */ a3("h1", { class: "g-title", children: [
                  "Your next ",
                  /* @__PURE__ */ a3("span", { class: "g-accent", children: "move." })
                ] }),
                /* @__PURE__ */ a3("p", { class: "g-subtitle", children: "The work ahead, the grade behind it, and a plan to get there." })
              ] }),
              coursePicker,
              active ? /* @__PURE__ */ a3(M, { children: [
                /* @__PURE__ */ a3("div", { class: "g-grade-card", children: [
                  /* @__PURE__ */ a3("div", { class: "g-grade-ring", style: { "--grade": Math.min(100, Math.max(0, active.currentScore ?? 0)) }, children: /* @__PURE__ */ a3("div", { children: [
                    /* @__PURE__ */ a3("strong", { children: score(active.currentScore) }),
                    /* @__PURE__ */ a3("small", { children: "Current grade" })
                  ] }) }),
                  /* @__PURE__ */ a3("div", { class: "g-grade-info", children: [
                    /* @__PURE__ */ a3("h2", { children: active.code }),
                    /* @__PURE__ */ a3("p", { children: [
                      active.input.course.applyGroupWeights ? "Weighted assignment groups" : "Total points grading",
                      /* @__PURE__ */ a3("br", {}),
                      active.assignments.length,
                      " assignments in Canvas"
                    ] }),
                    gradeMatches ? /* @__PURE__ */ a3("span", { children: [
                      /* @__PURE__ */ a3(Icon, { name: "check", size: 11 }),
                      "Grade model matches Canvas"
                    ] }) : /* @__PURE__ */ a3("span", { children: [
                      /* @__PURE__ */ a3(Icon, { name: "shield", size: 11 }),
                      "Official Canvas total"
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ a3("section", { children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("h2", { children: "Coursework" }),
                    /* @__PURE__ */ a3("button", { class: "g-link-btn", onClick: () => exportCalendar(tasks.filter((t3) => t3.course.id === active.id && pending(t3.assignment) && dueDate(t3.assignment) >= Date.now()), snapshot.origin), title: "Download upcoming assignment deadlines", children: [
                      /* @__PURE__ */ a3(Icon, { name: "download", size: 13 }),
                      "Calendar"
                    ] })
                  ] }),
                  /* @__PURE__ */ a3("div", { class: "g-search", children: [
                    /* @__PURE__ */ a3(Icon, { name: "search", size: 15 }),
                    /* @__PURE__ */ a3("input", { "aria-label": "Search coursework", placeholder: "Find an assignment\u2026", value: query, onInput: (e3) => setQuery(e3.currentTarget.value) })
                  ] }),
                  /* @__PURE__ */ a3("div", { class: "g-chips", style: { margin: "10px 0 14px" }, children: [{ value: "todo", label: "To do" }, { value: "submitted", label: "Submitted" }, { value: "graded", label: "Graded" }, { value: "all", label: "All work" }].map((f4) => /* @__PURE__ */ a3("button", { class: `g-chip ${filter === f4.value ? "active" : ""}`, "aria-pressed": filter === f4.value, onClick: () => setFilter(f4.value), children: f4.label }, f4.value)) }),
                  /* @__PURE__ */ a3("div", { class: "g-card", children: activeTasks.length ? activeTasks.map((task) => /* @__PURE__ */ a3(TaskRow, { task }, task.assignment.id)) : /* @__PURE__ */ a3(Empty, { title: "Nothing in this view", children: "Try a different filter or search to find your coursework." }) })
                ] }),
                simAssignment && /* @__PURE__ */ a3("section", { class: "g-card", children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("h2", { children: "What if you scored\u2026" }),
                    /* @__PURE__ */ a3("span", { class: "g-label-count", children: "SIMULATOR" })
                  ] }),
                  /* @__PURE__ */ a3("label", { class: "g-field-label", for: "g-whatif-assignment", children: "Assignment" }),
                  /* @__PURE__ */ a3("select", { id: "g-whatif-assignment", "aria-label": "Assignment to simulate", class: "g-select", value: simAssignment.id, onChange: (e3) => setAssignmentId(e3.currentTarget.value), children: active.assignments.filter((a4) => a4.pointsPossible > 0).map((a4) => /* @__PURE__ */ a3("option", { value: a4.id, children: a4.name }, a4.id)) }),
                  /* @__PURE__ */ a3("div", { class: "g-title-row", style: { marginTop: "16px" }, children: [
                    /* @__PURE__ */ a3("span", { class: "g-small", children: "Hypothetical assignment score" }),
                    /* @__PURE__ */ a3("strong", { style: { fontSize: "24px", color: "#2855e8", letterSpacing: "-.8px" }, children: [
                      whatIf,
                      "%"
                    ] })
                  ] }),
                  /* @__PURE__ */ a3("input", { class: "g-range", "aria-label": "What-if score percentage", type: "range", min: "0", max: "100", step: "1", value: whatIf, onInput: (e3) => setWhatIf(Number(e3.currentTarget.value)) }),
                  /* @__PURE__ */ a3("div", { class: "g-legend", children: [
                    /* @__PURE__ */ a3("span", { children: "0%" }),
                    /* @__PURE__ */ a3("span", { children: "50%" }),
                    /* @__PURE__ */ a3("span", { children: "100%" })
                  ] }),
                  /* @__PURE__ */ a3("div", { class: "g-whatif-result", children: [
                    /* @__PURE__ */ a3("div", { children: [
                      /* @__PURE__ */ a3("strong", { children: score(computed) }),
                      /* @__PURE__ */ a3("small", { children: "Model current grade" })
                    ] }),
                    /* @__PURE__ */ a3("div", { style: { background: "#e8f5ed" }, children: [
                      /* @__PURE__ */ a3("strong", { style: { color: "#187352" }, children: score(simulated) }),
                      /* @__PURE__ */ a3("small", { children: "With this assignment score" })
                    ] })
                  ] }),
                  /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "10px" }, children: "A local calculation using visible scores and Canvas group rules. Hidden grades and extra-credit rules may differ. Nothing is saved to Canvas." }),
                  plain2(simAssignment.descriptionHtml) && /* @__PURE__ */ a3("details", { style: { marginTop: "13px" }, children: [
                    /* @__PURE__ */ a3("summary", { style: { cursor: "pointer", fontSize: "11px", fontWeight: 700 }, children: "Assignment brief" }),
                    /* @__PURE__ */ a3("p", { class: "g-assignment-description", children: plain2(simAssignment.descriptionHtml) }),
                    /* @__PURE__ */ a3("a", { class: "g-course-link", href: safeLink(simAssignment.htmlUrl), style: { marginTop: "10px" }, children: [
                      "Open assignment in Canvas ",
                      /* @__PURE__ */ a3(Icon, { name: "arrow", size: 12 })
                    ] })
                  ] })
                ] }),
                simAssignment && /* @__PURE__ */ a3(AssignmentFeedback, { assignment: simAssignment }),
                /* @__PURE__ */ a3("section", { class: "g-card g-plan", children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("div", { children: [
                      /* @__PURE__ */ a3("div", { class: "g-eyebrow", style: { color: "#2855e8", marginBottom: "7px" }, children: "A plan with purpose" }),
                      /* @__PURE__ */ a3("h2", { children: "Make your hours count." })
                    ] }),
                    /* @__PURE__ */ a3(Icon, { name: "bolt", size: 26 })
                  ] }),
                  /* @__PURE__ */ a3("p", { class: "g-subtitle", style: { maxWidth: "100%" }, children: [
                    "A suggested allocation for ",
                    active.code,
                    ", based on upcoming work and the grade model."
                  ] }),
                  /* @__PURE__ */ a3("div", { class: "g-plan-controls", children: [
                    /* @__PURE__ */ a3("label", { class: "g-hours", children: [
                      /* @__PURE__ */ a3("input", { "aria-label": "Study hours available", type: "number", min: ".5", max: "30", step: ".5", value: hours, onChange: (e3) => setHours(Math.max(0.5, Math.min(30, Number(e3.currentTarget.value) || 0.5))) }),
                      "hours"
                    ] }),
                    /* @__PURE__ */ a3("button", { class: "g-primary", onClick: buildPlan, disabled: planning, children: planning ? /* @__PURE__ */ a3(M, { children: [
                      /* @__PURE__ */ a3(Icon, { name: "refresh", size: 14, className: "g-spinner" }),
                      "Planning\u2026"
                    ] }) : /* @__PURE__ */ a3(M, { children: [
                      "Build my study plan ",
                      /* @__PURE__ */ a3(Icon, { name: "arrow", size: 13 })
                    ] }) })
                  ] }),
                  planError && /* @__PURE__ */ a3("p", { class: "g-notice", role: "alert", style: { marginTop: "12px" }, children: planError }),
                  plan && /* @__PURE__ */ a3("div", { class: "g-plan-result", "aria-live": "polite", children: [
                    plan.recommendations.length ? plan.recommendations.map((rec) => /* @__PURE__ */ a3("div", { class: "g-task", children: [
                      /* @__PURE__ */ a3("div", { class: "g-task-marker", children: /* @__PURE__ */ a3(Icon, { name: "clock", size: 14 }) }),
                      /* @__PURE__ */ a3("div", { class: "g-task-main", children: [
                        /* @__PURE__ */ a3("strong", { children: rec.assignmentName }),
                        /* @__PURE__ */ a3("p", { class: "g-small", children: "Suggested focus block" })
                      ] }),
                      /* @__PURE__ */ a3("span", { class: "g-due normal", children: [
                        rec.allocatedHours.toFixed(1),
                        " hrs"
                      ] })
                    ] }, rec.assignmentId)) : /* @__PURE__ */ a3("p", { class: "g-small", children: "No eligible upcoming work to allocate. You may be all caught up." }),
                    /* @__PURE__ */ a3("p", { class: "g-small", style: { marginTop: "12px" }, children: [
                      plan.allocatedHours.toFixed(1),
                      " of ",
                      hours,
                      " hours allocated. Effort curves are assumptions, not a promise of a score or grade."
                    ] })
                  ] })
                ] })
              ] }) : /* @__PURE__ */ a3(Empty, { title: "No courses to show", children: "Active student courses will appear after a successful sync." })
            ] }),
            tab === "resources" && /* @__PURE__ */ a3("div", { class: "g-stack", children: [
              /* @__PURE__ */ a3("div", { children: [
                /* @__PURE__ */ a3("div", { class: "g-eyebrow", children: "Less searching. More learning." }),
                /* @__PURE__ */ a3("h1", { class: "g-title", children: [
                  "Find your ",
                  /* @__PURE__ */ a3("span", { class: "g-accent", children: "flow." })
                ] }),
                /* @__PURE__ */ a3("p", { class: "g-subtitle", children: "Your course materials and updates, one click away." })
              ] }),
              coursePicker,
              active && /* @__PURE__ */ a3(M, { children: [
                /* @__PURE__ */ a3("div", { class: "g-search", children: [
                  /* @__PURE__ */ a3(Icon, { name: "search", size: 15 }),
                  /* @__PURE__ */ a3("input", { "aria-label": "Search resources", placeholder: "Search your course materials\u2026", value: resourceQuery, onInput: (e3) => setResourceQuery(e3.currentTarget.value) })
                ] }),
                /* @__PURE__ */ a3("div", { class: "g-chips", children: [{ id: "all", label: "Everything" }, { id: "module", label: "Modules" }, { id: "page", label: "Pages" }, { id: "file", label: "Files" }].map((f4) => /* @__PURE__ */ a3("button", { class: `g-chip ${resourceFilter === f4.id ? "active" : ""}`, "aria-pressed": resourceFilter === f4.id, onClick: () => setResourceFilter(f4.id), children: f4.label })) }),
                /* @__PURE__ */ a3("section", { class: "g-card", children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("h2", { children: "Course library" }),
                    /* @__PURE__ */ a3("span", { class: "g-label-count", children: [
                      active.resources.length,
                      " ITEMS"
                    ] })
                  ] }),
                  active.resources.filter((r3) => (resourceFilter === "all" || r3.type === resourceFilter) && r3.title.toLowerCase().includes(resourceQuery.toLowerCase())).map((r3) => /* @__PURE__ */ a3("a", { class: "g-resource", href: safeLink(r3.url), children: [
                    /* @__PURE__ */ a3("span", { class: "g-resource-icon", children: /* @__PURE__ */ a3(Icon, { name: r3.type === "module" ? "layers" : r3.type === "file" ? "file" : "book", size: 17 }) }),
                    /* @__PURE__ */ a3("span", { children: [
                      /* @__PURE__ */ a3("strong", { children: r3.title }),
                      /* @__PURE__ */ a3("small", { children: r3.type })
                    ] }),
                    /* @__PURE__ */ a3(Icon, { name: "chevron", size: 14 })
                  ] }, `${r3.type}-${r3.id}`)),
                  !active.resources.filter((r3) => (resourceFilter === "all" || r3.type === resourceFilter) && r3.title.toLowerCase().includes(resourceQuery.toLowerCase())).length && /* @__PURE__ */ a3(Empty, { title: "No matching materials", children: "Try another search. Some materials may only be available through your course's Modules page." })
                ] }),
                /* @__PURE__ */ a3("section", { class: "g-card", children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("h2", { children: "Course updates" }),
                    /* @__PURE__ */ a3(Icon, { name: "calendar", size: 16 })
                  ] }),
                  active.announcements.length ? active.announcements.slice(0, 10).map((a4) => /* @__PURE__ */ a3("details", { class: "g-announcement", children: [
                    /* @__PURE__ */ a3("summary", { children: a4.title }),
                    /* @__PURE__ */ a3("p", { children: plain2(a4.bodyHtml) }),
                    a4.postedAt && /* @__PURE__ */ a3("div", { class: "g-small", style: { marginTop: "6px" }, children: new Date(a4.postedAt).toLocaleDateString() }),
                    /* @__PURE__ */ a3("a", { href: safeLink(a4.url), children: "Read in Canvas \u2192" })
                  ] }, a4.id)) : /* @__PURE__ */ a3("p", { class: "g-small", children: "No announcements returned for this course." })
                ] }),
                active.syllabusHtml && /* @__PURE__ */ a3("section", { class: "g-card", children: [
                  /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                    /* @__PURE__ */ a3("h2", { children: "Syllabus" }),
                    /* @__PURE__ */ a3("a", { class: "g-course-link", href: `${safeLink(active.url)}/assignments/syllabus`, children: [
                      "Open ",
                      /* @__PURE__ */ a3(Icon, { name: "arrow", size: 12 })
                    ] })
                  ] }),
                  /* @__PURE__ */ a3("p", { class: "g-syllabus", children: plain2(active.syllabusHtml) })
                ] }),
                /* @__PURE__ */ a3(MaterialAccess, { courses: [active], compact: true }),
                active.issues.length > 0 && /* @__PURE__ */ a3("div", { class: "g-notice", children: [
                  /* @__PURE__ */ a3(Icon, { name: "shield", size: 16 }),
                  /* @__PURE__ */ a3("span", { children: "Some sections could not finish syncing. Available materials are listed above; see sync details in Settings." })
                ] })
              ] })
            ] }),
            tab === "settings" && /* @__PURE__ */ a3("div", { class: "g-stack", children: [
              /* @__PURE__ */ a3("div", { children: [
                /* @__PURE__ */ a3("div", { class: "g-eyebrow", children: "Built around you" }),
                /* @__PURE__ */ a3("h1", { class: "g-title", children: [
                  "Your ",
                  /* @__PURE__ */ a3("span", { class: "g-accent", children: "workspace." })
                ] }),
                /* @__PURE__ */ a3("p", { class: "g-subtitle", children: "A clear view of your connection and preferences." })
              ] }),
              /* @__PURE__ */ a3("section", { class: "g-card", children: [
                /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                  /* @__PURE__ */ a3("h2", { children: "Connected account" }),
                  /* @__PURE__ */ a3("div", { class: "g-user", children: initials(snapshot.user.name) })
                ] }),
                /* @__PURE__ */ a3("div", { class: "g-setting-row", children: [
                  /* @__PURE__ */ a3("span", { children: "Signed in as" }),
                  /* @__PURE__ */ a3("strong", { children: snapshot.user.name })
                ] }),
                /* @__PURE__ */ a3("div", { class: "g-setting-row", children: [
                  /* @__PURE__ */ a3("span", { children: "Canvas" }),
                  /* @__PURE__ */ a3("strong", { children: new URL(snapshot.origin).hostname })
                ] }),
                /* @__PURE__ */ a3("div", { class: "g-setting-row", children: [
                  /* @__PURE__ */ a3("span", { children: "Last updated" }),
                  /* @__PURE__ */ a3("strong", { children: new Date(snapshot.syncedAt).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) })
                ] }),
                /* @__PURE__ */ a3("div", { class: "g-setting-row", children: [
                  /* @__PURE__ */ a3("span", { children: "Data source" }),
                  /* @__PURE__ */ a3("strong", { children: preview ? "Sample preview data" : "Your signed-in Canvas session" })
                ] }),
                /* @__PURE__ */ a3("button", { class: "g-secondary", style: { marginTop: "14px", width: "100%" }, onClick: onRefresh, disabled: loading, children: [
                  /* @__PURE__ */ a3(Icon, { name: "refresh", size: 14 }),
                  "Refresh now"
                ] })
              ] }),
              /* @__PURE__ */ a3("div", { class: "g-notice success", children: [
                /* @__PURE__ */ a3(Icon, { name: "shield", size: 18 }),
                /* @__PURE__ */ a3("span", { children: [
                  /* @__PURE__ */ a3("strong", { children: "Your account stays yours." }),
                  /* @__PURE__ */ a3("br", {}),
                  "GRADIENT reads your student courses in this tab. When you ask the assistant, selected coursework goes to your local AI service. Web research sends topic searches to public search services. Canvas access stays read-only."
                ] })
              ] }),
              /* @__PURE__ */ a3("section", { class: "g-card g-credits", children: [
                /* @__PURE__ */ a3("div", { class: "g-section-head", children: [
                  /* @__PURE__ */ a3("h2", { children: "Course credit hours" }),
                  /* @__PURE__ */ a3(Icon, { name: "book", size: 16 })
                ] }),
                /* @__PURE__ */ a3("p", { class: "g-small", style: { marginBottom: "10px" }, children: "Canvas doesn't provide credit hours. Set them here for planning; each course defaults to 3." }),
                courses.map((c3) => /* @__PURE__ */ a3("label", { children: [
                  /* @__PURE__ */ a3("span", { children: c3.code }),
                  /* @__PURE__ */ a3("input", { class: "g-credit", "aria-label": `Credit hours for ${c3.code}`, type: "number", min: ".5", max: "30", step: ".5", value: credits[c3.id] ?? 3, onChange: (e3) => saveCredit(c3.id, Number(e3.currentTarget.value)) })
                ] }, c3.id)),
                creditError && /* @__PURE__ */ a3("p", { class: "g-notice", role: "alert", children: creditError })
              ] }),
              /* @__PURE__ */ a3(DeadlineTracker, { snapshot, preview }),
              /* @__PURE__ */ a3(MaterialAccess, { courses }),
              allIssues.length > 0 && /* @__PURE__ */ a3("details", { class: "g-issue-details", children: [
                /* @__PURE__ */ a3("summary", { children: [
                  "Sync issues \xB7 ",
                  allIssues.length,
                  " need attention"
                ] }),
                /* @__PURE__ */ a3("ul", { children: allIssues.map((issue, i3) => /* @__PURE__ */ a3("li", { children: [
                  /* @__PURE__ */ a3("strong", { children: [
                    courses.find((c3) => c3.id === issue.courseId)?.code ?? "Canvas",
                    " \xB7 ",
                    issue.section,
                    ":"
                  ] }),
                  " ",
                  issue.message
                ] }, i3)) })
              ] }),
              /* @__PURE__ */ a3("p", { class: "g-small", children: "GRADIENT respects your existing Canvas permissions. Unpublished, locked, and instructor-only materials remain unavailable. Course contents stay in memory for this tab. Preferences and enabled reminder metadata are saved locally. Completed AI jobs expire from local service memory after 30 minutes." })
            ] })
          ] }),
          assistantSnapshot.current && (assistantOpened || tab === "assistant") && /* @__PURE__ */ a3("div", { hidden: tab !== "assistant" || !snapshot, children: /* @__PURE__ */ a3(AssistantView, { snapshot: assistantSnapshot.current, preview, initialCourseId: selectedCourseId || initialCourseId, initialAssignmentId }, `${assistantSnapshot.current.origin}|${assistantSnapshot.current.user.id}`) }, "local-assistant")
        ] }),
        /* @__PURE__ */ a3("footer", { class: "g-footer", children: [
          /* @__PURE__ */ a3("span", { children: [
            /* @__PURE__ */ a3(Icon, { name: "shield", size: 11 }),
            preview ? "Preview environment" : "Read-only \xB7 In your Canvas tab"
          ] }),
          /* @__PURE__ */ a3("span", { children: [
            snapshot?.user.shortName || "Made for your next step",
            /* @__PURE__ */ a3("span", { class: "g-user", children: snapshot ? initials(snapshot.user.name) : "G" })
          ] })
        ] })
      ] })
    ] });
  }

  // extension/ui/CanvasApp.tsx
  function CanvasApp({ initialUrl }) {
    const [snapshot, setSnapshot] = d2(null);
    const [loading, setLoading] = d2(true);
    const [error, setError] = d2(null);
    const [progress, setProgress] = d2("Connecting to your Canvas account\u2026");
    const activeRequest = T2(null);
    const courseId = new URL(initialUrl).pathname.match(/^\/courses\/(\d+)/)?.[1];
    const assignmentId = new URL(initialUrl).pathname.match(/^\/courses\/\d+\/assignments\/(\d+)/)?.[1];
    const refresh = b(() => {
      activeRequest.current?.abort();
      const controller = new AbortController();
      activeRequest.current = controller;
      setLoading(true);
      setSnapshot(null);
      setError(null);
      loadCanvasSnapshot({ courseId, signal: controller.signal, onProgress: (message2) => {
        if (!controller.signal.aborted) setProgress(message2);
      } }).then((result) => {
        if (!controller.signal.aborted) {
          setSnapshot(result);
          void syncTrackedDeadlines(result).catch(() => {
          });
        }
      }).catch((reason) => {
        if (!controller.signal.aborted) {
          setSnapshot(null);
          setError(reason instanceof Error ? reason.message : "Canvas could not be reached. Sign in and try again.");
        }
      }).finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    }, [courseId]);
    A(() => {
      refresh();
      return () => activeRequest.current?.abort();
    }, [refresh]);
    return /* @__PURE__ */ a3(
      Workspace,
      {
        snapshot,
        loading,
        error,
        progress,
        onRefresh: refresh,
        initialCourseId: courseId,
        initialAssignmentId: assignmentId
      }
    );
  }

  // extension/content.ts
  function matchesCanvasHost(hostname, pattern) {
    if (pattern.startsWith("*.")) {
      const suffix = pattern.slice(2).toLowerCase();
      return hostname === suffix || hostname.endsWith(`.${suffix}`);
    }
    return hostname === pattern.toLowerCase();
  }
  async function initPanel() {
    if (window.top !== window.self) return { injected: false, reason: "Top-level Canvas pages only" };
    if (!shouldRunOnPage(window.location.href, document)) {
      return { injected: false, reason: "Assessment page or unsupported Canvas view" };
    }
    const options = await loadOptions();
    if (!options.canvasHosts.some((host2) => matchesCanvasHost(window.location.hostname, host2))) {
      return { injected: false, reason: "This host is not configured as Canvas" };
    }
    if (!shouldRunOnPage(window.location.href, document)) return { injected: false, reason: "Canvas navigated to an assessment" };
    if (document.getElementById("gradient-panel-host")) return { injected: true, reason: "Already mounted" };
    const host = document.createElement("div");
    host.id = "gradient-panel-host";
    host.style.cssText = "all:initial;position:fixed;inset:0 0 auto auto;width:0;height:0;z-index:2147483646;";
    const shadow = host.attachShadow({ mode: "open" });
    document.body.appendChild(host);
    K(k(CanvasApp, { initialUrl: window.location.href }), shadow);
    return { injected: true, reason: "Connected Canvas workspace mounted" };
  }
  var lastUrl = "";
  var mounting = false;
  async function reconcilePage() {
    if (mounting) return;
    const host = document.getElementById("gradient-panel-host");
    if (!shouldRunOnPage(window.location.href, document)) {
      if (host?.shadowRoot) K(null, host.shadowRoot);
      host?.remove();
      lastUrl = "";
      return;
    }
    if (host && lastUrl === window.location.href) return;
    if (host?.shadowRoot) {
      K(k(CanvasApp, { initialUrl: window.location.href }), host.shadowRoot);
      lastUrl = window.location.href;
      return;
    }
    mounting = true;
    try {
      const result = await initPanel();
      if (result.injected) lastUrl = window.location.href;
    } finally {
      mounting = false;
    }
  }
  if (typeof window !== "undefined" && typeof document !== "undefined") {
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", () => void reconcilePage(), { once: true });
    else void reconcilePage();
    window.setInterval(() => void reconcilePage(), 1e3);
    window.addEventListener("popstate", () => void reconcilePage());
    if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
      chrome.runtime.onMessage.addListener((message2) => {
        if (message2?.type === "GRADIENT_TOGGLE") window.dispatchEvent(new Event("gradient:toggle"));
      });
    }
  }
})();
